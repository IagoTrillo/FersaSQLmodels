--Procedure que detecta qué sources cargar

DROP PROCEDURE IF EXISTS fersaSS.sp_Load_Movement_Sources(VARCHAR, VARCHAR);

CREATE OR REPLACE PROCEDURE fersaSS.sp_Load_Movement_Sources(
    IN p_scenario VARCHAR,
    IN p_calctype VARCHAR
)
LANGUAGE PLvSQL
AS $$
DECLARE
    v_i INT;
    v_total INT;

    v_scenario VARCHAR;
    v_source_role VARCHAR;
    v_source_code VARCHAR;
    v_source_type VARCHAR;
BEGIN

    PERFORM DROP TABLE IF EXISTS tmp_movement_sources_to_load;

    PERFORM CREATE LOCAL TEMP TABLE tmp_movement_sources_to_load
    (
        RN INT,
        SCENARIO VARCHAR(100),
        SOURCE_ROLE VARCHAR(20),
        SOURCE_CODE VARCHAR(100),
        SOURCE_TYPE VARCHAR(100)
    )
    ON COMMIT PRESERVE ROWS;

    PERFORM INSERT INTO tmp_movement_sources_to_load
    SELECT
        ROW_NUMBER() OVER
        (
            ORDER BY
                SCENARIO,
                SOURCE_ROLE,
                PRIORITY,
                SOURCE_CODE
        ) AS RN,
        SCENARIO,
        SOURCE_ROLE,
        SOURCE_CODE,
        SOURCE_TYPE
    FROM
    (
        SELECT DISTINCT
            cfg.SCENARIO,
            src.SOURCE_ROLE,
            src.SOURCE_CODE,
            src.SOURCE_TYPE,
            src.PRIORITY
        FROM fersaSS.Config_MovementCalcType cfg
        INNER JOIN fersaSS.Config_MovementSource src
            ON src.SOURCE_CODE = cfg.SUPPLY_SOURCE
           AND src.SOURCE_ROLE = 'SUPPLY'
           AND src.ENABLED = true
        WHERE cfg.ENABLED = true
          AND (p_scenario IS NULL OR cfg.SCENARIO = p_scenario)
          AND (p_calctype IS NULL OR cfg.CALCTYPE = p_calctype)

        UNION

        SELECT DISTINCT
            cfg.SCENARIO,
            src.SOURCE_ROLE,
            src.SOURCE_CODE,
            src.SOURCE_TYPE,
            src.PRIORITY
        FROM fersaSS.Config_MovementCalcType cfg
        INNER JOIN fersaSS.Config_MovementSource src
            ON src.SOURCE_CODE = cfg.DEMAND_SOURCE
           AND src.SOURCE_ROLE = 'DEMAND'
           AND src.ENABLED = true
        WHERE cfg.ENABLED = true
          AND (p_scenario IS NULL OR cfg.SCENARIO = p_scenario)
          AND (p_calctype IS NULL OR cfg.CALCTYPE = p_calctype)
    ) x;

    SELECT COUNT(*)
    INTO v_total
    FROM tmp_movement_sources_to_load;

    v_i := 1;

    WHILE v_i <= v_total LOOP

        SELECT
            SCENARIO,
            SOURCE_ROLE,
            SOURCE_CODE,
            SOURCE_TYPE
        INTO
            v_scenario,
            v_source_role,
            v_source_code,
            v_source_type
        FROM tmp_movement_sources_to_load
        WHERE RN = v_i;

        PERFORM CALL fersaSS.sp_Load_Movement_Source(
            v_scenario,
            v_source_role,
            v_source_code,
            v_source_type
        );

        v_i := v_i + 1;

    END LOOP;

END;
$$;