--Procedure único de carga de sources
--Este es el sitio donde se añaden nuevos sources.
--La firma ahora incluye p_scenario, para que no quede atado a OBSOLETE.

DROP PROCEDURE IF EXISTS fersaSS.sp_Load_Movement_Source(VARCHAR, VARCHAR, VARCHAR, VARCHAR);

CREATE OR REPLACE PROCEDURE fersaSS.sp_Load_Movement_Source(
    IN p_scenario VARCHAR,
    IN p_source_role VARCHAR,
    IN p_source_code VARCHAR,
    IN p_source_type VARCHAR
)
LANGUAGE PLvSQL
AS $$
BEGIN

    /*
        ============================================================
        SOURCE TYPE: OBSOLETE_MAXSTOCK
        ROLE       : SUPPLY

        Qué carga:
            Movement_Supply

        Cuándo se usa:
            Cuando Config_MovementSource tenga:
                SOURCE_ROLE = 'SUPPLY'
                SOURCE_TYPE = 'OBSOLETE_MAXSTOCK'

        Cómo añadir otro supply:
            Copia este bloque y cambia:
                p_source_type
                SQL interno
        ============================================================
    */

    IF p_source_role = 'SUPPLY'
    AND p_source_type = 'OBSOLETE_MAXSTOCK'
    THEN

        PERFORM DELETE FROM fersaSS.Movement_Supply
        WHERE SCENARIO = p_scenario
        AND SUPPLY_SOURCE = p_source_code;

        PERFORM INSERT INTO fersaSS.Movement_Supply
        (
            SCENARIO,
            SUPPLY_SOURCE,
            FLAG,
            GROUPITEM,
            SUBSIDIARYID,
            INVENTLOCATIONID,
            ITEMIDFROM,
            QTY
        )

        WITH
        PARAMS AS
        (
            SELECT
                'INVENTSUM' AS STOCK_SOURCE
        ),

        EXCLUDED_LOCATIONS AS
        (
            SELECT
                NULL::varchar(20) AS SUBSIDIARYID,
                NULL::varchar(80) AS INVENTLOCATIONID
            WHERE 1 = 0
        ),

        CURRENT_STOCK_RAW AS
        (
            SELECT
                inv.SUBSIDIARYID,
                inv.INVENTLOCATIONID,
                inv.ITEMID,
                SUM(inv.PHYSICALINVENT) AS PHYSICALINVENT
            FROM fersadv.InventSum_ALL inv
            WHERE inv.PHYSICALINVENT > 0
            GROUP BY
                inv.SUBSIDIARYID,
                inv.INVENTLOCATIONID,
                inv.ITEMID
            HAVING SUM(inv.PHYSICALINVENT) > 0
        ),

        CURRENT_STOCK_NORM AS
        (
            SELECT
                COALESCE(wlea.SUBSIDIARYID_TO, csr.SUBSIDIARYID) AS SUBSIDIARYID,
                COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID) AS INVENTLOCATIONID,
                csr.ITEMID,
                SUM(csr.PHYSICALINVENT) AS PHYSICALINVENT
            FROM CURRENT_STOCK_RAW csr
            CROSS JOIN PARAMS p
            LEFT JOIN fersaSS.WarehouseLocationEquivalences_ALL wlea
                ON wlea.MODEL = p.STOCK_SOURCE
            AND wlea.SUBSIDIARYID_FROM = csr.SUBSIDIARYID
            AND wlea.INVENTLOCATIONID_FROM <=> csr.INVENTLOCATIONID
            LEFT JOIN EXCLUDED_LOCATIONS ex
                ON ex.SUBSIDIARYID = COALESCE(wlea.SUBSIDIARYID_TO, csr.SUBSIDIARYID)
            AND ex.INVENTLOCATIONID <=> COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID)
            WHERE ex.SUBSIDIARYID IS NULL
            AND COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID) IS NOT NULL
            AND TRIM(COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID)) <> ''
            GROUP BY
                COALESCE(wlea.SUBSIDIARYID_TO, csr.SUBSIDIARYID),
                COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID),
                csr.ITEMID
            HAVING SUM(csr.PHYSICALINVENT) > 0
        ),

        OBSOLETE_CANDIDATES AS
        (
            SELECT
                CASE
                    WHEN oi.FLAG LIKE 'DAILY%' THEN 'DAILY'
                    ELSE oi.FLAG
                END AS FLAG,

                oi.SUBSIDIARYID,
                oi.INVENTLOCATIONID,
                oi.ITEMID,

                COALESCE(map.GROUPITEM, hash(oi.ITEMID)::varchar(200)) AS GROUPITEM,

                FLOOR(SUM(oi.OBSOLETEQTY)) AS OBSOLETEQTY

            FROM fersaSS.ObsoleteItems_ALL oi

            LEFT JOIN
            (
                SELECT
                    ITEMIDFROM,
                    MIN(GROUPITEM)::varchar(200) AS GROUPITEM
                FROM fersaSS.vw_Movement_ItemMapping
                GROUP BY
                    ITEMIDFROM
            ) map
                ON hash(map.ITEMIDFROM) = hash(oi.ITEMID)

            WHERE oi.INVENTLOCATIONID IS NOT NULL
            AND TRIM(oi.INVENTLOCATIONID) <> ''
            AND oi.OBSOLETEQTY > 0

            GROUP BY
                CASE
                    WHEN oi.FLAG LIKE 'DAILY%' THEN 'DAILY'
                    ELSE oi.FLAG
                END,
                oi.SUBSIDIARYID,
                oi.INVENTLOCATIONID,
                oi.ITEMID,
                COALESCE(map.GROUPITEM, hash(oi.ITEMID)::varchar(200))

            HAVING FLOOR(SUM(oi.OBSOLETEQTY)) > 0
        ),

        SUPPLY_RAW_PRE AS
        (
            SELECT
                oc.FLAG,
                oc.GROUPITEM,
                oc.SUBSIDIARYID,
                oc.INVENTLOCATIONID,
                oc.ITEMID AS ITEMIDFROM,

                FLOOR(LEAST(cs.PHYSICALINVENT, oc.OBSOLETEQTY)) AS QTY,

                cs.PHYSICALINVENT

            FROM OBSOLETE_CANDIDATES oc

            INNER JOIN CURRENT_STOCK_NORM cs
                ON cs.SUBSIDIARYID = oc.SUBSIDIARYID
            AND cs.INVENTLOCATIONID = oc.INVENTLOCATIONID
            AND cs.ITEMID = oc.ITEMID

            WHERE FLOOR(LEAST(cs.PHYSICALINVENT, oc.OBSOLETEQTY)) > 0
        ),

        SUPPLY_RAW_CAPPED AS
        (
            SELECT
                FLAG,
                GROUPITEM,
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMIDFROM,

                FLOOR
                (
                    LEAST(QTY_END, PHYSICALINVENT) - QTY_START
                ) AS QTY

            FROM
            (
                SELECT
                    srp.*,

                    SUM(srp.QTY) OVER
                    (
                        PARTITION BY
                            srp.SUBSIDIARYID,
                            srp.INVENTLOCATIONID,
                            srp.ITEMIDFROM
                        ORDER BY
                            srp.QTY DESC,
                            srp.FLAG,
                            srp.GROUPITEM
                    ) - srp.QTY AS QTY_START,

                    SUM(srp.QTY) OVER
                    (
                        PARTITION BY
                            srp.SUBSIDIARYID,
                            srp.INVENTLOCATIONID,
                            srp.ITEMIDFROM
                        ORDER BY
                            srp.QTY DESC,
                            srp.FLAG,
                            srp.GROUPITEM
                    ) AS QTY_END

                FROM SUPPLY_RAW_PRE srp
            ) x

            WHERE LEAST(QTY_END, PHYSICALINVENT) > QTY_START
        )

        SELECT
            p_scenario AS SCENARIO,
            p_source_code AS SUPPLY_SOURCE,
            FLAG,
            GROUPITEM,
            SUBSIDIARYID,
            INVENTLOCATIONID,
            ITEMIDFROM,
            QTY
        FROM SUPPLY_RAW_CAPPED
        WHERE QTY > 0;

    /*
        ============================================================
        SOURCE TYPE: CONSUMPTION_2Y_MAXSTOCK
        ROLE       : DEMAND
        ============================================================
    */

    ELSIF p_source_role = 'DEMAND'
        AND p_source_type = 'CONSUMPTION_2Y_MAXSTOCK'
    THEN

        PERFORM DELETE FROM fersaSS.Movement_Demand
        WHERE SCENARIO = p_scenario
        AND DEMAND_SOURCE = p_source_code;

        PERFORM INSERT INTO fersaSS.Movement_Demand
        (
            SCENARIO,
            DEMAND_SOURCE,
            FLAG,
            GROUPITEM,
            SUBSIDIARYID,
            INVENTLOCATIONID,
            ITEMIDFROM,
            ITEMIDTO,
            QTY,
            FLAGITEM,
            PRIORITY
        )

        WITH
        PARAMS AS
        (
            SELECT
                CURRENT_DATE() AS CLOSINGDATE,
                'INVENTSUM' AS STOCK_SOURCE,
                'FINANCIAL' AS DATE_MODE
        ),

        EXCLUDED_LOCATIONS AS
        (
            SELECT
                NULL::varchar(20) AS SUBSIDIARYID,
                NULL::varchar(80) AS INVENTLOCATIONID
            WHERE 1 = 0
        ),

        SUBSIDIARY AS
        (
            SELECT DISTINCT
                HASH(UPPER(DATAAREAID)) AS SUBSIDIARY_HASH
            FROM fersads.ds_InventTrans_FER

            UNION ALL

            SELECT DISTINCT
                HASH(UPPER(DATAAREAID)) AS SUBSIDIARY_HASH
            FROM fersads.ds_InventTrans_CHN_HIST
        ),

        CURRENT_STOCK_RAW AS
        (
            SELECT
                inv.SUBSIDIARYID,
                inv.INVENTLOCATIONID,
                inv.ITEMID,
                SUM(inv.PHYSICALINVENT) AS PHYSICALINVENT
            FROM fersadv.InventSum_ALL inv
            WHERE inv.PHYSICALINVENT > 0
            GROUP BY
                inv.SUBSIDIARYID,
                inv.INVENTLOCATIONID,
                inv.ITEMID
            HAVING SUM(inv.PHYSICALINVENT) > 0
        ),

        CURRENT_STOCK_NORM AS
        (
            SELECT
                COALESCE(wlea.SUBSIDIARYID_TO, csr.SUBSIDIARYID) AS SUBSIDIARYID,
                COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID) AS INVENTLOCATIONID,
                csr.ITEMID,
                SUM(csr.PHYSICALINVENT) AS PHYSICALINVENT
            FROM CURRENT_STOCK_RAW csr
            CROSS JOIN PARAMS p
            LEFT JOIN fersaSS.WarehouseLocationEquivalences_ALL wlea
                ON wlea.MODEL = p.STOCK_SOURCE
            AND wlea.SUBSIDIARYID_FROM = csr.SUBSIDIARYID
            AND wlea.INVENTLOCATIONID_FROM <=> csr.INVENTLOCATIONID
            LEFT JOIN EXCLUDED_LOCATIONS ex
                ON ex.SUBSIDIARYID = COALESCE(wlea.SUBSIDIARYID_TO, csr.SUBSIDIARYID)
            AND ex.INVENTLOCATIONID <=> COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID)
            WHERE ex.SUBSIDIARYID IS NULL
            AND COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID) IS NOT NULL
            AND TRIM(COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID)) <> ''
            GROUP BY
                COALESCE(wlea.SUBSIDIARYID_TO, csr.SUBSIDIARYID),
                COALESCE(wlea.INVENTLOCATIONID_TO, csr.INVENTLOCATIONID),
                csr.ITEMID
            HAVING SUM(csr.PHYSICALINVENT) > 0
        ),

        NOFER_SalesBase AS
        (
            SELECT
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMID,
                0 AS REFERENCECATEGORY,
                SALESID AS REFERENCEID,
                1 AS STATUSISSUE,
                0 AS STATUSRECEIPT,
                INVOICEDATE AS DATEPHYSICAL,
                INVOICEDATE AS DATEFINANCIAL,
                -INVOICEQTY AS QTY
            FROM fersadv.SalesInvoices_ALL
            WHERE HASH(SUBSIDIARYID) NOT IN
            (
                SELECT SUBSIDIARY_HASH
                FROM SUBSIDIARY
            )
        ),

        NOFER_PurchaseBase_sinPFI AS
        (
            SELECT
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMID,
                3 AS REFERENCECATEGORY,
                PURCHASEID AS REFERENCEID,
                0 AS STATUSISSUE,
                1 AS STATUSRECEIPT,
                INVOICEDATE + 60 AS DATEPHYSICAL,
                INVOICEDATE + 60 AS DATEFINANCIAL,
                INVOICEQTY AS QTY
            FROM fersadv.PurchaseInvoices_ALL
            CROSS JOIN PARAMS p
            WHERE HASH(SUBSIDIARYID) NOT IN
            (
                SELECT SUBSIDIARY_HASH
                FROM SUBSIDIARY
            )
            AND INVOICEDATE + 60 <= p.CLOSINGDATE
        ),

        NOFER_PurchaseBase_PFI AS
        (
            SELECT
                cvics.TODATAAREAID AS SUBSIDIARYID,
                NULL AS INVENTLOCATIONID,
                sia.ITEMID,
                3 AS REFERENCECATEGORY,
                sia.SALESID AS REFERENCEID,
                0 AS STATUSISSUE,
                1 AS STATUSRECEIPT,
                sia.INVOICEDATE + 60 AS DATEPHYSICAL,
                sia.INVOICEDATE + 60 AS DATEFINANCIAL,
                sia.INVOICEQTY AS QTY
            FROM fersadv.SalesInvoices_ALL sia
            LEFT JOIN fersaParamsPublic.CustomerVendorInterCo_standalone cvics
                ON sia.CUSTOMERID = cvics.CUSTVENDACCOUNT
            AND sia.SUBSIDIARYID = cvics.FROMDATAAREAID
            AND cvics."DEFAULT" IS TRUE
            CROSS JOIN PARAMS p
            WHERE HASH(cvics.TODATAAREAID) NOT IN
            (
                SELECT SUBSIDIARY_HASH
                FROM SUBSIDIARY
            )
            AND sia.INVOICEDATE + 60 <= p.CLOSINGDATE
            GROUP BY
                cvics.TODATAAREAID,
                sia.ITEMID,
                sia.SALESID,
                sia.INVOICEDATE,
                sia.INVOICEQTY
        ),

        FER_TransactionsBase AS
        (
            SELECT
                UPPER(it.DATAAREAID) AS SUBSIDIARYID,
                id.INVENTLOCATIONID,
                it.ITEMID,
                io.REFERENCECATEGORY,
                io.REFERENCEID,
                it.STATUSISSUE,
                it.STATUSRECEIPT,
                it.DATEPHYSICAL,
                it.DATEFINANCIAL,
                SUM(it.QTY) AS QTY
            FROM fersads.ds_InventTransOrigin_FER io
            INNER JOIN fersads.ds_InventTrans_FER it
                ON io.RECID = it.INVENTTRANSORIGIN
            AND io.DATAAREAID = it.DATAAREAID
            INNER JOIN fersads.ds_InventDim_FER id
                ON it.INVENTDIMID = id.INVENTDIMID
            AND it.DATAAREAID = id.DATAAREAID
            WHERE HASH(UPPER(it.DATAAREAID)) IN
            (
                SELECT SUBSIDIARY_HASH
                FROM SUBSIDIARY
            )
            AND (it.STATUSISSUE = 1 OR it.STATUSISSUE = 0 OR it.STATUSISSUE IS NULL)
            AND (it.STATUSRECEIPT < 2 OR it.STATUSRECEIPT IS NULL)
            GROUP BY
                UPPER(it.DATAAREAID),
                id.INVENTLOCATIONID,
                it.ITEMID,
                io.REFERENCECATEGORY,
                io.REFERENCEID,
                it.STATUSISSUE,
                it.STATUSRECEIPT,
                it.DATEPHYSICAL,
                it.DATEFINANCIAL

            UNION ALL

            SELECT
                UPPER(it.DATAAREAID) AS SUBSIDIARYID,
                id.INVENTLOCATIONID,
                it.ITEMID,
                io.REFERENCECATEGORY,
                io.REFERENCEID,
                it.STATUSISSUE,
                it.STATUSRECEIPT,
                it.DATEPHYSICAL,
                it.DATEFINANCIAL,
                SUM(it.QTY) AS QTY
            FROM fersads.ds_InventTransOrigin_CHN_HIST io
            INNER JOIN fersads.ds_InventTrans_CHN_HIST it
                ON io.RECID = it.INVENTTRANSORIGIN
            AND io.DATAAREAID = it.DATAAREAID
            INNER JOIN fersads.ds_InventDim_CHN_HIST id
                ON it.INVENTDIMID = id.INVENTDIMID
            AND it.DATAAREAID = id.DATAAREAID
            WHERE HASH(UPPER(it.DATAAREAID)) IN
            (
                SELECT SUBSIDIARY_HASH
                FROM SUBSIDIARY
            )
            AND (it.STATUSISSUE = 1 OR it.STATUSISSUE = 0 OR it.STATUSISSUE IS NULL)
            AND (it.STATUSRECEIPT < 2 OR it.STATUSRECEIPT IS NULL)
            GROUP BY
                UPPER(it.DATAAREAID),
                id.INVENTLOCATIONID,
                it.ITEMID,
                io.REFERENCECATEGORY,
                io.REFERENCEID,
                it.STATUSISSUE,
                it.STATUSRECEIPT,
                it.DATEPHYSICAL,
                it.DATEFINANCIAL
        ),

        ALL_TransactionsBase AS
        (
            SELECT * FROM NOFER_SalesBase
            UNION ALL
            SELECT * FROM NOFER_PurchaseBase_sinPFI
            UNION ALL
            SELECT * FROM NOFER_PurchaseBase_PFI
            UNION ALL
            SELECT * FROM FER_TransactionsBase
        ),

        TransactionsBase_norm AS
        (
            SELECT
                COALESCE(wlea.SUBSIDIARYID_TO, t.SUBSIDIARYID) AS SUBSIDIARYID,
                COALESCE(wlea.INVENTLOCATIONID_TO, t.INVENTLOCATIONID) AS INVENTLOCATIONID,
                t.ITEMID,
                t.REFERENCECATEGORY,
                t.REFERENCEID,
                t.STATUSISSUE,
                t.STATUSRECEIPT,
                CASE
                    WHEN p.DATE_MODE = 'FINANCIAL' THEN t.DATEFINANCIAL
                    ELSE t.DATEPHYSICAL
                END AS TRANSDATE,
                t.DATEPHYSICAL,
                t.DATEFINANCIAL,
                t.QTY
            FROM ALL_TransactionsBase t
            CROSS JOIN PARAMS p
            LEFT JOIN fersaSS.WarehouseLocationEquivalences_ALL wlea
                ON wlea.MODEL = p.STOCK_SOURCE
            AND wlea.SUBSIDIARYID_FROM = t.SUBSIDIARYID
            AND wlea.INVENTLOCATIONID_FROM <=> t.INVENTLOCATIONID
            LEFT JOIN EXCLUDED_LOCATIONS ex
                ON ex.SUBSIDIARYID = COALESCE(wlea.SUBSIDIARYID_TO, t.SUBSIDIARYID)
            AND ex.INVENTLOCATIONID <=> COALESCE(wlea.INVENTLOCATIONID_TO, t.INVENTLOCATIONID)
            WHERE ex.SUBSIDIARYID IS NULL
            AND COALESCE(wlea.INVENTLOCATIONID_TO, t.INVENTLOCATIONID) IS NOT NULL
            AND TRIM(COALESCE(wlea.INVENTLOCATIONID_TO, t.INVENTLOCATIONID)) <> ''
        ),

        Transactions2Y AS
        (
            SELECT
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMID,
                REFERENCECATEGORY,
                REFERENCEID,
                STATUSISSUE,
                STATUSRECEIPT,
                TRANSDATE,
                DATEPHYSICAL,
                DATEFINANCIAL,
                SUM(QTY) AS QTY
            FROM TransactionsBase_norm
            CROSS JOIN PARAMS p
            WHERE REFERENCECATEGORY IN (8, 2, 0, 3, 22, 21)
            AND TRANSDATE >= p.CLOSINGDATE - (365 * 2)
            AND TRANSDATE <= p.CLOSINGDATE
            GROUP BY
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMID,
                REFERENCECATEGORY,
                REFERENCEID,
                STATUSISSUE,
                STATUSRECEIPT,
                TRANSDATE,
                DATEPHYSICAL,
                DATEFINANCIAL
        ),

        OPWithNORW AS
        (
            SELECT
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMID,
                SUM(QTY) AS QTY
            FROM
            (
                SELECT
                    SUBSIDIARYID,
                    INVENTLOCATIONID,
                    ITEMID,
                    REFERENCEID,
                    SUM(QTY) AS QTY
                FROM Transactions2Y
                CROSS JOIN PARAMS p
                WHERE (STATUSISSUE = 1 OR STATUSRECEIPT = 1)
                AND (REFERENCECATEGORY = 8 OR REFERENCECATEGORY = 2)
                AND TRANSDATE >= p.CLOSINGDATE - (365 * 2)
                GROUP BY
                    SUBSIDIARYID,
                    INVENTLOCATIONID,
                    ITEMID,
                    REFERENCEID
                HAVING SUM(QTY) < 0
            ) a
            GROUP BY
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMID
            HAVING SUM(QTY) < 0
        ),

        LAST2YEARS AS
        (
            SELECT
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMID,
                SUM(CONSUMQTY) AS CONSUMQTY
            FROM
            (
                SELECT
                    SUBSIDIARYID,
                    INVENTLOCATIONID,
                    ITEMID,
                    -QTY AS CONSUMQTY
                FROM OPWithNORW

                UNION ALL

                SELECT
                    SUBSIDIARYID,
                    INVENTLOCATIONID,
                    ITEMID,
                    -SUM(QTY) AS CONSUMQTY
                FROM Transactions2Y
                CROSS JOIN PARAMS p
                WHERE (REFERENCECATEGORY = 0 OR REFERENCECATEGORY = 21)
                AND TRANSDATE >= p.CLOSINGDATE - (365 * 2)
                GROUP BY
                    SUBSIDIARYID,
                    INVENTLOCATIONID,
                    ITEMID
                HAVING SUM(QTY) < 0
            ) a
            GROUP BY
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMID
        ),

        DEMAND_RAW AS
        (
            SELECT
                ly.SUBSIDIARYID,
                ly.INVENTLOCATIONID,
                ly.ITEMID AS ITEMIDTO,
                FLOOR(ly.CONSUMQTY - COALESCE(cs.PHYSICALINVENT, 0)) AS QTY
            FROM LAST2YEARS ly
            LEFT JOIN CURRENT_STOCK_NORM cs
                ON cs.SUBSIDIARYID = ly.SUBSIDIARYID
            AND cs.INVENTLOCATIONID = ly.INVENTLOCATIONID
            AND cs.ITEMID = ly.ITEMID
            WHERE FLOOR(ly.CONSUMQTY - COALESCE(cs.PHYSICALINVENT, 0)) > 0
        )

        SELECT
            p_scenario AS SCENARIO,
            p_source_code AS DEMAND_SOURCE,
            'DAILY' AS FLAG,
            map.GROUPITEM,
            dr.SUBSIDIARYID,
            dr.INVENTLOCATIONID,
            map.ITEMIDFROM,
            dr.ITEMIDTO::varchar(50) AS ITEMIDTO,
            dr.QTY,
            map.FLAGITEM,
            map.PRIORITY
        FROM DEMAND_RAW dr
        INNER JOIN fersaSS.vw_Movement_ItemMapping map
            ON hash(map.ITEMIDTO) = hash(dr.ITEMIDTO)
        WHERE dr.QTY > 0;

    /*
        ============================================================
        NUEVO SOURCE

        Para añadir otro source:
            1. Insertar en Config_MovementSource.
            2. Añadir un ELSIF aquí.

        Ejemplo:

        ELSIF p_source_role = 'SUPPLY'
              AND p_source_type = 'STOCK'
        THEN
            DELETE FROM Movement_Supply...
            INSERT INTO Movement_Supply...

        ELSIF p_source_role = 'DEMAND'
              AND p_source_type = 'FORECAST'
        THEN
            DELETE FROM Movement_Demand...
            INSERT INTO Movement_Demand...
        ============================================================
    */

    ELSE

        RAISE EXCEPTION 'Movement source not implemented. SCENARIO %, ROLE %, CODE %, TYPE %',
            p_scenario,
            p_source_role,
            p_source_code,
            p_source_type;

    END IF;

END;
$$;