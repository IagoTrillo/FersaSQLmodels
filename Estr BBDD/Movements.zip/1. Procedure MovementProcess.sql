DROP PROCEDURE IF EXISTS fersaSS.sp_Run_Movement_Process(VARCHAR, VARCHAR);

CREATE OR REPLACE PROCEDURE fersaSS.sp_Run_Movement_Process(
    IN p_scenario VARCHAR,
    IN p_calctype VARCHAR
)
LANGUAGE PLvSQL
AS $$
BEGIN

    PERFORM CALL fersaSS.sp_Load_Movement_Sources(p_scenario, p_calctype);

    PERFORM CALL fersaSS.sp_Run_Movement_All(p_scenario, p_calctype);

END;
$$;

/*
Uso genérico:
CALL fersaSS.sp_Run_Movement_Process(NULL, NULL);

O solo uno:
CALL fersaSS.sp_Run_Movement_Process('OBSOLETE', 'MAXSTOCK');
*/