--Procedure que ejecuta todos los calctypes activos
--Este asume que ya tienes creado sp_Movement_Proportional3Levels.

DROP PROCEDURE IF EXISTS fersaSS.sp_Run_Movement_All(VARCHAR, VARCHAR);

CREATE OR REPLACE PROCEDURE fersaSS.sp_Run_Movement_All(
    IN p_scenario VARCHAR,
    IN p_calctype VARCHAR
)
LANGUAGE PLvSQL
AS $$
DECLARE
    v_i INT;
    v_total INT;

    v_scenario VARCHAR;
    v_calctype VARCHAR;
BEGIN

    PERFORM DROP TABLE IF EXISTS tmp_movement_run_cfg;

    PERFORM CREATE LOCAL TEMP TABLE tmp_movement_run_cfg
    (
        RN INT,
        SCENARIO VARCHAR(100),
        CALCTYPE VARCHAR(100)
    )
    ON COMMIT PRESERVE ROWS;

    PERFORM INSERT INTO tmp_movement_run_cfg
    SELECT
        ROW_NUMBER() OVER
        (
            ORDER BY
                SCENARIO,
                PRIORITY,
                CALCTYPE
        ) AS RN,
        SCENARIO,
        CALCTYPE
    FROM fersaSS.Config_MovementCalcType
    WHERE ENABLED = true
      AND (p_scenario IS NULL OR SCENARIO = p_scenario)
      AND (p_calctype IS NULL OR CALCTYPE = p_calctype);

    SELECT COUNT(*)
    INTO v_total
    FROM tmp_movement_run_cfg;

    v_i := 1;

    WHILE v_i <= v_total LOOP

        SELECT
            SCENARIO,
            CALCTYPE
        INTO
            v_scenario,
            v_calctype
        FROM tmp_movement_run_cfg
        WHERE RN = v_i;

        PERFORM CALL fersaSS.sp_Movement_Proportional3Levels(v_scenario, v_calctype);

        v_i := v_i + 1;

    END LOOP;

END;
$$;