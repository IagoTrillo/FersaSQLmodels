DROP PROCEDURE IF EXISTS fersaSS.sp_Movement_Proportional3Levels(VARCHAR, VARCHAR);

CREATE OR REPLACE PROCEDURE fersaSS.sp_Movement_Proportional3Levels(
    IN p_scenario VARCHAR,
    IN p_calctype VARCHAR
)
LANGUAGE PLvSQL
AS $$
DECLARE
    v_priority INT;
    v_rows INT;
BEGIN

    /*
        Limpia resultado previo solo para el scenario/calctype ejecutado.
    */

    PERFORM DELETE FROM fersaSS.Movement_ALL
    WHERE SCENARIO = p_scenario
      AND CALCTYPE = p_calctype;

    PERFORM DROP TABLE IF EXISTS tmp_mov_supply;
    PERFORM DROP TABLE IF EXISTS tmp_mov_demand;
    PERFORM DROP TABLE IF EXISTS tmp_mov_alloc;
    PERFORM DROP TABLE IF EXISTS tmp_mov_result;

    /*
        Supply temporal del cálculo.
    */

    PERFORM CREATE LOCAL TEMP TABLE tmp_mov_supply
    (
        SUPPLY_ID INT,
        SCENARIO VARCHAR(100),
        CALCTYPE VARCHAR(100),
        SUPPLY_SOURCE VARCHAR(100),
        DEMAND_SOURCE VARCHAR(100),
        FLAG VARCHAR(100),
        GROUPITEM VARCHAR(200),
        SUBSIDIARYID VARCHAR(20),
        INVENTLOCATIONID VARCHAR(80),
        ITEMIDFROM VARCHAR(50),
        QTY FLOAT
    )
    ON COMMIT PRESERVE ROWS;

    /*
        Demand temporal del cálculo.
    */

    PERFORM CREATE LOCAL TEMP TABLE tmp_mov_demand
    (
        DEMAND_ID INT,
        SCENARIO VARCHAR(100),
        CALCTYPE VARCHAR(100),
        SUPPLY_SOURCE VARCHAR(100),
        DEMAND_SOURCE VARCHAR(100),
        FLAG VARCHAR(100),
        GROUPITEM VARCHAR(200),
        SUBSIDIARYID VARCHAR(20),
        INVENTLOCATIONID VARCHAR(80),
        ITEMIDFROM VARCHAR(50),
        ITEMIDTO VARCHAR(50),
        FLAGITEM VARCHAR(100),
        PRIORITY INT,
        QTY FLOAT
    )
    ON COMMIT PRESERVE ROWS;

    /*
        Alloc temporal de cada fase.
    */

    PERFORM CREATE LOCAL TEMP TABLE tmp_mov_alloc
    (
        SUPPLY_ID INT,
        DEMAND_ID INT,
        QTY FLOAT
    )
    ON COMMIT PRESERVE ROWS;

    /*
        Resultado temporal antes de agrupar.
    */

    PERFORM CREATE LOCAL TEMP TABLE tmp_mov_result
    (
        SCENARIO VARCHAR(100),
        CALCTYPE VARCHAR(100),
        SUPPLY_SOURCE VARCHAR(100),
        DEMAND_SOURCE VARCHAR(100),
        MOVEMENT_LEVEL VARCHAR(50),
        FLAG VARCHAR(100),
        GROUPITEM VARCHAR(200),
        SUBSIDIARYIDFROM VARCHAR(20),
        INVENTLOCATIONIDFROM VARCHAR(80),
        SUBSIDIARYIDTO VARCHAR(20),
        INVENTLOCATIONIDTO VARCHAR(80),
        ITEMIDFROM VARCHAR(50),
        ITEMIDTO VARCHAR(50),
        QTY FLOAT,
        FLAGITEM VARCHAR(100),
        PRIORITY INT
    )
    ON COMMIT PRESERVE ROWS;

    /*
        1. Carga Supply del CALCTYPE configurado.
    */

    PERFORM INSERT INTO tmp_mov_supply
    SELECT
        ROW_NUMBER() OVER
        (
            ORDER BY
                s.FLAG,
                s.GROUPITEM,
                s.ITEMIDFROM,
                s.SUBSIDIARYID,
                s.INVENTLOCATIONID
        ) AS SUPPLY_ID,

        cfg.SCENARIO,
        cfg.CALCTYPE,
        cfg.SUPPLY_SOURCE,
        cfg.DEMAND_SOURCE,

        s.FLAG,
        s.GROUPITEM,
        s.SUBSIDIARYID,
        s.INVENTLOCATIONID,
        s.ITEMIDFROM,

        FLOOR(SUM(s.QTY)) AS QTY

    FROM fersaSS.Config_MovementCalcType cfg
    INNER JOIN fersaSS.Movement_Supply s
        ON s.SCENARIO = cfg.SCENARIO
       AND s.SUPPLY_SOURCE = cfg.SUPPLY_SOURCE
    WHERE cfg.SCENARIO = p_scenario
      AND cfg.CALCTYPE = p_calctype
      AND cfg.ENABLED = true
    GROUP BY
        cfg.SCENARIO,
        cfg.CALCTYPE,
        cfg.SUPPLY_SOURCE,
        cfg.DEMAND_SOURCE,
        s.FLAG,
        s.GROUPITEM,
        s.SUBSIDIARYID,
        s.INVENTLOCATIONID,
        s.ITEMIDFROM
    HAVING FLOOR(SUM(s.QTY)) > 0;

    /*
        2. Carga Demand del CALCTYPE configurado.
    */

    PERFORM INSERT INTO tmp_mov_demand
    SELECT
        ROW_NUMBER() OVER
        (
            ORDER BY
                d.FLAG,
                d.GROUPITEM,
                d.ITEMIDFROM,
                d.SUBSIDIARYID,
                d.INVENTLOCATIONID,
                d.PRIORITY,
                FLOOR(SUM(d.QTY)) DESC,
                d.ITEMIDTO,
                d.FLAGITEM
        ) AS DEMAND_ID,

        cfg.SCENARIO,
        cfg.CALCTYPE,
        cfg.SUPPLY_SOURCE,
        cfg.DEMAND_SOURCE,

        d.FLAG,
        d.GROUPITEM,
        d.SUBSIDIARYID,
        d.INVENTLOCATIONID,
        d.ITEMIDFROM,
        d.ITEMIDTO,
        d.FLAGITEM,
        d.PRIORITY,

        FLOOR(SUM(d.QTY)) AS QTY

    FROM fersaSS.Config_MovementCalcType cfg
    INNER JOIN fersaSS.Movement_Demand d
        ON d.SCENARIO = cfg.SCENARIO
       AND d.DEMAND_SOURCE = cfg.DEMAND_SOURCE
    WHERE cfg.SCENARIO = p_scenario
      AND cfg.CALCTYPE = p_calctype
      AND cfg.ENABLED = true
    GROUP BY
        cfg.SCENARIO,
        cfg.CALCTYPE,
        cfg.SUPPLY_SOURCE,
        cfg.DEMAND_SOURCE,
        d.FLAG,
        d.GROUPITEM,
        d.SUBSIDIARYID,
        d.INVENTLOCATIONID,
        d.ITEMIDFROM,
        d.ITEMIDTO,
        d.FLAGITEM,
        d.PRIORITY
    HAVING FLOOR(SUM(d.QTY)) > 0;

    /*
        3. EXACTO LOCAL SIN MOVIMIENTO.

        Mismo subsidiary.
        Misma inventlocation.
        Mismo item.
        ITEMIDFROM = ITEMIDTO.

        Esto se resta del supply y demand, pero no genera línea en Movement_ALL.
    */

    PERFORM DELETE FROM tmp_mov_alloc;

    PERFORM INSERT INTO tmp_mov_alloc
    WITH
    S_SEQ AS
    (
        SELECT
            s.*,
            SUM(s.QTY) OVER
            (
                PARTITION BY
                    s.FLAG,
                    s.GROUPITEM,
                    s.SUBSIDIARYID,
                    s.INVENTLOCATIONID,
                    s.ITEMIDFROM
                ORDER BY
                    s.SUPPLY_ID
            ) - s.QTY AS QTY_START,
            SUM(s.QTY) OVER
            (
                PARTITION BY
                    s.FLAG,
                    s.GROUPITEM,
                    s.SUBSIDIARYID,
                    s.INVENTLOCATIONID,
                    s.ITEMIDFROM
                ORDER BY
                    s.SUPPLY_ID
            ) AS QTY_END
        FROM tmp_mov_supply s
        WHERE s.QTY > 0
    ),
    D_SEQ AS
    (
        SELECT
            d.*,
            SUM(d.QTY) OVER
            (
                PARTITION BY
                    d.FLAG,
                    d.GROUPITEM,
                    d.SUBSIDIARYID,
                    d.INVENTLOCATIONID,
                    d.ITEMIDFROM
                ORDER BY
                    d.PRIORITY ASC,
                    d.QTY DESC,
                    d.DEMAND_ID
            ) - d.QTY AS QTY_START,
            SUM(d.QTY) OVER
            (
                PARTITION BY
                    d.FLAG,
                    d.GROUPITEM,
                    d.SUBSIDIARYID,
                    d.INVENTLOCATIONID,
                    d.ITEMIDFROM
                ORDER BY
                    d.PRIORITY ASC,
                    d.QTY DESC,
                    d.DEMAND_ID
            ) AS QTY_END
        FROM tmp_mov_demand d
        WHERE d.QTY > 0
          AND d.ITEMIDTO = d.ITEMIDFROM
    )
    SELECT
        s.SUPPLY_ID,
        d.DEMAND_ID,
        FLOOR(LEAST(s.QTY_END, d.QTY_END) - GREATEST(s.QTY_START, d.QTY_START)) AS QTY
    FROM S_SEQ s
    INNER JOIN D_SEQ d
        ON d.FLAG = s.FLAG
       AND d.GROUPITEM = s.GROUPITEM
       AND d.SUBSIDIARYID = s.SUBSIDIARYID
       AND d.INVENTLOCATIONID = s.INVENTLOCATIONID
       AND d.ITEMIDFROM = s.ITEMIDFROM
    WHERE LEAST(s.QTY_END, d.QTY_END) > GREATEST(s.QTY_START, d.QTY_START);

    PERFORM UPDATE tmp_mov_supply s
    SET QTY = s.QTY - x.QTY
    FROM
    (
        SELECT
            SUPPLY_ID,
            SUM(QTY) AS QTY
        FROM tmp_mov_alloc
        WHERE QTY > 0
        GROUP BY SUPPLY_ID
    ) x
    WHERE s.SUPPLY_ID = x.SUPPLY_ID;

    PERFORM UPDATE tmp_mov_demand d
    SET QTY = d.QTY - x.QTY
    FROM
    (
        SELECT
            DEMAND_ID,
            SUM(QTY) AS QTY
        FROM tmp_mov_alloc
        WHERE QTY > 0
        GROUP BY DEMAND_ID
    ) x
    WHERE d.DEMAND_ID = x.DEMAND_ID;

    PERFORM DELETE FROM tmp_mov_supply WHERE QTY <= 0;
    PERFORM DELETE FROM tmp_mov_demand WHERE QTY <= 0;

    /*
        4. LEVEL 1: SAME_LOCATION.

        Mismo subsidiary.
        Misma inventlocation.
        Cambio de item / variante / equivalencia.
    */

    FOR v_priority IN QUERY
        SELECT DISTINCT PRIORITY
        FROM tmp_mov_demand
        WHERE QTY > 0
        ORDER BY PRIORITY
    LOOP

        PERFORM DELETE FROM tmp_mov_alloc;

        PERFORM INSERT INTO tmp_mov_alloc
        WITH
        S_GROUP AS
        (
            SELECT
                FLAG,
                GROUPITEM,
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMIDFROM,
                SUM(QTY) AS TOTAL_SUPPLY_QTY
            FROM tmp_mov_supply
            WHERE QTY > 0
            GROUP BY
                FLAG,
                GROUPITEM,
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMIDFROM
        ),
        D_GROUP AS
        (
            SELECT
                FLAG,
                GROUPITEM,
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMIDFROM,
                SUM(QTY) AS TOTAL_DEMAND_QTY
            FROM tmp_mov_demand
            WHERE QTY > 0
              AND PRIORITY = v_priority
            GROUP BY
                FLAG,
                GROUPITEM,
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMIDFROM
        ),
        D_TARGET_BASE AS
        (
            SELECT
                d.DEMAND_ID,
                d.FLAG,
                d.GROUPITEM,
                d.SUBSIDIARYID,
                d.INVENTLOCATIONID,
                d.ITEMIDFROM,
                d.QTY AS DEMAND_QTY,
                LEAST(sg.TOTAL_SUPPLY_QTY, dg.TOTAL_DEMAND_QTY) AS TOTAL_TO_ALLOC,
                dg.TOTAL_DEMAND_QTY,
                FLOOR
                (
                    LEAST(sg.TOTAL_SUPPLY_QTY, dg.TOTAL_DEMAND_QTY)
                    * d.QTY
                    / NULLIF(dg.TOTAL_DEMAND_QTY, 0)
                ) AS QTY_BASE
            FROM tmp_mov_demand d
            INNER JOIN D_GROUP dg
                ON dg.FLAG = d.FLAG
               AND dg.GROUPITEM = d.GROUPITEM
               AND dg.SUBSIDIARYID = d.SUBSIDIARYID
               AND dg.INVENTLOCATIONID = d.INVENTLOCATIONID
               AND dg.ITEMIDFROM = d.ITEMIDFROM
            INNER JOIN S_GROUP sg
                ON sg.FLAG = d.FLAG
               AND sg.GROUPITEM = d.GROUPITEM
               AND sg.SUBSIDIARYID = d.SUBSIDIARYID
               AND sg.INVENTLOCATIONID = d.INVENTLOCATIONID
               AND sg.ITEMIDFROM = d.ITEMIDFROM
            WHERE d.QTY > 0
              AND d.PRIORITY = v_priority
        ),
        D_REST AS
        (
            SELECT
                FLAG,
                GROUPITEM,
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMIDFROM,
                MAX(TOTAL_TO_ALLOC) - SUM(QTY_BASE) AS REST_QTY
            FROM D_TARGET_BASE
            GROUP BY
                FLAG,
                GROUPITEM,
                SUBSIDIARYID,
                INVENTLOCATIONID,
                ITEMIDFROM
        ),
        D_TARGET AS
        (
            SELECT
                b.*,
                b.QTY_BASE +
                CASE
                    WHEN ROW_NUMBER() OVER
                    (
                        PARTITION BY
                            b.FLAG,
                            b.GROUPITEM,
                            b.SUBSIDIARYID,
                            b.INVENTLOCATIONID,
                            b.ITEMIDFROM
                        ORDER BY
                            b.DEMAND_QTY DESC,
                            b.DEMAND_ID
                    ) <= r.REST_QTY
                    THEN 1
                    ELSE 0
                END AS QTY_TARGET
            FROM D_TARGET_BASE b
            INNER JOIN D_REST r
                ON r.FLAG = b.FLAG
               AND r.GROUPITEM = b.GROUPITEM
               AND r.SUBSIDIARYID = b.SUBSIDIARYID
               AND r.INVENTLOCATIONID = b.INVENTLOCATIONID
               AND r.ITEMIDFROM = b.ITEMIDFROM
        ),
        S_SEQ AS
        (
            SELECT
                s.*,
                SUM(s.QTY) OVER
                (
                    PARTITION BY
                        s.FLAG,
                        s.GROUPITEM,
                        s.SUBSIDIARYID,
                        s.INVENTLOCATIONID,
                        s.ITEMIDFROM
                    ORDER BY
                        s.QTY DESC,
                        s.SUPPLY_ID
                ) - s.QTY AS QTY_START,
                SUM(s.QTY) OVER
                (
                    PARTITION BY
                        s.FLAG,
                        s.GROUPITEM,
                        s.SUBSIDIARYID,
                        s.INVENTLOCATIONID,
                        s.ITEMIDFROM
                    ORDER BY
                        s.QTY DESC,
                        s.SUPPLY_ID
                ) AS QTY_END
            FROM tmp_mov_supply s
            WHERE s.QTY > 0
        ),
        D_SEQ AS
        (
            SELECT
                d.*,
                dt.QTY_TARGET,
                SUM(dt.QTY_TARGET) OVER
                (
                    PARTITION BY
                        d.FLAG,
                        d.GROUPITEM,
                        d.SUBSIDIARYID,
                        d.INVENTLOCATIONID,
                        d.ITEMIDFROM
                    ORDER BY
                        d.QTY DESC,
                        d.DEMAND_ID
                ) - dt.QTY_TARGET AS QTY_START,
                SUM(dt.QTY_TARGET) OVER
                (
                    PARTITION BY
                        d.FLAG,
                        d.GROUPITEM,
                        d.SUBSIDIARYID,
                        d.INVENTLOCATIONID,
                        d.ITEMIDFROM
                    ORDER BY
                        d.QTY DESC,
                        d.DEMAND_ID
                ) AS QTY_END
            FROM tmp_mov_demand d
            INNER JOIN D_TARGET dt
                ON dt.DEMAND_ID = d.DEMAND_ID
            WHERE dt.QTY_TARGET > 0
        )
        SELECT
            s.SUPPLY_ID,
            d.DEMAND_ID,
            FLOOR(LEAST(s.QTY_END, d.QTY_END) - GREATEST(s.QTY_START, d.QTY_START)) AS QTY
        FROM S_SEQ s
        INNER JOIN D_SEQ d
            ON d.FLAG = s.FLAG
           AND d.GROUPITEM = s.GROUPITEM
           AND d.SUBSIDIARYID = s.SUBSIDIARYID
           AND d.INVENTLOCATIONID = s.INVENTLOCATIONID
           AND d.ITEMIDFROM = s.ITEMIDFROM
        INNER JOIN fersaSS.Config_MovementCalcType cfg
            ON cfg.SCENARIO = s.SCENARIO
           AND cfg.CALCTYPE = s.CALCTYPE
        WHERE cfg.ALLOW_SAME_LOCATION = true
          AND LEAST(s.QTY_END, d.QTY_END) > GREATEST(s.QTY_START, d.QTY_START);

        PERFORM INSERT INTO tmp_mov_result
        SELECT
            s.SCENARIO,
            s.CALCTYPE,
            s.SUPPLY_SOURCE,
            s.DEMAND_SOURCE,
            'SAME_LOCATION' AS MOVEMENT_LEVEL,
            s.FLAG,
            s.GROUPITEM,
            s.SUBSIDIARYID AS SUBSIDIARYIDFROM,
            s.INVENTLOCATIONID AS INVENTLOCATIONIDFROM,
            d.SUBSIDIARYID AS SUBSIDIARYIDTO,
            d.INVENTLOCATIONID AS INVENTLOCATIONIDTO,
            s.ITEMIDFROM,
            d.ITEMIDTO,
            a.QTY,
            d.FLAGITEM,
            d.PRIORITY
        FROM tmp_mov_alloc a
        INNER JOIN tmp_mov_supply s
            ON s.SUPPLY_ID = a.SUPPLY_ID
        INNER JOIN tmp_mov_demand d
            ON d.DEMAND_ID = a.DEMAND_ID
        WHERE a.QTY > 0;

        PERFORM UPDATE tmp_mov_supply s
        SET QTY = s.QTY - x.QTY
        FROM
        (
            SELECT SUPPLY_ID, SUM(QTY) AS QTY
            FROM tmp_mov_alloc
            WHERE QTY > 0
            GROUP BY SUPPLY_ID
        ) x
        WHERE s.SUPPLY_ID = x.SUPPLY_ID;

        PERFORM UPDATE tmp_mov_demand d
        SET QTY = d.QTY - x.QTY
        FROM
        (
            SELECT DEMAND_ID, SUM(QTY) AS QTY
            FROM tmp_mov_alloc
            WHERE QTY > 0
            GROUP BY DEMAND_ID
        ) x
        WHERE d.DEMAND_ID = x.DEMAND_ID;

        PERFORM DELETE FROM tmp_mov_supply WHERE QTY <= 0;
        PERFORM DELETE FROM tmp_mov_demand WHERE QTY <= 0;

    END LOOP;

    /*
        5. LEVEL 2: SAME_SUBSIDIARY.

        Mismo subsidiary.
        Distinta inventlocation.
    */

    FOR v_priority IN QUERY
        SELECT DISTINCT PRIORITY
        FROM tmp_mov_demand
        WHERE QTY > 0
        ORDER BY PRIORITY
    LOOP

        PERFORM DELETE FROM tmp_mov_alloc;

        PERFORM INSERT INTO tmp_mov_alloc
        WITH
        S_SEQ AS
        (
            SELECT
                s.*,
                SUM(s.QTY) OVER
                (
                    PARTITION BY
                        s.FLAG,
                        s.GROUPITEM,
                        s.SUBSIDIARYID,
                        s.ITEMIDFROM
                    ORDER BY
                        s.QTY DESC,
                        s.SUPPLY_ID
                ) - s.QTY AS QTY_START,
                SUM(s.QTY) OVER
                (
                    PARTITION BY
                        s.FLAG,
                        s.GROUPITEM,
                        s.SUBSIDIARYID,
                        s.ITEMIDFROM
                    ORDER BY
                        s.QTY DESC,
                        s.SUPPLY_ID
                ) AS QTY_END
            FROM tmp_mov_supply s
            WHERE s.QTY > 0
        ),
        D_SEQ AS
        (
            SELECT
                d.*,
                SUM(d.QTY) OVER
                (
                    PARTITION BY
                        d.FLAG,
                        d.GROUPITEM,
                        d.SUBSIDIARYID,
                        d.ITEMIDFROM
                    ORDER BY
                        d.QTY DESC,
                        d.DEMAND_ID
                ) - d.QTY AS QTY_START,
                SUM(d.QTY) OVER
                (
                    PARTITION BY
                        d.FLAG,
                        d.GROUPITEM,
                        d.SUBSIDIARYID,
                        d.ITEMIDFROM
                    ORDER BY
                        d.QTY DESC,
                        d.DEMAND_ID
                ) AS QTY_END
            FROM tmp_mov_demand d
            WHERE d.QTY > 0
              AND d.PRIORITY = v_priority
        )
        SELECT
            s.SUPPLY_ID,
            d.DEMAND_ID,
            FLOOR(LEAST(s.QTY_END, d.QTY_END) - GREATEST(s.QTY_START, d.QTY_START)) AS QTY
        FROM S_SEQ s
        INNER JOIN D_SEQ d
            ON d.FLAG = s.FLAG
           AND d.GROUPITEM = s.GROUPITEM
           AND d.SUBSIDIARYID = s.SUBSIDIARYID
           AND d.INVENTLOCATIONID <> s.INVENTLOCATIONID
           AND d.ITEMIDFROM = s.ITEMIDFROM
        INNER JOIN fersaSS.Config_MovementCalcType cfg
            ON cfg.SCENARIO = s.SCENARIO
           AND cfg.CALCTYPE = s.CALCTYPE
        WHERE cfg.ALLOW_SAME_SUBSIDIARY = true
          AND LEAST(s.QTY_END, d.QTY_END) > GREATEST(s.QTY_START, d.QTY_START);

        PERFORM INSERT INTO tmp_mov_result
        SELECT
            s.SCENARIO,
            s.CALCTYPE,
            s.SUPPLY_SOURCE,
            s.DEMAND_SOURCE,
            'SAME_SUBSIDIARY' AS MOVEMENT_LEVEL,
            s.FLAG,
            s.GROUPITEM,
            s.SUBSIDIARYID AS SUBSIDIARYIDFROM,
            s.INVENTLOCATIONID AS INVENTLOCATIONIDFROM,
            d.SUBSIDIARYID AS SUBSIDIARYIDTO,
            d.INVENTLOCATIONID AS INVENTLOCATIONIDTO,
            s.ITEMIDFROM,
            d.ITEMIDTO,
            a.QTY,
            d.FLAGITEM,
            d.PRIORITY
        FROM tmp_mov_alloc a
        INNER JOIN tmp_mov_supply s
            ON s.SUPPLY_ID = a.SUPPLY_ID
        INNER JOIN tmp_mov_demand d
            ON d.DEMAND_ID = a.DEMAND_ID
        WHERE a.QTY > 0;

        PERFORM UPDATE tmp_mov_supply s
        SET QTY = s.QTY - x.QTY
        FROM
        (
            SELECT SUPPLY_ID, SUM(QTY) AS QTY
            FROM tmp_mov_alloc
            WHERE QTY > 0
            GROUP BY SUPPLY_ID
        ) x
        WHERE s.SUPPLY_ID = x.SUPPLY_ID;

        PERFORM UPDATE tmp_mov_demand d
        SET QTY = d.QTY - x.QTY
        FROM
        (
            SELECT DEMAND_ID, SUM(QTY) AS QTY
            FROM tmp_mov_alloc
            WHERE QTY > 0
            GROUP BY DEMAND_ID
        ) x
        WHERE d.DEMAND_ID = x.DEMAND_ID;

        PERFORM DELETE FROM tmp_mov_supply WHERE QTY <= 0;
        PERFORM DELETE FROM tmp_mov_demand WHERE QTY <= 0;

    END LOOP;

    /*
        6. LEVEL 3: CROSS_SUBSIDIARY.

        Distinto subsidiary.
    */

    FOR v_priority IN QUERY
        SELECT DISTINCT PRIORITY
        FROM tmp_mov_demand
        WHERE QTY > 0
        ORDER BY PRIORITY
    LOOP

        PERFORM DELETE FROM tmp_mov_alloc;

        PERFORM INSERT INTO tmp_mov_alloc
        WITH
        S_SEQ AS
        (
            SELECT
                s.*,
                SUM(s.QTY) OVER
                (
                    PARTITION BY
                        s.FLAG,
                        s.GROUPITEM,
                        s.ITEMIDFROM
                    ORDER BY
                        s.QTY DESC,
                        s.SUPPLY_ID
                ) - s.QTY AS QTY_START,
                SUM(s.QTY) OVER
                (
                    PARTITION BY
                        s.FLAG,
                        s.GROUPITEM,
                        s.ITEMIDFROM
                    ORDER BY
                        s.QTY DESC,
                        s.SUPPLY_ID
                ) AS QTY_END
            FROM tmp_mov_supply s
            WHERE s.QTY > 0
        ),
        D_SEQ AS
        (
            SELECT
                d.*,
                SUM(d.QTY) OVER
                (
                    PARTITION BY
                        d.FLAG,
                        d.GROUPITEM,
                        d.ITEMIDFROM
                    ORDER BY
                        d.QTY DESC,
                        d.DEMAND_ID
                ) - d.QTY AS QTY_START,
                SUM(d.QTY) OVER
                (
                    PARTITION BY
                        d.FLAG,
                        d.GROUPITEM,
                        d.ITEMIDFROM
                    ORDER BY
                        d.QTY DESC,
                        d.DEMAND_ID
                ) AS QTY_END
            FROM tmp_mov_demand d
            WHERE d.QTY > 0
              AND d.PRIORITY = v_priority
        )
        SELECT
            s.SUPPLY_ID,
            d.DEMAND_ID,
            FLOOR(LEAST(s.QTY_END, d.QTY_END) - GREATEST(s.QTY_START, d.QTY_START)) AS QTY
        FROM S_SEQ s
        INNER JOIN D_SEQ d
            ON d.FLAG = s.FLAG
           AND d.GROUPITEM = s.GROUPITEM
           AND d.SUBSIDIARYID <> s.SUBSIDIARYID
           AND d.ITEMIDFROM = s.ITEMIDFROM
        INNER JOIN fersaSS.Config_MovementCalcType cfg
            ON cfg.SCENARIO = s.SCENARIO
           AND cfg.CALCTYPE = s.CALCTYPE
        WHERE cfg.ALLOW_CROSS_SUBSIDIARY = true
          AND LEAST(s.QTY_END, d.QTY_END) > GREATEST(s.QTY_START, d.QTY_START);

        PERFORM INSERT INTO tmp_mov_result
        SELECT
            s.SCENARIO,
            s.CALCTYPE,
            s.SUPPLY_SOURCE,
            s.DEMAND_SOURCE,
            'CROSS_SUBSIDIARY' AS MOVEMENT_LEVEL,
            s.FLAG,
            s.GROUPITEM,
            s.SUBSIDIARYID AS SUBSIDIARYIDFROM,
            s.INVENTLOCATIONID AS INVENTLOCATIONIDFROM,
            d.SUBSIDIARYID AS SUBSIDIARYIDTO,
            d.INVENTLOCATIONID AS INVENTLOCATIONIDTO,
            s.ITEMIDFROM,
            d.ITEMIDTO,
            a.QTY,
            d.FLAGITEM,
            d.PRIORITY
        FROM tmp_mov_alloc a
        INNER JOIN tmp_mov_supply s
            ON s.SUPPLY_ID = a.SUPPLY_ID
        INNER JOIN tmp_mov_demand d
            ON d.DEMAND_ID = a.DEMAND_ID
        WHERE a.QTY > 0;

        PERFORM UPDATE tmp_mov_supply s
        SET QTY = s.QTY - x.QTY
        FROM
        (
            SELECT SUPPLY_ID, SUM(QTY) AS QTY
            FROM tmp_mov_alloc
            WHERE QTY > 0
            GROUP BY SUPPLY_ID
        ) x
        WHERE s.SUPPLY_ID = x.SUPPLY_ID;

        PERFORM UPDATE tmp_mov_demand d
        SET QTY = d.QTY - x.QTY
        FROM
        (
            SELECT DEMAND_ID, SUM(QTY) AS QTY
            FROM tmp_mov_alloc
            WHERE QTY > 0
            GROUP BY DEMAND_ID
        ) x
        WHERE d.DEMAND_ID = x.DEMAND_ID;

        PERFORM DELETE FROM tmp_mov_supply WHERE QTY <= 0;
        PERFORM DELETE FROM tmp_mov_demand WHERE QTY <= 0;

    END LOOP;

    /*
        7. INSERT FINAL AGRUPADO.
    */

    PERFORM INSERT INTO fersaSS.Movement_ALL
    (
        SCENARIO,
        CALCTYPE,
        SUPPLY_SOURCE,
        DEMAND_SOURCE,
        MOVEMENT_LEVEL,
        FLAG,
        GROUPITEM,
        SUBSIDIARYIDFROM,
        INVENTLOCATIONIDFROM,
        SUBSIDIARYIDTO,
        INVENTLOCATIONIDTO,
        ITEMIDFROM,
        ITEMIDTO,
        QTY,
        FLAGITEM,
        PRIORITY
    )
    SELECT
        SCENARIO,
        CALCTYPE,
        SUPPLY_SOURCE,
        DEMAND_SOURCE,
        MOVEMENT_LEVEL,
        FLAG,
        GROUPITEM,
        SUBSIDIARYIDFROM,
        INVENTLOCATIONIDFROM,
        SUBSIDIARYIDTO,
        INVENTLOCATIONIDTO,
        ITEMIDFROM,
        ITEMIDTO,
        SUM(QTY) AS QTY,
        FLAGITEM,
        PRIORITY
    FROM tmp_mov_result
    WHERE QTY > 0
    GROUP BY
        SCENARIO,
        CALCTYPE,
        SUPPLY_SOURCE,
        DEMAND_SOURCE,
        MOVEMENT_LEVEL,
        FLAG,
        GROUPITEM,
        SUBSIDIARYIDFROM,
        INVENTLOCATIONIDFROM,
        SUBSIDIARYIDTO,
        INVENTLOCATIONIDTO,
        ITEMIDFROM,
        ITEMIDTO,
        FLAGITEM,
        PRIORITY;

    SELECT COUNT(*)
    INTO v_rows
    FROM fersaSS.Movement_ALL
    WHERE SCENARIO = p_scenario
      AND CALCTYPE = p_calctype;

    RAISE INFO 'Movement proportional 3 levels finished. Rows inserted: %', v_rows;

END;
$$;