/*STEP 3. Delete all groups and insert the new ones*/
/*DELETE old variables-Group*/
DELETE FROM VariablesGroup
WHERE ORIGIN=0 AND CONCAT(SUBSIDIARYID,CLASS,variableName) NOT IN (
		SELECT DISTINCT CONCAT(SUBSIDIARYID,CLASS,variableName)
		FROM VariablesValues
		WHERE ORIGIN=0
		);

/*ADD new Group*/
WITH newGroup as(
	SELECT DISTINCT variableName, CLASS, null as subclass, SUBSIDIARYID, ORIGIN, MAX(date) as date, null as roworder, null as colorder
	FROM(
		SELECT SUBSIDIARYID,ITEMID,CATALOGNUMBER,CLASS,ORIGIN,variableName,variableValue,date
		FROM VariablesValues
		WHERE ORIGIN=0
		)T
	WHERE CONCAT(SUBSIDIARYID,CLASS,variableName) NOT IN (select CONCAT(SUBSIDIARYID,CLASS,variableName) from VariablesGroup where ORIGIN=0)
	GROUP BY SUBSIDIARYID,CLASS,variableName,ORIGIN
)
INSERT INTO VariablesGroup (variableName,class,subclass,SUBSIDIARYID,ORIGIN,date,roworder,colorder)
SELECT variableName,class,subclass,SUBSIDIARYID,ORIGIN,date,roworder,colorder
FROM newGroup;

