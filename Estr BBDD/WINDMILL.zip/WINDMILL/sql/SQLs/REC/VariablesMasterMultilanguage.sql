/*STEP 2, add the new variables with the label same as variableName*/
WITH newVariables as (
SELECT distinct(variableName) as variableName
FROM VariablesValues where ORIGIN=0 and variableName NOT IN (select variableName from VariablesMasterMultilanguage where origin=0)
)
INSERT INTO VariablesMasterMultilanguage(variableName,label,language,ORIGIN,[date],type)
SELECT variableName,variableName as label, 'es-ES' as language, 0 as ORIGIN, GETDATE() as date, 'text' as type
FROM newVariables
union
SELECT variableName,variableName as label, 'en-US' as language, 0 as ORIGIN, GETDATE() as date, 'text' as type
FROM newVariables
;