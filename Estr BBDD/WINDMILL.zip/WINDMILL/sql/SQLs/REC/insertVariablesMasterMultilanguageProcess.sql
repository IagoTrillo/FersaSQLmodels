delete from VariablesMasterMultilanguage where origin=1;

insert into VariablesMasterMultilanguage(variableName,label,language,ORIGIN,[date],type)
select [Nueva variable] as variableName,[Propuesta descripci¢n] as label, 'es-ES' as language, 1 as ORIGIN, GETDATE() as date, 'text' as type
from [etiquetasProceso]
union
select [Nueva variable] as variableName,[Propuesta descripci¢n] as label, 'en-US' as language, 1 as ORIGIN, GETDATE() as date, 'text' as type
from [etiquetasProceso]