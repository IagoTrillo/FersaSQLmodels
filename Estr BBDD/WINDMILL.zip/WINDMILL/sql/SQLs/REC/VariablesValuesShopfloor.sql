/*STEP 4. Insert in a shopfloor table prepared to publish in the two apps(zgz and china) */
TRUNCATE table VariablesValuesShopfloor;

INSERT INTO VariablesValuesShopfloor(SUBSIDIARYID,ITEMID,CATALOGNUMBER,ORIGIN,variableName,language,label,variableValue,date,roworder,colorder,ORIGIN_VERTICA)
select VariablesValues.SUBSIDIARYID,VariablesValues.ITEMID,VariablesValues.CATALOGNUMBER,VariablesValues.ORIGIN,
VariablesValues.variableName, VariablesMasterMultilanguage.language, VariablesMasterMultilanguage.label,  VariablesValues.variableValue, VariablesValues.date,
VariablesGroup.roworder,VariablesGroup.colorder,ORIGIN_VERTICA
from VariablesValues
left join VariablesGroup on VariablesGroup.SUBSIDIARYID=VariablesValues.SUBSIDIARYID and
		VariablesGroup.variableName=VariablesValues.variableName and VariablesGroup.class=VariablesValues.CLASS
left join VariablesMasterMultilanguage on VariablesMasterMultilanguage.variableName=VariablesValues.variableName and VariablesMasterMultilanguage.ORIGIN=VariablesValues.ORIGIN
;