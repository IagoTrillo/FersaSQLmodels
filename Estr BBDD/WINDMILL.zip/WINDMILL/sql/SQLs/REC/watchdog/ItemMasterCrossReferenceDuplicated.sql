select *
from ItemMasterCrossReference
where concat(SUBSIDIARYID,ITEMID,ORIGIN,CROSSREFERENCETYPE) in(
    select concat(SUBSIDIARYID,ITEMID,ORIGIN,CROSSREFERENCETYPE) as error
    from (
        SELECT DISTINCT
              SUBSIDIARYID
              ,ITEMID
              ,ORIGIN
        ,CROSSREFERENCETYPE,count(*) as col
        FROM ItemMasterCrossReference itemCross
        where Active=1 and ((CROSSREFERENCETYPE=0 and ORIGIN='FER') or (CROSSREFERENCETYPE=4 and ORIGIN='CHN'))
		and DRAWINGNUMBER<>'' and DRAWINGNUMBER like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]%'
		and CROSSREFERENCETYPENUMBER<>'' and CROSSREFERENCETYPENUMBER IS NOT NULL
        group by SUBSIDIARYID
             ,ITEMID
             ,ORIGIN
            ,CROSSREFERENCETYPE
        having count(*)>1
        )ddd
)order by itemid
;