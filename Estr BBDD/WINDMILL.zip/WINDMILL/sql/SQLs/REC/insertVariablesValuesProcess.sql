delete from VariablesMasterMultilanguage where origin=1;

/* PROCESS VARIABLES - INNER*/

  INSERT INTO [dbo].[VariablesValues] (SUBSIDIARYID,ITEMID,CATALOGNUMBER,CLASS,ORIGIN,variableName,variableValue,date)
  SELECT  'FBEA' as SUBSIDIARYID, [ITEMNUMBER] as ITEMID, [CATALOGNUMBER], CLASS, 1 as ORIGIN, variableName, variableValue, ORIGIN_VERTICA='FER', GETDATE() as date
  FROM
  (
    select
	  [ITEMNUMBER]
	  ,[CATALOGNUMBER]
	  ,left([ITEMNUMBER],3) as CLASS
      ,CAST([TOL_B_PD1_MAX] AS varchar) [TOL_B_PD1_MAX]
      ,CAST([TOL_B_PD1_MIN] AS varchar) [TOL_B_PD1_MIN]
      ,CAST([TOL_B_PD2_MAX] AS varchar) [TOL_B_PD2_MAX]
      ,CAST([TOL_B_PD2_MIN] AS varchar) [TOL_B_PD2_MIN]
      ,CAST([TOL_B_PA_MAX] AS varchar) [TOL_B_PA_MAX]
      ,CAST([TOL_B_PA_MIN] AS varchar) [TOL_B_PA_MIN]
      ,CAST([TOL_M_PPL_MAX] AS varchar) [TOL_M_PPL_MAX]
      ,CAST([TOL_M_PPL_MIN] AS varchar) [TOL_M_PPL_MIN]
      ,CAST([TOL_B_PPD_MAX] AS varchar) [TOL_B_PPD_MAX]
      ,CAST([TOL_B_PPD_MIN] AS varchar) [TOL_B_PPD_MIN]
      ,CAST([TOL_PM_MAX] AS varchar) [TOL_PM_MAX]
      ,CAST([TOL_PM_MIN] AS varchar) [TOL_PM_MIN]
      ,CAST([TOL_d_P_MAX] AS varchar) [TOL_d_P_MAX]
      ,CAST([TOL_d_P_MIN] AS varchar) [TOL_d_P_MIN]
      ,CAST([TOL_M_P_MAX] AS varchar) [TOL_M_P_MAX]
      ,CAST([TOL_M_P_MIN] AS varchar) [TOL_M_P_MIN]
      ,CAST([TOL_d1_PD_MAX] AS varchar) [TOL_d1_PD_MAX]
      ,CAST([TOL_d1_PD_MIN] AS varchar) [TOL_d1_PD_MIN]
      ,CAST([TOL_d1_PA_MAX] AS varchar) [TOL_d1_PA_MAX]
      ,CAST([TOL_d1_PA_MIN] AS varchar) [TOL_d1_PA_MIN]
      ,CAST([TOL_d1_O_PD_MAX] AS varchar) [TOL_d1_O_PD_MAX]
      ,CAST([TOL_d1_O_PD_MIN] AS varchar) [TOL_d1_O_PD_MIN]
      ,CAST([TOL_d1_T_PD_MAX] AS varchar) [TOL_d1_T_PD_MAX]
      ,CAST([TOL_d1_T_PD_MIN] AS varchar) [TOL_d1_T_PD_MIN]
      ,CAST([TOL_A_P_MAX] AS varchar) [TOL_A_P_MAX]
      ,CAST([TOL_A_P_MIN] AS varchar) [TOL_A_P_MIN]
      ,CAST([TOL_TI_P_MAX] AS varchar) [TOL_TI_P_MAX]
      ,CAST([TOL_TI_P_MIN] AS varchar) [TOL_TI_P_MIN]
      ,CAST([TOL_TIINV_P_MAX] AS varchar) [TOL_TIINV_P_MAX]
      ,CAST([TOL_TIINV_P_MIN] AS varchar) [TOL_TIINV_P_MIN]
      ,CAST([TOL_P_COM_P_MIN] AS varchar) [TOL_P_COM_P_MIN]
      ,CAST([TOL_P_COM_P_MAX] AS varchar) [TOL_P_COM_P_MAX]
	  FROM VariablesProceso_Inner
	  where itemnumber IS NOT NULL
	  ) p
	  UNPIVOT
	  (
	  variableValue FOR variableName IN(
      [TOL_B_PD1_MAX]
      ,[TOL_B_PD1_MIN]
      ,[TOL_B_PD2_MAX]
      ,[TOL_B_PD2_MIN]
      ,[TOL_B_PA_MAX]
      ,[TOL_B_PA_MIN]
      ,[TOL_M_PPL_MAX]
      ,[TOL_M_PPL_MIN]
      ,[TOL_B_PPD_MAX]
      ,[TOL_B_PPD_MIN]
      ,[TOL_PM_MAX]
      ,[TOL_PM_MIN]
      ,[TOL_d_P_MAX]
      ,[TOL_d_P_MIN]
      ,[TOL_M_P_MAX]
      ,[TOL_M_P_MIN]
      ,[TOL_d1_PD_MAX]
      ,[TOL_d1_PD_MIN]
      ,[TOL_d1_PA_MAX]
      ,[TOL_d1_PA_MIN]
      ,[TOL_d1_O_PD_MAX]
      ,[TOL_d1_O_PD_MIN]
      ,[TOL_d1_T_PD_MAX]
      ,[TOL_d1_T_PD_MIN]
      ,[TOL_A_P_MAX]
      ,[TOL_A_P_MIN]
      ,[TOL_TI_P_MAX]
      ,[TOL_TI_P_MIN]
      ,[TOL_TIINV_P_MAX]
      ,[TOL_TIINV_P_MIN]
      ,[TOL_P_COM_P_MIN]
      ,[TOL_P_COM_P_MAX])
	  )AS unpvt

/* PROCESS VARIABLES - OUTER*/

 INSERT INTO [dbo].[VariablesValues] (SUBSIDIARYID,ITEMID,CATALOGNUMBER,CLASS,ORIGIN,variableName,variableValue,date)
  SELECT  'FBEA' as SUBSIDIARYID, [ITEMNUMBER] as ITEMID, [CATALOGNUMBER], CLASS, 1 as ORIGIN, variableName, variableValue, ORIGIN_VERTICA='FER', GETDATE() as date
  FROM
  (
    select
	  [ITEMNUMBER]
	  ,[CATALOGNUMBER]
	  ,left([ITEMNUMBER],3) as CLASS
      ,CAST([TOL_C_PD1_MAX] AS varchar) [TOL_C_PD1_MAX]
      ,CAST([TOL_C_PD1_MIN] AS varchar) [TOL_C_PD1_MIN]
      ,CAST([TOL_C_PD2_MAX] AS varchar) [TOL_C_PD2_MAX]
      ,CAST([TOL_C_PD2_MIN] AS varchar) [TOL_C_PD2_MIN]
      ,CAST([TOL_C_P_MAX] AS varchar) [TOL_C_P_MAX]
      ,CAST([TOL_C_P_MIN] AS varchar) [TOL_C_P_MIN]
      ,CAST([TOL_C_PPD_MAX] AS varchar)[TOL_C_PPD_MAX]
      ,CAST([TOL_C_PPD_MIN] AS varchar) [TOL_C_PPD_MIN]
      ,CAST([TOL_D_PD1_MAX] AS varchar) [TOL_D_PD1_MAX]
      ,CAST([TOL_D_PD1_MIN] AS varchar) [TOL_D_PD1_MIN]
      ,CAST([TOL_D_PD2_MAX] AS varchar) [TOL_D_PD2_MAX]
      ,CAST([TOL_D_PD2_MIN] AS varchar) [TOL_D_PD2_MIN]
      ,CAST([TOL_D_PA_MAX] AS varchar) [TOL_D_PA_MAX]
      ,CAST([TOL_D_PA_MIN] AS varchar) [TOL_D_PA_MIN]
      ,CAST([TOL_D_O_PD_MAX] AS varchar) [TOL_D_O_PD_MAX]
      ,CAST([TOL_D_O_PD_MIN] AS varchar) [TOL_D_O_PD_MIN]
      ,CAST([TOL_D_T_PD_MAX] AS varchar) [TOL_D_T_PD_MAX]
      ,CAST([TOL_D_T_PD_MIN] AS varchar) [TOL_D_T_PD_MIN]
      ,CAST([TOL_D1_PD_MAX] AS varchar) [TOL_D1_PD_MAX]
      ,CAST([TOL_D1_PD_MIN] AS varchar) [TOL_D1_PD_MIN]
      ,CAST([TOL_D1_PA_MAX] AS varchar) [TOL_D1_PA_MAX]
      ,CAST([TOL_D1_PA_MIN] AS varchar) [TOL_D1_PA_MIN]
      ,CAST([TOL_D1_O_PD_MAX] AS varchar) [TOL_D1_O_PD_MAX]
      ,CAST([TOL_D1_O_PD_MIN] AS varchar) [TOL_D1_O_PD_MIN]
      ,CAST([TOL_D1_T_PD_MAX] AS varchar) [TOL_D1_T_PD_MAX]
      ,CAST([TOL_D1_T_PD_MIN] AS varchar) [TOL_D1_T_PD_MIN]
      ,CAST([TOL_TE_P_MAX] AS varchar) [TOL_TE_P_MAX]
      ,CAST([TOL_TE_P_MIN] AS varchar) [TOL_TE_P_MIN]
      ,CAST([TOL_D1_SIN_P_MAX] AS varchar) [TOL_D1_SIN_P_MAX]
      ,CAST([TOL_D1_SIN_P_MIN] AS varchar) [TOL_D1_SIN_P_MIN]
      ,CAST([TOL_D1_SOUT_P_MAX] AS varchar) [TOL_D1_SOUT_P_MAX]
      ,CAST([TOL_D1_SOUT_P_MIN] AS varchar) [TOL_D1_SOUT_P_MIN]
	  FROM [VariablesProceso_Outer]
	  where itemnumber IS NOT NULL and len(itemnumber)<=14
	  ) p
	  UNPIVOT
	  (
	  variableValue FOR variableName IN(
       [TOL_C_PD1_MAX]
      ,[TOL_C_PD1_MIN]
      ,[TOL_C_PD2_MAX]
      ,[TOL_C_PD2_MIN]
      ,[TOL_C_P_MAX]
      ,[TOL_C_P_MIN]
      ,[TOL_C_PPD_MAX]
      ,[TOL_C_PPD_MIN]
      ,[TOL_D_PD1_MAX]
      ,[TOL_D_PD1_MIN]
      ,[TOL_D_PD2_MAX]
      ,[TOL_D_PD2_MIN]
      ,[TOL_D_PA_MAX]
      ,[TOL_D_PA_MIN]
      ,[TOL_D_O_PD_MAX]
      ,[TOL_D_O_PD_MIN]
      ,[TOL_D_T_PD_MAX]
      ,[TOL_D_T_PD_MIN]
      ,[TOL_D1_PD_MAX]
      ,[TOL_D1_PD_MIN]
      ,[TOL_D1_PA_MAX]
      ,[TOL_D1_PA_MIN]
      ,[TOL_D1_O_PD_MAX]
      ,[TOL_D1_O_PD_MIN]
      ,[TOL_D1_T_PD_MAX]
      ,[TOL_D1_T_PD_MIN]
      ,[TOL_TE_P_MAX]
      ,[TOL_TE_P_MIN]
      ,[TOL_D1_SIN_P_MAX]
      ,[TOL_D1_SIN_P_MIN]
      ,[TOL_D1_SOUT_P_MAX]
      ,[TOL_D1_SOUT_P_MIN])
	  )AS unpvt