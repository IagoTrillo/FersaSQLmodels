/*STEP 1. Insert all the variables from PDM with R&D RULES*/
delete from VariablesValues where ORIGIN=0;

INSERT INTO dbo.VariablesValues (SUBSIDIARYID,ITEMID,CATALOGNUMBER,CLASS,ORIGIN,variableName,variableValue,ORIGIN_VERTICA,date)
SELECT SUBSIDIARYID,ITEMID,CATALOG,CLASS,ORIGIN,variableName,variableValue, ORIGIN_VERTICA, MAX(rowTimeStamp) as date
FROM(
SELECT
	 calcPDM_Cross.SUBSIDIARYID
	 ,calcPDM_Cross.ITEMID
	 ,calcPDM_Cross.CATALOG
	 ,calcPDM_Cross.CLASS
	 ,0 AS ORIGIN
	 ,variables2.variableName
	 ,variables2.variableValue
	 ,calcPDM_Cross.ORIGIN_VERTICA
	 ,product.rowTimeStamp
FROM(
	SELECT itemCross.SUBSIDIARYID
		,ITEMID
		,DRAWINGNUMBER
		,CATALOG
		,productType.DRAWINGPRODUCTTYPE as CLASS
		,ISNULL(productType.FAMILYTYPE,left(DRAWINGNUMBER,3)) AS FamilyType
		,STR(ISNULL(productType.FAMILYTYPE,left(DRAWINGNUMBER,3)),3)+SUBSTRING(DRAWINGNUMBER,4,7) AS PDM_Cross
		,itemCross.ORIGIN_VERTICA
	FROM (
	    SELECT DISTINCT
            SUBSIDIARYID
            ,ITEMID
            ,CATALOG
            ,DRAWINGNUMBER
            ,CROSSREFERENCETYPE
            ,CROSSREFERENCETYPENUMBER
            ,(ORIGIN) AS ORIGIN_VERTICA
	    FROM ItemMasterCrossReference itemCross
	    where Active=1
	)itemCross
	INNER JOIN DrawingProductTypes productType ON productType.DRAWINGPRODUCTTYPE=left(itemCross.DRAWINGNUMBER,3) and productType.SUBSIDIARYID=itemCross.SUBSIDIARYID
	WHERE ((itemCross.CROSSREFERENCETYPE=0 and itemCross.ORIGIN_VERTICA='FER') or (itemCross.CROSSREFERENCETYPE=4 and itemCross.ORIGIN_VERTICA='CHN')) and itemCross.DRAWINGNUMBER <> ''
	    and DRAWINGNUMBER like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]%' and CROSSREFERENCETYPENUMBER<>'' and CROSSREFERENCETYPENUMBER IS NOT NULL
) calcPDM_Cross
LEFT JOIN [dbo].[AWProductVariables] variables ON  variables.variableName='Item Number F' and left(variables.variableValue,10) = PDM_Cross
LEFT JOIN [dbo].[AWProductVariables] variables2 ON variables.idProduct IS NOT NULL and variables2.idProduct=variables.idProduct
LEFT JOIN [AWProducts] product ON product.id=variables.idProduct
WHERE variables2.variableName is not null and variables2.variableValue is not null and rowTimeStamp is not null
)FINAL
GROUP BY SUBSIDIARYID,ITEMID,CATALOG,CLASS,ORIGIN,variableName,variableValue,ORIGIN_VERTICA;
