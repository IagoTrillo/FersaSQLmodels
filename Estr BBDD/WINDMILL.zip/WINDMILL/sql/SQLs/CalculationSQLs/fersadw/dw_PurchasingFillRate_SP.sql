TRUNCATE TABLE fersadw.PurchasingFillRate_SP;

INSERT INTO fersadw.PurchasingFillRate_SP(COMPANYID,SUBSIDIARYID,INVENTTRANSID,PURCHASEID,SUPPLIERID,ITEMID,PURCHASEQTY,PURCHASEDATE,EXPECTEDRECEPTIONDATE, RECEPTIONDATE,RECEIVEDQTY
,EXPECTEDSHIPDATE,SHIPDATE,PURCHASEAMOUNT,SHIPPEDQTY,RECEIVEDAMOUNT,SHIPPEDAMOUNT,ISINTERCO,REFERENCE, INVENTLOCATIONID)
-- CALLING TABLE IN WITH OPTIMIZE THE QUERY, THE JOINS ARE CALCULATED ONCE
WITH InventOriginTransDim_ALL AS (
	SELECT 	DATEPHYSICAL
			,QTY
			,INVENTTRANSID
			,REFERENCECATEGORY
			,STATUSRECEIPT
			,STATUSISSUE
			FROM fersadv.InventTransOrigin_ALL IO
	INNER JOIN fersadv.InventTrans_ALL IT ON IO.RECID = IT.INVENTTRANSORIGIN
	INNER JOIN fersadv.InventDim_ALL ID ON IT.INVENTDIMID = ID.INVENTDIMID
),
PURCHASEFILLRATE AS (
		-- RECEIVED WITH TRANSIT
								SELECT PO.COMPANYID,
	                                PO.SUBSIDIARYID,
	                                PO.INVENTTRANSID,
	                                PO.PURCHASEID,
	                                PO.SUPPLIERID,
	                                PO.ITEMID,
	                                PO.PURCHASEQTY,
	                                PO.PURCHASEDATE,
	                                CASE WHEN ((YEAR(FIRSTCONFIRMEDDATE) = 1900) OR (FIRSTCONFIRMEDDATE IS NULL)) THEN ISNULL(CONFIRMEDDATE,'1900-01-01 00:00:00.000')::TIMESTAMP
	                                    ELSE FIRSTCONFIRMEDDATE
	                                END AS EXPECTEDRECEPTIONDATE,
	                                ISNULL(IOT_DEL.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS RECEPTIONDATE,
	                                IOT_DEL.QTY AS RECEIVEDQTY,
	                                -- CALCULATE EXPECTEDSHIPDATE AS THE FIRSTCONFIRMEDDATE PLUS THE DIFFERENCE BETWEEN SHIPPINGDATECONFIRMED AND CONFIRMEDDATE
	                                (ISNULL(TIMESTAMPADD(day,(-1 * DATEDIFF(day,PO.SHIPPINGDATECONFIRMED, PO.CONFIRMEDDATE))
	                                                            ,PO.FIRSTCONFIRMEDDATE),'1900-01-01 00:00:00.000')) AS EXPECTEDSHIPDATE,
	                                ISNULL(IOT_SHIP.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS SHIPDATE,
	                                PO.AMOUNT AS PURCHASEAMOUNT,
	                                -- LIMIT QTYs AND AMOUNTs IN CASE THEY ARE BIGGER THAN PURCHQTY TO AVOID >100% FILLRATE (PENDING TO CHANGE)
	                                CASE WHEN IOT_SHIP.QTY > PO.PURCHASEQTY THEN PO.PURCHASEQTY
	                                    ELSE IOT_SHIP.QTY
	                                END AS SHIPPEDQTY,
	                                CASE WHEN IOT_DEL.QTY > PO.PURCHASEQTY THEN PO.AMOUNT
	                                     WHEN PO.PURCHASEQTY = 0 THEN 0
	                                     ELSE IOT_DEL.QTY * (PO.AMOUNT / PO.PURCHASEQTY)
	                                END AS RECEIVEDAMOUNT,
	                                CASE WHEN IOT_SHIP.QTY > PO.PURCHASEQTY THEN PO.AMOUNT
	                                     WHEN PO.PURCHASEQTY = 0 THEN 0
	                                     ELSE IOT_SHIP.QTY * (PO.AMOUNT / PO.PURCHASEQTY)
	                                END AS SHIPPEDAMOUNT,
	                                (CASE WHEN (INTERCO.CUSTVENDACCOUNT IS NULL) THEN 0 ELSE 1 END)::boolean AS ISINTERCO,
	                                -- FOR THESE CASES [WITH TRANSIT] THE TEAM IS INTERESTED ONLY ON DISPATCH
	                                'DISPATCH' AS REFERENCE
									, PO.INVENTLOCATIONID
	                            FROM fersadv.PurchaseLines_ALL PO
	                            -- INNER JOIN WITH TRANSITS TO ENSURE THAT PURCHASES HAVE TRANSIT
	                            JOIN fersadv.InventTransferLine_FER TL
	                                ON PO.INVENTTRANSID = TL.FERPURCHINVENTREFTRANSID
	                                -- INNER JOIN WITH INVENTTRANS TO FILTER RECEPTIONS AND GET DELIVERED QTYs
	                                JOIN InventOriginTransDim_ALL IOT_DEL
	                                    ON TL.INVENTTRANSIDRECEIVE = IOT_DEL.INVENTTRANSID AND IOT_DEL.REFERENCECATEGORY = 22 AND (IOT_DEL.STATUSRECEIPT <= 2) AND (IOT_DEL.STATUSISSUE = 0)
	                            -- INNER JOIN WITH INVENTTRANS TO GET SHIPPED QTYs
	                            JOIN
	                                (SELECT DATEPHYSICAL, INVENTTRANSID, ABS(SUM(QTY)) AS QTY, REFERENCECATEGORY
	                                FROM  InventOriginTransDim_ALL
	                                GROUP BY INVENTTRANSID, DATEPHYSICAL, REFERENCECATEGORY) IOT_SHIP
	                                ON TL.INVENTTRANSID = IOT_SHIP.INVENTTRANSID
	                            -- JOIN WIH INTERCOMPANY CODES TO IDENTIFY INTERCO CASES
	                            LEFT JOIN
	                                (SELECT CustomerVendorInterCo_standalone.CUSTVENDACCOUNT
	                                    FROM fersaParamsPublic.CustomerVendorInterCo_standalone
	                                GROUP BY CustomerVendorInterCo_standalone.CUSTVENDACCOUNT) AS INTERCO
	                                ON PO.SUPPLIERID = INTERCO.CUSTVENDACCOUNT
	                            -- JOIN WITH MASTER SUPPLIERS TO GET THOSE WITH TRANSIT
								JOIN
									(SELECT DISTINCT SUPPLIERID, SUPPLIERGROUP, SUBSIDIARYID
										FROM fersadv.Supplier_ALL
									WHERE SUPPLIERGROUP LIKE '%INTLPROV%') AS SUPPTYPE
									ON PO.SUPPLIERID = SUPPTYPE.SUPPLIERID AND PO.SUBSIDIARYID = SUPPTYPE.SUBSIDIARYID
	                            WHERE IOT_SHIP.REFERENCECATEGORY = 21 AND PO.PURCHASEDATE > '2020-01-01' AND PO.PURCHASEQTY > 0

	                            UNION ALL

	                            -- RECEIVED WITHOUT TRANSIT
	                            SELECT PO.COMPANYID,
	                                PO.SUBSIDIARYID,
	                                PO.INVENTTRANSID,
	                                PO.PURCHASEID,
	                                PO.SUPPLIERID,
	                                PO.ITEMID,
	                                PO.PURCHASEQTY,
	                                PO.PURCHASEDATE,
	                                -- CALCULATE EXPECTEDSHIPDATE AS THE FIRSTCONFIRMEDDATE PLUS THE DIFFERENCE BETWEEN SHIPPINGDATECONFIRMED AND CONFIRMEDDATE
	                                CASE WHEN ((YEAR(FIRSTCONFIRMEDDATE) = 1900) OR (FIRSTCONFIRMEDDATE IS NULL)) THEN ISNULL(CONFIRMEDDATE,'1900-01-01 00:00:00.000')::TIMESTAMP
	                                    ELSE FIRSTCONFIRMEDDATE
	                                END AS EXPECTEDRECEPTIONDATE,
	                                ISNULL(IOT.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS RECEPTIONDATE,
	                                IOT.QTY AS RECEIVEDQTY,
	                                (ISNULL(TIMESTAMPADD(day,(-1 * DATEDIFF(day,PO.SHIPPINGDATECONFIRMED, PO.CONFIRMEDDATE))
	                                                            ,PO.FIRSTCONFIRMEDDATE),'1900-01-01 00:00:00.000')) AS EXPECTEDSHIPDATE,
	                                ISNULL(IOT.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS SHIPDATE,
	                                PO.AMOUNT AS PURCHASEAMOUNT,
	                                -- LIMIT QTYs AND AMOUNTs IN CASE THEY ARE BIGGER THAN PURCHQTY TO AVOID >100% FILLRATE (PENDING TO CHANGE)
	                                CASE WHEN IOT.QTY > PO.PURCHASEQTY THEN PO.PURCHASEQTY
	                                    ELSE IOT.QTY
	                                END AS SHIPPEDQTY,
	                                CASE WHEN IOT.QTY > PO.PURCHASEQTY THEN PO.AMOUNT
	                                     WHEN PO.PURCHASEQTY = 0 THEN 0
	                                     ELSE IOT.QTY * (PO.AMOUNT / PO.PURCHASEQTY)
	                                END AS RECEIVEDAMOUNT,
	                                CASE WHEN IOT.QTY > PO.PURCHASEQTY THEN PO.AMOUNT
	                                     WHEN PO.PURCHASEQTY = 0 THEN 0
	                                     ELSE IOT.QTY * (PO.AMOUNT / PO.PURCHASEQTY)
	                                END AS SHIPPEDAMOUNT,
	                                (CASE WHEN (INTERCO.CUSTVENDACCOUNT IS NULL) THEN 0 ELSE 1 END)::boolean AS ISINTERCO,
	                                -- FOR THESE CASES [WITHOUT TRANSIT] THE TEAM IS INTERESTED ONLY ON ARRIVAL
	                                'ARRIVAL' AS REFERENCE,
									PO.INVENTLOCATIONID
	                            FROM fersadv.PurchaseLines_ALL PO
	                            -- LEFT OUTER JOIN TO FILTER PURCHASES WITHOUT TRANSITS
	                            LEFT JOIN fersadv.InventTransferLine_FER TL
	                                ON PO.INVENTTRANSID = TL.FERPURCHINVENTREFTRANSID
	                            -- LEFT JOIN WITH INVENTTRANS TO GET QTYs
	                            LEFT JOIN InventOriginTransDim_ALL IOT
	                                ON PO.INVENTTRANSID = IOT.INVENTTRANSID
	                            -- JOIN WIH INTERCOMPANY CODES TO IDENTIFY INTERCO CASES
	                            LEFT JOIN
	                                (SELECT CustomerVendorInterCo_standalone.CUSTVENDACCOUNT
	                                    FROM fersaParamsPublic.CustomerVendorInterCo_standalone
	                                GROUP BY CustomerVendorInterCo_standalone.CUSTVENDACCOUNT) AS INTERCO
	                                ON PO.SUPPLIERID = INTERCO.CUSTVENDACCOUNT
								-- JOIN WITH MASTER SUPPLIERS TO GET THOSE WITHOUT TRANSIT
								JOIN
									(SELECT DISTINCT SUPPLIERID, VENDGROUP, SUBSIDIARYID
										FROM fersadv.Supplier_ALL
									WHERE SUPPLIERGROUP NOT LIKE '%INTLPROV%') AS SUPPTYPE
									ON PO.SUPPLIERID = SUPPTYPE.SUPPLIERID AND PO.SUBSIDIARYID = SUPPTYPE.SUBSIDIARYID
								-- FILTERS TO GET RECEPTIONS WITHOUT TRANSITS
	                            WHERE (TL.FERPURCHINVENTREFTRANSID IS NULL) AND (PO.PURCHASEDATE > '2020-01-01') AND (REFERENCECATEGORY = 3) AND (STATUSRECEIPT <= 2) AND (STATUSISSUE <=1) AND (PO.PURCHASEQTY > 0) AND (IOT.QTY > 0)

	                            UNION ALL
	                            -- PENDING (NO TRANSIT YET)
	                            SELECT PO.COMPANYID,
	                                PO.SUBSIDIARYID,
	                                PO.INVENTTRANSID,
	                                PO.PURCHASEID,
	                                PO.SUPPLIERID,
	                                PO.ITEMID,
	                                PO.PURCHASEQTY,
	                                PO.PURCHASEDATE,
	                                CASE WHEN ((YEAR(FIRSTCONFIRMEDDATE) = 1900) OR (FIRSTCONFIRMEDDATE IS NULL)) THEN ISNULL(CONFIRMEDDATE,'1900-01-01 00:00:00.000')::TIMESTAMP
	                                    ELSE FIRSTCONFIRMEDDATE
	                                END AS EXPECTEDRECEPTIONDATE,
	                                ISNULL(IOT.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS RECEPTIONDATE,
	                                0 AS RECEIVEDQTY,
	                                -- CALCULATE EXPECTEDSHIPDATE AS THE FIRSTCONFIRMEDDATE PLUS THE DIFFERENCE BETWEEN SHIPPINGDATECONFIRMED AND CONFIRMEDDATE
	                                (ISNULL(TIMESTAMPADD(day,(-1 * DATEDIFF(day,PO.SHIPPINGDATECONFIRMED, PO.CONFIRMEDDATE))
	                                                            ,PO.FIRSTCONFIRMEDDATE),'1900-01-01 00:00:00.000')) AS EXPECTEDSHIPDATE,
	                                ISNULL(IOT.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS SHIPDATE,
	                                PO.AMOUNT AS PURCHASEAMOUNT,
	                                0 SHIPPEDQTY,
	                                0 RECEIVEDAMOUNT,
	                                0 SHIPPEDAMOUNT,
	                                (CASE WHEN (INTERCO.CUSTVENDACCOUNT IS NULL) THEN 0 ELSE 1 END)::boolean AS ISINTERCO,
	                                -- SET CLASSIFICATION DEPENDING ON SUPPLIER TYPE
	                                CASE WHEN (SUPPTYPE.SUPPLIERGROUP LIKE '%INTLPROV%') THEN 'DISPATCH'
	                                	ELSE 'ARRIVAL'
									END AS REFERENCE,
									PO.INVENTLOCATIONID
	                            FROM fersadv.PurchaseLines_ALL PO
	                            -- LEFT OUTER JOIN WITH TRANSITS TO FILTER PURCHASES WITHOUT TRANSIT
	                            LEFT JOIN fersadv.InventTransferLine_FER TL
	                                ON PO.INVENTTRANSID = TL.FERPURCHINVENTREFTRANSID AND (TL.FERPURCHINVENTREFTRANSID IS NULL)
	                            -- JOIN WITH INVENTTRANS TO GET DATES
	                            LEFT JOIN InventOriginTransDim_ALL IOT
	                                ON PO.INVENTTRANSID = IOT.INVENTTRANSID
	                            -- JOIN WIH INTERCOMPANY CODES TO IDENTIFY INTERCO CASES
	                            LEFT JOIN
	                                (SELECT CustomerVendorInterCo_standalone.CUSTVENDACCOUNT
	                                    FROM fersaParamsPublic.CustomerVendorInterCo_standalone
	                                GROUP BY CustomerVendorInterCo_standalone.CUSTVENDACCOUNT) AS INTERCO
	                                ON PO.SUPPLIERID = INTERCO.CUSTVENDACCOUNT
	                            -- JOIN WIH MASTER SUPPLIER AND FILTER SUPPLIERS WITH TRANSIT
	                            JOIN
									(SELECT DISTINCT SUPPLIERID, SUPPLIERGROUP, SUBSIDIARYID
										FROM fersadv.Supplier_ALL
									WHERE SUPPLIERGROUP LIKE '%INTLPROV%') AS SUPPTYPE
									ON PO.SUPPLIERID = SUPPTYPE.SUPPLIERID AND PO.SUBSIDIARYID = SUPPTYPE.SUBSIDIARYID
	                            WHERE PO.PURCHASEDATE > '2020-01-01' AND REFERENCECATEGORY = 3 AND (STATUSRECEIPT = 5) AND (STATUSISSUE = 0) AND (PO.PURCHASEQTY > 0)

	                            UNION ALL
	                            -- IN TRANSIT
	                            SELECT PO.COMPANYID,
	                                PO.SUBSIDIARYID,
	                                PO.INVENTTRANSID,
	                                PO.PURCHASEID,
	                                PO.SUPPLIERID,
	                                PO.ITEMID,
	                                PO.PURCHASEQTY,
	                                PO.PURCHASEDATE,
	                                CASE WHEN ((YEAR(FIRSTCONFIRMEDDATE) = 1900) OR (FIRSTCONFIRMEDDATE IS NULL)) THEN ISNULL(CONFIRMEDDATE,'1900-01-01 00:00:00.000')::TIMESTAMP
	                                    ELSE FIRSTCONFIRMEDDATE
	                                END AS EXPECTEDRECEPTIONDATE,
	                                ISNULL(IOT_DEL.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS RECEPTIONDATE,
	                                0 AS RECEIVEDQTY,
	                                -- CALCULATE EXPECTEDSHIPDATE AS THE FIRSTCONFIRMEDDATE PLUS THE DIFFERENCE BETWEEN SHIPPINGDATECONFIRMED AND CONFIRMEDDATE
	                                (ISNULL(TIMESTAMPADD(day,(-1 * DATEDIFF(day,PO.SHIPPINGDATECONFIRMED, PO.CONFIRMEDDATE))
	                                                            ,PO.FIRSTCONFIRMEDDATE),'1900-01-01 00:00:00.000')) AS EXPECTEDSHIPDATE,
	                                ISNULL(IOT_SHIP.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS SHIPDATE,
	                                PO.AMOUNT AS PURCHASEAMOUNT,
	                                -- TODO: LIMIT QTYs AND AMOUNTs IN CASE THEY ARE BIGGER THAN PURCHQTY TO AVOID >100% FILLRATE (PENDING TO CHANGE)
	                                CASE WHEN ABS(IOT_SHIP.QTY) > PO.PURCHASEQTY THEN PO.PURCHASEQTY
	                                    ELSE ABS(IOT_SHIP.QTY)
	                                END AS SHIPPEDQTY,
	                                0 AS RECEIVEDAMOUNT,
	                                CASE WHEN ABS(IOT_SHIP.QTY) > PO.PURCHASEQTY THEN PO.AMOUNT
	                                     WHEN PO.PURCHASEQTY = 0 THEN 0
	                                     ELSE ABS(IOT_SHIP.QTY) * (PO.AMOUNT / PO.PURCHASEQTY)
	                                END AS SHIPPEDAMOUNT,
	                                (CASE WHEN (INTERCO.CUSTVENDACCOUNT IS NULL) THEN 0 ELSE 1 END)::boolean AS ISINTERCO,
	                                -- FOR THESE CASES [IN TRANSIT] THE TEAM IS INTERESTED ONLY ON DISPATCH
	                                'DISPATCH' AS REFERENCE,
									PO.INVENTLOCATIONID
	                            FROM fersadv.PurchaseLines_ALL PO
	                            -- JOIN WITH TRANSITS TO FILTER PURCHASES WITH TRANSIT
	                            JOIN fersadv.InventTransferLine_FER TL
	                                ON PO.INVENTTRANSID = TL.FERPURCHINVENTREFTRANSID
	                            -- JOIN WITH INVENTTRANS TO GET DELIVERED QTYs
	                            JOIN InventOriginTransDim_ALL IOT_DEL
	                                ON TL.INVENTTRANSIDRECEIVE = IOT_DEL.INVENTTRANSID AND IOT_DEL.REFERENCECATEGORY = 22 AND (IOT_DEL.STATUSRECEIPT = 5)
	                            -- JOIN WITH INVENTTRANS TO GET SHIPPED QTYs
	                            JOIN InventOriginTransDim_ALL AS IOT_SHIP
	                                ON TL.INVENTTRANSID = IOT_SHIP.INVENTTRANSID
	                            -- JOIN WIH INTERCOMPANY CODES TO IDENTIFY INTERCO CASES
	                            LEFT JOIN
	                                (SELECT CustomerVendorInterCo_standalone.CUSTVENDACCOUNT
	                                    FROM fersaParamsPublic.CustomerVendorInterCo_standalone
	                                GROUP BY CustomerVendorInterCo_standalone.CUSTVENDACCOUNT) AS INTERCO
	                                ON PO.SUPPLIERID = INTERCO.CUSTVENDACCOUNT
								JOIN
								--JOIN WITH MASTER SUPPLIERS
									(SELECT DISTINCT SUPPLIERID, SUPPLIERGROUP, SUBSIDIARYID
										FROM fersadv.Supplier_ALL) AS SUPPTYPE
									ON PO.SUPPLIERID = SUPPTYPE.SUPPLIERID AND PO.SUBSIDIARYID = SUPPTYPE.SUBSIDIARYID
	                            WHERE IOT_SHIP.REFERENCECATEGORY = 21  AND (PO.PURCHASEQTY > 0)
	                                                            --RETURNS    
	                                                            UNION ALL   
                                SELECT PO.COMPANYID,
	                                PO.SUBSIDIARYID,
	                                PO.INVENTTRANSID,
	                                PO.PURCHASEID,
	                                PO.SUPPLIERID,
	                                PO.ITEMID,
	                                0 as PURCHASEQTY,
	                                PO.PURCHASEDATE,
	                                CASE WHEN ((YEAR(FIRSTCONFIRMEDDATE) = 1900) OR (FIRSTCONFIRMEDDATE IS NULL)) THEN ISNULL(CONFIRMEDDATE,'1900-01-01 00:00:00.000')::TIMESTAMP
	                                    ELSE FIRSTCONFIRMEDDATE
	                                END AS EXPECTEDRECEPTIONDATE,
	                                ISNULL(IOT.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS RECEPTIONDATE,
	                                IOT.QTY AS RECEIVEDQTY,
	                                (ISNULL(TIMESTAMPADD(day,(-1 * DATEDIFF(day,PO.SHIPPINGDATECONFIRMED, PO.CONFIRMEDDATE))
	                                                            ,PO.FIRSTCONFIRMEDDATE),'1900-01-01 00:00:00.000')) AS EXPECTEDSHIPDATE,
	                                ISNULL(IOT.DATEPHYSICAL,'1900-01-01 00:00:00.000')::TIMESTAMP AS SHIPDATE,
	                                PO.AMOUNT AS PURCHASEAMOUNT,
	                                -- LIMIT QTYs AND AMOUNTs IN CASE THEY ARE BIGGER THAN PURCHQTY TO AVOID >100% FILLRATE (PENDING TO CHANGE)
	                                CASE WHEN IOT.QTY > PO.PURCHASEQTY THEN PO.PURCHASEQTY
	                                    ELSE IOT.QTY
	                                END AS SHIPPEDQTY,
	                                CASE WHEN IOT.QTY > PO.PURCHASEQTY THEN PO.AMOUNT
	                                     WHEN PO.PURCHASEQTY = 0 THEN 0
	                                     ELSE IOT.QTY * (PO.AMOUNT / PO.PURCHASEQTY)
	                                END AS RECEIVEDAMOUNT,
	                                CASE WHEN IOT.QTY > PO.PURCHASEQTY THEN PO.AMOUNT
	                                     WHEN PO.PURCHASEQTY = 0 THEN 0
	                                     ELSE IOT.QTY * (PO.AMOUNT / PO.PURCHASEQTY)
	                                END AS SHIPPEDAMOUNT,
	                                (CASE WHEN (INTERCO.CUSTVENDACCOUNT IS NULL) THEN 0 ELSE 1 END)::boolean AS ISINTERCO,
	                                -- FOR THESE CASES [WITHOUT TRANSIT] THE TEAM IS INTERESTED ONLY ON ARRIVAL
	                                'RETURN' AS REFERENCE,
									PO.INVENTLOCATIONID
	                            FROM fersadv.PurchaseLines_ALL PO
	                            -- LEFT OUTER JOIN TO FILTER PURCHASES WITHOUT TRANSITS
	                            -- LEFT JOIN WITH INVENTTRANS TO GET QTYs
	                            LEFT JOIN InventOriginTransDim_ALL IOT
	                                ON PO.INVENTTRANSID = IOT.INVENTTRANSID
	                            -- JOIN WIH INTERCOMPANY CODES TO IDENTIFY INTERCO CASES
	                            LEFT JOIN
	                                (SELECT CustomerVendorInterCo_standalone.CUSTVENDACCOUNT
	                                    FROM fersaParamsPublic.CustomerVendorInterCo_standalone
	                                GROUP BY CustomerVendorInterCo_standalone.CUSTVENDACCOUNT) AS INTERCO
	                                ON PO.SUPPLIERID = INTERCO.CUSTVENDACCOUNT
								-- FILTERS TO GET RECEPTIONS WITHOUT TRANSITS
	                            WHERE(PO.PURCHASEDATE > '2020-01-01') AND (REFERENCECATEGORY = 3) AND (STATUSRECEIPT = 0) AND (STATUSISSUE =1)
	                            ) SELECT * FROM PURCHASEFILLRATE;