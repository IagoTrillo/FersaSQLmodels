TRUNCATE TABLE fersadv.OverStock_ALL;

INSERT INTO fersadv.OverStock_ALL(SUBSIDIARYID,ITEMID,INVENTLOCATIONID,INVENTSTYLEID,QTY,PHYSICALINVENT,STDCOST,PHYSICALINVENTCOST,COSTEXCHANGERATE_EUR)
WITH FINAL AS(
		SELECT OS.SUBSIDIARYID,OS.ITEMID,OS.INVENTLOCATIONID,OS.INVENTSTYLEID,SUM(QTY) QTY,SUM(PHYSICALINVENT) PHYSICALINVENT,SUM(QTY)*MAX(UNITPRICE) STDCOST,SUM(PHYSICALINVENT)*MAX(UNITPRICE) PHYSICALINVENTCOST,
                            CASE WHEN LOCS.CURRENCYCODE = 'EUR' THEN 1
                                                            ELSE ROUND(COSTEXCHANGERATES.EXCHANGERATE, 2)
                                                            END AS COSTEXCHANGERATE_EUR
                            FROM
                            (
                                (
                                    SELECT RC.SUBSIDIARYID, RC.ITEMID,RC.INVENTLOCATIONID,RC.INVENTSTYLEID,QTY, null as PHYSICALINVENT
                                    FROM fersadv.ReqTrans_ALL RC
                                    WHERE RC.REFTYPE in (14,10,21,12,45,43,35,16,17)
                                    AND INVENTLOCATIONID LIKE 'T_%'

                                    UNION ALL 

                                    SELECT RC.SUBSIDIARYID, RC.ITEMID,RC.INVENTLOCATIONID,RC.INVENTSTYLEID,QTY, null as PHYSICALINVENT
                                    FROM fersadv.ReqTrans_ALL RC
                                    WHERE RC.REFTYPE in (14,10,21,12,45,43,35,16)
                                    AND INVENTLOCATIONID NOT LIKE 'T_%'

                                    UNION ALL 

                                    SELECT RC.SUBSIDIARYID, RC.ITEMID,RC.INVENTLOCATIONID,RC.INVENTSTYLEID,RC.QTY, null as PHYSICALINVENT 
                                    FROM fersadv.ReqTrans_ALL RC
                                    INNER JOIN (
                                        SELECT DISTINCT UPPER(IT.DATAAREAID) SUBSIDIARYID,IT.INVENTTRANSORIGIN
                                        FROM fersads.ds_InventTransOrigin_FER IO
                                        INNER JOIN fersads.ds_InventTrans_FER IT ON IO.RECID = IT.INVENTTRANSORIGIN
                                        INNER JOIN fersadv.InventTransferLine_FER itf ON HASH(UPPER(IT.DATAAREAID),IO.INVENTTRANSID)=HASH(itf.SUBSIDIARYID,itf.INVENTTRANSIDRECEIVE)
                                        INNER JOIN fersads.ds_InventTransOrigin_FER IO2 ON HASH(itf.SUBSIDIARYID,itf.INVENTTRANSID)=HASH(UPPER(IO2.DATAAREAID),IO2.INVENTTRANSID)
                                        INNER JOIN fersads.ds_InventTrans_FER IT2 ON IO2.RECID = IT2.INVENTTRANSORIGIN
                                        INNER JOIN fersads.ds_InventDim_FER ID ON IT2.INVENTDIMID = ID.INVENTDIMID
                                        INNER JOIN fersadv.Supplier_ALL s ON HASH(UPPER(IO2.DATAAREAID),ID.INVENTLOCATIONID)=HASH(s.SUBSIDIARYID,s.SUPPLIERID)
                                        WHERE SUPPLIERTYPE<>'EXTERNAL'
                                        ) iot ON HASH(RC.SUBSIDIARYID,RC.INVENTTRANSORIGIN)=HASH(iot.SUBSIDIARYID,iot.INVENTTRANSORIGIN)
                                    WHERE RC.REFTYPE = 17
                                    AND RC.INVENTLOCATIONID NOT LIKE 'T_%'




                                )
                                UNION ALL
                                (
                                    SELECT ISF.SUBSIDIARYID , ISF.ITEMID,ISF.INVENTLOCATIONID,INVENTSTYLEID,ISF.PHYSICALINVENT QTY,ISF.PHYSICALINVENT
                                    FROM fersadv.InventSum_ALL ISF
                                )
                            ) OS
                            LEFT JOIN
                                (SELECT ITEMID, SUBSIDIARYID, UNITPRICE
                                FROM fersadv.StandardCosts_ALL) AS STDCOSTS
                                ON STDCOSTS.ITEMID = OS.ITEMID AND STDCOSTS.SUBSIDIARYID = OS.SUBSIDIARYID
                            INNER JOIN fersaParams.CompanyLocation_standalone AS LOCS
                                ON OS.SUBSIDIARYID = LOCS.LOCATIONID
                            LEFT JOIN
                                (SELECT FROMCURRENCYCODE, max(EXCHANGERATE)EXCHANGERATE
                                FROM fersadv.ExchangeRateDaily_ALL
                                WHERE TOCURRENCYCODE = 'EUR' AND ERPSOURCE = 'DEFAULT' and VALIDFROM = last_day(ADD_MONTHS(now(),-1))
                                group by  FROMCURRENCYCODE) COSTEXCHANGERATES
                                ON LOCS.CURRENCYCODE = COSTEXCHANGERATES.FROMCURRENCYCODE
                            GROUP BY OS.SUBSIDIARYID,OS.ITEMID,OS.INVENTSTYLEID,OS.INVENTLOCATIONID,LOCS.CURRENCYCODE,COSTEXCHANGERATES.EXCHANGERATE
)SELECT SUBSIDIARYID,ITEMID,INVENTLOCATIONID,INVENTSTYLEID,QTY,PHYSICALINVENT,STDCOST,PHYSICALINVENTCOST,COSTEXCHANGERATE_EUR
FROM  FINAL;
                            