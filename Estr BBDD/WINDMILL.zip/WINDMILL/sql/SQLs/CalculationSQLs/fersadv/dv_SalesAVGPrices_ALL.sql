TRUNCATE TABLE fersadv.SalesAVGPrices_ALL;

INSERT INTO fersadv.SalesAVGPrices_ALL(
COMPANYID, SUBSIDIARYID, ORIGIN, CUSTOMERID, YEAR, ITEMID, FERITEMCATEGORIZATION
,CustomerAvg_EUR, AreaAvg_EUR, ItemAvg_EUR, ItemAvgCost_EUR, CustomerAvgCost_EUR, AreaAvgCost_EUR
,CustomerAvg_USD, AreaAvg_USD, ItemAvg_USD, ItemAvgCost_USD, CustomerAvgCost_USD, AreaAvgCost_USD
,CustomerAvg_LOCAL, AreaAvg_LOCAL, ItemAvg_LOCAL, ItemAvgCost_LOCAL, CustomerAvgCost_LOCAL, AreaAvgCost_LOCAL
)
WITH  AverageItem AS ( SELECT SIA.SUBSIDIARYID AS SubsidiaryId,
	IA.CATALOG AS Catalog,
    CA.LINEOFBUSINESS,
	(date_part('year'::varchar(4), SIA.INVOICEDATE))::int AS Year,
    (sum(SIA.AMOUNT*EXCHANGERATE_EUR) / sum(SIA.INVOICEQTY)) AS ItemAvg_EUR,
    (sum(SIA.INVOICEQTY*SIA.UNITCOST*SIA.COSTEXCHANGERATE_EUR) / sum(SIA.INVOICEQTY)) AS ItemAvgCost_EUR,
    (sum(SIA.AMOUNT*EXCHANGERATE_USD) / sum(SIA.INVOICEQTY)) AS ItemAvg_USD,
    (sum(SIA.INVOICEQTY*SIA.UNITCOST*SIA.COSTEXCHANGERATE_USD) / sum(SIA.INVOICEQTY)) AS ItemAvgCost_USD,
    (sum(SIA.AMOUNT*EXCHANGERATE_LOCAL) / sum(SIA.INVOICEQTY)) AS ItemAvg_LOCAL,
    (sum(SIA.INVOICEQTY*SIA.UNITCOST*SIA.COSTEXCHANGERATE_LOCAL) / sum(SIA.INVOICEQTY)) AS ItemAvgCost_LOCAL
 FROM fersadv.SalesInvoices_ALL SIA JOIN fersadv.Customer_ALL CA ON ((SIA.CUSTOMERID = CA.CUSTOMERID) AND (SIA.SUBSIDIARYID = CA.SUBSIDIARYID)) 
 JOIN fersadv.Item_ALL IA ON ((SIA.ITEMID = IA.ITEMID) AND (SIA.SUBSIDIARYID = IA.SUBSIDIARYID))
 WHERE ((IA.ITEMTYPE = 0) AND (CA.CUSTOMERTYPE = 'EXTERNAL'::varchar(8)) AND (SIA.INVOICEQTY > 0) AND (date_part('year'::varchar(4), SIA.INVOICEDATE)::int >= date_part('year'::varchar(4), ((now())::timetz(6))::timestamp)::int - 3))
 GROUP BY SIA.SUBSIDIARYID,
 		IA.CATALOG,
        CA.LINEOFBUSINESS,
        (date_part('year'::varchar(4), SIA.INVOICEDATE))::int),  AverageCustomerItem AS ( SELECT SIA.COMPANYID AS CompanyId,
        SIA.SUBSIDIARYID AS SubsidiaryId,
        SIA.ORIGIN,
        SIA.CUSTOMERID AS CustomerId,
        CA.LINEOFBUSINESS,
        CA.CONTINENT AS Continent,
        CS.BUSINESSAREA,
        SIA.ITEMID,
        IA.CATALOG AS Catalog,
        CASE 
			WHEN SIA.FERITEMCATEGORIZATION IS NOT NULL THEN SIA.FERITEMCATEGORIZATION
			WHEN IA.FERITEMCATEGORIZATION IS NOT NULL THEN IA.FERITEMCATEGORIZATION
			ELSE 'Unset'
		END AS CATEGORIZATION,
        (date_part('year'::varchar(4), SIA.INVOICEDATE))::int AS Year,
        (sum(SIA.AMOUNT*EXCHANGERATE_EUR) / sum(SIA.INVOICEQTY)) AS CustomerAvg_EUR,
        (sum(SIA.INVOICEQTY*SIA.UNITCOST*EXCHANGERATE_EUR) / sum(SIA.INVOICEQTY)) AS CustomerAvgCost_EUR,     
        (sum(SIA.AMOUNT*EXCHANGERATE_USD) / sum(SIA.INVOICEQTY)) AS CustomerAvg_USD,
        (sum(SIA.INVOICEQTY*SIA.UNITCOST*EXCHANGERATE_USD) / sum(SIA.INVOICEQTY)) AS CustomerAvgCost_USD,
        (sum(SIA.AMOUNT*EXCHANGERATE_LOCAL) / sum(SIA.INVOICEQTY)) AS CustomerAvg_LOCAL,
        (sum(SIA.INVOICEQTY*SIA.UNITCOST*SIA.COSTEXCHANGERATE_LOCAL) / sum(SIA.INVOICEQTY)) AS CustomerAvgCost_LOCAL       
 FROM fersadv.SalesInvoices_ALL SIA JOIN fersadv.Customer_ALL CA ON ((SIA.CUSTOMERID = CA.CUSTOMERID) AND (SIA.SUBSIDIARYID = CA.SUBSIDIARYID)) 
 JOIN fersadv.Item_ALL IA ON ((SIA.ITEMID = IA.ITEMID) AND (SIA.SUBSIDIARYID = IA.SUBSIDIARYID))
 LEFT JOIN fersaParams.Country_standalone CS ON (CA.COUNTRY=CS.ISO3)
 WHERE ((IA.ITEMTYPE = 0) AND (CA.CUSTOMERTYPE = 'EXTERNAL'::varchar(8)) AND (SIA.INVOICEQTY > 0) AND (date_part('year'::varchar(4), SIA.INVOICEDATE)::int >= date_part('year'::varchar(4), ((now())::timetz(6))::timestamp)::int - 3))
 GROUP BY SIA.COMPANYID,
 		  SIA.SUBSIDIARYID,
 		  SIA.ORIGIN,
 		  SIA.CUSTOMERID,
          CA.LINEOFBUSINESS,
          CA.CONTINENT,
          CS.BUSINESSAREA,          
          SIA.ITEMID,
          IA.CATALOG,
 	      CATEGORIZATION,
          (date_part('year'::varchar(4), SIA.INVOICEDATE))::int), AverageItemArea AS ( SELECT SIA.SUBSIDIARYID AS SubsidiaryId,
        CA.LINEOFBUSINESS,
        CA.CONTINENT AS Continent,
        CS.BUSINESSAREA,
        IA.CATALOG AS Catalog,
        (date_part('year'::varchar(4), SIA.INVOICEDATE))::int AS Year,
        (sum(SIA.AMOUNT*EXCHANGERATE_EUR) / sum(SIA.INVOICEQTY)) AS ContinentAvg_EUR,
        (sum(SIA.INVOICEQTY*SIA.UNITCOST*EXCHANGERATE_EUR) / sum(SIA.INVOICEQTY)) AS ContinentAvgCost_EUR,
        (sum(SIA.AMOUNT*EXCHANGERATE_USD) / sum(SIA.INVOICEQTY)) AS ContinentAvg_USD,
        (sum(SIA.INVOICEQTY*SIA.UNITCOST*EXCHANGERATE_USD) / sum(SIA.INVOICEQTY)) AS ContinentAvgCost_USD,
        (sum(SIA.AMOUNT*EXCHANGERATE_LOCAL) / sum(SIA.INVOICEQTY)) AS ContinentAvg_LOCAL,
        (sum(SIA.INVOICEQTY*SIA.UNITCOST*SIA.COSTEXCHANGERATE_LOCAL) / sum(SIA.INVOICEQTY)) AS ContinentAvgCost_LOCAL
 FROM fersadv.SalesInvoices_ALL SIA JOIN fersadv.Customer_ALL CA ON ((SIA.CUSTOMERID = CA.CUSTOMERID) AND (SIA.SUBSIDIARYID = CA.SUBSIDIARYID))
 JOIN fersadv.Item_ALL IA ON ((SIA.ITEMID = IA.ITEMID) AND (SIA.SUBSIDIARYID = IA.SUBSIDIARYID))
 LEFT JOIN fersaParams.Country_standalone CS ON (CA.COUNTRY=CS.ISO3)
 WHERE ((IA.ITEMTYPE = 0) AND (CA.CUSTOMERTYPE = 'EXTERNAL'::varchar(8)) AND (SIA.INVOICEQTY > 0) AND (date_part('year'::varchar(4), SIA.INVOICEDATE)::int >= date_part('year'::varchar(4), ((now())::timetz(6))::timestamp)::int - 3))
 GROUP BY SIA.SUBSIDIARYID,
          CA.LINEOFBUSINESS,
          CA.CONTINENT,
          CS.BUSINESSAREA,
 	      IA.CATALOG,
          (date_part('year'::varchar(4), SIA.INVOICEDATE))::int), FINALTABLE AS (SELECT ACI.CompanyId,
  		ACI.SubsidiaryId,
  		ACI.ORIGIN,
  		ACI.CustomerId,
        ACI.ITEMID AS ItemId,
        ACI.Year,
        ACI.CATEGORIZATION AS FERITEMCATEGORIZATION,
        (ACI.CustomerAvg_EUR)::numeric(18,2) AS CustomerAvg_EUR,
        (AI.ItemAvg_EUR)::numeric(18,2) AS ItemAvg_EUR,
        (AIA.ContinentAvg_EUR)::numeric(18,2) AS AreaAvg_EUR, 
        (AI.ItemAvgCost_EUR)::numeric(18,2) AS ItemAvgCost_EUR,
        (ACI.CustomerAvgCost_EUR)::numeric(18,2) AS CustomerAvgCost_EUR,
        (AIA.ContinentAvgCost_EUR)::numeric(18,2) AS AreaAvgCost_EUR,       
        (ACI.CustomerAvg_USD)::numeric(18,2) AS CustomerAvg_USD,
        (AI.ItemAvg_USD)::numeric(18,2) AS ItemAvg_USD,
        (AIA.ContinentAvg_USD)::numeric(18,2) AS AreaAvg_USD, 
        (AI.ItemAvgCost_USD)::numeric(18,2) AS ItemAvgCost_USD,
        (ACI.CustomerAvgCost_USD)::numeric(18,2) AS CustomerAvgCost_USD,
        (AIA.ContinentAvgCost_USD)::numeric(18,2) AS AreaAvgCost_USD,
        (ACI.CustomerAvg_LOCAL)::numeric(18,2) AS CustomerAvg_LOCAL,
        (AI.ItemAvg_LOCAL)::numeric(18,2) AS ItemAvg_LOCAL,
        (AIA.ContinentAvg_LOCAL)::numeric(18,2) AS AreaAvg_LOCAL, 
        (AI.ItemAvgCost_LOCAL)::numeric(18,2) AS ItemAvgCost_LOCAL,
        (ACI.CustomerAvgCost_LOCAL)::numeric(18,2) AS CustomerAvgCost_LOCAL,
        (AIA.ContinentAvgCost_LOCAL)::numeric(18,2) AS AreaAvgCost_LOCAL
 FROM  AverageCustomerItem ACI JOIN  AverageItem AI ON ((ACI.Catalog = AI.Catalog) AND (AI.Year = ACI.Year) AND (AI.LINEOFBUSINESS = ACI.LINEOFBUSINESS) AND (AI.SubsidiaryId = ACI.SubsidiaryId))
 JOIN  AverageItemArea AIA ON ((AIA.Catalog = ACI.Catalog) AND (AIA.Year = ACI.Year) AND (AIA.LINEOFBUSINESS = ACI.LINEOFBUSINESS) AND (AIA.SubsidiaryId = ACI.SubsidiaryId) AND (AIA.Continent = ACI.Continent)))
SELECT
COMPANYID, SUBSIDIARYID, ORIGIN, CUSTOMERID, YEAR, ITEMID, FERITEMCATEGORIZATION
,CustomerAvg_EUR, AreaAvg_EUR, ItemAvg_EUR, ItemAvgCost_EUR, CustomerAvgCost_EUR, AreaAvgCost_EUR
,CustomerAvg_USD, AreaAvg_USD, ItemAvg_USD, ItemAvgCost_USD, CustomerAvgCost_USD, AreaAvgCost_USD
,CustomerAvg_LOCAL, AreaAvg_LOCAL, ItemAvg_LOCAL, ItemAvgCost_LOCAL, CustomerAvgCost_LOCAL, AreaAvgCost_LOCAL
FROM FINALTABLE;