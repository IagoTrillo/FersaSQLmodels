TRUNCATE TABLE fersads.ds_Customer_SP_NKE;

INSERT INTO fersads.ds_Customer_SP_NKE(COMPANYID,SUBSIDIARYID,CUSTOMERID,NAME,CUSTOMERGROUPNAME,CATEGORY,SECTOR,ACTIVITY,CUSTOMERTYPE,COUNTRY,CONTINENT,LINEOFBUSINESS,VATNUM,DIVISION,SALESMANAGER,SALESMANAGEREMAIL,ADMINMANAGER,ADMINMANAGEREMAIL,CURRENCYCODE,LANGUAGECODE,DELIVERYMODE,DELIVERYTERM,PRICEGROUP,DISCOUNTGROUP,INVOICEACCOUNT,COMMISSIONGROUP,CUSTGROUP,ORIGIN,MAINACCOUNTID,MAINACCOUNT,DELIVERYACCOUNT,MODELBUSINESS,WEBSHOPCUSTOMER,ISCOMPANY,DATEMODIFIED,EASYNUMBER,REPORTINGCATEGORY)
WITH
INDUSTRY AS (
SELECT		IndustryId
			,CASE
                WHEN RTRIM(IndustryId) = 'Baumaschinen' THEN 'Construction Machinery'
                WHEN RTRIM(IndustryId) = 'Rohstoffgewinnung' THEN 'Raw Material Extraction & Processing'
                WHEN RTRIM(IndustryId) = 'Metallerzeugung' THEN 'Metal Production- & Processing'
                WHEN RTRIM(IndustryId) = 'Elektr. Antriebstechnik' THEN 'Electrical Drive Technology'
                WHEN RTRIM(IndustryId) = 'Förder- und Lagertechnik' THEN 'Conveyor & Storage Technology'
                WHEN RTRIM(IndustryId) = 'Haushaltsgeräte_Werkzeuge' THEN 'White Goods, Electrical & Pneumatic Tools'
                WHEN RTRIM(IndustryId) = 'Holzbearbeitungsmaschinen' THEN 'Wood Processing Machinery'
                WHEN RTRIM(IndustryId) = 'Mechan. Antriebstechnik' THEN 'Mechanical Drive Technology'
                WHEN RTRIM(IndustryId) = 'Kunststoff und Gummi' THEN 'Sythetic Materials and Rubber'
                WHEN RTRIM(IndustryId) = 'Landtechnik_Landmaschinen' THEN 'Agricultural Machinery'
                WHEN RTRIM(IndustryId) = 'Luft- und Raumfahrt' THEN 'Aerospace'
                WHEN RTRIM(IndustryId) = 'Medizintechnik' THEN 'Medical Technology'
                WHEN RTRIM(IndustryId) = 'Nahrungsmittel_Verpackung' THEN 'Food and Packaging Industry'
                WHEN RTRIM(IndustryId) = 'Druckereimaschinen' THEN 'Printing Technology'
                WHEN RTRIM(IndustryId) = 'Fluidtechnik' THEN 'Fluids, Pumps & Compressors'
                WHEN RTRIM(IndustryId) = 'Feinmechanik und Optik' THEN 'Fine Mechanics and Optics'
                WHEN RTRIM(IndustryId) = 'Schienenfahrzeuge Trans' THEN 'Railway (Trans)'
                WHEN RTRIM(IndustryId) = 'Schienenfahrzeuge Axle Box' THEN 'Railway (Axle Box)'
                WHEN RTRIM(IndustryId) = 'Schienenfahrzeuge Traction Motor' THEN 'Railway (Traction Motor)'
                WHEN RTRIM(IndustryId) = 'Wasserfahrzeuge' THEN 'Watercraft'
                WHEN RTRIM(IndustryId) = 'Textilmaschinen' THEN 'Textile machinery'
                WHEN RTRIM(IndustryId) = 'Handel - Großhandel' THEN 'Distributor (Wholesale)'
                WHEN RTRIM(IndustryId) = 'Handel - Generaldistributor' THEN 'Distributor (General distributor)'
                WHEN RTRIM(IndustryId) = 'Energieerzeugung' THEN 'Energy Production excl. Wind & Oil'
                WHEN RTRIM(IndustryId) = 'Wehrtechnik' THEN 'Defense Technology'
                WHEN RTRIM(IndustryId) = 'Werkzeugmaschinen' THEN 'Tooling and Production Machinery'
                WHEN RTRIM(IndustryId) = 'Windkraft GENWN' THEN 'Wind (Generator)'
                WHEN RTRIM(IndustryId) = 'Windkraft TRAWN' THEN 'Wind (Trans)'
                WHEN RTRIM(IndustryId) = 'Windkraft MSB' THEN 'Wind (MSB)'
                WHEN RTRIM(IndustryId) = 'Zellstoff und Papier' THEN 'Pulp & Paper'
                WHEN RTRIM(IndustryId) = 'Sonstiges' THEN 'Other'
                WHEN RTRIM(IndustryId) = 'Automotive' THEN 'Automotive'
                WHEN RTRIM(IndustryId) = 'EDV' THEN 'Office & IT Technology'
                WHEN RTRIM(IndustryId) = 'Schrotthandel' THEN 'Scrap'
                WHEN RTRIM(IndustryId) = 'Wälzlager' THEN 'Bearing Manufacturer'
                WHEN RTRIM(IndustryId) = 'Private_Label' THEN 'Private Label'
                WHEN RTRIM(IndustryId) = 'Intercompany' THEN 'Intercompany'
                WHEN RTRIM(IndustryId) = 'Prüfinstitut' THEN 'Testing Institute'
                ELSE RTRIM(IndustryId)
            END AS ACTIVITY
			,NKE_GroupId AS SECTOR
			,NKE_DivisionId AS DIVISION
			,Industry.RecDateModified
			,Industry.SrcRecLocationId
FROM        nkeds.ds_Industry_NKE AS Industry
WHERE		UPPER(Industry.NKE_Level) = UPPER('BRANCHE') AND Industry.RecActive = 1
)
,DELIVERYTERM AS (
SELECT 		CompanyId, StdTxt AS INCOTERM, RecDateModified, SrcRecLocationId FROM (
SELECT		t1.CompanyId, t2.StdTxt, APPLY_MAX(ARRAY[t1.RecDateModified,t2.RecDateModified]) AS RecDateModified, t2.SrcRecLocationId
			,ROW_NUMBER() OVER(PARTITION BY t1.CompanyId, t2.SrcRecLocationId ORDER BY APPLY_MAX(ARRAY[t1.RecDateModified,t2.RecDateModified]) DESC, t2.Id DESC) AS i
FROM		nkeds.ds_StandardTextLink_NKE AS t1
			INNER JOIN nkeds.ds_StandardText_NKE AS t2 ON t2.StdTxt NOT IN ('LIK') AND CONCAT(CONCAT(',',t1.StdTxt),',') LIKE CONCAT(CONCAT('%,',t2.StdTxt),',%') AND UPPER(t2.Mark) = 'LB' AND UPPER(t2.Stone) = 'INCOTERM' AND ISNULL(t2.SalesFlag,0) = 1 AND t2.RecActive = 1 AND t2.SrcRecLocationId = t1.SrcRecLocationId
WHERE 		UPPER(t1.DocType) IN ('ANGEBOT','AUFTRAG','RECHNUNG') AND t1.RecActive = 1
) AS		tab WHERE i = 1
)
,DELIVERYMODE AS (
SELECT		CompanyAccountId, Name_EN AS DELIVERYMODE, RecDateModified, SrcRecLocationId FROM (
SELECT		t1.CompanyAccountId ,t2.Name_EN, APPLY_MAX(ARRAY[t1.RecDateModified,t2.RecDateModified]) AS RecDateModified, t2.SrcRecLocationId
			,ROW_NUMBER() OVER(PARTITION BY t1.CompanyAccountId, t2.SrcRecLocationId ORDER BY APPLY_MAX(ARRAY[t1.RecDateModified,t2.RecDateModified]) DESC, t1.Id DESC) AS i
FROM		nkeds.ds_NKE_TransportMode_NKE AS t1
			INNER JOIN nkeds.ds_NKE_TransportModeDef_NKE AS t2 ON t2.TransportModeId = t1.TransportModeId AND t2.SrcRecLocationId = t1.SrcRecLocationId
WHERE		ISNULL(t1.IsStandardFlag,0) = 1 AND t1.TransportModeId NOTNULL AND t1.RecActive = 1
) AS		tab WHERE i = 1
)
,WEBSHOPMAINACCOUNT AS (
SELECT		DISTINCT
			t2.CompanyAccountId AS MainAccountId
			,t1.NKE_WebshopCustomerFlag AS MainAccountWebshopEnabled
			,t1.SrcRecLocationId
FROM		nkeds.ds_CompanyAccount_NKE AS t1
			INNER JOIN nkeds.ds_Company_NKE AS t2 ON t2.CompanyId = t1.CompanyId AND t2.RecActive = 1 AND t2.SrcRecLocationId = t1.SrcRecLocationId
WHERE		ISNULL(t1.BlockedFlag,0) = 0
			AND ISNULL(t1.NKE_WebshopCustomerFlag,0) = 1
			AND t1.RecActive = 1
)
,CUSTOMER AS (
SELECT		CAST(CompanyAccount.SrcRecLocationId AS varchar(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
            ,CAST(CompanyAccount.CompanyAccountId AS varchar(80)) AS CUSTOMERID
            ,CAST(CompanyAccount.CompanyAccountName1 AS varchar(640)) AS NAME
            ,CAST(UPPER(Company.AccountingMatchCode) AS varchar(240)) AS CUSTOMERGROUPNAME
            ,CAST(Company.CustomerClassListId AS varchar(200)) AS CATEGORY
            ,CAST(INDUSTRY.SECTOR AS varchar(200)) AS SECTOR
            ,CAST(INDUSTRY.ACTIVITY AS varchar(200)) AS ACTIVITY
            ,CAST(UPPER(CASE
	            WHEN CompanyAccount.CompanyId IN ('100000') THEN 'Internal'
	            WHEN CompanyAccount.NKE_Segment IN ('Interco') OR LineOfBusiness.NKE_GroupId IN ('Interco') THEN 'Internal'
	            WHEN CompanyAccount.Industry IN ('Intercompany') THEN 'Internal'
	            ELSE 'External'
        	END) AS varchar(200)) AS CUSTOMERTYPE
            ,CAST( CASE WHEN CompanyAccount.CountryCode='XI' THEN 'GBR' ELSE Country.NKE_ISOAlpha3 END AS varchar(40)) AS COUNTRY
            ,CAST(NULL AS varchar(40)) AS CONTINENT
            ,CAST(ISNULL(LineOfBusiness.NKE_GroupId,LineOfBusinessMainAccount.NKE_GroupId) AS varchar(100)) AS LINEOFBUSINESS
            ,CAST(COALESCE(CompanyAccount.VATNumber,Company.VATNumber) AS varchar(100)) AS VATNUM
            ,CAST(INDUSTRY.DIVISION AS varchar(100)) AS DIVISION
            ,CAST(SalesManager.Name AS varchar(240)) AS SALESMANAGER
			,CAST(SalesManagerAccount.EMail AS varchar(1020)) AS SALESMANAGEREMAIL
			,CAST(Staff.Name AS varchar(240)) AS ADMINMANAGER
			,CAST(StaffAccount.EMail AS varchar(200)) AS ADMINMANAGEREMAIL
			,CAST(Company.CurrencyCode AS varchar(20)) AS CURRENCYCODE
			,CAST(CompanyAccount.Language AS varchar(28)) AS LANGUAGECODE
			,CAST(DELIVERYMODE.DELIVERYMODE AS varchar(80)) AS DELIVERYMODE
			,CAST(DELIVERYTERM.INCOTERM AS varchar(80)) AS DELIVERYTERM
			,CAST(Company.PriceCode AS varchar(40)) AS PRICEGROUP
			,CAST(NULL AS varchar(40)) AS DISCOUNTGROUP
			,CAST(CompanyAccount.InvoiceCompanyAccountId AS varchar(80)) AS INVOICEACCOUNT
			,CAST(NULL AS varchar(100)) AS COMMISSIONGROUP
			,CAST(CompanySuperordinate.Name AS varchar(120)) AS CUSTGROUP
			,CAST(NULL AS varchar(40)) AS ORIGIN
            ,CAST(Company.CompanyId AS varchar(80)) AS MAINACCOUNTID
			,CAST(Company.CompanyAccountId AS varchar(80)) AS MAINACCOUNT
			,CAST(CompanyAccount.DeliveryCompanyAccountId AS varchar(80)) AS DELIVERYACCOUNT
			,CAST(ISNULL(LineOfBusiness.ANP_SalesTargetMarket,LineOfBusinessMainAccount.ANP_SalesTargetMarket) AS varchar(40)) AS MODELBUSINESS
			,CAST(CASE WHEN ISNULL(CompanyAccount.BlockedFlag,0) <> 0 THEN 0 WHEN ISNULL(CompanyAccount.NKE_WebshopCustomerFlag,0) = 1 THEN 1 WHEN ISNULL(WEBSHOPMAINACCOUNT.MainAccountWebshopEnabled,0) = 1 THEN 1 ELSE 0 END AS INTEGER) AS WEBSHOPCUSTOMER
			,CAST(CASE WHEN Company.CompanyAccountId = CompanyAccount.CompanyAccountId THEN 1 ELSE 0 END AS INTEGER) AS ISCOMPANY
            ,CAST(APPLY_MAX(ARRAY[CompanyAccount.RecDateModified,Company.RecDateModified,CompanyMainAccount.RecDateModified,CompanySuperordinate.RecDateModified,LineOfBusiness.RecDateModified,LineOfBusinessMainAccount.RecDateModified,INDUSTRY.RecDateModified,Country.RecDateModified,SalesManager.RecDateModified,SalesManagerAccount.RecDateModified,Staff.RecDateModified,StaffAccount.RecDateModified,DELIVERYTERM.RecDateModified,DELIVERYMODE.RecDateModified]) AS timestamp) AS DATEMODIFIED
            ,CAST(Company.ANP_FactoringRef AS varchar(100)) AS EASYNUMBER
            ,CAST(ISNULL(LineOfBusiness.ANP_FERITEMCATEGORIZATIONNAME,LineOfBusinessMainAccount.ANP_FERITEMCATEGORIZATIONNAME) AS varchar(240)) AS REPORTINGCATEGORY
FROM        (SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_CompanyAccount_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_CompanyAccount_NKE AS CompanyAccount ON /*( ISNULL(CompanyAccount.CustomerFlag,0) = 1 OR ISNULL(CompanyAccount.ProspectFlag,0) = 1) AND ISNULL(CompanyAccount.StaffFlag,0) = 0 AND*/ CompanyAccount.RecActive = 1 AND CompanyAccount.SrcRecLocationId = Report.LocationId
            LEFT JOIN nkeds.ds_Company_NKE AS Company ON Company.CompanyId = CompanyAccount.CompanyId AND Company.RecActive = 1 AND Company.SrcRecLocationId = Report.LocationId
            LEFT JOIN nkeds.ds_CompanyAccount_NKE AS CompanyMainAccount ON CompanyMainAccount.CompanyAccountId = Company.CompanyAccountId AND CompanyMainAccount.RecActive = 1 AND CompanyMainAccount.SrcRecLocationId = Report.LocationId
            LEFT JOIN nkeds.ds_Company_NKE AS CompanySuperordinate ON CompanySuperordinate.CompanyId = Company.SuperordinateCompanyId AND CompanySuperordinate.RecActive = 1 AND CompanySuperordinate.SrcRecLocationId = Report.LocationId
            LEFT JOIN nkeds.ds_Industry_NKE AS LineOfBusiness ON LineOfBusiness.IndustryId = CompanyAccount.NKE_Segment AND UPPER(LineOfBusiness.NKE_Level) = UPPER('VERTRIEBSWEG') AND LineOfBusiness.RecActive = 1 AND LineOfBusiness.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Industry_NKE AS LineOfBusinessMainAccount ON LineOfBusinessMainAccount.IndustryId = CompanyMainAccount.NKE_Segment AND UPPER(LineOfBusinessMainAccount.NKE_Level) = UPPER('VERTRIEBSWEG') AND LineOfBusinessMainAccount.RecActive = 1 AND LineOfBusinessMainAccount.SrcRecLocationId = Report.LocationId
			LEFT JOIN INDUSTRY ON INDUSTRY.IndustryId = CompanyAccount.Industry AND INDUSTRY.SrcRecLocationId = Report.LocationId
            LEFT JOIN nkeds.ds_Country_NKE AS Country ON Country.CountryCode = CompanyAccount.CountryCode AND Country.RecActive = 1 AND Country.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Representative_NKE AS SalesManager ON SalesManager.RepresentativeId = ISNULL(CompanyAccount.RepresentativeId,CompanyAccount.RepresentativeI2Id) AND SalesManager.RecActive = 1 AND SalesManager.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_CompanyAccount_NKE AS SalesManagerAccount ON SalesManagerAccount.CompanyAccountId = SalesManager.CompanyAccountId AND SalesManagerAccount.RecActive = 1 AND SalesManagerAccount.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Staff_NKE AS Staff ON Staff.StaffId = CompanyAccount.StaffId AND Staff.RecActive = 1 AND Staff.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_CompanyAccount_NKE AS StaffAccount ON StaffAccount.CompanyAccountId = Staff.CompanyAccountId AND StaffAccount.RecActive = 1 AND StaffAccount.SrcRecLocationId = Report.LocationId
			LEFT JOIN DELIVERYTERM ON DELIVERYTERM.CompanyId = CompanyAccount.CompanyId AND DELIVERYTERM.SrcRecLocationId = Report.LocationId
			LEFT JOIN DELIVERYMODE ON DELIVERYMODE.CompanyAccountId = CompanyAccount.CompanyAccountId AND DELIVERYMODE.SrcRecLocationId = Report.LocationId
            LEFT JOIN WEBSHOPMAINACCOUNT ON WEBSHOPMAINACCOUNT.MainAccountId = CompanyAccount.CompanyAccountId AND WEBSHOPMAINACCOUNT.SrcRecLocationId = Report.LocationId
WHERE 		ISNULL(COALESCE(NULLIF(CompanyAccount.CustomerFlag,0),NULLIF(CompanyAccount.ProspectFlag,0),NULLIF(Company.CustomerFlag,0),NULLIF(Company.NKE_ProspectFlag,0)),0) = 1
			OR CompanyAccount.CompanyAccountId IN (SELECT t.CompanyAccountId FROM nkeds.ds_SalesOrder_NKE AS t)
			OR CompanyAccount.CompanyAccountId IN (SELECT t.InvoiceCompanyAccountId FROM nkeds.ds_SalesOrder_NKE AS t)
			OR CompanyAccount.CompanyAccountId IN (SELECT t.CompanyAccountId FROM nkeds.ds_SalesInvoice_NKE AS t)
			OR CompanyAccount.CompanyAccountId IN (SELECT t.InvoiceCompanyAccountId FROM nkeds.ds_SalesInvoice_NKE AS t)
/*ORDER BY 	CompanyAccount.CompanyAccountId ASC*/
)
SELECT * FROM CUSTOMER;