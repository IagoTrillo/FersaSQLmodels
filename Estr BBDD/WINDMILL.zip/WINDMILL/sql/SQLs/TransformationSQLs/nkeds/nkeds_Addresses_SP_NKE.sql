TRUNCATE TABLE fersads.ds_Addresses_SP_NKE;

INSERT INTO fersads.ds_Addresses_SP_NKE
(SUBSIDIARYID, EMAIL, COMPANYACCOUNTID, EXTERNALADDRESSID, POSTCODE, COUNTRY, "MINVALUE", "MAXVALUE", COMPANYACCOUNTNAME1, SUFFIX, PRIORITY, DELIVERYACCOUNT, MAXWEIGHT, MODIFIEDDATE, DELIVERYACCOUNTNAME1, PHONE, VATNUMBER, FAX, STREET, STREET2, CITY, REGION, COMPANYID, INVOICEACCOUNT, INVOICEACCOUNTNAME1, INVOICEPHONE, INVOICEVATNUMBER, INVOICEFAX, INVOICESTREET, INVOICESTREET2, INVOICECITY, INVOICEREGION, INVOICEPOSTCODE, INVOICECOUNTRY)
WITH
WEBSHOPTRANSPORTMODES AS (
SELECT		CompanyAccountId, VolumeMin, VolumeMax, MaxWeight, RecDateModified, SrcRecLocationId, ROW_NUMBER() OVER(PARTITION BY CompanyAccountId ORDER BY ISNULL(IsStandardFlag,0) DESC, Id DESC) AS i
FROM		nkeds.ds_NKE_TransportMode_NKE
WHERE 		RecActive = 1
			AND TransportModeId = 11
)
,WEBSHOPDELIVERYADDRESSES AS (
SELECT		CA.COMPANYID
			,CA.SUBSIDIARYID
			,CAST(CASE WHEN ISNULL(CA.WEBSHOPCUSTOMER,0) = 0 THEN NULL ELSE CompanyAccount.Email END AS VARCHAR(2000)) AS EMAIL
			,CAST(CA.CUSTOMERID AS VARCHAR(2000)) AS COMPANYACCOUNTID
			,CAST(NULL AS VARCHAR(1)) AS EXTERNALADDRESSID
			,CAST(CA.NAME AS VARCHAR(2000)) AS COMPANYACCOUNTNAME1
			,CAST(NULL AS VARCHAR(1)) AS SUFFIX
			,CAST(CASE
				WHEN CompanyDeliveryAccounts.CompanyAccountId IS NULL THEN NULL
				ELSE ROW_NUMBER() OVER(PARTITION BY CA.CUSTOMERID, CA.SUBSIDIARYID ORDER BY (CASE WHEN CA.DELIVERYACCOUNT = CompanyDeliveryAccounts.CompanyAccountId THEN 1 ELSE 0 END) DESC, CompanyDeliveryAccounts.CompanyAccountId ASC)
			END AS INT) AS PRIORITY
			,CompanyDeliveryAccounts.CompanyAccountId AS DELIVERYACCOUNT
			,CAST(CompanyDeliveryAccounts.CompanyAccountName1 AS VARCHAR(2000)) AS DELIVERYACCOUNTNAME1
			,CAST(ISNULL(CompanyDeliveryAccounts.Phone,'+43 000 000') AS VARCHAR(2000)) AS PHONE
			,CAST(CompanyDeliveryAccounts.VATNumber AS VARCHAR(2000)) AS VATNUMBER
			,CAST(CompanyDeliveryAccounts.Fax AS VARCHAR(2000)) AS FAX
			,CAST(CompanyDeliveryAccounts.Street AS VARCHAR(2000)) AS STREET
			,CAST(CompanyDeliveryAccounts.Street2 AS VARCHAR(2000)) AS STREET2
			,CAST(CompanyDeliveryAccounts.City AS VARCHAR(2000)) AS CITY
			,CAST(CompanyDeliveryAccounts.NKE_AdministrativeDistrict AS VARCHAR(2000)) AS REGION
			,CAST(ISNULL(CompanyDeliveryAccounts.PostCode,'-') AS VARCHAR(2000)) AS POSTCODE
			,CAST(CountryDelivery.NKE_ISOAlpha3 AS VARCHAR(2000)) AS COUNTRY
			,CAST(WEBSHOPTRANSPORTMODES.VolumeMin AS NUMERIC(32,6)) AS MINVALUE
			,CAST(WEBSHOPTRANSPORTMODES.VolumeMax AS NUMERIC(32,6)) AS MAXVALUE
			,CAST(WEBSHOPTRANSPORTMODES.MaxWeight AS NUMERIC(32,6)) AS MAXWEIGHT
			,CAST(CompanyInvoiceAccount.CompanyAccountId AS VARCHAR(2000)) AS INVOICEACCOUNT
			,CAST(CompanyInvoiceAccount.CompanyAccountName1 AS VARCHAR(2000)) AS INVOICEACCOUNTNAME1
			,CAST(ISNULL(CompanyInvoiceAccount.Phone,'+43 000 000') AS VARCHAR(2000)) AS INVOICEPHONE
			,CAST(CompanyInvoiceAccount.VATNumber AS VARCHAR(2000)) AS INVOICEVATNUMBER
			,CAST(CompanyInvoiceAccount.Fax AS VARCHAR(2000)) AS INVOICEFAX
			,CAST(CompanyInvoiceAccount.Street AS VARCHAR(2000)) AS INVOICESTREET
			,CAST(CompanyInvoiceAccount.Street2 AS VARCHAR(2000)) AS INVOICESTREET2
			,CAST(CompanyInvoiceAccount.City AS VARCHAR(2000)) AS INVOICECITY
			,CAST(CompanyInvoiceAccount.NKE_AdministrativeDistrict AS VARCHAR(2000)) AS INVOICEREGION
			,CAST(ISNULL(CompanyInvoiceAccount.PostCode,'-') AS VARCHAR(2000)) AS INVOICEPOSTCODE
			,CAST(CountryInvoice.NKE_ISOAlpha3 AS VARCHAR(2000)) AS INVOICECOUNTRY
			,APPLY_MAX(ARRAY[CompanyAccount.RecDateModified,Company.RecDateModified,CompanyDeliveryAccounts.RecDateModified,CountryDelivery.RecDateModified,WEBSHOPTRANSPORTMODES.RecDateModified,CompanyInvoiceAccount.RecDateModified,CountryInvoice.RecDateModified]) AS MODIFIEDDATE
FROM		fersads.ds_Customer_SP_NKE AS CA
			LEFT JOIN fersaParams.CompanyLocation_standalone CL ON CL.LOCATIONID = CA.SUBSIDIARYID
			LEFT JOIN nkeds.ds_CompanyAccount_NKE AS CompanyAccount ON CompanyAccount.CompanyAccountId = CA.CUSTOMERID AND CompanyAccount.RecActive = 1 AND CompanyAccount.SrcRecLocationId = CA.COMPANYID
			LEFT JOIN nkeds.ds_Company_NKE AS Company ON Company.CompanyId = CompanyAccount.CompanyId AND Company.RecActive = 1 AND Company.SrcRecLocationId = CA.COMPANYID
			LEFT JOIN nkeds.ds_CompanyAccount_NKE AS CompanyDeliveryAccountsSelect ON CompanyDeliveryAccountsSelect.CompanyId = Company.CompanyId AND ISNULL(CompanyDeliveryAccountsSelect.BlockedFlag,0) = 0 AND ISNULL(CompanyDeliveryAccountsSelect.DeliveryFlag,0) = 1 AND CompanyDeliveryAccountsSelect.CompanyAccountName1 IS NOT NULL AND CompanyDeliveryAccountsSelect.RecActive = 1 AND CompanyDeliveryAccountsSelect.SrcRecLocationId = CA.COMPANYID
			LEFT JOIN nkeds.ds_CompanyAccount_NKE AS CompanyDeliveryAccounts ON CompanyDeliveryAccounts.CompanyAccountId = ISNULL(CompanyDeliveryAccountsSelect.CompanyAccountId,CompanyAccount.DeliveryCompanyAccountId) AND CompanyDeliveryAccounts.RecActive = 1 AND CompanyDeliveryAccounts.SrcRecLocationId = CA.COMPANYID
			LEFT JOIN nkeds.ds_Country_NKE AS CountryDelivery ON CountryDelivery.CountryCode = CompanyDeliveryAccounts.CountryCode AND CountryDelivery.RecActive = 1 AND CountryDelivery.SrcReclocationId = CA.COMPANYID
			LEFT JOIN WEBSHOPTRANSPORTMODES ON WEBSHOPTRANSPORTMODES.CompanyAccountId = CompanyDeliveryAccounts.CompanyAccountId AND WEBSHOPTRANSPORTMODES.i = 1 AND WEBSHOPTRANSPORTMODES.SrcRecLocationId = CA.COMPANYID
			LEFT JOIN nkeds.ds_CompanyAccount_NKE AS CompanyInvoiceAccount ON CompanyInvoiceAccount.CompanyAccountId = CA.InvoiceAccount AND CompanyInvoiceAccount.SrcRecLocationId = CA.COMPANYID
			LEFT JOIN nkeds.ds_Country_NKE AS CountryInvoice ON CountryInvoice.CountryCode = CompanyInvoiceAccount.CountryCode AND CountryInvoice.RecActive = 1 AND CountryInvoice.SrcReclocationId = CA.COMPANYID
WHERE		( ISNULL(CA.WEBSHOPCUSTOMER,0) = 1
			OR (ISNULL(CA.ISCOMPANY,0) = 1 AND EXISTS (SELECT CA2.CUSTOMERID FROM fersads.ds_Customer_SP_NKE AS CA2 WHERE CA2.MAINACCOUNTID = CA.MAINACCOUNTID AND ISNULL(CA2.WEBSHOPCUSTOMER,0) = 1 AND CA2.SUBSIDIARYID = CA.SUBSIDIARYID))
			) AND CA.SUBSIDIARYID = 'NAUT'
)
SELECT SUBSIDIARYID, EMAIL, COMPANYACCOUNTID, EXTERNALADDRESSID, POSTCODE, COUNTRY, "MINVALUE", "MAXVALUE", COMPANYACCOUNTNAME1, SUFFIX, PRIORITY, DELIVERYACCOUNT, MAXWEIGHT, MODIFIEDDATE, DELIVERYACCOUNTNAME1, PHONE, VATNUMBER, FAX, STREET, STREET2, CITY, REGION, COMPANYID, INVOICEACCOUNT, INVOICEACCOUNTNAME1, INVOICEPHONE, INVOICEVATNUMBER, INVOICEFAX, INVOICESTREET, INVOICESTREET2, INVOICECITY, INVOICEREGION, INVOICEPOSTCODE, INVOICECOUNTRY FROM WEBSHOPDELIVERYADDRESSES;