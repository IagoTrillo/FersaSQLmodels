TRUNCATE TABLE fersads.ds_ItemBatchPurchase_SP_NKE;

INSERT INTO fersads.ds_ItemBatchPurchase_SP_NKE (
    COMPANYID,
    SUBSIDIARYID,
    SUPPLIERID,
    ITEMID,
    BATCHID,
    QUANTITY,
	RECEIPTDATE,
    PHYSICALDATE,
    UNITCOSTMAT,
    UNITCOST
)
WITH
COSTS AS (
SELECT		WarehouseStockMovement.DocumentNumber
			,SUM(CASE WHEN ISNULL(CostElement.IgnoreFlag,0) = 0 AND CostElement.CostElementId IN ('K01') THEN WarehouseStockMovementCosts.ElementValue ELSE NULL END) AS COSTSMAT
			,SUM(CASE WHEN ISNULL(CostElement.IgnoreFlag,0) = 0 THEN WarehouseStockMovementCosts.ElementValue ELSE NULL END) AS COSTS
			,WarehouseStockMovement.SrcRecLocationId
FROM		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_WarehouseStockMovement_NKE AS WarehouseStockMovement ON WarehouseStockMovement.Type IN ('WE','DF') AND ISNULL(WarehouseStockMovement.Quantity,0) <> 0 AND ISNULL(WarehouseStockMovement.Mode,0) IN (0,2) AND ISNULL(WarehouseStockMovement.CanceledFlag,0) = 0 AND ISNULL(WarehouseStockMovement.NoStockFlag,0) = 0 AND WarehouseStockMovement.RecActive = 1 AND WarehouseStockMovement.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = WarehouseStockMovement.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_WarehouseStockMovementElement_NKE AS WarehouseStockMovementCosts ON ISNULL(WarehouseStockMovementCosts.AverageFlag,0) = 1 AND WarehouseStockMovementCosts.DocumentNumber = WarehouseStockMovement.DocumentNumber AND WarehouseStockMovementCosts.RecActive = 1 AND WarehouseStockMovementCosts.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_CostElement_NKE AS CostElement ON CostElement.CostElementId = WarehouseStockMovementCosts.CostElementId AND CostElement.RecActive = 1 AND CostElement.SrcRecLocationId = Report.LocationId
GROUP BY	WarehouseStockMovement.DocumentNumber
			,WarehouseStockMovement.SrcRecLocationId
)
,MOVEMENTS AS (
SELECT		CAST(WarehouseStockMovement.SrcRecLocationId AS varchar(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
			,ISNULL(WarehouseStockMovement.OriginDocumentNumber,WarehouseStockMovement.DocumentNumber) AS DocumentNumberROOT
			,WarehouseStockMovement.DocumentNumber AS DocumentNumber
			,GoodsReceipt.CompanyAccountId AS SUPPLIERID
			,GoodsReceiptLine.LineType
			,WarehouseStockMovement.ItemId AS ITEMID
			,WarehouseStockMovement.BatchId AS BATCH
			,CAST((CASE WHEN ISNULL(WarehouseStockMovement.Mode,0) = 0 THEN WarehouseStockMovement.Quantity ELSE NULL END) AS NUMERIC(32,6)) AS QUANTITY
			,CAST(CAST(COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate) AS DATE) AS DATETIME) AS RECEIPTDATE
			,CAST(CAST(MIN(WarehouseStockMovement.Insdate) OVER(PARTITION BY ISNULL(WarehouseStockMovement.OriginDocumentNumber,WarehouseStockMovement.DocumentNumber), Report.LocationId ORDER BY WarehouseStockMovement.Insdate ASC) AS DATE) AS DATETIME) AS PHYSICALDATE
			,CAST(COSTS.COSTSMAT AS NUMERIC(32,6)) AS COSTSMAT
			,CAST(COSTS.COSTS AS NUMERIC(32,6)) AS COSTS
FROM        (SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_WarehouseStockMovement_NKE AS WarehouseStockMovement ON WarehouseStockMovement.Type IN ('WE','DF') AND ISNULL(WarehouseStockMovement.Quantity,0) <> 0 AND ISNULL(WarehouseStockMovement.Mode,0) IN (0,2) AND ISNULL(WarehouseStockMovement.CanceledFlag,0) = 0 AND ISNULL(WarehouseStockMovement.NoStockFlag,0) = 0 AND WarehouseStockMovement.RecActive = 1 AND WarehouseStockMovement.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = WarehouseStockMovement.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_GoodsReceiptLine_NKE AS GoodsReceiptLine ON GoodsReceiptLine.GoodsReceiptId = WarehouseStockMovement.WorkOrderId AND GoodsReceiptLine.LineId = WarehouseStockMovement.LineId AND GoodsReceiptLine.RecActive = 1 AND GoodsReceiptLine.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_GoodsReceipt_NKE AS GoodsReceipt ON GoodsReceipt.GoodsReceiptId = WarehouseStockMovement.WorkOrderId AND GoodsReceipt.RecActive = 1 AND GoodsReceipt.SrcRecLocationId = Report.LocationId
			LEFT JOIN COSTS ON COSTS.DocumentNumber = WarehouseStockMovement.DocumentNumber
)
,RECEIPTS AS (
SELECT		CAST(GoodsReceiptLine.SrcRecLocationId AS varchar(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
			,GoodsReceipt.CompanyAccountId AS SUPPLIERID
			,GoodsReceiptLine.ItemId AS ITEMID
			,COALESCE(GoodsReceiptLine.BatchId,GoodsReceiptLine.NKE_PreBatchId,PurchaseOrderLine.BatchId,PurchaseOrderLine.NKE_PreBatchId) AS BATCH
			,GoodsReceiptLine.DeliveryQuantity AS QUANTITY
			,CAST(CAST(COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate) AS DATE) AS DATETIME) AS RECEIPTDATE
			,CAST(NULL AS DATETIME) AS PHYSICALDATE
			,CAST(NULL AS NUMERIC(32,6)) AS COSTSMAT
			,CAST(NULL AS NUMERIC(32,6)) AS COSTS
FROM		(SELECT CAST(RecDateModified AS DATE) AS ReportDate, SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' ORDER BY RecId DESC LIMIT 1) AS Report
			INNER JOIN nkeds.ds_GoodsReceiptLine_NKE AS GoodsReceiptLine ON GoodsReceiptLine.Status <= 4 AND ISNULL(GoodsReceiptLine.DeliveryQuantity,0) > 0 AND GoodsReceiptLine.LineType IN ('WE') AND GoodsReceiptLine.RecActive = 1 AND GoodsReceiptLine.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_GoodsReceipt_NKE AS GoodsReceipt ON GoodsReceipt.GoodsReceiptId = GoodsReceiptLine.GoodsReceiptId AND GoodsReceiptLine.RecActive = 1 AND GoodsReceipt.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = GoodsReceiptLine.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_PurchaseOrderLine_NKE AS PurchaseOrderLine ON COALESCE(GoodsReceiptLine.BatchId,GoodsReceiptLine.NKE_PreBatchId) IS NULL AND  PurchaseOrderLine.PurchaseOrderId = GoodsReceiptLine.PurchaseOrderId AND PurchaseOrderLine.LineId = GoodsReceiptLine.PurchaseOrderLineId
WHERE		NOT EXISTS (SELECT x.Id FROM nkeds.ds_WarehouseStockMovement_NKE AS x WHERE x.Type IN ('WE','DF') AND ISNULL(x.Quantity,0) <> 0 AND ISNULL(x.Mode,0) IN (0,2) AND ISNULL(x.CanceledFlag,0) = 0 AND ISNULL(x.NoStockFlag,0) = 0 AND x.WorkOrderId = GoodsReceiptLine.GoodsReceiptId AND x.LineId = GoodsReceiptLine.LineId AND x.RecActive = 1 AND x.SrcRecLocationId = Report.LocationId)
			AND CAST(COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate) AS DATE) IS NOT NULL
			AND CAST(COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate) AS DATE) <= Report.ReportDate
)
,MOVEMENTS_AGGREGATED AS (
SELECT		CAST(MOVEMENTS.COMPANYID AS varchar(40)) AS COMPANYID
			,CAST(MOVEMENTS.SUBSIDIARYID AS VARCHAR(80)) AS SUBSIDIARYID
			,CAST(MOVEMENTS.SUPPLIERID AS VARCHAR(80)) AS SUPPLIERID
			,CAST(MOVEMENTS.ITEMID AS VARCHAR(160)) AS ITEMID
			,CAST(MOVEMENTS.BATCH AS VARCHAR(160)) AS BATCHID
			,CAST(SUM(MOVEMENTS.QUANTITY) AS NUMERIC(32,6)) AS QUANTITY
			,CAST(MOVEMENTS.RECEIPTDATE AS TIMESTAMP(6)) AS RECEIPTDATE
			,CAST(MOVEMENTS.PHYSICALDATE AS TIMESTAMP(6)) AS PHYSICALDATE
			,CAST(CAST(SUM(MOVEMENTS.COSTSMAT)/SUM(MOVEMENTS.QUANTITY) AS NUMERIC(32,2)) AS NUMERIC(32,6)) AS UNITCOSTMAT
			,CAST(CAST(SUM(MOVEMENTS.COSTS)/SUM(MOVEMENTS.QUANTITY) AS NUMERIC(32,2)) AS NUMERIC(32,6)) AS UNITCOST
FROM		MOVEMENTS
GROUP BY	MOVEMENTS.COMPANYID
			,MOVEMENTS.SUBSIDIARYID
			,MOVEMENTS.SUPPLIERID
			,MOVEMENTS.ITEMID
			,MOVEMENTS.BATCH
			,MOVEMENTS.RECEIPTDATE
			,MOVEMENTS.PHYSICALDATE
)
,RECEIPTS_AGGREGATED AS (
SELECT		CAST(RECEIPTS.COMPANYID AS varchar(40)) AS COMPANYID
			,CAST(RECEIPTS.SUBSIDIARYID AS VARCHAR(80)) AS SUBSIDIARYID
			,CAST(RECEIPTS.SUPPLIERID AS VARCHAR(80)) AS SUPPLIERID
			,CAST(RECEIPTS.ITEMID AS VARCHAR(160)) AS ITEMID
			,CAST(RECEIPTS.BATCH AS VARCHAR(160)) AS BATCHID
			,CAST(SUM(RECEIPTS.QUANTITY) AS NUMERIC(32,6)) AS QUANTITY
			,CAST(RECEIPTS.RECEIPTDATE AS TIMESTAMP(6)) AS RECEIPTDATE
			,CAST(RECEIPTS.PHYSICALDATE AS TIMESTAMP(6)) AS PHYSICALDATE
			,CAST(CAST(SUM(RECEIPTS.COSTSMAT)/SUM(RECEIPTS.QUANTITY) AS NUMERIC(32,2)) AS NUMERIC(32,6)) AS UNITCOSTMAT
			,CAST(CAST(SUM(RECEIPTS.COSTS)/SUM(RECEIPTS.QUANTITY) AS NUMERIC(32,2)) AS NUMERIC(32,6)) AS UNITCOST
FROM		RECEIPTS
GROUP BY	RECEIPTS.COMPANYID
			,RECEIPTS.SUBSIDIARYID
			,RECEIPTS.SUPPLIERID
			,RECEIPTS.ITEMID
			,RECEIPTS.BATCH
			,RECEIPTS.RECEIPTDATE
			,RECEIPTS.PHYSICALDATE
)
SELECT COMPANYID, SUBSIDIARYID, SUPPLIERID, ITEMID, BATCHID, QUANTITY, RECEIPTDATE, PHYSICALDATE, UNITCOSTMAT, UNITCOST FROM MOVEMENTS_AGGREGATED
UNION ALL
SELECT COMPANYID, SUBSIDIARYID, SUPPLIERID, ITEMID, BATCHID, QUANTITY, RECEIPTDATE, PHYSICALDATE, UNITCOSTMAT, UNITCOST FROM RECEIPTS_AGGREGATED;