TRUNCATE TABLE fersads.ds_InventTransitPurchase_SP_NKE;

INSERT INTO fersads.ds_InventTransitPurchase_SP_NKE(COMPANYID,SUBSIDIARYID,ITEMID,PHYSICALINVENT,RESERVPHYSICAL,PICKED,INVENTBATCHID,INVENTLOCATIONID,INVENTSERIALID,INVENTSITEID,INVENTSIZEID,INVENTSTATUSID,INVENTSTYLEID,LICENSEPLATEID,WMSLOCATIONID,RECTYPE,UNITCOST,CURRENCYCODE,EXCHANGERATE_EUR,EXCHANGERATE_USD) 
WITH
RECEIPTSTATUS AS (
SELECT CAST(1 AS INTEGER) AS Status, CAST('TRANSIT' AS VARCHAR(20)) AS StatusName
UNION ALL SELECT CAST(2 AS INTEGER) AS Status, CAST('ARRIVED' AS VARCHAR(20)) AS StatusName
UNION ALL SELECT CAST(3 AS INTEGER) AS Status, CAST('ARRIVED' AS VARCHAR(20)) AS StatusName
UNION ALL SELECT CAST(4 AS INTEGER) AS Status, CAST('INSTOCK' AS VARCHAR(20)) AS StatusName
)
,INVENTTRANSITPURCHASEPAID AS (
SELECT		* FROM (
SELECT		PurchaseOrderLine.PurchaseOrderId
			,PurchaseOrderLine.LineId AS PurchaseOrderLineId
			,ReferenceTable.GoodsReceiptId
			,ReferenceTable.GoodsReceiptLineId
			,GoodsReceiptLine.Status AS GoodsReceiptLineStatus
			,ROW_NUMBER() OVER(PARTITION BY ReferenceTable.GoodsReceiptId, ReferenceTable.GoodsReceiptLineId ORDER BY (CASE WHEN PurchaseSupplierInvoiceLine.Status < 4 AND PurchaseSupplierInvoice.Status = 4 THEN PurchaseSupplierInvoice.Status ELSE PurchaseSupplierInvoice.Status END) DESC, ReferenceTable.PurchaseSupplierInvoiceId ASC) AS i
			,CASE WHEN PurchaseSupplierInvoiceLine.Status < 4 AND PurchaseSupplierInvoice.Status = 4 THEN PurchaseSupplierInvoice.Status ELSE PurchaseSupplierInvoice.Status END AS PurchaseSupplierInvoiceLineStatus
			,COALESCE(PurchaseSupplierInvoice.PostingPeriod,PurchaseSupplierInvoice.ValutaDate,PurchaseSupplierInvoice.InvoiceDate,PurchaseSupplierInvoice.Date) AS PurchaseSupplierInvoicePostingPeriod
			,ReferenceTable.SrcRecLocationId
FROM		nkeds.ds_GoodsReceiptLinePurchaseSupplierInvoiceReference_NKE AS ReferenceTable
			INNER JOIN nkeds.ds_PurchaseSupplierInvoiceLine_NKE AS PurchaseSupplierInvoiceLine ON PurchaseSupplierInvoiceLine.PurchaseSupplierInvoiceId = ReferenceTable.PurchaseSupplierInvoiceId AND PurchaseSupplierInvoiceLine.LineId = ReferenceTable.PurchaseSupplierInvoiceLineId AND ISNULL(PurchaseSupplierInvoiceLine.Status,0) <> 5 AND PurchaseSupplierInvoiceLine.RecActive = 1 AND PurchaseSupplierInvoiceLine.SrcRecLocationId = ReferenceTable.SrcRecLocationId
			INNER JOIN nkeds.ds_PurchaseSupplierInvoice_NKE AS PurchaseSupplierInvoice ON PurchaseSupplierInvoice.PurchaseSupplierInvoiceId = PurchaseSupplierInvoiceLine.PurchaseSupplierInvoiceId AND ISNULL(PurchaseSupplierInvoice.Status,0) <> 5 AND COALESCE(NULLIF(PurchaseSupplierInvoice.CarrierFlag,0),NULLIF(PurchaseSupplierInvoice.ANP_AirFreightFlag,0),NULLIF(ANP_RailwayFreightFlag,0),0) = 0 AND PurchaseSupplierInvoice.RecActive = 1 AND PurchaseSupplierInvoice.SrcRecLocationId = ReferenceTable.SrcRecLocationId
			INNER JOIN nkeds.ds_GoodsReceiptLine_NKE AS GoodsReceiptLine ON GoodsReceiptLine.GoodsReceiptId = ReferenceTable.GoodsReceiptId AND GoodsReceiptLine.Status < 4 AND GoodsReceiptLine.LineId = ReferenceTable.GoodsReceiptLineId AND GoodsReceiptLine.RecActive = 1 AND GoodsReceiptLine.SrcRecLocationId = ReferenceTable.SrcRecLocationId
			INNER JOIN nkeds.ds_GoodsReceipt_NKE AS GoodsReceipt ON GoodsReceipt.GoodsReceiptId = GoodsReceiptLine.GoodsReceiptId AND GoodsReceipt.Status < 4 AND GoodsReceipt.RecActive = 1 AND GoodsReceipt.SrcRecLocationId = ReferenceTable.SrcRecLocationId
			LEFT JOIN nkeds.ds_PurchaseOrderLine_NKE AS PurchaseOrderLine ON PurchaseOrderLine.PurchaseOrderId = GoodsReceiptLine.PurchaseOrderId AND PurchaseOrderLine.LineId = GoodsReceiptLine.PurchaseOrderLineId AND PurchaseOrderLine.RecActive = 1 AND PurchaseOrderLine.SrcRecLocationId = ReferenceTable.SrcRecLocationId
			LEFT JOIN nkeds.ds_PurchaseOrder_NKE AS PurchaseOrder ON PurchaseOrder.PurchaseOrderId = PurchaseOrderLine.PurchaseOrderId AND PurchaseOrder.RecActive = 1 AND PurchaseOrder.SrcRecLocationId = ReferenceTable.SrcRecLocationId
WHERE 		ReferenceTable.RecActive = 1
) AS		TAB
WHERE		PurchaseSupplierInvoiceLineStatus = 4
			AND CAST(PurchaseSupplierInvoicePostingPeriod AS DATE) <= CAST(NOW() AS DATE)
)
,INVENTTRANSITPURCHASE AS (
SELECT		CAST(Report.LocationId AS VARCHAR(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
			,CAST(GoodsReceiptLine.ItemId AS VARCHAR(160)) AS ITEMID
			,CAST(GoodsReceiptLine.DeliveryQuantity AS NUMERIC(32,6)) AS PHYSICALINVENT
			,CAST(GoodsReceiptLine.DeliveryQuantity AS NUMERIC(32,6)) AS RESERVPHYSICAL
			,CAST(0/*GoodsReceiptLine.DeliveryQuantity*/ AS NUMERIC(32,6)) AS PICKED
			,CAST(GoodsReceiptLine.BatchId AS VARCHAR(80)) AS INVENTBATCHID
			,CAST(CASE WHEN RECEIPTSTATUS.StatusName = 'ARRIVED' THEN 'NAUT' ELSE CONCAT('T_',GoodsReceipt.CompanyAccountId) END AS VARCHAR(80)) AS INVENTLOCATIONID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSERIALID
			,CAST('NAUT' AS VARCHAR(80)) AS INVENTSITEID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSIZEID
			,CAST(CASE WHEN RECEIPTSTATUS.StatusName = 'ARRIVED' THEN 'Available' ELSE 'Transit' END AS VARCHAR(40)) AS INVENTSTATUSID
			,CAST(ISNULL(Item.MaterialGroupId,'GEN') AS VARCHAR(40)) AS INVENTSTYLEID
			,CAST(NULL AS VARCHAR(400)) AS LICENSEPLATEID
			,CAST(CASE WHEN RECEIPTSTATUS.StatusName = 'ARRIVED' THEN CONCAT('T_',GoodsReceipt.CompanyAccountId) ELSE GoodsReceipt.CompanyAccountId END AS VARCHAR(40)) AS WMSLOCATIONID
			,CAST(NULL AS NUMERIC(32,6)) AS RECTYPE
			,CAST(CASE WHEN ISNULL(PurchaseOrderLine.FreeOfChargeFlag,0) = 1 THEN 0 ELSE ISNULL(PurchaseOrderLine.CostsPerUnit,0) END AS NUMERIC(32,6)) AS UNITCOST
			,CAST(REPLACE(PurchaseOrder.CurrencyCode,'SFr','CHF') AS VARCHAR(20)) AS CURRENCYCODE
			,CAST(1.00/ISNULL(CAST(PurchaseOrder.DmFactor AS NUMERIC(32,6)),1.000) AS NUMERIC(32,6)) AS EXCHANGERATE_EUR
    		,CAST(NULL AS NUMERIC(32,6)) AS EXCHANGERATE_USD
FROM		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_GoodsReceiptLine_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_GoodsReceiptLine_NKE AS GoodsReceiptLine ON GoodsReceiptLine.Status < 4 AND GoodsReceiptLine.RecActive = 1 AND GoodsReceiptLine.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_GoodsReceipt_NKE AS GoodsReceipt ON GoodsReceipt.GoodsReceiptId = GoodsReceiptLine.GoodsReceiptId AND GoodsReceipt.Status < 4 AND GoodsReceipt.RecActive = 1 AND GoodsReceipt.SrcRecLocationId = Report.LocationId
			LEFT JOIN RECEIPTSTATUS ON RECEIPTSTATUS.Status = GoodsReceiptLine.Status
			INNER JOIN INVENTTRANSITPURCHASEPAID ON INVENTTRANSITPURCHASEPAID.GoodsReceiptId = GoodsReceiptLine.GoodsReceiptId AND INVENTTRANSITPURCHASEPAID.GoodsReceiptLineId = GoodsReceiptLine.LineId AND INVENTTRANSITPURCHASEPAID.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_PurchaseOrderLine_NKE AS PurchaseOrderLine ON PurchaseOrderLine.PurchaseOrderId = GoodsReceiptLine.PurchaseOrderId AND PurchaseOrderLine.LineId = GoodsReceiptLine.PurchaseOrderLineId AND PurchaseOrderLine.RecActive = 1 AND PurchaseOrderLine.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_PurchaseOrder_NKE AS PurchaseOrder ON PurchaseOrder.PurchaseOrderId = PurchaseOrderLine.PurchaseOrderId AND PurchaseOrder.RecActive = 1 AND PurchaseOrder.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = GoodsReceiptLine.ItemId AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
)
SELECT * FROM INVENTTRANSITPURCHASE;