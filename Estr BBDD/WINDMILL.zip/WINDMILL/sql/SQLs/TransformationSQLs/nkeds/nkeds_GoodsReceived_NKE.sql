TRUNCATE TABLE fersads.ds_GoodsReceived_SP_NKE;
 
INSERT INTO fersads.ds_GoodsReceived_SP_NKE (COMPANYID, SUBSIDIARYID, ITEMID, SUPPLIERID, PURCHASEID, CURRENCYCODE, RECEPTIONDATE, RECEIVEDQTY, RECEIVEDAMOUNT)
WITH GOODSRECEIVED AS (SELECT CAST(Report.LocationId AS VARCHAR(40)) AS COMPANYID
	,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
	,CAST(ISNULL(GRL.ItemId,'99999') AS VARCHAR(160)) AS ITEMID
    ,CAST(GR.CompanyAccountId AS varchar(80)) AS SUPPLIERID
    ,CAST(CONCAT(CONCAT(CAST(GRL.PurchaseOrderId AS varchar(40)),'.')
    ,CAST(GRL.PurchaseOrderLineId AS varchar(40))) AS varchar(160)) AS PURCHASEID
    ,CAST(REPLACE(ISNULL(PO.CurrencyCode,'EUR'),'SFr','CHF') AS VARCHAR(20)) AS CURRENCYCODE
    ,CAST(COALESCE(GRL.NKE_ReceivingDate,GR.ANP_ReceivingDate,GRL.PostingDate,GR.Date) AS TIMESTAMP(6)) AS RECEPTIONDATE
    ,CAST(GRL.DeliveryQuantity AS NUMERIC(32,6)) AS RECEIVEDQTY
    ,CAST((CASE WHEN POL.Id IS NULL THEN NULL WHEN ISNULL(POL.FreeOfChargeFlag,0) = 1 THEN 0
        ELSE ISNULL(POL.CostsPerUnit,0) END) * GRL.DeliveryQuantity AS NUMERIC(32,6)) AS RECEIVEDAMOUNT
FROM (SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_GoodsReceiptLine_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
      	INNER JOIN nkeds.ds_GoodsReceiptLine_NKE AS GRL ON GRL.Status BETWEEN 2 AND 4 AND ISNULL(GRL.DeliveryQuantity,0) <> 0 AND GRL.LineType NOT IN ('VK')
      		AND GRL.RecActive = 1 AND GRL.SrcRecLocationId = Report.LocationId
        INNER JOIN nkeds.ds_GoodsReceipt_NKE AS GR ON GR.GoodsReceiptId = GRL.GoodsReceiptId  AND GR.Status BETWEEN 1 AND 4 AND GR.RecActive = 1
        	AND GR.SrcRecLocationId = Report.LocationId
        LEFT JOIN nkeds.ds_PurchaseOrderLine_NKE AS POL ON POL.PurchaseOrderId = GRL.PurchaseOrderId
            AND POL.LineId = GRL.PurchaseOrderLineId AND POL.RecActive = 1
            AND POL.SrcRecLocationId = Report.LocationId
        LEFT JOIN nkeds.ds_PurchaseOrder_NKE AS PO ON PO.PurchaseOrderId = POL.PurchaseOrderId
            AND PO.RecActive = 1 AND PO.SrcRecLocationId = Report.LocationId
WHERE GRL.WarehouseBinId NOT LIKE '%-K' AND ISNULL(GRL.ServiceFlag,0) = 0)
SELECT * FROM GOODSRECEIVED;