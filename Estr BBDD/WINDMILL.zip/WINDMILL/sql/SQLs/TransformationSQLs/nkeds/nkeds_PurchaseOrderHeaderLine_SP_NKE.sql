TRUNCATE TABLE fersads.ds_PurchaseOrderHeaderLine_SP_NKE;

INSERT INTO fersads.ds_PurchaseOrderHeaderLine_SP_NKE(
	PURCHASEID,
	PURCHASEQTY,
	SUBSIDIARYID,
	CURRENCYCODE,
	CURRENCYEXCHANGERATE,
	EXTERNALITEMID,
	DRAWINGNUMBER,
	DRAWINGVERSION,
	ITEMID,
	DISCOUNTPERCENT,
	DISCOUNTAMOUNT,
	PURCHASEDATE,
	UNITPRICE,
	PRICEUNIT,
	AMOUNT,
	SUPPLIERID,
	PURCHSTATUS,
	PENDINGQTY,
	CONFIRMEDDATE,
	REQUESTEDDATE,
	FIRSTCONFIRMEDDATE,
	FIRSTREQUESTEDDATE,
	EXTERNALPURCHASEID,
	EXTERNALPURCHASERECID,
	LINENUMBER,
	INVOICEACCOUNT,
	CREATEDDATETIME,
	INVENTTRANSID,
	COMPANYID,
	ERPSOURCE,
	RECID,
	PAYMENTTERMS,
	PAYMENTMETHOD,
	TRANSITQTY, 
	PURCHUNIT, 
	MODIFIEDDATETIME
)
WITH
CURRENCYEXCHANGERATE AS (
SELECT	CompanyId
		,CurrencyCode
		,ExchangeRate
		,CASE WHEN CurrencyCode = 'EUR' AND CompanyId ISNULL AND (ROW_NUMBER() OVER(PARTITION BY ISNULL(CompanyId,'Standard'), CurrencyCode, SrcRecLocationId ORDER BY Id ASC, ValidFrom ASC)) = 1 THEN '1900-01-01' ELSE ValidFrom END AS ValidFrom
		,(LEAD(ValidFrom) OVER(PARTITION BY CompanyId, CurrencyCode, SrcRecLocationId ORDER BY ValidFrom ASC))-1 AS ValidTo
		,SrcRecLocationId
FROM 	nkeds.ds_CurrencyExchangeRate_NKE
WHERE 	ValidFrom <= NOW() AND RecActive = 1
)
,PURCHASEORDERSTATUSENUMERATION AS (
	SELECT 1 AS NkeStatus, 0 AS FersaStatus
	UNION ALL SELECT 2 AS NkeStatus, 0 AS FersaStatus
	UNION ALL SELECT 3 AS NkeStatus, 1 AS FersaStatus
	UNION ALL SELECT 4 AS NkeStatus, 1 AS FersaStatus
	UNION ALL SELECT 5 AS NkeStatus, 1 AS FersaStatus
	UNION ALL SELECT 6 AS NkeStatus, 2 AS FersaStatus
	UNION ALL SELECT 7 AS NkeStatus, 3 AS FersaStatus
	UNION ALL SELECT 8 AS NkeStatus, 4 AS FersaStatus
	UNION ALL SELECT 9 AS NkeStatus, 0 AS FersaStatus
)
,PURCHASEORDERHEADERLINE AS (
SELECT			CAST(PurchaseOrderLine.PurchaseOrderId AS varchar(160)) AS PURCHASEID
				,CAST(PurchaseOrderLine.PurchaseQuantity AS numeric(32,6)) AS PURCHASEQTY
				,CAST('NAUT' AS varchar(80)) AS SUBSIDIARYID
				,CAST(REPLACE(ISNULL(PurchaseOrder.CurrencyCode,'EUR'),'SFr','CHF') AS varchar(20)) AS CURRENCYCODE
				,CAST(1.00/COALESCE(CAST(PurchaseOrder.DmFactor AS NUMERIC(32,6)),CURRENCYEXCHANGERATEINDIVIDUAL.ExchangeRate,CURRENCYEXCHANGERATE.ExchangeRate) AS numeric(32,6)) AS CURRENCYEXCHANGERATE
				,CAST(NULL AS varchar(100)) AS EXTERNALITEMID
				,CAST(PurchaseOrderLine.DrawingNumber AS varchar(400)) AS DRAWINGNUMBER
				,CAST(NULL AS varchar(400)) AS DRAWINGVERSION
				,CAST(ISNULL(RTRIM(LTRIM(Item.ItemId)),'99999') AS varchar(160)) AS ITEMID
				,CAST(CASE
					WHEN ISNULL(PurchaseOrderLine.Net,0) = 0 THEN 0
					WHEN ISNULL(PurchaseOrderLine.FreeOfChargeFlag,0) = 1 THEN 100
					WHEN ISNULL(PurchaseOrderLine.Net,0) = ISNULL(PurchaseOrderLine.CostsPerUnit,0) THEN 0
					ELSE (1.00-(PurchaseOrderLine.CostsPerUnit/PurchaseOrderLine.Net))*100.00
				END AS numeric(32,6)) AS DISCOUNTPERCENT
				,CAST(CASE
					WHEN ISNULL(PurchaseOrderLine.FreeOfChargeFlag,0) = 1 THEN PurchaseOrderLine.Net
					ELSE ISNULL(PurchaseOrderLine.RebatePrice,0) + ISNULL(PurchaseOrderLine.RebatePrice,0)
				END AS numeric(32,6)) AS DISCOUNTAMOUNT
				,CAST(COALESCE(NULLIF(PurchaseOrder.Date,'2099-12-31'),NULLIF(PurchaseOrder.TodeliverDueDate,'2099-12-31')-100,PurchaseOrder.Insdate) AS timestamp(6)) AS PURCHASEDATE
				,CAST(ISNULL(PurchaseOrderLine.Net,0) AS numeric(32,6)) AS UNITPRICE
				,CAST(ISNULL(PurchaseOrderLine.PurchasePriceUnit,1) AS INT) AS PRICEUNIT
				,CAST(CASE WHEN ISNULL(PurchaseOrderLine.FreeOfChargeFlag,0) = 1 THEN 0 ELSE ISNULL(PurchaseOrderLine.Costs,0) END AS numeric(32,6)) AS AMOUNT
				,CAST(PurchaseOrder.CompanyAccountId AS varchar(80)) AS SUPPLIERID
				,CAST(PURCHASEORDERSTATUSENUMERATION.FersaStatus AS varchar(20)) AS PURCHSTATUS
				,CAST(CASE WHEN PurchaseOrderLine.Status < 6 THEN PurchaseOrderLine.PurchaseQuantity ELSE 0 END AS numeric(32,6)) AS PENDINGQTY
				,CAST(PurchaseOrderLine.DeliveryScheduleDate AS timestamp(6)) AS CONFIRMEDDATE
				,CAST(PurchaseOrderLine.RequiredDate AS timestamp(6)) AS REQUESTEDDATE
				,CAST(ISNULL(PurchaseOrderLine.DueDateOld,PurchaseOrderLine.DeliveryScheduleDate) AS timestamp(6)) AS FIRSTCONFIRMEDDATE
				,CAST(ISNULL(PurchaseOrderLine.RequiredDateOld,PurchaseOrderLine.RequiredDate) AS timestamp(6)) AS FIRSTREQUESTEDDATE
				,CAST(NULL AS varchar(160)) AS EXTERNALPURCHASEID
				,CAST(PurchaseOrderLine.NKE_InterfaceAXID AS int) AS EXTERNALPURCHASERECID
				,CAST(PurchaseOrderLine.LineId AS int) AS LINENUMBER
				,CAST(PurchaseOrder.CompanyAccountId AS varchar(80)) AS INVOICEACCOUNT
				,CAST(PurchaseOrderLine.Insdate AS timestamp(6)) AS CREATEDDATETIME
				,CAST(NULL AS varchar(100)) AS INVENTTRANSID
				,CAST(PurchaseOrderLine.SrcRecLocationId AS varchar(40)) AS COMPANYID
				,CAST('AP+' AS varchar(40)) AS ERPSOURCE
				,CAST(PurchaseOrderLine.Id AS integer) AS RECID
				,CAST(ISNULL(PaymentTerm.TermsPaymentId,'30TAGE') AS varchar(120)) PAYMENTTERMS
				,CAST(NULL AS varchar(40)) AS PAYMENTMETHOD
				,CAST(CASE WHEN PurchaseOrderLine.Status BETWEEN 5 AND 5 THEN PurchaseOrderLine.PurchaseQuantity ELSE 0 END AS numeric(32,6)) AS TRANSITQTY
				,CAST(PurchaseUoMId AS varchar(100)) AS PURCHUNIT
				,CAST(APPLY_MAX(ARRAY[PurchaseOrderLine.RecDateModified, PurchaseOrder.RecDateModified , PaymentTerm.RecDateModified , Item.RecDateModified]) AS timestamp(6))
FROM            (SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_PurchaseOrderLine_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
				INNER JOIN nkeds.ds_PurchaseOrderLine_NKE AS PurchaseOrderLine ON ISNULL(PurchaseOrderLine.Status,0) >= 3 AND ISNULL(PurchaseOrderLine.Status,0) NOT IN ('8','9') AND ISNULL(PurchaseOrderLine.NoStatisticsFlag,0) = 0 AND PurchaseOrderLine.RecActive = 1 AND PurchaseOrderLine.SrcRecLocationId = Report.LocationId
				INNER JOIN nkeds.ds_PurchaseOrder_NKE AS PurchaseOrder ON PurchaseOrder.PurchaseOrderId = PurchaseOrderLine.PurchaseOrderId AND PurchaseOrder.RecActive = 1 AND PurchaseOrder.SrcRecLocationId = Report.LocationId
				LEFT JOIN nkeds.ds_PaymentTerm_NKE AS PaymentTerm ON UPPER(PaymentTerm.TermsPaymentId) = UPPER(ISNULL(PurchaseOrder.TermsPaymentId,'14TAGE')) AND ISNULL(PaymentTerm.PurchaseFlag,0) = 1 AND PaymentTerm.RecActive = 1 AND PaymentTerm.SrcRecLocationId = Report.LocationId
				LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = RTRIM(LTRIM(PurchaseOrderLine.ItemId)) AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
				LEFT JOIN CURRENCYEXCHANGERATE AS CURRENCYEXCHANGERATEINDIVIDUAL ON PurchaseOrder.DMFactor ISNULL AND CURRENCYEXCHANGERATEINDIVIDUAL.CompanyId = PurchaseOrder.CompanyId AND CURRENCYEXCHANGERATEINDIVIDUAL.CurrencyCode = PurchaseOrder.CurrencyCode AND CAST(COALESCE(NULLIF(PurchaseOrder.Date,'2099-12-31'),NULLIF(PurchaseOrder.TodeliverDueDate,'2099-12-31')-100,PurchaseOrder.Insdate) AS timestamp(6)) BETWEEN CURRENCYEXCHANGERATEINDIVIDUAL.ValidFrom AND ISNULL(CURRENCYEXCHANGERATEINDIVIDUAL.ValidTo,CAST(COALESCE(NULLIF(PurchaseOrder.Date,'2099-12-31'),NULLIF(PurchaseOrder.TodeliverDueDate,'2099-12-31')-100,PurchaseOrder.Insdate) AS timestamp(6))) AND CURRENCYEXCHANGERATEINDIVIDUAL.SrcRecLocationId = Report.LocationId
				LEFT JOIN CURRENCYEXCHANGERATE AS CURRENCYEXCHANGERATE ON PurchaseOrder.DMFactor IS NULL AND CURRENCYEXCHANGERATEINDIVIDUAL.CompanyId ISNULL AND CURRENCYEXCHANGERATE.CurrencyCode = PurchaseOrder.CurrencyCode AND CAST(COALESCE(NULLIF(PurchaseOrder.Date,'2099-12-31'),NULLIF(PurchaseOrder.TodeliverDueDate,'2099-12-31')-100,PurchaseOrder.Insdate) AS timestamp(6)) BETWEEN CURRENCYEXCHANGERATE.ValidFrom AND ISNULL(CURRENCYEXCHANGERATE.ValidTo,CAST(COALESCE(NULLIF(PurchaseOrder.Date,'2099-12-31'),NULLIF(PurchaseOrder.TodeliverDueDate,'2099-12-31')-100,PurchaseOrder.Insdate) AS timestamp(6))) AND CURRENCYEXCHANGERATE.SrcRecLocationId = Report.LocationId
				LEFT JOIN PURCHASEORDERSTATUSENUMERATION AS PURCHASEORDERSTATUSENUMERATION ON PURCHASEORDERSTATUSENUMERATION.NkeStatus = PurchaseOrderLine.Status
WHERE 			PurchaseOrder.CompanyAccountId IS NOT NULL
)
SELECT * FROM PURCHASEORDERHEADERLINE;
