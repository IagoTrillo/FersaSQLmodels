TRUNCATE TABLE fersads.ds_CustomerTransaction_SP_NKE;

INSERT INTO fersads.ds_CustomerTransaction_SP_NKE(SUBSIDIARYID, InvoiceId, ACCOUNTNUM, AMOUNT, AMOUNT_LOCAL,
			SETTLEAMOUNT, SETTLEAMOUNT_LOCAL, DUEAMOUNT, DUEAMOUNT_LOCAL, PAYMENTTERMID,
			TRANSDATE, DUEDATE,CLOSEDDATE, DUEDAYS, CONFIRMEDCLOSE,  CURRENCYCODE, RecId, CreditLimit)
WITH Invoices AS (
        SELECT SUBSTRING(SIH.InvoiceId,1,POSITION('.' IN SIH.InvoiceId)-1) InvoiceId
        		,CUSTOMERID  as ACCOUNTNUM
                ,SubsidiaryId
                ,CurrencyCode
                ,CompanyId
                ,PAYMENTTERMS  AS PAYMENTTERMID
                ,DueDate
                ,SUM(Amount) Amount
        FROM  fersads.ds_SalesInvoiceHeaderLine_SP_NKE as SIH 
                WHERE Year(InvoiceDate) >= 2018/* AND invoiceid LIKE '30208204%'*/ 
                        GROUP BY SUBSTRING(SIH.InvoiceId, 1, POSITION('.' IN SIH.InvoiceId) - 1), SubsidiaryId, 
                        CurrencyCode, CompanyId, PAYMENTTERMS, DueDate, CUSTOMERID
 ), CUSTPENDINGDUEBT AS(
 SELECT   InvoiceId
	        ,Invoices.subsidiaryid
	        ,Invoices.currencycode
	        ,Invoices.companyid
	        ,Invoices.ACCOUNTNUM
	        ,Amount AMOUNT, Amount AMOUNT_LOCAL,
	        CAST(payPending.Gross-payPending.GrossPending as numeric(32,6)) AS SETTLEAMOUNT, 
			CAST(payPending.Gross-payPending.GrossPending as numeric(32,6)) AS SETTLEAMOUNT_LOCAL,
			CAST(payPending.GrossPending as numeric(32,6)) AS DUEAMOUNT,
			CAST(payPending.GrossPending as numeric(32,6)) AS DUEAMOUNT_LOCAL,
			-1*(payPending.DueDays) AS DUEDAYS
	        ,PAYMENTTERMID
	        ,paymStatus.ValutaDate
	        ,paymStatus.RecId 
	        ,COALESCE(paymStatus.ValutaDate,payPending.PostingDate) AS TransDate
	        ,COALESCE(paymStatus.ValutaDate + payPending.NetDays,DueDate) AS DueDate
	        ,paymStatus.NKE_PaidDate as CLOSEDDATE
	        ,CASE WHEN paymStatus.NKE_PaidFlag <> 1 
					THEN False 
					ELSE True END AS CONFIRMEDCLOSE
			,dcn.CreditLimit 
	FROM Invoices 
	LEFT JOIN nkeds.ds_NKE_SalesInvoicePaymentsStatus_NKE paymStatus
	        ON Invoices.InvoiceId = paymStatus.SalesInvoiceId
	LEFT JOIN nkeds.ds_NKE_SalesInvoicePaymentsPending_NKE payPending
                ON Invoices.InvoiceId = payPending.DocumentNumber
    LEFT JOIN nkeds.ds_Company_NKE dcn 
    			ON SUBSTRING(Invoices.ACCOUNTNUM, 1, POSITION('.' IN Invoices.ACCOUNTNUM) - 1) = dcn.CompanyId )
    			SELECT SUBSIDIARYID, InvoiceId, ACCOUNTNUM, AMOUNT, AMOUNT_LOCAL,
			SETTLEAMOUNT, SETTLEAMOUNT_LOCAL, DUEAMOUNT, DUEAMOUNT_LOCAL, PAYMENTTERMID,
			TRANSDATE, DUEDATE,CLOSEDDATE, DUEDAYS, CONFIRMEDCLOSE,  CURRENCYCODE, RecId, CreditLimit
			FROM CUSTPENDINGDUEBT ; 