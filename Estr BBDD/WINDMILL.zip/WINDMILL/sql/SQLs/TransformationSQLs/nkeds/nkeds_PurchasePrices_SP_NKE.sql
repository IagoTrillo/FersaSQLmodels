TRUNCATE TABLE fersads.ds_PurchasePrices_SP_NKE;

INSERT INTO fersads.ds_PurchasePrices_SP_NKE(COMPANYID,SUBSIDIARYID,SUPPLIERID,ITEMID,FROMDATE,TODATE,FROMQUANTITY,TOQUANTITY,CURRENCYCODE,UNITPRICE,PRIORITY,UNITID,PRICEUNIT)
WITH
TABLECLEANUP AS (
SELECT	y.ItemSupplierRelationId
		,CAST(CAST(ISNULL(y.ValidFrom,y.Insdate) AS VARCHAR(10)) AS TIMESTAMP) AS ValidFrom
		,y.ValidTo
		,ROW_NUMBER() OVER(PARTITION BY y.ItemSupplierRelationId, y.SrcRecLocationId ORDER BY ISNULL(z.ValidFrom,z.Insdate) ASC, z.ItemSupplierRelationId DESC) AS i
		,CASE
			WHEN y.ValidTo ISNULL AND ISNULL(z.ValidFrom,z.Insdate) IS NULL THEN NULL
			WHEN ISNULL(z.ValidFrom,z.Insdate) ISNULL THEN y.ValidTo
			WHEN y.ValidTo NOTNULL AND y.ValidTo <= (ISNULL(z.ValidFrom,z.Insdate)-1) THEN y.ValidTo
			WHEN y.ValidTo NOTNULL AND y.ValidTo > (ISNULL(z.ValidFrom,z.Insdate)-1) THEN (ISNULL(z.ValidFrom,z.Insdate)-1)
			ELSE (ISNULL(z.ValidFrom,z.Insdate)-1)
		END AS ValidToCalculated
		,Report.LocationId
FROM 	(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_ItemSupplierRelation_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
		INNER JOIN nkeds.ds_ItemSupplierRelation_NKE AS y ON y.CompanyId NOTNULL AND y.RecActive = 1 AND y.SrcRecLocationId = Report.LocationId
		INNER JOIN nkeds.ds_Item_NKE AS ItemExists ON ItemExists.ItemId = y.ItemId AND ItemExists.RecActive = 1 AND ItemExists.SrcRecLocationId = Report.LocationId
		LEFT JOIN nkeds.ds_ItemSupplierRelation_NKE AS z ON z.CompanyId = y.CompanyId AND TRIM(z.ItemId) = TRIM(y.ItemId) AND ISNULL(z.ValidFrom,z.Insdate) >= ISNULL(y.ValidFrom,y.Insdate) AND z.ItemSupplierRelationId != y.ItemSupplierRelationId AND z.RecActive = 1 AND z.SrcRecLocationId = Report.LocationId
WHERE	CAST(CAST(ISNULL(y.ValidFrom,y.Insdate) AS VARCHAR(10)) AS TIMESTAMP) <= CAST(CAST(COALESCE(y.ValidTo,y.ValidFrom,y.Insdate) AS VARCHAR(10)) AS TIMESTAMP)		
)
,TABLEDERIVED AS (
SELECT	ItemSupplierRelation.ItemSupplierRelationId AS PRICEGROUPID
		,ItemSupplierRelation.SrcRecLocationId AS COMPANYID
		,ItemSupplierRelation.SrcRecLocationId AS SUBSIDIARYID
		,ItemSupplierRelation.CompanyId AS SUPPLIERID
		,TRIM(ItemSupplierRelation.ItemId) AS ITEMID
--		,ItemSupplierRelation.ValidFrom AS FROMDATE
		,CAST(CAST(ISNULL(ItemSupplierRelation.ValidFrom,ItemSupplierRelation.Insdate) AS VARCHAR(10)) AS TIMESTAMP) AS FROMDATE
		,TABLECLEANUP.ValidToCalculated AS TODATE
		,ISNULL(NULLIF(ItemSupplierRelation.MinOrderQuantity,0),1) AS MinOrderQuantity
		,CASE WHEN QtyIndex.StartIndex = 1 THEN ISNULL(ItemSupplierRelationLine.Quantity,1) ELSE ItemSupplierRelationLine.Quantity END AS FROMQUANTITY
		,ItemSupplierRelationLine2.Quantity - 1 AS TOQUANTITY
		,ROW_NUMBER() OVER(PARTITION BY ItemSupplierRelation.ItemSupplierRelationId, (CASE WHEN QtyIndex.StartIndex = 1 THEN ISNULL(ItemSupplierRelationLine.Quantity,1) ELSE ItemSupplierRelationLine.Quantity END) ORDER BY ItemSupplierRelationLine2.Quantity ASC) AS i
		,ISNULL(ItemSupplierRelation.RebateScaleFlag,0) AS REBATESCALE
		,ItemSupplierRelation.BasePrice AS BASEPRICEMASTER
		,CASE WHEN ISNULL(ItemSupplierRelation.RebateScaleFlag,0) = 0 THEN ISNULL(ItemSupplierRelationLine.Value,ItemSupplierRelation.BasePrice) ELSE ItemSupplierRelation.BasePrice END AS BASEPRICE
		,ItemSupplierRelation.CurrencyCode AS CURRENCYCODE
		,ItemSupplierRelation.Rebate AS REBATEMASTER
		,ISNULL(CASE WHEN ISNULL(ItemSupplierRelation.RebateScaleFlag,0) = 0 THEN ItemSupplierRelation.Rebate ELSE ItemSupplierRelationLine.Value END,0) AS REBATE
		,ISNULL(ItemSupplierRelation.Rebate2,0) AS REBATE2
		,ItemSupplierRelation.SrcRecLocationId
FROM	TABLECLEANUP
		LEFT JOIN nkeds.ds_ItemSupplierRelation_NKE AS ItemSupplierRelation ON ItemSupplierRelation.ItemSupplierRelationId = TABLECLEANUP.ItemSupplierRelationId AND ItemSupplierRelation.RecActive = 1 AND ItemSupplierRelation.SrcRecLocationId = TABLECLEANUP.LocationId
		LEFT JOIN (SELECT CAST(1 AS INTEGER) AS StartIndex, CAST(1 AS INTEGER) AS EndIndex UNION ALL SELECT CAST(2 AS INTEGER) AS StartIndex, CAST(NULL AS INTEGER) AS EndIndex) AS QtyIndex ON ItemSupplierRelation.ItemSupplierRelationId NOTNULL
		LEFT JOIN nkeds.ds_ItemSupplierRelationLine_NKE AS ItemSupplierRelationLine ON ItemSupplierRelationLine.ItemSupplierRelationId = ItemSupplierRelation.ItemSupplierRelationId AND ISNULL(ItemSupplierRelationLine.Quantity,1) BETWEEN QtyIndex.StartIndex AND ISNULL(QtyIndex.EndIndex,ISNULL(ItemSupplierRelationLine.Quantity,1)) AND ItemSupplierRelationLine.Value NOTNULL AND ItemSupplierRelationLine.RecActive = 1 AND ItemSupplierRelationLine.SrcRecLocationId = TABLECLEANUP.LocationId
		LEFT JOIN nkeds.ds_ItemSupplierRelationLine_NKE AS ItemSupplierRelationLine2 ON ItemSupplierRelationLine2.ItemSupplierRelationId = ItemSupplierRelation.ItemSupplierRelationId AND ISNULL(ItemSupplierRelationLine2.Quantity,0) > (CASE WHEN QtyIndex.StartIndex = 1 THEN ISNULL(ItemSupplierRelationLine.Quantity,1) ELSE ItemSupplierRelationLine.Quantity END) AND ItemSupplierRelationLine2.RecActive = 1 AND ItemSupplierRelationLine2.SrcRecLocationId = TABLECLEANUP.LocationId
WHERE 	TABLECLEANUP.i = 1	
)
,PURCHASEPRICES AS (
SELECT	CAST(TABLEDERIVED.COMPANYID AS varchar(40)) AS COMPANYID
		,CAST(/*TABLEDERIVED.SUBSIDIARYID*/'NAUT' AS varchar(80)) AS SUBSIDIARYID
		,CAST(ISNULL(CompanyAccount.CompanyAccountId,Company.CompanyAccountId) AS varchar(80)) AS SUPPLIERID
		,CAST(TABLEDERIVED.ITEMID AS varchar(80)) AS ITEMID
		,CAST(TABLEDERIVED.FROMDATE AS timestamp) AS FROMDATE
		,CAST(TABLEDERIVED.TODATE AS timestamp) AS TODATE
		,CAST(TABLEDERIVED.FROMQUANTITY AS numeric(32,6)) AS FROMQUANTITY
		,CAST(TABLEDERIVED.TOQUANTITY AS numeric(32,6)) AS TOQUANTITY
		,CAST(TABLEDERIVED.CURRENCYCODE AS varchar(20)) AS CURRENCYCODE
		,CAST(ISNULL(TABLEDERIVED.BASEPRICE,0) * ((1.00 * (1.00-(ISNULL(TABLEDERIVED.REBATE,0.00)/100.00))) * (1.00-(ISNULL(TABLEDERIVED.REBATE2,0.00)/100.00))) AS numeric(32,2))  AS UNITPRICE
		,CAST(1 AS integer) AS PRIORITY
		,CAST(ISNULL(UomLng.TranslatedUoMId,UoM.BasicUoMId) AS varchar(40)) AS UNITID
		,CAST(ISNULL(ItemSupplierRelation.PurchasePriceUnit,0) AS numeric(32,6)) AS PRICEUNIT
FROM 	TABLEDERIVED
		LEFT JOIN nkeds.ds_ItemSupplierRelation_NKE AS ItemSupplierRelation ON ItemSupplierRelation.ItemSupplierRelationId = TABLEDERIVED.PRICEGROUPID AND ItemSupplierRelation.RecActive = 1 AND ItemSupplierRelation.SrcRecLocationId = TABLEDERIVED.SrcRecLocationId
		LEFT JOIN nkeds.ds_CompanyAccount_NKE AS CompanyAccount ON CompanyAccount.CompanyId = TABLEDERIVED.SupplierId AND /*ISNULL(CompanyAccount.SupplierFlag,1) = 1 AND ISNULL(CompanyAccount.InvoiceFlag,0) = 1 AND*/ CompanyAccount.RecActive = 1 AND CompanyAccount.SrcRecLocationId = TABLEDERIVED.SrcRecLocationId
		LEFT JOIN nkeds.ds_Company_NKE AS Company ON CompanyAccount.CompanyAccountId ISNULL AND Company.CompanyId = TABLEDERIVED.SUPPLIERID AND Company.RecActive = 1 AND Company.SrcRecLocationId = TABLEDERIVED.SrcRecLocationId
		LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = TABLEDERIVED.ITEMID AND Item.RecActive = 1 AND Item.SrcRecLocationId = TABLEDERIVED.SrcRecLocationId
		LEFT JOIN nkeds.ds_UnitOfMeasurement_NKE AS UoM ON UoM.UoMId = COALESCE(ItemSupplierRelation.PurchasePriceUoMId,Item.PriceUoMId,Item.ConsumptionUoMId) AND UoM.ItemId ISNULL AND UoM.RecActive = 1 AND UoM.SrcRecLocationId = TABLEDERIVED.SrcRecLocationId
		LEFT JOIN nkeds.ds_UnitOfMeasurementLng_NKE AS UoMLng ON UoMLng.UoMId = UoM.UoMId AND UoMLng.Language = 'en' AND UoMLng.RecActive = 1 AND UoMLng.SrcRecLocationId = TABLEDERIVED.SrcRecLocationId
WHERE	TABLEDERIVED.i = 1
		AND TABLEDERIVED.FROMQUANTITY NOTNULL
		AND TABLEDERIVED.FROMDATE <= ISNULL(TABLEDERIVED.TODATE,TABLEDERIVED.FROMDATE)
		AND (
			ISNULL(COALESCE(NULLIF(CompanyAccount.SupplierFlag,0),NULLIF(Company.SupplierFlag,0)),0) = 1
			OR CompanyAccount.CompanyAccountId IN (SELECT t.CompanyAccountId FROM nkeds.ds_PurchaseOrder_NKE AS t)
			OR CompanyAccount.CompanyAccountId IN (SELECT t.CompanyAccountId FROM nkeds.ds_PurchaseSupplierInvoice_NKE AS t)
		)
)
SELECT * FROM PURCHASEPRICES;
