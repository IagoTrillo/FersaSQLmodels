TRUNCATE TABLE fersads.ds_PurchaseInvoiceHeaderLine_SP_NKE;

INSERT INTO fersads.ds_PurchaseInvoiceHeaderLine_SP_NKE(
	COMPANYID,
	 ITEMID,
	 PURCHASEID,
	 INVENTQTY,
	 SUBSIDIARYID,
	 INVOICEQTY,
	 INVOICEID,
	 INTERNALINVOICEID,
	 INVENTTRANSID,
	 CURRENCYCODE,
	 CURRENCYEXCHANGERATE,
	 INVOICEDATE,
	 INVOICEACCOUNT,
	 SUPPLIERID,
	 AMOUNT,
	 PRICEUNIT,
	 UNITPRICE,
	 DISCOUNTAMOUNT,
	 DISCOUNTPERCENT,
	 DUEDATE,
	 PAYMENTTERMS,
	 PAYMENTMETHOD,
	 DELIVERYTERMS,
	 EXTERNALITEMID,
	 DOCUMENTDATE,
	 ADDITIONALCHARGES,
	 ERPSOURCE,
	 RECID,
	 DELIVERYMODE,
	 TAXRATE, 
	 PURCHUNIT
)
WITH
DELIVERYTERM AS (
SELECT	PurchaseSupplierInvoiceId, StdTxt AS INCOTERM, SrcRecLocationId FROM (
SELECT	t1.PurchaseSupplierInvoiceId, t2.StdTxt, t2.SrcRecLocationId
		,ROW_NUMBER() OVER(PARTITION BY t1.PurchaseSupplierInvoiceId, t2.SrcRecLocationId ORDER BY t2.Id DESC) AS i
FROM	nkeds.ds_PurchaseSupplierInvoice_NKE AS t1
		INNER JOIN nkeds.ds_StandardText_NKE AS t2 ON t2.StdTxt NOT IN ('LIK') AND CONCAT(CONCAT(',',t1.TermsPurchaseDeliveryStdTxt),',') LIKE CONCAT(CONCAT('%,',t2.StdTxt),',%') AND ISNULL(t2.PurchaseFlag,0) = 1 AND t2.Mark = 'LB' AND t2.Stone = 'INCOTERM' AND t2.Language = t1.Language AND t2.RecActive = 1 AND t2.SrcRecLocationId = t1.SrcRecLocationId
WHERE	t1.RecActive = 1
) AS 	tab WHERE i = 1		
)
,DELIVERYMODE AS (
SELECT	PurchaseOrderId, PurchaseOrderLineId, DELIVERYMODE, SrcRecLocationId FROM (
SELECT	GoodsReceiptLine.PurchaseOrderId, GoodsReceiptLine.PurchaseOrderLineId, TransportModeDef.Name_En AS DELIVERYMODE, GoodsReceiptLine.SrcRecLocationId
		,ROW_NUMBER() OVER(PARTITION BY GoodsReceiptLine.PurchaseOrderId, GoodsReceiptLine.PurchaseOrderLineId, GoodsReceiptLine.SrcRecLocationId ORDER BY  GoodsReceiptLine.RecId DESC) AS i
FROM 	nkeds.ds_GoodsReceiptLine_NKE AS GoodsReceiptLine
		INNER JOIN nkeds.ds_GoodsReceipt_NKE AS GoodsReceipt ON GoodsReceipt.GoodsReceiptId = GoodsReceiptLine.GoodsReceiptId AND GoodsReceipt.RecActive = 1 AND GoodsReceipt.SrcRecLocationId = GoodsReceiptLine.SrcRecLocationId
		INNER JOIN nkeds.ds_NKE_TransportMode_NKE AS TransportModeNKE ON TransportModeNKE.NKE_TransportModeId = GoodsReceipt.ANP_TransportModeId AND TransportModeNKE.RecActive = 1 AND TransportModeNKE.SrcRecLocationId = GoodsReceiptLine.SrcRecLocationId
		INNER JOIN nkeds.ds_NKE_TransportModeDef_NKE AS TransportModeDef ON TransportModeDef.TransportModeId = TransportModeNKE.TransportModeId AND TransportModeDef.RecActive = 1 AND TransportModeDef.SrcRecLocationId = GoodsReceiptLine.SrcRecLocationId
WHERE	GoodsReceiptLine.RecActive = 1
		AND ISNULL(GoodsReceiptLine.Status,0) <> 5
		AND PurchaseOrderId NOTNULL
) AS tab WHERE i = 1
)
,CURRENCYEXCHANGERATE AS (
SELECT	CompanyId
		,CurrencyCode
		,ExchangeRate
		,CASE WHEN CurrencyCode = 'EUR' AND CompanyId ISNULL AND (ROW_NUMBER() OVER(PARTITION BY ISNULL(CompanyId,'Standard'), CurrencyCode, SrcRecLocationId ORDER BY Id ASC, ValidFrom ASC)) = 1 THEN '1900-01-01' ELSE ValidFrom END AS ValidFrom
		,(LEAD(ValidFrom) OVER(PARTITION BY CompanyId, CurrencyCode, SrcRecLocationId ORDER BY ValidFrom ASC))-1 AS ValidTo
		,SrcRecLocationId
FROM 	nkeds.ds_CurrencyExchangeRate_NKE
WHERE 	ValidFrom <= NOW() AND RecActive = 1
)
,PURCHASEINVOICEHEADERLINE AS (
SELECT		CAST(PurchaseSupplierInvoiceLine.SrcRecLocationId AS varchar(40)) AS COMPANYID
		    ,CAST(ISNULL(Item.ItemId,'99999') AS varchar(160)) AS ITEMID
		    ,CAST( CONCAT(CONCAT(CAST(PurchaseOrderLine.PurchaseOrderId AS varchar(40)),'.'),CAST(PurchaseOrderLine.LineId AS varchar(40))) AS varchar(80)) AS PURCHASEID
		    ,CAST(CASE
			    WHEN COALESCE( NULLIF(PurchaseSupplierInvoiceLine.DeliveryCostsFlag,0),NULLIF(PurchaseSupplierInvoice.CarrierFlag,0),NULLIF(PurchaseSupplierInvoiceLine.TextLineFlag,0),NULLIF(PurchaseSupplierInvoiceLine.SectionSumFlag,0),NULLIF(PurchaseSupplierInvoiceLine.ServiceFlag,0),0 ) <> 0  
			    THEN 0
			    WHEN ( ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 OR ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 )
			    THEN 0
			    WHEN PurchaseSupplierInvoice.Type IN ('G') THEN -PurchaseSupplierInvoiceLine.PurchaseQuantity
			    ELSE PurchaseSupplierInvoiceLine.PurchaseQuantity
		    END AS numeric(32,6)) AS INVENTQTY
		    ,CAST('NAUT' AS varchar(80)) AS SUBSIDIARYID
		     ,CAST(CASE
		    	WHEN ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 THEN 0
		    	WHEN PurchaseSupplierInvoice.Type IN ('G') THEN -PurchaseSupplierInvoiceLine.PurchaseQuantity
		    	ELSE PurchaseSupplierInvoiceLine.PurchaseQuantity
		    END AS numeric(32,6)) AS INVOICEQTY
		    ,CAST(ISNULL(PurchaseSupplierInvoice.InvoiceNumber,PurchaseSupplierInvoice.InvoiceData) AS varchar(240)) AS INVOICEID
		    ,CAST( CONCAT(CONCAT(CAST(PurchaseSupplierInvoiceLine.PurchaseSupplierInvoiceId AS varchar(40)),'.'),CAST(PurchaseSupplierInvoiceLine.LineId AS varchar(40))) AS varchar(80)) AS INTERNALINVOICEID
		    ,CAST(NULL AS varchar(80)) AS INVENTTRANSID
		    ,CAST(REPLACE(PurchaseSupplierInvoice.CurrencyCode,'SFr','CHF') AS varchar(20)) AS CURRENCYCODE
			,CAST(1.00/COALESCE(CAST(PurchaseSupplierInvoice.DmFactor AS NUMERIC(32,6)),CURRENCYEXCHANGERATEINDIVIDUAL.ExchangeRate,CURRENCYEXCHANGERATE.ExchangeRate) AS numeric(32,6)) AS CURRENCYEXCHANGERATE
		    ,CAST(ISNULL(PurchaseSupplierInvoice.PostingPeriod,PurchaseSupplierInvoice.Date) AS timestamp) AS INVOICEDATE
		    ,CAST(PurchaseSupplierInvoice.CompanyAccountId AS varchar(80)) AS INVOICEACCOUNT
		    ,CAST(PurchaseSupplierInvoice.CompanyAccountId AS varchar(80)) AS SUPPLIERID
		    ,CAST(
		    	CASE
				WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) NOT IN ('G') AND (ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 ) THEN PurchaseSupplierInvoiceLine.Costs
				WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') AND (ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 ) THEN -PurchaseSupplierInvoiceLine.Costs 
				WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') THEN PurchaseSupplierInvoiceLine.CostsPerUnit 
				ELSE PurchaseSupplierInvoiceLine.CostsPerUnit 
				END
		    	*
		    	CASE
			    WHEN ISNULL(PurchaseSupplierInvoiceLine.FreeOfChargeFlag,0) = 1 THEN 0
			    WHEN ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 THEN 1
				WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') THEN -PurchaseSupplierInvoiceLine.PurchaseQuantity
				ELSE PurchaseSupplierInvoiceLine.PurchaseQuantity
			END AS numeric(32,6)) AS AMOUNT
		    ,CAST( 1 AS numeric(32,6) ) AS PRICEUNIT
		    ,CAST( CASE
				WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) NOT IN ('G') AND (ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 ) THEN PurchaseSupplierInvoiceLine.Costs
				WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') AND (ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 ) THEN -PurchaseSupplierInvoiceLine.Costs
				WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') AND (ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 0 ) THEN (PurchaseSupplierInvoiceLine.Net/ISNULL(NULLIF(PurchaseSupplierInvoiceLine.PurchasePriceUnit ,0),1.00))
				ELSE (PurchaseSupplierInvoiceLine.Net/ISNULL(NULLIF(PurchaseSupplierInvoiceLine.PurchasePriceUnit ,0),1.00))
			END AS NUMERIC(32,6) ) AS UNITPRICE
		    ,CAST(
				CASE
				WHEN ISNULL(PurchaseSupplierInvoiceLine.FreeOfChargeFlag,0) = 1 THEN (PurchaseSupplierInvoiceLine.Net/ISNULL(NULLIF(PurchaseSupplierInvoiceLine.PurchasePriceUnit,0),1.00))
				WHEN ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 THEN 0
				WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') THEN (PurchaseSupplierInvoiceLine.Net/ISNULL(NULLIF(PurchaseSupplierInvoiceLine.PurchasePriceUnit,0),1.00))-PurchaseSupplierInvoiceLine.CostsPerUnit 
				ELSE (PurchaseSupplierInvoiceLine.Net/ISNULL(NULLIF(PurchaseSupplierInvoiceLine.PurchasePriceUnit,0),1.00))-PurchaseSupplierInvoiceLine.CostsPerUnit
				END
				*
				CASE
				WHEN ISNULL(PurchaseSupplierInvoiceLine.FreeOfChargeFlag,0) = 1 THEN 1
				WHEN ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 THEN 1
				WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') THEN -PurchaseSupplierInvoiceLine.PurchaseQuantity
				ELSE PurchaseSupplierInvoiceLine.PurchaseQuantity
				END
			AS NUMERIC(32,6) ) AS DISCOUNTAMOUNT
		    ,CAST(ISNULL(CASE 
		    	WHEN ISNULL(PurchaseSupplierInvoiceLine.FreeOfChargeFlag,0) = 1 THEN 100
		    	WHEN ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 THEN 0
				WHEN ISNULL(PurchaseSupplierInvoiceLine.CostsPerUnit,0) = 0 AND ISNULL(PurchaseSupplierInvoiceLine.Net,0) = 0 THEN 0
				WHEN ISNULL(PurchaseSupplierInvoiceLine.CostsPerUnit,0) = 0 AND ISNULL(PurchaseSupplierInvoiceLine.Net,0) <> 0 THEN 100
				WHEN ISNULL(PurchaseSupplierInvoiceLine.CostsPerUnit,0) <> 0 AND ISNULL(PurchaseSupplierInvoiceLine.Net,0) = 0 THEN NULL
				ELSE	(1.00 - (
						CAST(
							CASE
							WHEN ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 THEN 0
							WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') THEN (PurchaseSupplierInvoiceLine.CostsPerUnit/ISNULL(NULLIF(PurchaseSupplierInvoiceLine.PurchasePriceUnit,0),1.00))
							ELSE (PurchaseSupplierInvoiceLine.CostsPerUnit/ISNULL(NULLIF(PurchaseSupplierInvoiceLine.PurchasePriceUnit,0),1.00))
						END AS NUMERIC(32,6) )
						/
						CAST( CASE
							WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) NOT IN ('G') AND ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 THEN PurchaseSupplierInvoiceLine.Costs
							WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') AND ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 1 THEN -PurchaseSupplierInvoiceLine.Costs
							WHEN UPPER(RTRIM(PurchaseSupplierInvoice.Type)) IN ('G') AND ISNULL(PurchaseSupplierInvoice.CreditNoteValueRefundFlag,0) = 0 THEN (PurchaseSupplierInvoiceLine.Net/ISNULL(NULLIF(PurchaseSupplierInvoiceLine.PurchasePriceUnit ,0),1.00))
							ELSE (PurchaseSupplierInvoiceLine.Net/ISNULL(NULLIF(PurchaseSupplierInvoiceLine.PurchasePriceUnit ,0),1.00))
						END AS NUMERIC(32,6) )
						)) * 100.00
			END,0) AS NUMERIC(32,6)) AS DISCOUNTPERCENT
		    ,CAST(ISNULL(PurchaseSupplierInvoice.PostingPeriod,PurchaseSupplierInvoice.Date) + PaymentTerm.NetDays AS timestamp) AS DUEDATE
		    ,CAST(PaymentTerm.TermsPaymentId AS varchar(80)) AS PAYMENTTERMS
		    ,CAST(NULL/*PurchaseSupplierInvoice.PaymentMode*/ AS varchar(80)) AS PAYMENTMETHOD
		    ,CAST(DELIVERYTERM.INCOTERM AS varchar(80)) AS DELIVERYTERMS
		    ,CAST(PurchaseSupplierInvoiceLine.DocDeliveryItemId AS varchar(100)) AS EXTERNALITEMID
		    ,CAST(COALESCE(PurchaseSupplierInvoice.InvoiceDate,PurchaseSupplierInvoice.Date,PurchaseSupplierInvoice.PostingPeriod) AS timestamp) AS DOCUMENTDATE
		    ,CAST(NULL AS numeric(32,6)) AS ADDITIONALCHARGES
		    ,CAST('AP+' AS varchar(40)) AS ERPSOURCE
		    ,CAST(PurchaseSupplierInvoiceLine.Id AS integer) AS RECID
		    ,CAST(DELIVERYMODE.DELIVERYMODE AS varchar(80)) AS DELIVERYMODE
		    ,CAST(ISNULL(PurchaseSupplierInvoiceLine.OriginTaxPrice,0) AS numeric(32,6)) AS TAXRATE
			,CAST(PurchaseSupplierInvoiceLine.PurchaseUoMId AS varchar(100)) AS PURCHUNIT
FROM 		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_PurchaseSupplierInvoiceLine_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_PurchaseSupplierInvoiceLine_NKE AS PurchaseSupplierInvoiceLine ON ISNULL(PurchaseSupplierInvoiceLine.Status,0) BETWEEN 3 AND 4 AND ISNULL(PurchaseSupplierInvoiceLine.NoStatisticsFlag,0) = 0 AND PurchaseSupplierInvoiceLine.RecActive = 1 AND PurchaseSupplierInvoiceLine.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_PurchaseSupplierInvoice_NKE AS PurchaseSupplierInvoice ON PurchaseSupplierInvoice.PurchaseSupplierInvoiceId = PurchaseSupplierInvoiceLine.PurchaseSupplierInvoiceId AND PurchaseSupplierInvoice.RecActive = 1 AND PurchaseSupplierInvoice.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = PurchaseSupplierInvoiceLine.ItemId AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_PurchaseSupplierInvoiceLineOrderReference_NKE AS Reference ON Reference.PurchaseSupplierInvoiceId = PurchaseSupplierInvoiceLine.PurchaseSupplierInvoiceId AND Reference.PurchaseSupplierInvoiceLineId = PurchaseSupplierInvoiceLine.LineId AND Reference.RecActive = 1 AND Reference.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_PurchaseSupplierInvoiceLine_NKE AS RootLine ON Reference.Id ISNULL AND RootLine.PurchaseSupplierInvoiceId = PurchaseSupplierInvoiceLine.PurchaseSupplierInvoiceId AND PurchaseSupplierInvoiceLine.UserLine LIKE CONCAT(RootLine.UserLine,'.%') AND RootLine.RecActive = 1 AND RootLine.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_PurchaseSupplierInvoiceLineOrderReference_NKE AS RootReference ON Reference.Id ISNULL AND RootReference.PurchaseSupplierInvoiceId = RootLine.PurchaseSupplierInvoiceId AND RootReference.PurchaseSupplierInvoiceLineId = RootLine.LineId AND RootReference.RecActive = 1 AND RootReference.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_PurchaseOrderLine_NKE AS PurchaseOrderLine ON PurchaseOrderLine.PurchaseOrderId = ISNULL(RootReference.PurchaseOrderId,Reference.PurchaseOrderId) AND PurchaseOrderLine.LineId = ISNULL(RootReference.PurchaseOrderLine,Reference.PurchaseOrderLine) AND PurchaseOrderLine.RecActive = 1 AND PurchaseOrderLine.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_PaymentTerm_NKE AS PaymentTerm ON PaymentTerm.TermsPaymentId = PurchaseSupplierInvoice.TermsPaymentId AND ISNULL(PaymentTerm.PurchaseFlag,0) = 1 AND PaymentTerm.RecActive = 1 AND PaymentTerm.SrcRecLocationId = Report.LocationId		
			LEFT JOIN DELIVERYMODE AS DELIVERYMODE ON DELIVERYMODE.PurchaseOrderId = PurchaseOrderLine.PurchaseOrderId AND DELIVERYMODE.PurchaseOrderLineId = PurchaseOrderLine.LineId AND DELIVERYMODE.SrcRecLocationId = Report.LocationId
			LEFT JOIN DELIVERYTERM AS DELIVERYTERM ON DELIVERYTERM.PurchaseSupplierInvoiceId = PurchaseSupplierInvoice.PurchaseSupplierInvoiceId AND DELIVERYTERM.SrcRecLocationId = Report.LocationId
			LEFT JOIN CURRENCYEXCHANGERATE AS CURRENCYEXCHANGERATEINDIVIDUAL ON PurchaseSupplierInvoice.DMFactor ISNULL AND CURRENCYEXCHANGERATEINDIVIDUAL.CompanyId = PurchaseSupplierInvoice.CompanyId AND CURRENCYEXCHANGERATEINDIVIDUAL.CurrencyCode = ISNULL(PurchaseSupplierInvoice.CurrencyCode,'EUR') AND CAST(COALESCE(PurchaseSupplierInvoice.InvoiceDate,PurchaseSupplierInvoice.Date,PurchaseSupplierInvoice.PostingPeriod) AS timestamp) BETWEEN CURRENCYEXCHANGERATEINDIVIDUAL.ValidFrom AND ISNULL(CURRENCYEXCHANGERATEINDIVIDUAL.ValidTo,CAST(COALESCE(PurchaseSupplierInvoice.InvoiceDate,PurchaseSupplierInvoice.Date,PurchaseSupplierInvoice.PostingPeriod) AS timestamp)) AND CURRENCYEXCHANGERATEINDIVIDUAL.SrcRecLocationId = Report.LocationId
			LEFT JOIN CURRENCYEXCHANGERATE AS CURRENCYEXCHANGERATE ON PurchaseSupplierInvoice.DMFactor IS NULL AND CURRENCYEXCHANGERATEINDIVIDUAL.CompanyId ISNULL AND CURRENCYEXCHANGERATE.CurrencyCode = ISNULL(PurchaseSupplierInvoice.CurrencyCode,'EUR') AND CAST(COALESCE(PurchaseSupplierInvoice.InvoiceDate,PurchaseSupplierInvoice.Date,PurchaseSupplierInvoice.PostingPeriod) AS timestamp) BETWEEN CURRENCYEXCHANGERATE.ValidFrom AND ISNULL(CURRENCYEXCHANGERATE.ValidTo,CAST(COALESCE(PurchaseSupplierInvoice.InvoiceDate,PurchaseSupplierInvoice.Date,PurchaseSupplierInvoice.PostingPeriod) AS timestamp)) AND CURRENCYEXCHANGERATE.SrcRecLocationId = Report.LocationId
)
SELECT * FROM PURCHASEINVOICEHEADERLINE;
