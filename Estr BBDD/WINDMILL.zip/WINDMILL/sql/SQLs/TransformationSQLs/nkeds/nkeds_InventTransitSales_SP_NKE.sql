TRUNCATE TABLE fersads.ds_InventTransitSales_SP_NKE;

INSERT INTO fersads.ds_InventTransitSales_SP_NKE(COMPANYID,SUBSIDIARYID,ITEMID,PHYSICALINVENT,RESERVPHYSICAL,PICKED,INVENTBATCHID,INVENTLOCATIONID,INVENTSERIALID,INVENTSITEID,INVENTSIZEID,INVENTSTATUSID,INVENTSTYLEID,LICENSEPLATEID,WMSLOCATIONID,RECTYPE,UNITCOST,CURRENCYCODE,EXCHANGERATE_EUR,EXCHANGERATE_USD) 
WITH
INVENTTRANSITSALESINVOICES AS (
SELECT		SalesInvoiceLine.GoodsIssueId
			,SalesInvoiceLine.GoodsIssueLineId
			,SUM(SalesInvoiceLine.Revenue/ISNULL(CAST(SalesInvoice.DMFactor AS NUMERIC(32,8)),1.00000000)/ISNULL(NULLIF(SalesInvoiceLine.Quantity,0),1.000)) OVER(PARTITION BY SalesInvoiceLine.GoodsIssueId, SalesInvoiceLine.SrcRecLocationId) AS RevenueValue
			,ROW_NUMBER() OVER(PARTITION BY SalesInvoiceLine.GoodsIssueId, SalesInvoiceLine.SrcRecLocationId ORDER BY SalesInvoiceLine.Status DESC, SalesInvoiceLine.Id DESC) AS headerAsc
			,ROW_NUMBER() OVER(PARTITION BY SalesInvoiceLIne.GoodsIssueId, SalesInvoiceLine.GoodsIssueLineId, SalesInvoiceLIne.SrcRecLocationId ORDER BY SalesInvoiceLine.Status DESC, SalesInvoiceLine.Id DESC) AS lineAsc
			,SalesInvoiceLine.Status AS SalesInvoiceLineStatus
			,(SalesInvoiceLine.Revenue/ISNULL(CAST(SalesInvoice.DMFactor AS NUMERIC(32,8)),1.000000))/ISNULL(NULLIF(SalesInvoiceLine.Quantity,0),1.000) AS SalesInvoiceLineRevenuePerUnitEur
			,ISNULL(SalesInvoice.PostingPeriod,SalesInvoice.ValutaDate) AS SalesInvoiceLinePostingDate
			,SalesInvoiceLine.SrcRecLocationId
FROM		nkeds.ds_SalesInvoiceLine_NKE AS SalesInvoiceLine
			INNER JOIN nkeds.ds_SalesInvoice_NKE AS SalesInvoice ON SalesInvoice.SalesInvoiceId = SalesInvoiceLine.SalesInvoiceId AND ISNULL(SalesInvoice.Status,0) <> 6 AND SalesInvoice.Type NOT IN ('G','GU') AND ISNULL(SalesInvoice.CreditNoteValueRefundFlag,0) = 0 AND SalesInvoice.RecActive = 1 AND SalesInvoice.SrcRecLocationId = SalesInvoiceLine.SrcRecLocationId
WHERE 		SalesInvoiceLine.RecActive = 1
			AND ISNULL(SalesInvoiceLine.Status,0) <> 6
			AND SalesInvoiceLine.GoodsIssueId IS NOT NULL
)
,INVENTTRANSITSALESGOODSISSUES AS (
SELECT tabfinal.* FROM (
SELECT		tab.*
			,CASE
				WHEN GoodsIssueRevenueValue = 0 THEN (CASE WHEN GoodsIssueLineStatus < 3 THEN 'InventoryTransitSalesPending' ELSE 'Closed' END)
				WHEN InvoiceLineStatus NOTNULL AND InvoiceLineStatus = 5 AND InvoiceLinePostingDate <= NOW() THEN 'Closed'
				WHEN (InvoiceLineStatus NOTNULL AND InvoiceLineStatus < 5) OR (InvoiceLineStatus = 5 AND InvoiceLinePostingDate > NOW()) THEN (CASE WHEN GoodsIssueLineStatus < 3 THEN 'InventoryTransitSalesPending' ELSE 'InventoryTransitSales' END)
				WHEN (InvoiceLineStatus IS NULL AND QtyToInvoice NOTNULL AND ISNULL(QtyToInvoice,0) <= 0) THEN (CASE WHEN GoodsIssueLineStatus < 3 THEN 'InventoryTransitSalesPending' ELSE 'Closed' END)
				WHEN (InvoiceLineStatus IS NULL AND QtyToInvoice NOTNULL AND ISNULL(QtyToInvoice,0) > 0) THEN (CASE WHEN GoodsIssueStatus = 3 AND GoodsIssueLineStatus = 3 AND ISNULL(SalesOrderLineRevenuePerUnit,0) = 0 THEN 'Closed' WHEN GoodsIssueStatus = 3 AND GoodsIssueLineStatus = 3 THEN 'InventoryTransitSales' ELSE 'InventoryTransitSalesPending' END)
				ELSE 'Closed'
			END AS DocumentType	
FROM (
SELECT		GoodsIssueLine.GoodsIssueId
			,GoodsIssueLine.LineId AS GoodsIssueLineId
			,GoodsIssueLine.UserLine AS GoodsIssueUserLineId
			,COALESCE(GoodsIssue.InvoiceCompanyAccountId,GoodsIssue.CompanyAccountId,GoodsIssue.ANP_FinalDeliveryCompanyAccountId,GoodsIssue.DeliveryCompanyAccountId) AS GoodsIssueCompanyAccountId
			,ISNULL( SUM( ISNULL(InvoiceLine.RevenueValue, (SalesOrderLine.Revenue/ISNULL(CAST(SalesOrder.DMFactor AS NUMERIC(32,8)),1.00000000))/ISNULL(NULLIF(SalesOrderLine.Quantity,0),1.000) ) ) OVER(PARTITION BY GoodsIssueLine.GoodsIssueId, GoodsIssueLine.SrcRecLocationId) ,0 ) AS GoodsIssueRevenueValue
			,GoodsIssue.Status AS GoodsIssueStatus
			,CASE WHEN GoodsIssue.Status = 3 AND GoodsIssueLine.Status IN (1,2) THEN GoodsIssue.Status ELSE GoodsIssueLine.Status END AS GoodsIssueLineStatus
			,ISNULL(InvoiceLine.SalesInvoiceLineRevenuePerUnitEur,(SalesOrderLine.Revenue/ISNULL(CAST(SalesOrder.DMFactor AS NUMERIC(32,8)),1.000000))/ISNULL(NULLIF(SalesOrderLine.Quantity,0),1.000)) AS SalesOrderLineRevenuePerUnit
			,CASE WHEN COALESCE(InvoiceLine.SalesInvoiceLineStatus,InvoiceHeader.SalesInvoiceLineStatus) ISNULL AND COALESCE(NULLIF(GoodsIssueLine.GoodsIssueLineNoInvoicing,0),NULLIF(GoodsIssue.GoodsIssueNoInvoicing,0),0) <> 0 AND GoodsIssueLine.Status = 3 THEN 5 ELSE COALESCE(InvoiceLine.SalesInvoiceLineStatus,InvoiceHeader.SalesInvoiceLineStatus) END AS InvoiceLineStatus
			,CASE WHEN COALESCE(InvoiceLine.SalesInvoiceLineStatus,InvoiceHeader.SalesInvoiceLineStatus) ISNULL AND COALESCE(NULLIF(GoodsIssueLine.GoodsIssueLineNoInvoicing,0),NULLIF(GoodsIssue.GoodsIssueNoInvoicing,0),0) <> 0 AND GoodsIssueLine.Status = 3 THEN GoodsIssue.Date ELSE COALESCE(InvoiceLine.SalesInvoiceLinePostingDate,InvoiceHeader.SalesInvoiceLinePostingDate) END AS InvoiceLinePostingDate
			,CASE WHEN GoodsIssue.OrderType IN ('BA','FV') OR SalesOrderLine.Status IN (8,9) OR SalesOrder.Status IN (8,9) THEN 0 ELSE SalesOrderLine.InvoicedQuantity END AS QtyToInvoice
			,GoodsIssueLine.SrcRecLocationId
FROM		nkeds.ds_GoodsIssueLine_NKE AS GoodsIssueLine
			INNER JOIN nkeds.ds_GoodsIssue_NKE AS GoodsIssue ON GoodsIssue.GoodsIssueId = GoodsIssueLine.GoodsIssueId AND ISNULL(GoodsIssue.Status,0) <> 4 AND GoodsIssue.RecActive = 1 AND GoodsIssue.SrcRecLocationId = GoodsIssueLine.SrcRecLocationId
			LEFT JOIN INVENTTRANSITSALESINVOICES AS InvoiceLine ON InvoiceLine.lineAsc = 1 AND InvoiceLine.GoodsIssueId = GoodsIssueLine.GoodsIssueId AND InvoiceLine.GoodsIssueLineId = GoodsIssueLine.LineId AND InvoiceLine.SrcRecLocationId = GoodsIssueLine.SrcRecLocationId
			LEFT JOIN INVENTTRANSITSALESINVOICES AS InvoiceHeader ON InvoiceLine.lineAsc ISNULL AND InvoiceHeader.headerAsc = 1 AND InvoiceHeader.GoodsIssueId = GoodsIssueLine.GoodsIssueId AND InvoiceHeader.SrcRecLocationId = GoodsIssueLine.SrcRecLocationId
			LEFT JOIN nkeds.ds_SalesOrderLine_NKE AS SalesOrderLine ON InvoiceLine.lineAsc IS NULL AND SalesOrderLine.SalesOrderId = GoodsIssueLine.SalesOrderId AND SalesOrderLine.LineId = GoodsIssueLine.SalesOrderLineId AND SalesOrderLine.RecActive = 1 AND SalesOrderLine.SrcRecLocationId = GoodsIssueLine.SrcRecLocationId
			LEFT JOIN nkeds.ds_SalesOrder_NKE AS SalesOrder ON InvoiceLine.lineAsc IS NULL AND SalesOrder.SalesOrderId = GoodsIssueLine.SalesOrderId AND SalesOrder.RecActive = 1 AND SalesOrder.SrcRecLocationId = GoodsIssueLine.SrcRecLocationId
WHERE		ISNULL(GoodsIssueLine.Status,0) <> 4
			AND GoodsIssueLine.RecActive = 1
) AS		tab
) AS tabfinal WHERE DocumentType NOT IN ('Closed')
)
,INVENTTRANSITSALES AS (
SELECT		CAST(Report.LocationId AS VARCHAR(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
			,CAST(StockMovement.ItemId AS VARCHAR(160)) AS ITEMID
			,CAST(StockMovement.Quantity AS NUMERIC(32,6)) AS PHYSICALINVENT
			,CAST(StockMovement.Quantity AS NUMERIC(32,6)) AS RESERVPHYSICAL
			,CAST(0/*StockMovement.Quantity*/ AS NUMERIC(32,6)) AS PICKED
			,CAST(StockMovement.BatchId AS VARCHAR(80)) AS INVENTBATCHID
			,CAST(CASE WHEN GoodsIssueLine.DocumentType = 'InventoryTransitSalesPending' THEN 'NAUT' ELSE 'T-NAUT' END AS VARCHAR(80)) AS INVENTLOCATIONID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSERIALID
			,CAST('NAUT' AS VARCHAR(80)) AS INVENTSITEID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSIZEID
			,CAST(CASE WHEN GoodsIssueLine.DocumentType = 'InventoryTransitSalesPending' THEN 'Available' ELSE 'Transit' END AS VARCHAR(40)) AS INVENTSTATUSID
			,CAST(ISNULL(Item.MaterialGroupId,'GEN') AS VARCHAR(40)) AS INVENTSTYLEID
			,CAST(StockMovement.SerialNumber AS VARCHAR(400)) AS LICENSEPLATEID
			,CAST(CASE WHEN GoodsIssueLine.DocumentType = 'InventoryTransitSalesPending' THEN CONCAT(GoodsIssueLine.GoodsIssueCompanyAccountId,'-T') ELSE GoodsIssueLine.GoodsIssueCompanyAccountId END AS VARCHAR(40)) AS WMSLOCATIONID
			,CAST(NULL AS NUMERIC(32,6)) AS RECTYPE
			,CAST(SUM(StockMovementElement.ElementValue)/ISNULL(NULLIF(StockMovement.Quantity,0),1.000) AS NUMERIC(32,6)) AS UNITCOST
			,CAST('EUR' AS VARCHAR(20)) AS CURRENCYCODE
			,CAST(1 AS NUMERIC(32,6)) AS EXCHANGERATE_EUR
    		,CAST(NULL AS NUMERIC(32,6)) AS EXCHANGERATE_USD
FROM		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_WarehouseStockMovement_NKE AS StockMovement ON StockMovement.Type = 'WA' AND ISNULL(StockMovement.NoStockFlag,0) = 0 AND ISNULL(StockMovement.Quantity,0) <> 0 AND ISNULL(StockMovement.Mode,0) = 0 AND ISNULL(StockMovement.CanceledFlag,0) = 0 AND StockMovement.RecActive = 1 AND StockMovement.SrcRecLocationId = Report.LocationId
			INNER JOIN INVENTTRANSITSALESGOODSISSUES AS GoodsIssueLine ON GoodsIssueLine.GoodsIssueId = StockMovement.NewWorkOrderId AND GoodsIssueLine.GoodsIssueLineId = StockMovement.NewLineId AND GoodsIssueLine.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = StockMovement.ItemId AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_WarehouseStockMovementElement_NKE AS StockMovementElement ON StockMovementElement.DocumentNumber = StockMovement.DocumentNumber AND ISNULL(StockMovementElement.AverageFlag,0) = 1 AND StockMovementelement.RecActive = 1 AND StockMovementElement.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_CostElement_NKE AS CostElement ON CostElement.CostElementId = StockMovementElement.CostElementId AND CostElement.RecActive = 1 AND CostElement.SrcRecLocationId = Report.LocationId
GROUP BY 	Report.LocationId
			,StockMovement.ItemId
			,StockMovement.Quantity
			,StockMovement.BatchId
			,GoodsIssueLine.GoodsIssueCompanyAccountId
			,GoodsIssueLine.DocumentType
			,Item.MaterialGroupId
			,StockMovement.SerialNumber
)
SELECT * FROM INVENTTRANSITSALES;