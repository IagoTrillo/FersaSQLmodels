TRUNCATE TABLE fersads.ds_ItemBatchProduction_SP_NKE;

INSERT INTO fersads.ds_ItemBatchProduction_SP_NKE (
    COMPANYID,
    SUBSIDIARYID,
    SUPPLIERID,
    ITEMID,
    BATCHID,
    QUANTITY,
	RECEIPTDATE,
    PHYSICALDATE,
    UNITCOSTMAT,
    UNITCOST
)
WITH
BATCHES_DELIVERED AS (
SELECT		tab.ItemId, tab.BatchId, tab.NKE_PreBatchId, tab.CompanyAccountId, tab.Priority, MIN(tab.ReceivingDate) AS ReceivingDate, MAX(tab.ReceivingDateCnt) AS ReceivingDateCnt
FROM (
SELECT		GoodsReceiptLine.ItemId, GoodsReceiptLine.NKE_PreBatchId AS BatchId, NULL AS NKE_PreBatchId, GoodsReceipt.CompanyAccountId, MIN(CAST(CAST(COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate) AS DATE) AS DATETIME)) AS ReceivingDate, COUNT(DISTINCT COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate)) AS ReceivingDateCnt, 1 AS Priority
FROM		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_GoodsReceiptLine_NKE AS GoodsReceiptLine ON GoodsReceiptLine.Status = 4 AND GoodsReceiptLine.NKE_PreBatchId IS NOT NULL AND GoodsReceiptLine.RecActive = 1 AND GoodsReceiptLine.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_GoodsReceipt_NKE AS GoodsReceipt ON GoodsReceipt.GoodsReceiptId = GoodsReceiptLine.GoodsReceiptId AND GoodsReceipt.RecActive = 1 AND GoodsReceipt.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = GoodsReceiptLine.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND Item.SrcRecLocationId = Report.LocationId
GROUP BY	GoodsReceiptLine.ItemId, GoodsReceiptLine.NKE_PreBatchId, GoodsReceiptLine.BatchId, GoodsReceipt.CompanyAccountId
UNION ALL
SELECT		GoodsReceiptLine.ItemId, GoodsReceiptLine.BatchId AS BatchId, NULL AS NKE_PreBatchId, GoodsReceipt.CompanyAccountId, MIN(CAST(CAST(COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate) AS DATE) AS DATETIME)) AS ReceivingDate, COUNT(DISTINCT COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate)) AS ReceivingDateCnt, 1 AS Priority
FROM		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_GoodsReceiptLine_NKE AS GoodsReceiptLine ON GoodsReceiptLine.Status = 4 AND GoodsReceiptLine.BatchId IS NOT NULL AND GoodsReceiptLine.RecActive = 1 AND GoodsReceiptLine.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_GoodsReceipt_NKE AS GoodsReceipt ON GoodsReceipt.GoodsReceiptId = GoodsReceiptLine.GoodsReceiptId AND GoodsReceipt.RecActive = 1 AND GoodsReceipt.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = GoodsReceiptLine.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND Item.SrcRecLocationId = Report.LocationId
GROUP BY	GoodsReceiptLine.ItemId, GoodsReceiptLine.NKE_PreBatchId, GoodsReceiptLine.BatchId, GoodsReceipt.CompanyAccountId
UNION ALL
SELECT		WarehouseStockMovement.ItemId, WarehouseStockMovement.BatchId AS BatchId, GoodsReceiptLine.NKE_PreBatchId AS NKE_PreBatchId, GoodsReceipt.CompanyAccountId, MIN(CAST(CAST(COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate) AS DATE) AS DATETIME)) AS ReceivingDate, COUNT(DISTINCT COALESCE(GoodsReceiptLine.NKE_ReceivingDate,GoodsReceipt.ANP_ReceivingDate,GoodsReceiptLine.PostingDate,GoodsReceipt.PostingDate)) AS ReceivingDateCnt, 2 AS Priority
FROM		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_WarehouseStockMovement_NKE AS WarehouseStockMovement ON ISNULL(WarehouseStockMovement.Quantity,0) <> 0 AND WarehouseStockMovement.BatchId IS NOT NULL AND WarehouseStockMovement.Type IN ('WE') AND ISNULL(WarehouseStockMovement.CanceledFlag,0) = 0 AND ISNULL(WarehouseStockMovement.NoStockFlag,0) = 0 AND WarehouseStockMovement.RecActive = 1 AND WarehouseStockMovement.SrcRecLocationId = Report.LocationId 
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = WarehouseStockMovement.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND Item.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_GoodsReceiptLine_NKE AS GoodsReceiptLine ON GoodsReceiptLine.GoodsReceiptId = WarehouseStockMovement.WorkorderId AND GoodsReceiptLine.LineId = WarehouseStockMovement.LineId AND GoodsReceiptLine.RecActive = 1 AND GoodsReceiptLine.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_GoodsReceipt_NKE AS GoodsReceipt ON GoodsReceipt.GoodsReceiptId = GoodsReceiptLine.GoodsReceiptId AND GoodsReceipt.RecActive = 1 AND GoodsReceipt.SrcRecLocationId = Report.LocationId
GROUP BY	WarehouseStockMovement.ItemId, WarehouseStockMovement.BatchId, GoodsReceiptLine.NKE_PreBatchId, GoodsReceipt.CompanyAccountId
UNION ALL
SELECT		WarehouseStockMovement.ItemId, WarehouseStockMovement.BatchId AS BatchId, NULL AS NKE_PreBatchId, GoodsReceipt.CompanyAccountId, MIN(CAST(CAST(COALESCE(GoodsReceipt.ANP_ReceivingDate,GoodsReceipt.PostingDate) AS DATE) AS DATETIME)) AS ReceivingDate, COUNT(DISTINCT COALESCE(GoodsReceipt.ANP_ReceivingDate,GoodsReceipt.PostingDate)) AS ReceivingDateCnt, 3 AS Priority
FROM		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_WarehouseStockMovement_NKE AS WarehouseStockMovement ON ISNULL(WarehouseStockMovement.Quantity,0) <> 0 AND WarehouseStockMovement.BatchId IS NOT NULL AND WarehouseStockMovement.Type IN ('WE') AND ISNULL(WarehouseStockMovement.CanceledFlag,0) = 0 AND ISNULL(WarehouseStockMovement.NoStockFlag,0) = 0 AND WarehouseStockMovement.RecActive = 1 AND WarehouseStockMovement.SrcRecLocationId = Report.LocationId 
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = WarehouseStockMovement.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND Item.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_GoodsReceipt_NKE AS GoodsReceipt ON GoodsReceipt.GoodsReceiptId = WarehouseStockMovement.WorkOrderId AND GoodsReceipt.RecActive = 1 AND GoodsReceipt.SrcRecLocationId = Report.LocationId
GROUP BY	WarehouseStockMovement.ItemId, WarehouseStockMovement.BatchId, GoodsReceipt.CompanyAccountId
) AS tab
GROUP BY	tab.ItemId, tab.BatchId, tab.NKE_PreBatchId, tab.CompanyAccountId, tab.Priority
)
,COSTS AS (
SELECT		WarehouseStockMovement.DocumentNumber
			,SUM(CASE WHEN ISNULL(CostElement.IgnoreFlag,0) = 0 AND CostElement.CostElementId IN ('K01') THEN WarehouseStockMovementCosts.ElementValue ELSE NULL END) AS COSTSMAT
			,SUM(CASE WHEN ISNULL(CostElement.IgnoreFlag,0) = 0 THEN WarehouseStockMovementCosts.ElementValue ELSE NULL END) AS COSTS
			,WarehouseStockMovement.SrcRecLocationId
FROM		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_WarehouseStockMovement_NKE AS WarehouseStockMovement ON ISNULL(WarehouseStockMovement.Quantity,0) <> 0 AND ( (WarehouseStockMovement.Type IN ('AE') AND ISNULL(WarehouseStockMovement.Mode,0) IN (0,2)) OR (WarehouseStockMovement.Type IN ('RS') AND ISNULL(WarehouseStockMovement.Mode,1) IN (1)) ) AND ISNULL(WarehouseStockMovement.CanceledFlag,0) = 0 AND ISNULL(WarehouseStockMovement.NoStockFlag,0) = 0 AND WarehouseStockMovement.RecActive = 1 AND WarehouseStockMovement.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = WarehouseStockMovement.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_WarehouseStockMovementElement_NKE AS WarehouseStockMovementCosts ON ISNULL(WarehouseStockMovementCosts.AverageFlag,0) = 1 AND WarehouseStockMovementCosts.DocumentNumber = WarehouseStockMovement.DocumentNumber AND WarehouseStockMovementCosts.RecActive = 1 AND WarehouseStockMovementCosts.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_CostElement_NKE AS CostElement ON CostElement.CostElementId = WarehouseStockMovementCosts.CostElementId AND CostElement.RecActive = 1 AND CostElement.SrcRecLocationId = Report.LocationId
GROUP BY	WarehouseStockMovement.DocumentNumber
			,WarehouseStockMovement.SrcRecLocationId
)
,MOVEMENTS_PRODBOM AS (
SELECT		CAST(WarehouseStockMovement.SrcRecLocationId AS varchar(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
			,ISNULL(WarehouseStockMovement.OriginDocumentNumber,WarehouseStockMovement.DocumentNumber) AS DocumentNumberROOT
			,WarehouseStockMovement.DocumentNumber AS DocumentNumber
			,CASE WHEN ISNULL(Item.NKE_MadeInAustriaFlag,0) = 1 THEN '100000.001' ELSE NULL END AS SUPPLIERID
			,WarehouseStockMovement.ItemId AS ITEMID
			,WarehouseStockMovement.BatchId AS BATCH
			,CAST((CASE WHEN WarehouseStockMovement.Type IN ('RS') THEN -WarehouseStockMovement.Quantity WHEN ISNULL(WarehouseStockMovement.Mode,0) = 0 THEN WarehouseStockMovement.Quantity ELSE NULL END) AS NUMERIC(32,6)) AS QUANTITY
			,CAST(NULL AS DATETIME) AS RECEIPTDATE
			,CAST(CAST(MIN(WarehouseStockMovement.Insdate) OVER(PARTITION BY ISNULL(WarehouseStockMovement.OriginDocumentNumber,WarehouseStockMovement.DocumentNumber), Report.LocationId ORDER BY WarehouseStockMovement.Insdate ASC) AS DATE) AS DATETIME) AS PHYSICALDATE
			,CAST(CASE WHEN WarehouseStockMovement.Type IN ('RS') THEN -COSTS.COSTSMAT ELSE COSTS.COSTSMAT END AS NUMERIC(32,6)) AS COSTSMAT
			,CAST(CASE WHEN WarehouseStockMovement.Type IN ('RS') THEN -COSTS.COSTS ELSE COSTS.COSTS END AS NUMERIC(32,6)) AS COSTS
FROM        (SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_WarehouseStockMovement_NKE AS WarehouseStockMovement ON ISNULL(WarehouseStockMovement.Quantity,0) <> 0 AND ( (WarehouseStockMovement.Type IN ('AE') AND ISNULL(WarehouseStockMovement.Mode,0) IN (0,2)) OR (WarehouseStockMovement.Type IN ('RS') AND ISNULL(WarehouseStockMovement.Mode,1) IN (1)) ) AND ISNULL(WarehouseStockMovement.CanceledFlag,0) = 0 AND ISNULL(WarehouseStockMovement.NoStockFlag,0) = 0 AND WarehouseStockMovement.RecActive = 1 AND WarehouseStockMovement.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = WarehouseStockMovement.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND ( ISNULL(Item.NKE_MadeInAustriaFlag,0) = 1 OR (ISNULL(Item.NKE_MadeInAustriaFlag,0) = 0 AND ISNULL(Item.PurchaseFlag,0) = 0) ) AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN COSTS ON COSTS.DocumentNumber = WarehouseStockMovement.DocumentNumber
)
,MOVEMENTS_PURCHBOM AS (
SELECT		CAST(WarehouseStockMovement.SrcRecLocationId AS varchar(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
			,ISNULL(WarehouseStockMovement.OriginDocumentNumber,WarehouseStockMovement.DocumentNumber) AS DocumentNumberROOT
			,WarehouseStockMovement.DocumentNumber AS DocumentNumber
			,COALESCE(try1.CompanyAccountId,try2.CompanyAccountId,try3.CompanyAccountId,try4.CompanyAccountId,try5.CompanyAccountId,try6.CompanyAccountId,try7.CompanyAccountId,'124306.002') AS SUPPLIERID
			,WarehouseStockMovement.ItemId AS ITEMID
			,WarehouseStockMovement.BatchId AS BATCH
			,CAST((CASE WHEN WarehouseStockMovement.Type IN ('RS') THEN -WarehouseStockMovement.Quantity WHEN ISNULL(WarehouseStockMovement.Mode,0) = 0 THEN WarehouseStockMovement.Quantity ELSE NULL END) AS NUMERIC(32,6)) AS QUANTITY
			,CAST(COALESCE(try1.ReceivingDate,try2.ReceivingDate,try3.ReceivingDate,try4.ReceivingDate,try5.ReceivingDate,try6.ReceivingDate,try7.ReceivingDate,NULL) AS DATETIME) AS RECEIPTDATE
			,CAST(CAST(MIN(WarehouseStockMovement.Insdate) OVER(PARTITION BY ISNULL(WarehouseStockMovement.OriginDocumentNumber,WarehouseStockMovement.DocumentNumber), Report.LocationId ORDER BY WarehouseStockMovement.Insdate ASC) AS DATE) AS DATETIME) AS PHYSICALDATE
			,CAST(CASE WHEN WarehouseStockMovement.Type IN ('RS') THEN -COSTS.COSTSMAT ELSE COSTS.COSTSMAT END AS NUMERIC(32,6)) AS COSTSMAT
			,CAST(CASE WHEN WarehouseStockMovement.Type IN ('RS') THEN -COSTS.COSTS ELSE COSTS.COSTS END AS NUMERIC(32,6)) AS COSTS	
FROM        (SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_WarehouseStockMovement_NKE AS WarehouseStockMovement ON ISNULL(WarehouseStockMovement.Quantity,0) <> 0 AND ( (WarehouseStockMovement.Type IN ('AE') AND ISNULL(WarehouseStockMovement.Mode,0) IN (0,2)) OR (WarehouseStockMovement.Type IN ('RS') AND ISNULL(WarehouseStockMovement.Mode,1) IN (1)) ) AND ISNULL(WarehouseStockMovement.CanceledFlag,0) = 0 AND ISNULL(WarehouseStockMovement.NoStockFlag,0) = 0 AND WarehouseStockMovement.RecActive = 1 AND WarehouseStockMovement.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = WarehouseStockMovement.ItemId AND Item.ItemGroupId BETWEEN 5000 AND 6999 AND ISNULL(Item.NKE_MadeInAustriaFlag,0) = 0 AND ISNULL(Item.PurchaseFlag,0) = 1 AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_OrderBomLine_NKE AS OrderBomLine ON OrderBomLine.OrderBomId = WarehouseStockMovement.WorkOrderId AND OrderBomLine.Structure = WarehouseStockMovement.LineId AND OrderBomLine.RecActive = 1 AND OrderBomLine.SrcRecLocationId = Report.LocationId
			LEFT JOIN BATCHES_DELIVERED AS try1 ON OrderBomLine.NKE_PreBatchId IS NOT NULL AND try1.Priority = 1
				AND try1.ItemId = OrderBomLine.ItemId AND try1.BatchId = OrderBomLine.NKE_PreBatchId
			LEFT JOIN BATCHES_DELIVERED AS try2 ON try1.CompanyAccountId IS NULL AND OrderBomLine.BatchId IS NOT NULL AND try2.Priority = 1
				AND try2.ItemId = OrderBomLine.ItemId AND try2.BatchId = OrderBomLine.BatchId
			LEFT JOIN BATCHES_DELIVERED AS try3 ON COALESCE(try1.CompanyAccountId,try2.CompanyAccountId) IS NULL AND ISNULL(OrderBomLine.NKE_PreBatchId,OrderBomLine.BatchId) IS NOT NULL AND try3.Priority = 2
				AND try3.ItemId = OrderBomLine.ItemId AND try3.BatchId = WarehouseStockMovement.BatchId AND try3.NKE_PreBatchId = ISNULL(OrderBomLine.NKE_PreBatchId,OrderBomLine.BatchId)
			LEFT JOIN BATCHES_DELIVERED AS try4 ON COALESCE(try1.CompanyAccountId,try2.CompanyAccountId,try3.CompanyAccountId) IS NULL AND WarehouseStockMovement.BatchId IS NOT NULL AND try4.Priority = 3
				AND try4.ItemId = OrderBomLine.ItemId AND try4.BatchId = WarehouseStockMovement.BatchId
			LEFT JOIN BATCHES_DELIVERED AS try5 ON COALESCE(try1.CompanyAccountId,try2.CompanyAccountId,try3.CompanyAccountId,try4.CompanyAccountId) IS NULL AND WarehouseStockMovement.BatchId IS NOT NULL AND try5.Priority = 3
				AND try5.ItemId = WarehouseStockMovement.ItemId AND try5.BatchId = WarehouseStockMovement.BatchId
			LEFT JOIN BATCHES_DELIVERED AS try6 ON COALESCE(try1.CompanyAccountId,try2.CompanyAccountId,try3.CompanyAccountId,try4.CompanyAccountId,try5.CompanyAccountId) IS NULL AND WarehouseStockMovement.BatchId IS NOT NULL AND try6.Priority = 1
				AND try6.ItemId = OrderBomLine.ItemId AND try6.BatchId = WarehouseStockMovement.BatchId
			LEFT JOIN BATCHES_DELIVERED AS try7 ON COALESCE(try1.CompanyAccountId,try2.CompanyAccountId,try3.CompanyAccountId,try4.CompanyAccountId,try5.CompanyAccountId,try6.CompanyAccountId) IS NULL AND WarehouseStockMovement.BatchId IS NOT NULL AND try7.Priority = 1
				AND try7.ItemId = WarehouseStockMovement.ItemId AND try7.BatchId = WarehouseStockMovement.BatchId
			LEFT JOIN COSTS ON COSTS.DocumentNumber = WarehouseStockMovement.DocumentNumber
)
,MOVEMENTS AS (
SELECT COMPANYID, SUBSIDIARYID, DocumentNumberROOT, DocumentNumber, SUPPLIERID, ITEMID, BATCH, QUANTITY, RECEIPTDATE, PHYSICALDATE, COSTSMAT, COSTS FROM MOVEMENTS_PRODBOM
UNION ALL
SELECT COMPANYID, SUBSIDIARYID, DocumentNumberROOT, DocumentNumber, SUPPLIERID, ITEMID, BATCH, QUANTITY, ISNULL(RECEIPTDATE,PHYSICALDATE) AS RECEIPTDATE, PHYSICALDATE, COSTSMAT, COSTS FROM MOVEMENTS_PURCHBOM
)
SELECT		CAST(MOVEMENTS.COMPANYID AS varchar(40)) AS COMPANYID
			,CAST(MOVEMENTS.SUBSIDIARYID AS VARCHAR(80)) AS SUBSIDIARYID
			,CAST(MOVEMENTS.SUPPLIERID AS VARCHAR(80)) AS SUPPLIERID
			,CAST(MOVEMENTS.ITEMID AS VARCHAR(160)) AS ITEMID
			,CAST(MOVEMENTS.BATCH AS VARCHAR(160)) AS BATCHID
			,CAST(SUM(MOVEMENTS.QUANTITY) AS NUMERIC(32,6)) AS QUANTITY
			,CAST(RECEIPTDATE AS TIMESTAMP(6)) AS RECEIPTDATE
			,CAST(MOVEMENTS.PHYSICALDATE AS TIMESTAMP(6)) AS PHYSICALDATE
			,CAST( CASE WHEN SUM(MOVEMENTS.QUANTITY) = 0 THEN 0 ELSE CAST(SUM(MOVEMENTS.COSTSMAT)/SUM(MOVEMENTS.QUANTITY) AS NUMERIC(32,2)) END AS NUMERIC(32,6)) AS UNITCOSTMAT
			,CAST( CASE WHEN SUM(MOVEMENTS.QUANTITY) = 0 THEN 0 ELSE CAST(SUM(MOVEMENTS.COSTS)/SUM(MOVEMENTS.QUANTITY) AS NUMERIC(32,2)) END AS NUMERIC(32,6)) AS UNITCOST
FROM		MOVEMENTS
GROUP BY	MOVEMENTS.COMPANYID
			,MOVEMENTS.SUBSIDIARYID
			,MOVEMENTS.SUPPLIERID
			,MOVEMENTS.ITEMID
			,MOVEMENTS.BATCH
			,MOVEMENTS.RECEIPTDATE
			,MOVEMENTS.PHYSICALDATE
HAVING		SUM(MOVEMENTS.QUANTITY) <> 0;