TRUNCATE TABLE fersads.ds_InventWarehouse_SP_NKE;

INSERT INTO fersads.ds_InventWarehouse_SP_NKE(COMPANYID,SUBSIDIARYID,ITEMID,PHYSICALINVENT,RESERVPHYSICAL,PICKED,INVENTBATCHID,INVENTLOCATIONID,INVENTSERIALID,INVENTSITEID,INVENTSIZEID,INVENTSTATUSID,INVENTSTYLEID,LICENSEPLATEID,WMSLOCATIONID,RECTYPE,UNITCOST,CURRENCYCODE,EXCHANGERATE_EUR,EXCHANGERATE_USD) 
WITH
INVENTSTANDARDPRICES AS (
SELECT		t1.ItemId, t2.ElementValueNew/ISNULL(NULLIF(t1.InventoryPriceQuantity,0),1.000000) AS CostsMat, t1.InventoryPriceNew/ISNULL(NULLIF(t1.InventoryPriceQuantity,0),1.000000) AS Costs, t1.SrcRecLocationId
FROM (
SELECT		InventoryPriceHistory.ItemId, MAX(InventoryPriceHistory.InventoryPriceHistoryId) AS InventoryPriceHistoryId, InventoryPriceHistory.SrcRecLocationId
FROM 		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_InventoryPriceHistory_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_InventoryPriceHistory_NKE AS InventoryPriceHistory ON InventoryPriceHistory.RecActive = 1 AND InventoryPriceHistory.SrcRecLocationId = Report.LocationId
GROUP BY	InventoryPriceHistory.ItemId, InventoryPriceHistory.SrcRecLocationId
) AS		SelectedHistory
			INNER JOIN nkeds.ds_InventoryPriceHistory_NKE AS t1 ON t1.InventoryPriceHistoryId = SelectedHistory.InventoryPriceHistoryId AND t1.RecActive = 1
			INNER JOIN nkeds.ds_InventoryPriceHistoryElement_NKE AS t2 ON t2.InventoryPriceHistoryId = t1.InventoryPriceHistoryId AND t2.CostElementId = 'K01' AND t2.RecActive = 1
WHERE		COALESCE(NULLIF(t1.InventoryPriceNew,0),NULLIF(t2.ElementValueNew,0)) IS NOT NULL
)
,BATCHDATES AS (
SELECT		BatchId, ItemId, CAST(CAST(MIN(Insdate) AS DATE) AS DATETIME) AS BatchDate, SrcRecLocationId
FROM		nkeds.ds_WarehouseStockMovement_NKE
WHERE 		RecActive = 1 AND BatchId NOTNULL
GROUP BY	BatchId, ItemId, SrcRecLocationId
)
,RESERVEDQTY AS (
SELECT		t1.ItemId, SUM(t1.AssignedQuantity) AS Quantity, t1.SrcRecLocationId
FROM 		nkeds.ds_ItemDispo_NKE AS t1
			INNER JOIN nkeds.ds_DispoType_NKE AS t2 ON t2.DispoType = t1.Type AND ISNULL(t2.NKE_AssignedDispoFlag,0) = 1 AND t2.RecActive = 1 AND t2.SrcRecLocationId = t1.SrcRecLocationId
WHERE		t1.RecActive = 1
GROUP BY	t1.ItemId, t1.SrcRecLocationId
HAVING 		SUM(t1.AssignedQuantity) > 0
)
--,PRICEGROUPINGQTY AS (
--SELECT		PriceGroupingId, SUM(Quantity) AS Quantity, SrcRecLocationId
--FROM		nkeds.ds_WarehouseOccupancy_NKE
--WHERE		RecActive = 1
--GROUP BY	PriceGroupingId, SrcRecLocationId
--)
--,PRICEGROUPINGCOSTS AS (
--SELECT		t1.PriceGroupingId, t3.Quantity, SUM(CASE WHEN t1.CostElementId IN ('K01') THEN t1.TotalElementValue ELSE NULL END)/t3.Quantity AS BatchCostsMatPerUnit,SUM(t1.TotalElementValue)/t3.Quantity AS BatchCostsPerUnit, t1.SrcRecLocationId
--FROM		nkeds.ds_WarehouseOccupancyElement_NKE AS t1
--			INNER JOIN nkeds.ds_CostElement_NKE AS t2 ON t2.CostElementId = t1.CostElementId AND ISNULL(t2.IgnoreFlag,0) = 0 AND t2.RecActive = 1 AND t2.SrcRecLocationId = t1.SrcRecLocationId
--			LEFT JOIN PRICEGROUPINGQTY AS t3 ON t3.PriceGroupingId = t1.PriceGroupingId AND t3.SrcRecLocationId = t1.SrcRecLocationId
--WHERE 		t1.RecActive = 1
--GROUP BY	t1.PriceGroupingId, t3.Quantity, t1.SrcRecLocationId
--)
,INVENTWAREHOUSE AS (
SELECT		CAST(Report.LocationId AS VARCHAR(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
			,CAST(Invent.ItemId AS VARCHAR(160)) AS ITEMID
			,CAST(Invent.Quantity AS NUMERIC(32,6)) AS PHYSICALINVENT
			,CAST(CASE
				WHEN ISNULL(RESERVEDQTY.Quantity,0) = 0 OR ISNULL(Warehouse.NKE_InventoryValueFlag,0) = 0 OR ISNULL(Warehouse.WarehouseType,0) IN (1,8) OR ISNULL(Warehouse.DispoFlag,0) = 0
				THEN 0
				WHEN ISNULL(RESERVEDQTY.Quantity,0) >= ISNULL(SUM(CASE WHEN ISNULL(Warehouse.WarehouseType,0) NOT IN (1,8) AND ISNULL(Warehouse.DispoFlag,0) = 1 THEN Invent.Quantity ELSE 0 END) OVER(PARTITION BY Invent.ItemId ORDER BY ISNULL(BATCHDATES.BatchDate,Invent.InDate) ASC, Invent.Quantity ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),0)
				THEN Invent.Quantity
				WHEN ISNULL(RESERVEDQTY.Quantity,0) BETWEEN ISNULL(SUM(CASE WHEN ISNULL(Warehouse.WarehouseType,0) NOT IN (1,8) AND ISNULL(Warehouse.DispoFlag,0) = 1 THEN Invent.Quantity ELSE 0 END) OVER(PARTITION BY Invent.ItemId ORDER BY ISNULL(BATCHDATES.BatchDate,Invent.InDate) ASC, Invent.Quantity ASC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0) AND ISNULL(SUM(CASE WHEN ISNULL(Warehouse.WarehouseType,0) NOT IN (1,8) AND ISNULL(Warehouse.DispoFlag,0) = 1 THEN Invent.Quantity ELSE 0 END) OVER(PARTITION BY Invent.ItemId ORDER BY ISNULL(BATCHDATES.BatchDate,Invent.InDate) ASC, Invent.Quantity ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),0)
				THEN ISNULL(RESERVEDQTY.Quantity,0) - ISNULL(SUM(CASE WHEN ISNULL(Warehouse.WarehouseType,0) NOT IN (1,8) AND ISNULL(Warehouse.DispoFlag,0) = 1 THEN Invent.Quantity ELSE 0 END) OVER(PARTITION BY Invent.ItemId ORDER BY ISNULL(BATCHDATES.BatchDate,Invent.InDate) ASC, Invent.Quantity ASC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0)
				ELSE 0
			END AS NUMERIC(32,6)) AS RESERVPHYSICAL
			,CAST(CASE
				WHEN ISNULL(Warehouse.WarehouseType,0) IN (8)
				THEN 0--Invent.Quantity
				ELSE 0
			END AS NUMERIC(32,6)) AS PICKED
			,CAST(Invent.BatchId AS VARCHAR(160)) AS INVENTBATCHID
			,CAST(CASE
				WHEN ISNULL(Warehouse.WarehouseType,0) IN (1,8)
				THEN RTRIM(Warehouse.CompanyAccountId) /*2024-02-13: CustomerId in case of sales consignation acc. Ignacio Torralba*/
				ELSE 'NAUT' /*2023-07-11: NAUT instead of WarehouseId acc. to Diego Bazo*/
			END AS VARCHAR(80)) AS INVENTLOCATIONID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSERIALID
			,CAST(CASE
				WHEN UPPER(Warehouse.LocationId) = UPPER('Default') THEN 'NAUT'
				ELSE Warehouse.LocationId 
			END AS VARCHAR(80)) AS INVENTSITEID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSIZEID
			,CAST(CASE
				WHEN ISNULL(Warehouse.WarehouseType,0) = 1 THEN 'Consignation'
				WHEN ISNULL(Warehouse.WarehouseType,0) = 8 THEN 'Consignation Transfer'
				WHEN ISNULL(Warehouse.DispoFlag,0) = 0 THEN 'Blocked'
				WHEN ISNULL(Warehouse.DispoFlag,0) = 1 THEN 'Available'
				ELSE NULL
			END AS VARCHAR(40)) AS INVENTSTATUSID
			,CAST(ISNULL(Item.MaterialGroupId,'GEN') AS VARCHAR(40)) AS INVENTSTYLEID
			,CAST(Invent.SerialNumber AS VARCHAR(400)) AS LICENSEPLATEID
			,CAST(RTRIM(Invent.WarehouseId)||'.'||RTRIM(Invent.WarehouseBinId) AS VARCHAR(40)) AS WMSLOCATIONID /*2023-07-11: WarehouseId + BinId acc. to Diego Bazo, incl. WMSLocation master table*/
			,CAST(NULL AS NUMERIC(32,6)) AS RECTYPE
			,CAST(CASE
				WHEN ISNULL(Warehouse.NKE_InventoryValueFlag,0) = 0
				THEN NULL
				ELSE INVENTSTANDARDPRICES.Costs
			END AS NUMERIC(32,6)) AS UNITCOST
			,CAST(CASE
				WHEN ISNULL(Warehouse.NKE_InventoryValueFlag,0) = 0 OR INVENTSTANDARDPRICES.Costs IS NULL
				THEN NULL
				ELSE 'EUR'
			END AS VARCHAR(20)) AS CURRENCYCODE
			,CAST(CASE
				WHEN ISNULL(Warehouse.NKE_InventoryValueFlag,0) = 0 OR INVENTSTANDARDPRICES.Costs IS NULL
				THEN NULL
				ELSE 1
			END AS NUMERIC(32,6)) AS EXCHANGERATE_EUR
			,CAST(NULL AS NUMERIC(32,6)) AS EXCHANGERATE_USD
FROM		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_WarehouseStockMovement_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_WarehouseOccupancy_NKE AS Invent ON Invent.RecActive = 1 AND Invent.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Warehouse_NKE AS Warehouse ON Warehouse.WarehouseId = Invent.WarehouseId AND Warehouse.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = Invent.ItemId AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN BATCHDATES ON BATCHDATES.ItemId = Invent.ItemId AND BATCHDATES.BatchId = Invent.BatchId AND BATCHDATES.SrcRecLocationId = Report.LocationId
			LEFT JOIN RESERVEDQTY ON RESERVEDQTY.ItemId = Invent.ItemId AND RESERVEDQTY.SrcRecLocationId = Report.LocationId
			-- LEFT JOIN PRICEGROUPINGCOSTS ON PRICEGROUPINGCOSTS.PriceGroupingId = Invent.PriceGroupingId AND PRICEGROUPINGCOSTS.SrcRecLocationId = Report.LocationId
			LEFT JOIN INVENTSTANDARDPRICES ON INVENTSTANDARDPRICES.ItemId = Invent.ItemId AND INVENTSTANDARDPRICES.SrcRecLocationId = Report.LocationId
)
SELECT * FROM INVENTWAREHOUSE;