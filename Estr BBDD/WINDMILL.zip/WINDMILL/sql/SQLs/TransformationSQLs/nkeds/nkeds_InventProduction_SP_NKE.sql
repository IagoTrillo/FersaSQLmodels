TRUNCATE TABLE fersads.ds_InventProduction_SP_NKE;

INSERT INTO fersads.ds_InventProduction_SP_NKE(COMPANYID,SUBSIDIARYID,ITEMID,PHYSICALINVENT,RESERVPHYSICAL,PICKED,INVENTBATCHID,INVENTLOCATIONID,INVENTSERIALID,INVENTSITEID,INVENTSIZEID,INVENTSTATUSID,INVENTSTYLEID,LICENSEPLATEID,WMSLOCATIONID,RECTYPE,UNITCOST,CURRENCYCODE,EXCHANGERATE_EUR,EXCHANGERATE_USD) 
WITH
INVENTSTANDARDPRICES AS (
SELECT		t1.ItemId, t2.ElementValueNew/ISNULL(NULLIF(t1.InventoryPriceQuantity,0),1.000000) AS UnitCostsMat, t1.InventoryPriceNew/ISNULL(NULLIF(t1.InventoryPriceQuantity,0),1.000000) AS UnitCosts, t1.SrcRecLocationId
FROM (
SELECT		InventoryPriceHistory.ItemId, MAX(InventoryPriceHistory.InventoryPriceHistoryId) AS InventoryPriceHistoryId, InventoryPriceHistory.SrcRecLocationId
FROM 		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_InventoryPriceHistory_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_InventoryPriceHistory_NKE AS InventoryPriceHistory ON InventoryPriceHistory.RecActive = 1 AND InventoryPriceHistory.SrcRecLocationId = Report.LocationId
GROUP BY	InventoryPriceHistory.ItemId, InventoryPriceHistory.SrcRecLocationId
) AS		SelectedHistory
			INNER JOIN nkeds.ds_InventoryPriceHistory_NKE AS t1 ON t1.InventoryPriceHistoryId = SelectedHistory.InventoryPriceHistoryId AND t1.RecActive = 1
			INNER JOIN nkeds.ds_InventoryPriceHistoryElement_NKE AS t2 ON t2.InventoryPriceHistoryId = t1.InventoryPriceHistoryId AND t2.CostElementId = 'K01' AND t2.RecActive = 1
WHERE		COALESCE(NULLIF(t1.InventoryPriceNew,0),NULLIF(t2.ElementValueNew,0)) IS NOT NULL
),
UNPLANNEDSTOCKMOVEMENTS AS (
SELECT		NewWorkOrderId, NewLineId, SUM(ISNULL(Quantity,0)) AS QuantityTotal, SrcRecLocationId
FROM 		nkeds.ds_WarehouseStockMovement_NKE
WHERE 		Type = 'UF' AND ISNULL(Mode,0) = 0 AND ISNULL(CanceledFlag,0) = 0 AND RecActive = 1
GROUP BY	NewWorkOrderId, NewLineId, SrcRecLocationId
)
,PRODUCTIONCOMPONENTS AS (
SELECT		CAST(OrderBomLine.SrcRecLocationId AS VARCHAR(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
			,CAST(OrderBomLine.ItemId AS VARCHAR(160)) AS ITEMID
			,CAST(CASE
				WHEN ISNULL(ProductionOrder.ActualQuantity,0) BETWEEN 0 AND ISNULL(SUM(StockMovement.DocumentQuantity) OVER(PARTITION BY OrderBomLine.Id ORDER BY StockMovement.Id ASC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0)
				THEN ISNULL(StockMovement.DocumentQuantity,0)
				WHEN ISNULL(ProductionOrder.ActualQuantity,0) BETWEEN ISNULL(SUM(StockMovement.DocumentQuantity) OVER(PARTITION BY OrderBomLine.Id ORDER BY StockMovement.Id ASC ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0) AND ISNULL(SUM(StockMovement.DocumentQuantity) OVER(PARTITION BY OrderBomLine.Id ORDER BY StockMovement.Id ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),0)
				THEN -ISNULL(ProductionOrder.ActualQuantity,0) + ISNULL(SUM(StockMovement.DocumentQuantity) OVER(PARTITION BY OrderBomLine.Id ORDER BY StockMovement.Id ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),0)
				ELSE 0
			END AS NUMERIC(32,6)) AS PHYSICALINVENT
			,CAST(StockMovement.BatchId AS VARCHAR(160)) AS INVENTBATCHID
			,CAST('PRODUCTION (Components)' AS VARCHAR(80)) AS INVENTLOCATIONID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSERIALID
			,CAST('NAUT' AS VARCHAR(80)) AS INVENTSITEID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSIZEID
			,CAST('Available' AS VARCHAR(40)) AS INVENTSTATUSID
			,CAST(ISNULL(Item.MaterialGroupId,'GEN') AS VARCHAR(40)) AS INVENTSTYLEID
			,CAST(StockMovement.SerialNumber AS VARCHAR(400)) AS LICENSEPLATEID
			,CAST(NULL/*OrderBomLine.OrderBomId*/ AS VARCHAR(40)) AS WMSLOCATIONID
			,CAST(NULL AS NUMERIC(32,6)) AS RECTYPE
			,CAST(StockMovement.ConsumptionPrice AS NUMERIC(32,6)) AS UNITCOST
			,CAST('EUR' AS VARCHAR(20)) AS CURRENCYCODE
			,CAST(1 AS NUMERIC(32,6)) AS EXCHANGERATE_EUR
    		,CAST(NULL AS NUMERIC(32,6)) AS EXCHANGERATE_USD
FROM 		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_OrderBomLine_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_OrderBomLine_NKE AS OrderBomLine ON OrderBomLine.Status = 8 AND OrderBomLine.Structure <> 0 AND OrderBomLine.RecActive = 1 AND OrderBomLine.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_OrderBom_NKE AS OrderBom ON OrderBom.OrderBomId = OrderBomLine.OrderBomId AND OrderBom.RecActive = 1 AND OrderBom.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_OrderBomLine_NKE AS OrderBomLinePre ON OrderBomLinePre.OrderBomId = OrderBomLine.OrderBomId AND OrderBomLinePre.LineId = OrderBomLine.Structure AND OrderBomLinePre.Status BETWEEN 5 AND 6 AND OrderBomLinePre.RecActive = 1 AND OrderBomLinePre.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_ProductionOrder_NKE AS ProductionOrder ON ProductionOrder.WorkOrderId = OrderBomLinePre.FulfillerDocId AND ProductionOrder.LineId = OrderBomLinePre.WorkOrderLineId AND ProductionOrder.RecActive = 1 AND ProductionOrder.SrcRecLocationId = Report.LocationId
			LEFT JOIN UNPLANNEDSTOCKMOVEMENTS AS StockMovementUF ON StockMovementUF.NewWorkOrderId = OrderBomLine.OrderBomId AND StockMovementUf.NewLineId = OrderBomLine.LineId AND StockMovementUF.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_WarehouseStockMovement_NKE AS StockMovement ON StockMovement.NewWorkOrderId = OrderBomLine.OrderBomId AND StockMovement.NewLineId = OrderBomLine.LineId AND StockMovement.Type IN ('AF','UF') AND ISNULL(StockMovement.Mode,0) = 0 AND ISNULL(StockMovement.CanceledFlag,0) = 0 AND StockMovement.RecActive = 1 AND StockMovement.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = OrderBomLine.ItemId AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
WHERE 		ISNULL(OrderBomLine.Quantity,0) <> 0
			AND ( ISNULL(OrderBomLine.ActualQuantity,0) + ISNULL(StockMovementUF.QuantityTotal,0) - ISNULL(ProductionOrder.ActualQuantity,0) ) > 0
)
,INVENTPRODUCTIONCOMPONENTS AS (
SELECT		COMPANYID
			,SUBSIDIARYID
			,ITEMID
			,CAST(0 AS NUMERIC(32,6)) AS PHYSICALINVENT /*2023-07-10: 0 acc. to Diego Bazo*/
			,CAST(0 AS NUMERIC(32,6)) AS RESERVPHYSICAL /*2023-07-10: 0 acc. to Diego Bazo*/
			,CAST(SUM(PHYSICALINVENT) AS NUMERIC(32,6)) AS PICKED
			,INVENTBATCHID
			,INVENTLOCATIONID
			,INVENTSERIALID
			,INVENTSITEID
			,INVENTSIZEID
			,INVENTSTATUSID
			,INVENTSTYLEID
			,LICENSEPLATEID
			,WMSLOCATIONID
			,RECTYPE
			,UNITCOST
			,CURRENCYCODE
			,EXCHANGERATE_EUR
    		,EXCHANGERATE_USD
FROM		PRODUCTIONCOMPONENTS
WHERE 		ISNULL(PHYSICALINVENT,0) <> 0
GROUP BY	COMPANYID
			,SUBSIDIARYID
			,ITEMID
			,INVENTBATCHID
			,INVENTLOCATIONID
			,INVENTSERIALID
			,INVENTSITEID
			,INVENTSIZEID
			,INVENTSTATUSID
			,INVENTSTYLEID
			,LICENSEPLATEID
			,WMSLOCATIONID
			,RECTYPE
			,UNITCOST
			,CURRENCYCODE
			,EXCHANGERATE_EUR
    		,EXCHANGERATE_USD
)
,INVENTFINISHEDGOODS AS (
SELECT 		CAST(OrderBomLine.SrcRecLocationId AS VARCHAR(40)) AS COMPANYID
			,CAST('NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
			,CAST(OrderBomLine.ItemId AS VARCHAR(160)) AS ITEMID
			,CAST(0 AS NUMERIC(32,6)) AS PHYSICALINVENT /*2023-07-10: 0 acc. to Diego Bazo*/
			,CAST(0 AS DECIMAL(32,6)) AS RESERVPHYSICAL /*2023-07-10: 0 acc. to Diego Bazo*/
			,CAST((ISNULL(OrderBomLine.Quantity,0) - ISNULL(ProductionOrder.ActualQuantity,0)) AS DECIMAL(32,6)) AS PICKED
			,CAST(OrderBomLine.BatchId AS VARCHAR(160)) AS INVENTBATCHID
			,CAST('PRODUCTION (Finished Goods)' AS VARCHAR(80)) AS INVENTLOCATIONID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSERIALID
			,CAST('NAUT' AS VARCHAR(80)) AS INVENTSITEID
			,CAST(NULL AS VARCHAR(400)) AS INVENTSIZEID
			,CAST('Available' AS VARCHAR(40)) AS INVENTSTATUSID
			,CAST(ISNULL(Item.MaterialGroupId,'GEN') AS VARCHAR(40)) AS INVENTSTYLEID
			,CAST(NULL AS VARCHAR(400)) AS LICENSEPLATEID
			,CAST(NULL/*OrderBomLine.OrderBomId*/ AS VARCHAR(40)) AS WMSLOCATIONID
			,CAST(NULL AS NUMERIC(32,6)) AS RECTYPE
			,CAST(INVENTSTANDARDPRICES.UnitCosts AS NUMERIC(32,6)) AS UNITCOST
			,CAST('EUR' AS VARCHAR(20)) AS CURRENCYCODE
			,CAST(1 AS NUMERIC(32,6)) AS EXCHANGERATE_EUR
    		,CAST(NULL AS NUMERIC(32,6)) AS EXCHANGERATE_USD
FROM 		(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_OrderBomLine_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
			INNER JOIN nkeds.ds_OrderBomLine_NKE AS OrderBomLine ON OrderBomLine.Status = 7 AND OrderBomLine.Structure = 0 AND OrderBomLine.RecActive = 1 AND OrderBomLine.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_OrderBom_NKE AS OrderBom ON OrderBom.OrderBomId = OrderBomLine.OrderBomId AND OrderBom.RecActive = 1 AND OrderBom.SrcRecLocationId = Report.LocationId
			INNER JOIN nkeds.ds_OrderBomLine_NKE AS OrderBomLinePre ON OrderBomLinePre.OrderBomId = OrderBomLine.OrderBomId AND OrderBomLinePre.LineId = OrderBomLine.Structure AND OrderBomLinePre.Status < 7 AND OrderBomLinePre.RecActive = 1 AND OrderBomLinePre.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_PurchaseOrderLine_NKE AS PurchaseOrderLine ON PurchaseOrderLine.PurchaseOrderId = OrderBomLine.FulfillerDocId AND PurchaseOrderLine.LineId = OrderBomLine.WorkOrderLineId AND OrderBomLIne.FulfillerType IN ('E') AND PurchaseOrderLIne.RecActive = 1 AND PurchaseOrderLine.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_ProductionOrder_NKE AS ProductionOrder ON ProductionOrder.WorkOrderId = OrderBomLine.FulfillerDocId AND ProductionOrder.LineId = OrderBomLine.WorkOrderLineId AND OrderBomLine.FulfillerType IN ('F') AND ProductionOrder.RecActive = 1 AND ProductionOrder.SrcRecLocationId = Report.LocationId
			LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = OrderBomLine.ItemId AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
			LEFT JOIN INVENTSTANDARDPRICES AS INVENTSTANDARDPRICES ON INVENTSTANDARDPRICES.ItemId = OrderBomLine.ItemId AND INVENTSTANDARDPRICES.SrcRecLocationId = Report.LocationId
WHERE		ISNULL(PurchaseOrderLine.Status,0) <> 7
			AND ISNULL(ProductionOrder.Status,0) <> 6
			AND (ISNULL(OrderBomLine.Quantity,0) - ISNULL(ProductionOrder.ActualQuantity,0)) <> 0
)
SELECT * FROM INVENTPRODUCTIONCOMPONENTS UNION ALL SELECT * FROM INVENTFINISHEDGOODS;