TRUNCATE TABLE fersads.ds_BOMPlain_SP_NKE;

INSERT INTO fersads.ds_BOMPlain_SP_NKE(BOMID,ITEMID,BOMTYPE,BOMQTY,UNITID,PMFPLANGROUPID,PRIORITY,SUBSIDIARYID,ACTIVE,APPROVED,RECID,BOMITEMID,COMPANYID)
WITH BOMPLAIN AS (SELECT	CAST(Bom.BomId AS VARCHAR(160)) AS BOMID
		,CAST(Bom.ItemId AS VARCHAR(160)) AS ITEMID
		,CAST(NULL AS INTEGER) AS BOMTYPE
		,CAST(ISNULL(BomLine.Quantity,1) AS NUMERIC(32,6)) AS BOMQTY
		,CAST(ISNULL(UoMLng.TranslatedUoMId,UoM.UoMId) AS VARCHAR(16)) AS UNITID
		,CAST( CASE WHEN Bom.PrioAsc = 1 AND Bom.PrioAsc = Bom.PrioDesc THEN NULL ELSE CONCAT(Bom.PMFPREFIX,Bom.PMFGROUP) END AS VARCHAR(16)) AS PMFPLANGROUPID
		,CAST(Bom.PrioAsc AS INTEGER) AS PRIORITY
		,CAST(/*Bom.SrcRecLocationId*/'NAUT' AS VARCHAR(40)) AS SUBSIDARYID
		,CAST(CASE WHEN ISNULL(Bom.Active,0) = 1 AND ISNULL(Item.ItemStatus,0) = 3 THEN true ELSE false END AS BOOLEAN) AS ACTIVE
		,CAST(true AS BOOLEAN) AS APPROVED
		,CAST(Bom.BomRecId AS INTEGER) AS RECID
		,CAST(BomLine.ItemId AS VARCHAR(160)) AS BOMITEMID
		,CAST(Bom.SrcRecLocationId AS VARCHAR(40)) AS COMPANYID
FROM 	(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_ItemBom_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
		INNER JOIN (
			SELECT DerivedTab.*
			,ROW_NUMBER() OVER(PARTITION BY ItemId, SrcRecLocationId ORDER BY Standard DESC, Active DESC, Insdate DESC) AS PrioASC
			,ROW_NUMBER() OVER(PARTITION BY ItemId, SrcRecLocationId ORDER BY Standard ASC, Active ASC, Insdate ASC) AS PrioDESC
			FROM (
			SELECT 	'A' AS PMFPREFIX
					,CONCAT( REPEAT('0',10-LENGTH(CAST(ItemBomAlternative.RecId AS VARCHAR(10)))), TRIM(CAST(ItemBomAlternative.RecId AS VARCHAR(10))) ) AS PMFGROUP
					,BomItem.Id AS BomRecId, BomItem.NKE_ItemTypeId AS BomItemType, ItemBomAlternative.BomItemId AS BomId, ItemBomAlternative.ItemId AS ItemId
					,ISNULL(ItemBomAlternative.StandardBomFlag,0) AS Standard
					,CASE WHEN BomItem.ItemStatus = 3 AND Item.ItemStatus = 3 THEN 1 ELSE 0 END AS Active
					,ItemBomAlternative.SrcRecLocationId
					,ItemBomAlternative.Insdate
			FROM	nkeds.ds_ItemBomAlternative_NKE AS ItemBomAlternative
					LEFT JOIN nkeds.ds_Item_NKE AS BomItem ON BomItem.ItemId = ItemBomAlternative.BomItemId AND BomItem.RecActive = 1 AND BomItem.SrcRecLocationId = ItemBomAlternative.SrcRecLocationId
					LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = ItemBomAlternative.ItemId AND Item.RecActive = 1 AND Item.SrcRecLocationId = ItemBomAlternative.SrcRecLocationId
					INNER JOIN (SELECT DISTINCT BomItemId, SrcRecLocationId FROM nkeds.ds_ItemBom_NKE WHERE RecActive = 1) AS ItemBomExists ON ItemBomExists.BomItemId = ItemBomAlternative.BomItemId AND ItemBomExists.SrcRecLocationId = ItemBomAlternative.SrcRecLocationId
			WHERE 	ItemBomAlternative.RecActive = 1
					AND ItemBomAlternative.BomItemId != ItemBomAlternative.ItemId
			UNION ALL
			SELECT	'S' AS PMFPREFIX
					,CONCAT( REPEAT('0',10-LENGTH(CAST(ItemBom.RecId AS VARCHAR(10)))), TRIM(CAST(ItemBom.RecId AS VARCHAR(10))) ) AS PMFGROUP
					,BomItem.Id AS BomRecId, BomItem.NKE_ItemTypeId AS BomItemType, ItemBom.BomItemId AS BomId, ItemBom.BomItemId AS ItemId
					,CASE WHEN ISNULL(ItemBomAlternative.Cnt,0) = 0 THEN 1 ELSE 0 END AS Standard
					,CASE WHEN BomItem.ItemStatus = 3 THEN 1 ELSE 0 END AS Active
					,ItemBom.SrcRecLocationId
					,ItemBom.Insdate
			FROM 	nkeds.ds_ItemBom_NKE AS ItemBom
					LEFT JOIN nkeds.ds_Item_NKE AS BomItem ON BomItem.ItemId = ItemBom.BomItemId AND BomItem.RecActive = 1 AND BomItem.SrcRecLocationId = ItemBom.SrcRecLocationId
					LEFT JOIN (SELECT ItemId, SrcRecLocationId, COUNT(*) AS Cnt FROM nkeds.ds_ItemBomAlternative_NKE WHERE ISNULL(StandardBomFlag,0) = 1 AND BomItemId != ItemId AND RecActive = 1 GROUP BY ItemId, SrcRecLocationId) AS ItemBomAlternative ON ItemBomAlternative.ItemId = ItemBom.BomItemId AND ItemBomAlternative.SrcRecLocationId = ItemBom.SrcRecLocationId
			WHERE 	ItemBom.RecActive = 1	
			) AS DerivedTab
		) AS Bom ON Bom.SrcRecLocationId = Report.LocationId
		LEFT JOIN nkeds.ds_ItemBomLine_NKE AS BomLine ON BomLine.BomItemId = Bom.BomId AND BomLine.ItemId IS NOT NULL AND BomLine.RecActive = 1 AND BomLine.SrcRecLocationId = Report.LocationId
		LEFT JOIN nkeds.ds_Item_NKE AS Item ON Item.ItemId = BomLine.ItemId AND Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
		LEFT JOIN nkeds.ds_UnitOfMeasurement_NKE AS UoM ON UoM.UoMId = BomLine.ConsumptionUoMId AND UoM.ItemId IS NULL AND UoM.RecActive = 1 AND UoM.SrcRecLocationId = Report.LocationId
        LEFT JOIN nkeds.ds_UnitOfMeasurementLng_NKE AS UoMLng ON UoMLng.UoMId = UoM.UoMId AND UoMLng.Language = 'en' AND UoMLng.RecActive = 1 AND UoMLng.SrcRecLocationId = Report.LocationId
WHERE	BomLine.ItemId NOTNULL
)SELECT * FROM BOMPLAIN;