TRUNCATE TABLE fersads.ds_Item_SP_NKE;

INSERT INTO fersads.ds_Item_SP_NKE(
        COMPANYID
        ,SUBSIDIARYID
        ,ITEMID
        ,CATALOG
        ,NAME
        ,DESCRIPTION
        ,BEARINGTYPE
        ,BEARINGSUBTYPE
        ,ANGLE
        ,HEIGHT
        ,WIDTH
        ,INNERDIAMETER
        ,OUTERDIAMETER
        ,OUTERDIAMETER2
        ,RADIUS
        ,UNITID
        ,NETWEIGHT
        ,TARAWEIGHT
        ,GROSSWEIGHT
        ,ITEMTYPE
        ,SBU
        ,FAMILYNAME
        ,GLOBALCATALOG
        ,GLOBALPRODUCTTYPE
        ,MOQ
        ,ITEMCATEGORYCODE
        ,NAMEALIAS
        ,DEFAULTORDERTYPE
        ,ITEMGROUP
        ,ABC
        ,PLANNERGROUP
        ,MODELGROUPID
        ,INTRASTATCOMMODITY
        ,SALESBLOCKED
        ,PURCHBLOCKED
        ,INVENTORYBLOCKED
        ,COSTGROUP
        ,FINNACIALDIMENSIONS
        ,BRAND
        ,FERPRODUCTTYPE
        ,PRIMARYVENDORID
        ,PATH
        ,ORIGIN
        ,PURCHASECATEGORY
        ,PURCHASESUBCATEGORY
        ,WEBACTIVE
        ,PUBLISHWEBDATE
        ,FERITEMID
        ,ITEMGROUPID
        ,MODIFIEDDATETIME
)
WITH
ITEMCATEGORYCODESDEF AS (
SELECT 1 AS ANP_ItemQualityCategoryId, 'T1P' AS ItemQualityCategoryName
UNION ALL SELECT 2 AS ANP_ItemQualityCategoryId, 'T1SN' AS ItemQualityCategoryName
UNION ALL SELECT 3 AS ANP_ItemQualityCategoryId, 'T1S' AS ItemQualityCategoryName
UNION ALL SELECT 4 AS ANP_ItemQualityCategoryId, 'AM' AS ItemQualityCategoryName
UNION ALL SELECT 5 AS ANP_ItemQualityCategoryId, 'FIT' AS ItemQualityCategoryName
)
,ITEMNKE AS (
SELECT          CAST(Item.SrcRecLocationId AS VARCHAR(40)) AS COMPANYID
        ,CAST(/*Item.SrcRecLocationId*/'NAUT' AS VARCHAR(80)) AS SUBSIDIARYID
        ,CAST(Item.ItemId AS VARCHAR(160)) AS ITEMID
        ,CAST(Item.Name AS VARCHAR(240)) AS CATALOG
        ,CAST(Item.Name AS VARCHAR(240)) AS NAME
        ,CAST(Item.Name AS VARCHAR(400)) AS NAME
        ,CAST(ItemGroup.Anp_BearingTyp AS VARCHAR(240)) AS BEARINGTYPE
        ,CAST(ItemGroup.Anp_BearingSubtype AS VARCHAR(240)) AS BEARINGSUBTYPE
        ,CAST(NULL AS NUMERIC(32,6)) AS ANGLE
        ,CAST(Item.NKE_OuterDiameter AS NUMERIC(32,6)) AS HEIGHT
        ,CAST(Item.NKE_Width AS NUMERIC(32,6)) AS WIDTH
        ,CAST(Item.NKE_BoreDiameter AS NUMERIC(32,6)) AS INNERDIAMETER
        ,CAST(Item.NKE_OuterDiameter AS NUMERIC(32,6)) AS OUTERDIAMETER
        ,CAST(NULL AS NUMERIC(32,6)) AS OUTERDIAMETER2
        ,CAST(NULL AS NUMERIC(32,6)) AS RADIUS
        ,CAST(UoMLng.TranslatedUoMId AS VARCHAR(40)) AS UNITID
        ,CAST(Item.Weight AS NUMERIC(32,6)) AS NETWEIGHT
        ,CAST(NULL AS NUMERIC(32,6)) AS TARAWEIGHT
        ,CAST(NULL AS NUMERIC(32,6)) AS GROSSWEIGHT
        ,CAST(CASE
                WHEN Item.ItemGroupId BETWEEN 5000 AND 6999 OR Item.ItemId IN ('99998','99999') THEN 0
                WHEN Item.ItemGroupId BETWEEN 2210 AND 2249 THEN 0
                WHEN Item.ItemGroupId BETWEEN 8110 AND 8189 THEN 0
                WHEN Item.ItemGroupId BETWEEN 7010 AND 7010 THEN 0
                WHEN Item.ItemGroupId IS NULL AND Item.MaterialGroupId NOTNULL THEN 0
                ELSE 1
        END AS INTEGER) AS ITEMTYPE
        ,CAST(NULL AS VARCHAR(240)) AS SBU
        ,CAST(NULL AS VARCHAR(80)) AS FAMILYNAME
        ,CAST(NULL AS VARCHAR(80)) AS GLOBALCATALOG
        ,CAST(NULL AS VARCHAR(80)) AS GLOBALPRODUCTTYPE
        ,CAST((CASE WHEN ISNULL(Item.PurchaseFlag,0) = 1 THEN Item.MinOrderQuantity ELSE NULL END) AS NUMERIC(32,6)) AS MOQ
        ,CAST(ITEMCATEGORYCODESDEF.ItemQualityCategoryName AS VARCHAR(240)) AS ITEMCATEGORYCODE
        ,CAST(Item.Name AS VARCHAR(80)) AS NAMEALIAS
        ,CAST(CASE WHEN ISNULL(Item.PurchaseFlag,0)=1 THEN 0 WHEN ISNULL(Item.ProductionFlag,0)=1 AND Item.ItemGroupId BETWEEN 5000 AND 6999 THEN 1 ELSE NULL END AS INTEGER) AS DEFAULTORDERTYPE
        ,CAST(COALESCE(ItemGroup.NKE_Name_EN,ItemGroup.NKE_Name_USA,ItemGroup.Name,Item.ItemGroupId) AS VARCHAR(100)) AS ITEMGROUP
        ,CAST(Item.NKE_ABCSalesItem AS VARCHAR(8)) AS ABC
        ,CAST(Item.StaffId AS VARCHAR(40)) AS PLANNERGROUP
        ,CAST(Item.NKE_ItemTypeId AS VARCHAR(40)) AS MODELGROUPID
        ,CAST(Item.CustomsTariffId AS VARCHAR(80)) AS INTRASTATCOMMODITY
        ,CAST( (CASE WHEN ISNULL(Item.SalesFlag,0) = 0 OR ( ISNULL(Item.ItemStatus,'0') IN ('3') AND ISNULL(Item.NKE_Status,'0') NOT IN ('3','4','5','7') ) OR ISNULL(Item.ItemStatus,'0') = '4' THEN true ELSE false END) AS BOOLEAN) AS SALESBLOCKED
        ,CAST( (CASE WHEN ISNULL(Item.PurchaseFlag,0) = 0 OR ( ISNULL(Item.ItemStatus,'0') IN ('3') AND ISNULL(Item.NKE_Status,'0') NOT IN ('3','4','5') ) OR ISNULL(Item.ItemStatus,'0') = '4' THEN true ELSE false END) AS BOOLEAN) AS PURCHBLOCKED
        ,CAST( (CASE WHEN ISNULL(Item.ItemStatus,'0') NOT IN ('3') THEN true ELSE false END) AS BOOLEAN) AS INVENTORYBLOCKED
        ,CAST(Item.OverheadCostGroupId AS VARCHAR(40)) AS COSTGROUP
        ,CAST(CASE WHEN Item.MaterialGroupId = 'FERSA' THEN '---FER---' ELSE '---NKE---' END AS VARCHAR(2000)) AS FINNACIALDIMENSIONS
        ,CAST(CASE WHEN Item.MaterialGroupId = 'FERSA' THEN 'FER' ELSE Item.MaterialGroupId END AS VARCHAR(400)) AS BRAND
        ,CAST(Item.NKE_ItemTypeId AS VARCHAR(80)) AS FERPRODUCTTYPE
        ,CAST(Item.CompanyAccountId AS VARCHAR(80)) AS PRIMARYVENDORID
        ,CAST(NULL AS VARCHAR(450)) AS PATH
        ,CAST(NULL AS VARCHAR(40)) AS ORIGIN
        ,CAST(ItemGroupPurchase.Category AS VARCHAR(160)) AS PURCHASECATEGORY
        ,CAST(ItemGroupPurchase.SubCategory AS VARCHAR(160)) AS PURCHASESUBCATEGORY
        ,CAST((CASE WHEN ISNULL(Item.NKE_WebshopFlag,0) = 1 THEN True ELSE False END) AS BOOLEAN) AS WEBACTIVE
        ,CAST( ItemWebshop.ValidFrom AS DATETIME ) AS PUBLISHWEBDATE
        ,CAST(Item.NKE_ItemNumber_Fersa AS VARCHAR(160)) AS FERITEMID
        ,CAST(Item.ItemGroupId AS VARCHAR(80)) AS ITEMGROUPID
        ,CAST(APPLY_MAX(ARRAY[Item.RecDateModified, ItemGroup.RecDateModified, ItemGroupPurchase.RecDateModified, UoM.RecDateModified, UoMLng.RecDateModified, ItemWebshop.RecDateModified]) AS timestamp(6)) AS MODIFIEDDATETIME
FROM	(SELECT SrcRecLocationId AS LocationId FROM nkeds.ds_Item_NKE WHERE SrcRecLocationId = 'NKE' LIMIT 1) AS Report
	INNER JOIN nkeds.ds_Item_NKE AS Item ON /*ISNULL(Item.P2PlusSystemFlag,0) = 0 AND*/ Item.RecActive = 1 AND Item.SrcRecLocationId = Report.LocationId
        LEFT JOIN ITEMCATEGORYCODESDEF ON ITEMCATEGORYCODESDEF.ANP_ItemQualityCategoryId = Item.ANP_ItemQualityCategoryId
        LEFT JOIN nkeds.ds_ItemGroup_NKE AS ItemGroup ON ItemGroup.ItemGroupId = Item.ItemGroupId AND ItemGroup.RecActive = 1 AND ItemGroup.SrcRecLocationId = Report.LocationId
        LEFT JOIN nkeds.ds_NKE_ItemGroupPurchase_NKE AS ItemGroupPurchase ON ItemGroupPurchase.ItemGroupId = Item.ItemGroupId AND ItemGroupPurchase.RecActive = 1 AND ItemGroupPurchase.SrcRecLocationId = Report.LocationId
        LEFT JOIN nkeds.ds_UnitOfMeasurement_NKE AS UoM ON UoM.UoMId = Item.ConsumptionUoMId AND UoM.ItemId ISNULL AND UoM.RecActive = 1 AND UoM.SrcRecLocationId = Report.LocationId
        LEFT JOIN nkeds.ds_UnitOfMeasurementLng_NKE AS UoMLng ON UoMLng.UoMId = UoM.UoMId AND UoMLng.Language = 'en' AND UoMLng.RecActive = 1 AND UoMLng.SrcRecLocationId = Report.LocationId
        LEFT JOIN nkeds.ds_NKE_ItemWebshop_NKE AS ItemWebshop ON ItemWebshop.ItemId = Item.ItemId AND ItemWebshop.RecActive = 1 AND ItemWebshop.SrcRecLocationId = Report.LocationId
)
SELECT * FROM ITEMNKE;