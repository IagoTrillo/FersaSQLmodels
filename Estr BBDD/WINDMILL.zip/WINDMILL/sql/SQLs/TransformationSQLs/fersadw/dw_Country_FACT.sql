TRUNCATE TABLE fersadw.Country_FACT;

INSERT INTO fersadw.Country_FACT(COUNTRYID, COUNTRYNAME, ISO2, CONTINENTID, CONTINENTNAME, BUSINESSAREA, STATE)
SELECT COUNTRYID, country.NAME AS COUNTRYNAME, ISO2 AS COUNTRYISO2, country.ContinentId AS CONTINENTID, continent.Name AS CONTINENTNAME, NULL AS BUSINESSAREA, NULL AS STATE
FROM fersaParams.Country_standalone country
INNER JOIN fersaParams.Continent_standalone continent on continent.ContinentId = country.ContinentId;