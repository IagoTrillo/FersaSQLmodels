TRUNCATE TABLE fersadw.PurchasePriceEvolution_FACT;

INSERT INTO fersadw.PurchasePriceEvolution_FACT(COMPANYID,ITEMID,SUPPLIERID,CURRENCYCODE,UNITPRICE, SUBSIDIARYID, UNITID, EXCHANGERATE_EUR, EXCHANGERATE_USD, PERIOD1, PERIOD2,ISINTERCO)
 SELECT ALL_PRICES.COMPANYID,
        ALL_PRICES.ITEMID,
        ALL_PRICES.SUPPLIERID,
        ALL_PRICES.CURRENCYCODE,
        ALL_PRICES.UNITPRICE,
        ALL_PRICES.SUBSIDIARYID,
        ALL_PRICES.UNITID,
        ALL_PRICES.EXCHANGERATE_EUR,
        ALL_PRICES.EXCHANGERATE_USD,
        ALL_PRICES.PERIOD1,
        ALL_PRICES.PERIOD2,
        (CASE WHEN (INTERCO.CUSTVENDACCOUNT IS NULL) THEN 0 ELSE 1 END)::boolean AS ISINTERCO
 FROM (( SELECT EXCEPTION_SUPPLIERS.COMPANYID,
        EXCEPTION_SUPPLIERS.ITEMID,
        EXCEPTION_SUPPLIERS.SUPPLIERID,
        EXCEPTION_SUPPLIERS.CURRENCYCODE,
        EXCEPTION_SUPPLIERS.UNITPRICE,
        EXCEPTION_SUPPLIERS.SUBSIDIARYID,
        EXCEPTION_SUPPLIERS.UNITID,
        EXCEPTION_SUPPLIERS.EXCHANGERATE_EUR,
        EXCEPTION_SUPPLIERS.EXCHANGERATE_USD,
        GP1.MPRICE AS PERIOD1,
        GP2.MPRICE AS PERIOD2
 FROM (((( SELECT PurchasePrices_ALL.COMPANYID,
        PurchasePrices_ALL.ITEMID,
        PurchasePrices_ALL.SUPPLIERID,
        PurchasePrices_ALL.CURRENCYCODE,
        PurchasePrices_ALL.SUBSIDIARYID,
        PurchasePrices_ALL.UNITID,
        PurchasePrices_ALL.UNITPRICE,
        PurchasePrices_ALL.EXCHANGERATE_EUR,
        PurchasePrices_ALL.EXCHANGERATE_USD,
        PurchasePrices_ALL.FROMDATE,
        PurchasePrices_ALL.TODATE
 FROM fersadv.PurchasePrices_ALL
 WHERE ((PurchasePrices_ALL.SUPPLIERID = ANY (ARRAY['P0201417'::varchar(8), 'P0100707'::varchar(8), 'P0100303'::varchar(8)])) AND ((date_part('year'::varchar(4), PurchasePrices_ALL.FROMDATE))::int = (date_part('year'::varchar(4), ((now())::date)::timestamp))::int))) EXCEPTION_SUPPLIERS JOIN ( SELECT PurchasePrices_ALL.COMPANYID,
        PurchasePrices_ALL.ITEMID,
        PurchasePrices_ALL.SUPPLIERID,
        PurchasePrices_ALL.CURRENCYCODE,
        PurchasePrices_ALL.SUBSIDIARYID,
        PurchasePrices_ALL.UNITID,
        max(PurchasePrices_ALL.FROMDATE) AS FROMDATE
 FROM fersadv.PurchasePrices_ALL
 WHERE ((PurchasePrices_ALL.SUPPLIERID = ANY (ARRAY['P0201417'::varchar(8), 'P0100707'::varchar(8), 'P0100303'::varchar(8)])) AND ((date_part('year'::varchar(4), PurchasePrices_ALL.FROMDATE))::int = (date_part('year'::varchar(4), ((now())::date)::timestamp))::int))
 GROUP BY PurchasePrices_ALL.COMPANYID,
          PurchasePrices_ALL.ITEMID,
          PurchasePrices_ALL.SUPPLIERID,
          PurchasePrices_ALL.SUBSIDIARYID,
          PurchasePrices_ALL.CURRENCYCODE,
          PurchasePrices_ALL.UNITID) EXCEPTION_SUPPLIERS_DATES ON (((EXCEPTION_SUPPLIERS.COMPANYID = EXCEPTION_SUPPLIERS_DATES.COMPANYID) AND (EXCEPTION_SUPPLIERS.ITEMID = EXCEPTION_SUPPLIERS_DATES.ITEMID) AND (EXCEPTION_SUPPLIERS.SUPPLIERID = EXCEPTION_SUPPLIERS_DATES.SUPPLIERID) AND (EXCEPTION_SUPPLIERS.SUBSIDIARYID = EXCEPTION_SUPPLIERS_DATES.SUBSIDIARYID) AND (EXCEPTION_SUPPLIERS.UNITID = EXCEPTION_SUPPLIERS_DATES.UNITID) AND (EXCEPTION_SUPPLIERS.FROMDATE = EXCEPTION_SUPPLIERS_DATES.FROMDATE)))) LEFT  JOIN ( SELECT PP1.ITEMID,
        min(PP1.UNITPRICE) AS MPRICE,
        PP1.SUBSIDIARYID,
        PP1.CURRENCYCODE,
        PP1.EXCHANGERATE_EUR,
        PP1.EXCHANGERATE_USD
 FROM fersadv.PurchasePrices_ALL PP1
 WHERE ((date_part('year'::varchar(4), PP1.TODATE))::int = ((date_part('year'::varchar(4), ((now())::date)::timestamp))::int - 1))
 GROUP BY PP1.ITEMID,
          PP1.SUBSIDIARYID,
          PP1.CURRENCYCODE,
          PP1.EXCHANGERATE_EUR,
          PP1.EXCHANGERATE_USD) GP1 ON (((GP1.ITEMID = EXCEPTION_SUPPLIERS.ITEMID) AND (GP1.SUBSIDIARYID = EXCEPTION_SUPPLIERS.SUBSIDIARYID) AND (GP1.CURRENCYCODE = EXCEPTION_SUPPLIERS.CURRENCYCODE)))) LEFT  JOIN ( SELECT PP2.ITEMID,
        min(PP2.UNITPRICE) AS MPRICE,
        PP2.SUBSIDIARYID,
        PP2.CURRENCYCODE,
        PP2.EXCHANGERATE_EUR,
        PP2.EXCHANGERATE_USD
 FROM fersadv.PurchasePrices_ALL PP2
 WHERE (((date_part('year'::varchar(4), PP2.TODATE))::int > ((date_part('year'::varchar(4), ((now())::date)::timestamp))::int - 3)) AND ((date_part('year'::varchar(4), PP2.TODATE))::int < ((date_part('year'::varchar(4), ((now())::date)::timestamp))::int - 1)))
 GROUP BY PP2.ITEMID,
          PP2.SUBSIDIARYID,
          PP2.CURRENCYCODE,
          PP2.EXCHANGERATE_EUR,
          PP2.EXCHANGERATE_USD) GP2 ON (((GP2.ITEMID = EXCEPTION_SUPPLIERS.ITEMID) AND (GP2.SUBSIDIARYID = EXCEPTION_SUPPLIERS.SUBSIDIARYID) AND (GP2.CURRENCYCODE = EXCEPTION_SUPPLIERS.CURRENCYCODE))))
 WHERE ((coalesce(EXCEPTION_SUPPLIERS.ITEMID, ''::varchar) <> ''::varchar) AND ((EXCEPTION_SUPPLIERS.TODATE IS NULL) OR (EXCEPTION_SUPPLIERS.TODATE > (now())::date)) AND (coalesce(EXCEPTION_SUPPLIERS.SUPPLIERID, ''::varchar) <> ''::varchar)) UNION ALL  SELECT PP.COMPANYID,
        PP.ITEMID,
        PP.SUPPLIERID,
        PP.CURRENCYCODE,
        min(PP.UNITPRICE) AS UNITPRICE,
        PP.SUBSIDIARYID,
        PP.UNITID,
        avg(PP.EXCHANGERATE_EUR) AS EXCHANGERATE_EUR,
        avg(PP.EXCHANGERATE_USD) AS EXCHANGERATE_USD,
        avg(GP1.MPRICE) AS PERIOD1,
        avg(GP2.MPRICE) AS PERIOD2
 FROM ((fersadv.PurchasePrices_ALL PP LEFT  JOIN ( SELECT PP1.ITEMID,
        min(PP1.UNITPRICE) AS MPRICE,
        PP1.SUBSIDIARYID,
        PP1.CURRENCYCODE,
        PP1.EXCHANGERATE_EUR,
        PP1.EXCHANGERATE_USD
 FROM fersadv.PurchasePrices_ALL PP1
 WHERE ((date_part('year'::varchar(4), PP1.TODATE))::int = ((date_part('year'::varchar(4), ((now())::date)::timestamp))::int - 1))
 GROUP BY PP1.ITEMID,
          PP1.SUBSIDIARYID,
          PP1.CURRENCYCODE,
          PP1.EXCHANGERATE_EUR,
          PP1.EXCHANGERATE_USD) GP1 ON (((GP1.ITEMID = PP.ITEMID) AND (GP1.SUBSIDIARYID = PP.SUBSIDIARYID) AND (GP1.CURRENCYCODE = PP.CURRENCYCODE)))) LEFT  JOIN ( SELECT PP2.ITEMID,
        min(PP2.UNITPRICE) AS MPRICE,
        PP2.SUBSIDIARYID,
        PP2.CURRENCYCODE,
        PP2.EXCHANGERATE_EUR,
        PP2.EXCHANGERATE_USD
 FROM fersadv.PurchasePrices_ALL PP2
 WHERE (((date_part('year'::varchar(4), PP2.TODATE))::int > ((date_part('year'::varchar(4), ((now())::date)::timestamp))::int - 3)) AND ((date_part('year'::varchar(4), PP2.TODATE))::int < ((date_part('year'::varchar(4), ((now())::date)::timestamp))::int - 1)))
 GROUP BY PP2.ITEMID,
          PP2.SUBSIDIARYID,
          PP2.CURRENCYCODE,
          PP2.EXCHANGERATE_EUR,
          PP2.EXCHANGERATE_USD) GP2 ON (((GP2.ITEMID = PP.ITEMID) AND (GP2.SUBSIDIARYID = PP.SUBSIDIARYID) AND (GP2.CURRENCYCODE = PP.CURRENCYCODE))))
 WHERE ((coalesce(PP.ITEMID, ''::varchar) <> ''::varchar) AND ((PP.TODATE IS NULL) OR (PP.TODATE > (now())::date)) AND (coalesce(PP.SUPPLIERID, ''::varchar) <> ''::varchar) AND (((date_part('year'::varchar(4), PP.FROMDATE))::int < (date_part('year'::varchar(4), ((now())::date)::timestamp))::int) OR ((PP.SUPPLIERID <> ALL (ARRAY['P0201417'::varchar(8), 'P0100707'::varchar(8), 'P0100303'::varchar(8)])) AND ((date_part('year'::varchar(4), PP.FROMDATE))::int = (date_part('year'::varchar(4), ((now())::date)::timestamp))::int))))
 GROUP BY PP.COMPANYID,
          PP.ITEMID,
          PP.SUPPLIERID,
          PP.SUBSIDIARYID,
          PP.CURRENCYCODE,
          PP.UNITID) ALL_PRICES LEFT  JOIN ( SELECT CustomerVendorInterCo_standalone.CUSTVENDACCOUNT
 FROM fersaParamsPublic.CustomerVendorInterCo_standalone
 GROUP BY CustomerVendorInterCo_standalone.CUSTVENDACCOUNT) INTERCO ON ((ALL_PRICES.SUPPLIERID = INTERCO.CUSTVENDACCOUNT)));