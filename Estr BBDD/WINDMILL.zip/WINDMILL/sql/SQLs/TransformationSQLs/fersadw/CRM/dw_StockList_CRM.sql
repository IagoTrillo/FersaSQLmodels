TRUNCATE TABLE fersadw.StockList_CRM;

INSERT INTO fersadw.StockList_CRM (
    subsidiary ,
    model ,
    defaultsku ,
    sku ,
    brand ,
    qty ,
    inventstyleid ,
    stock_bucket ,
    KEY ,
    MODIFIEDDATE 
)
SELECT
    SUBSIDIARYID   AS subsidiary,
    CASE
        WHEN SUBSIDIARYID IN ('FUSA', 'FBEA', 'FBRA', 'NAUT') AND MODEL LIKE '%%NKE_%%'THEN REPLACE(REPLACE(MODEL, 'NKE_', ''), '"', 'INCH')
        WHEN DEFAULTMODEL ILIKE '%"%' THEN REPLACE(DEFAULTMODEL, '"', 'INCH')
        ELSE DEFAULTMODEL
    END AS model,
    DEFAULTSKU     AS defaultsku,
    SKU            AS sku,
    CASE
        WHEN BRAND = 'FER'
        THEN 'FERSA'
        ELSE BRAND
    END AS brand,
    QUANTITY       AS qty,
    INVENTSTYLEID  AS inventstyleid,
    CASE
        WHEN DATEDIFF('day', CURRENT_DATE, DATEFROM) <= 1 THEN 'stock_1'
        WHEN DATEDIFF('day', CURRENT_DATE, DATEFROM) BETWEEN  2 AND 7  THEN 'stock_2'
        WHEN DATEDIFF('day', CURRENT_DATE, DATEFROM) BETWEEN  8 AND 30 THEN 'stock_3'
        WHEN DATEDIFF('day', CURRENT_DATE, DATEFROM) BETWEEN 31 AND 60 THEN 'stock_4'
        WHEN DATEDIFF('day', CURRENT_DATE, DATEFROM) BETWEEN 61 AND 90 THEN 'stock_5'
        ELSE 'stock_6'
    END AS stock_bucket,
    CONCAT(SUBSIDIARYID, SKU) AS KEY,
    MODIFIEDDATE
FROM fersadw.WebshopStockList_FACT
WHERE 
    RANK = 0 AND
    SUBSIDIARYID IN ('FBEA', 'FBRA', 'FUSA', 'NAUT');