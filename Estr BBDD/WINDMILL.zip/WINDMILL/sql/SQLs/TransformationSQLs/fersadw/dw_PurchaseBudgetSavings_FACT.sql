TRUNCATE TABLE fersadw.PurchaseBudgetSavings_FACT;

INSERT INTO fersadw.PurchaseBudgetSavings_FACT(ITEMID, SUPPLIERID, YEAR, COMPANYID, SUBSIDIARYID, YEARLYSAVINGS, BUDGETSAVINGS)
 SELECT VV2.ITEMID,
        VV2.SUPPLIERID,
        VV2.YEAR,
        VV2.COMPANYID,
        VV2.SUBSIDIARYID,
        CASE WHEN (((VV2.AveragePrevious - VV2.Average) * VV2.QTYPOR) = 0::numeric(1,0)) THEN NULL::numeric(1,0) ELSE ((VV2.AveragePrevious - VV2.Average) * VV2.QTYPOR) END AS YearlySavings,
        CASE WHEN (((VV2.AverageBudget - VV2.Average) * VV2.QTYPOR) = 0::numeric(1,0)) THEN NULL::numeric(1,0) ELSE ((VV2.AverageBudget - VV2.Average) * VV2.QTYPOR) END AS BudgetSavings
 FROM ( SELECT VV.ITEMID,
        VV.SUPPLIERID,
        VV.YEAR,
        VV.COMPANYID,
        VV.SUBSIDIARYID,
        CASE WHEN (VV.sumqtyyear = 0::numeric(18,0)) THEN 0::numeric(18,0) ELSE ((VV.sumamount_eur + VV.sumadditionalchages_EUR) / CASE WHEN (VV.sumqtyyear = 0::numeric(1,0)) THEN NULL::numeric(1,0) ELSE VV.sumqtyyear END) END AS Average,
        CASE WHEN (VV.sumqtyyearprevious = 0::numeric(18,0)) THEN 0::numeric(18,0) ELSE ((VV.sumamountprevious_eur + VV.sumadditionalchagesprevious_EUR) / CASE WHEN (VV.sumqtyyearprevious = 0::numeric(1,0)) THEN NULL::numeric(1,0) ELSE VV.sumqtyyearprevious END) END AS AveragePrevious,
        CASE WHEN (VV.QTY = 0::numeric(18,0)) THEN 0::numeric(18,0) ELSE (VV.sumBdgYear_EUR / CASE WHEN (VV.QTY = 0::numeric(1,0)) THEN NULL::numeric(1,0) ELSE VV.QTY END) END AS AverageBudget,
        least(VV.QTY, VV.sumqtyyear) AS QTYPOR
 FROM ( SELECT PurchaseBudgetYearly_ALL.SUBSIDIARYID,
        PurchaseBudgetYearly_ALL.ITEMID,
        PurchaseBudgetYearly_ALL.SUPPLIERID,
        PurchaseBudgetYearly_ALL.YEAR,
        PurchaseBudgetYearly_ALL.QTY,
        COMP.COMPANYID,
        (((((PurchaseBudgetYearly_ALL.UNITPRICE * PurchaseBudgetYearly_ALL.EXCHANGERATE_EUR) + PurchaseBudgetYearly_ALL.CUSTOMCOST) + PurchaseBudgetYearly_ALL.TRANSPORTCOST) * PurchaseBudgetYearly_ALL.CORRECTIONFACTOR) * PurchaseBudgetYearly_ALL.QTY) AS sumBdgYear_EUR,
        coalesce(( SELECT sum(pia.INVOICEQTY) AS sum
 FROM fersadv.PurchaseInvoices_ALL pia
 WHERE ((pia.ITEMID = PurchaseBudgetYearly_ALL.ITEMID) AND (pia.SUPPLIERID = PurchaseBudgetYearly_ALL.SUPPLIERID) AND ((date_part('year'::varchar(4), pia.INVOICEDATE))::int = PurchaseBudgetYearly_ALL.YEAR) AND (pia.SUBSIDIARYID = PurchaseBudgetYearly_ALL.SUBSIDIARYID))), 0::numeric(18,0)) AS sumqtyyear,
        coalesce(( SELECT sum(pia.INVOICEQTY) AS sum
 FROM fersadv.PurchaseInvoices_ALL pia
 WHERE ((pia.ITEMID = PurchaseBudgetYearly_ALL.ITEMID) AND (pia.SUPPLIERID = PurchaseBudgetYearly_ALL.SUPPLIERID) AND ((date_part('year'::varchar(4), pia.INVOICEDATE))::int = (PurchaseBudgetYearly_ALL.YEAR - 1)) AND (pia.SUBSIDIARYID = PurchaseBudgetYearly_ALL.SUBSIDIARYID))), NULL::numeric(1,0)) AS sumqtyyearprevious,
        coalesce(( SELECT sum((pia.AMOUNT * pia.EXCHANGERATE_EUR)) AS sum
 FROM fersadv.PurchaseInvoices_ALL pia
 WHERE ((pia.ITEMID = PurchaseBudgetYearly_ALL.ITEMID) AND (pia.SUPPLIERID = PurchaseBudgetYearly_ALL.SUPPLIERID) AND ((date_part('year'::varchar(4), pia.INVOICEDATE))::int = PurchaseBudgetYearly_ALL.YEAR) AND (pia.SUBSIDIARYID = PurchaseBudgetYearly_ALL.SUBSIDIARYID))), 0::numeric(18,0)) AS sumamount_eur,
        coalesce(( SELECT sum((pia.AMOUNT * pia.EXCHANGERATE_EUR)) AS sum
 FROM fersadv.PurchaseInvoices_ALL pia
 WHERE ((pia.ITEMID = PurchaseBudgetYearly_ALL.ITEMID) AND (pia.SUPPLIERID = PurchaseBudgetYearly_ALL.SUPPLIERID) AND ((date_part('year'::varchar(4), pia.INVOICEDATE))::int = (PurchaseBudgetYearly_ALL.YEAR - 1)) AND (pia.SUBSIDIARYID = PurchaseBudgetYearly_ALL.SUBSIDIARYID))), 0::numeric(18,0)) AS sumamountprevious_eur,
        coalesce(CASE WHEN (COMP.CURRENCYCODE = 'EUR'::varchar(3)) THEN ( SELECT sum(pia.ADDITIONALCHARGES) AS sum
 FROM fersadv.PurchaseInvoices_ALL pia
 WHERE ((pia.ITEMID = PurchaseBudgetYearly_ALL.ITEMID) AND (pia.SUPPLIERID = PurchaseBudgetYearly_ALL.SUPPLIERID) AND ((date_part('year'::varchar(4), pia.INVOICEDATE))::int = PurchaseBudgetYearly_ALL.YEAR) AND (pia.SUBSIDIARYID = PurchaseBudgetYearly_ALL.SUBSIDIARYID))) ELSE ( SELECT sum((pia.ADDITIONALCHARGES * pia.EXCHANGERATE_EUR)) AS sum
 FROM fersadv.PurchaseInvoices_ALL pia
 WHERE ((pia.ITEMID = PurchaseBudgetYearly_ALL.ITEMID) AND (pia.SUPPLIERID = PurchaseBudgetYearly_ALL.SUPPLIERID) AND ((date_part('year'::varchar(4), pia.INVOICEDATE))::int = PurchaseBudgetYearly_ALL.YEAR) AND (pia.SUBSIDIARYID = PurchaseBudgetYearly_ALL.SUBSIDIARYID))) END, 0::numeric(18,0)) AS sumadditionalchages_EUR,
        coalesce(CASE WHEN (COMP.CURRENCYCODE = 'EUR'::varchar(3)) THEN ( SELECT sum(pia.ADDITIONALCHARGES) AS sum
 FROM fersadv.PurchaseInvoices_ALL pia
 WHERE ((pia.ITEMID = PurchaseBudgetYearly_ALL.ITEMID) AND (pia.SUPPLIERID = PurchaseBudgetYearly_ALL.SUPPLIERID) AND ((date_part('year'::varchar(4), pia.INVOICEDATE))::int = (PurchaseBudgetYearly_ALL.YEAR - 1)) AND (pia.SUBSIDIARYID = PurchaseBudgetYearly_ALL.SUBSIDIARYID))) ELSE ( SELECT sum((pia.ADDITIONALCHARGES * pia.EXCHANGERATE_EUR)) AS sum
 FROM fersadv.PurchaseInvoices_ALL pia
 WHERE ((pia.ITEMID = PurchaseBudgetYearly_ALL.ITEMID) AND (pia.SUPPLIERID = PurchaseBudgetYearly_ALL.SUPPLIERID) AND ((date_part('year'::varchar(4), pia.INVOICEDATE))::int = (PurchaseBudgetYearly_ALL.YEAR - 1)) AND (pia.SUBSIDIARYID = PurchaseBudgetYearly_ALL.SUBSIDIARYID))) END, 0::numeric(18,0)) AS sumadditionalchagesprevious_EUR
 FROM (fersadv.PurchaseBudgetYearly_ALL PurchaseBudgetYearly_ALL LEFT  JOIN fersaParams.CompanyLocation_standalone COMP ON ((COMP.LOCATIONID = upper(PurchaseBudgetYearly_ALL.SUBSIDIARYID))))) VV
 WHERE (VV.QTY > 0::numeric(18,0))) VV2;