TRUNCATE TABLE fersadw.RelatedApplicationProducts_FACT;

INSERT INTO fersadw.RelatedApplicationProducts_FACT(APPLICATIONCATEGORY ,APPLICATIONBRAND , APPLICATIONMODEL , FERGENERALAPPLICATIONMASTERV4RECID , SUBSIDIARYID, ORDERACCOUNT ,NAME , SALESMANAGER ,
    sold_bearings , total_bearings , ratio ,total_FBOX ,sold_FBOX , max_sold , min_sold , ITEMID , CATALOG ,IS_FBOX , ItemAvg_EUR , ItemAvgCost_EUR )

/*select  dercf.NAME, dercf1.NAME  ,dff.* from 
		fersads.ds_FERGENERALAPPLICATIONMASTERV4_FER dff 
		INNER JOIN fersads.ds_EcoResCategory_FER dercf  on dercf.RECID = DFF.APPLICATIONCATEGORYID 
		INNER JOIN fersads.ds_EcoResCategory_FER dercf1  on dercf1.RECID = DFF.APPLICATIONBRANDCATEGORYID  
		where dff.recid='5637146321';
select * from fersads.ds_FERGENERALAPPLICATIONV4_FER d  where d.FERGENERALAPPLICATIONMASTER  ='5637146321' ;*/


--SELECT *  FROM fersadv.SalesInvoices_ALL WHERE  itemid='59010027101000' and year(INVOICEDATE)>2021 --CUSTOMERID = '101037' and
--select * from fersads.ds_FERGENERALAPPLICATIONMASTERV4_FER dff where recid='5637146321';
--select * from fersadv.Item_ALL ia where ia.ITEMID ='59010027101000' and ia.SUBSIDIARYID = 'FBEA';
--select * from fersadv.Customer_ALL ca  where ca.CUSTOMERID ='105356' and ca.SUBSIDIARYID  = 'FBEA';
-- Sacamos las ventas por clientes
WITH CustomerSaleshist as(
							 SELECT distinct itemid 
							 				,sia.CUSTOMERID AS ORDERACCOUNT
							 				,sia.SUBSIDIARYID 
									FROM fersadv.SalesInvoices_ALL sia 
										INNER JOIN fersadv.Customer_ALL ca ON  ca.CUSTOMERID = sia.CUSTOMERID AND ca.SUBSIDIARYID = sia.SUBSIDIARYID 
											where LENGTH (itemid) >0
											AND sia.SUBSIDIARYID ='FBEA'
											and sia.CUSTOMERID = '101037'
											and year(sia.INVOICEDATE)>2021
											and ca.CUSTOMERTYPE  != 'INTERNAL'
											and sia.AMOUNT>0)

,CustomerSaleshist2 as(       SELECT itemid 
							 				,sia.CUSTOMERID AS ORDERACCOUNT
							 				,sia.SUBSIDIARYID 
							 				, sum(sia.INVOICEQTY) total_sold
									FROM fersadv.SalesInvoices_ALL sia 
										INNER JOIN fersadv.Customer_ALL ca ON  ca.CUSTOMERID = sia.CUSTOMERID AND ca.SUBSIDIARYID = sia.SUBSIDIARYID 
											where LENGTH (itemid) >0
											AND sia.SUBSIDIARYID ='FBEA'
											and sia.CUSTOMERID = '101037'
											and year(sia.INVOICEDATE)>2021
											and ca.CUSTOMERTYPE  != 'INTERNAL'
											and sia.AMOUNT > 0
											--and sia.ITEMID ='10010363001001'
											group by itemid, sia.CUSTOMERID, sia.SUBSIDIARYID)											
											
--select * from CustomerSaleshist2
-- Sacamos los productos por aplicación
,ItemsPerApllicationaux as(
							select dff.RECID FERGENERALAPPLICATIONMASTERV4RECID, 
								dff2.ITEMID, 
								ia."CATALOG",
								--INSTR(ia."CATALOG",'FDRK') as IS_FBOX
								INSTR(ia.BEARINGTYPE ,'FBOX') as IS_FBOX
							from
								fersads.ds_FERGENERALAPPLICATIONMASTERV4_FER dff 
								INNER JOIN fersads.ds_FERGENERALAPPLICATIONV4_FER dff2 on dff.RECID  = dff2.FERGENERALAPPLICATIONMASTER
								INNER JOIN fersadv.Item_ALL ia  ON ia.ITEMID = dff2.ITEMID AND ia.SUBSIDIARYID ='FBEA'
								where -- dff.RECID  = dff2.FERGENERALAPPLICATIONMASTER
							          --and 
							          LENGTH(dff2.ITEMID)>0
							           --AND dff.RECID = '5637144747'
								)

--select * from ItemsPerApllicationaux

,ItemsPerApllicationAVGPriceAUX as( select sia.itemid
										--,sia.SUBSIDIARYID
										, (sum(sia.AMOUNT_EUR) / sum(sia.INVOICEQTY)) ItemAvg_EUR
										, (sum(sia.COSTAMOUNT_EUR) / sum(sia.INVOICEQTY)) ItemAvgCost_EUR
									FROM fersadw.SalesInvoice_FACT sia 	
									 INNER  JOIN fersadv.Customer_ALL ca ON  ca.CUSTOMERID = sia.CUSTOMERID AND ca.SUBSIDIARYID = sia.SUBSIDIARYID 
									 where LENGTH (sia.itemid) >0
											AND sia.COMPANYID  ='FER'
											--and sia.CUSTOMERID = '101037'
											and year(sia.INVOICEDATE)>2021
											and ca.CUSTOMERTYPE  != 'INTERNAL'
											and sia.AMOUNT_EUR > 0
											AND sia.INVOICEQTY > 0
									  group by sia.itemid --,sia.SUBSIDIARYID
								)
--select * from ItemsPerApllicationAVGPriceAUX

,ItemsPerApllication as (select ItemsPerApllicationaux.*
									from ItemsPerApllicationaux
											inner join ItemsPerApllicationAVGPriceAUX ON ItemsPerApllicationAVGPriceAUX.ITEMID= ItemsPerApllicationaux.ITEMID)


--select * from ItemsPerApllication
--select * from ItemsPerApllicationAVGPriceAUX;


-- Calculamos los prodcutos por aplicación
,BearingsPerApplication as (select FERGENERALAPPLICATIONMASTERV4RECID, count(*) total_bearings, SUM(IS_FBOX) total_FBOX from 
								ItemsPerApllication
								group by FERGENERALAPPLICATIONMASTERV4RECID)

								


--select * from BearingsPerApplication;
-- Calculamos los prodcutos vendidos por por aplicación y cliente 

,BearingsSoldByApplicaionAndCustomeraux as(select ItemsPerApllication.itemid
												,ItemsPerApllication.FERGENERALAPPLICATIONMASTERV4RECID
												,CustomerSaleshist.ORDERACCOUNT  
												,CustomerSaleshist.SUBSIDIARYID
												,ItemsPerApllication.IS_FBOX
											from 
												ItemsPerApllication 
														INNER JOIN CustomerSaleshist ON  ItemsPerApllication.ITEMID = CustomerSaleshist.ITEMID )
								
,BearingsSoldByApplicaionAndCustomeraux2 as(select ItemsPerApllication.itemid
												,ItemsPerApllication.FERGENERALAPPLICATIONMASTERV4RECID
												,CustomerSaleshist2.ORDERACCOUNT  
												,CustomerSaleshist2.SUBSIDIARYID
												,ItemsPerApllication.IS_FBOX
												,total_sold
											from 									
													ItemsPerApllication 
															INNER JOIN CustomerSaleshist2 ON  ItemsPerApllication.ITEMID = CustomerSaleshist2.ITEMID )

--select * from 	BearingsSoldByApplicaionAndCustomeraux2;	

,BearingsSoldByApplicaionAndCustomerMaxMin as (select FERGENERALAPPLICATIONMASTERV4RECID
												,ORDERACCOUNT  
												,SUBSIDIARYID 
												, MAX(total_sold) max_sold
												,MIN(total_sold) min_sold
												from BearingsSoldByApplicaionAndCustomeraux2
												group by FERGENERALAPPLICATIONMASTERV4RECID,ORDERACCOUNT,SUBSIDIARYID)


--select * from BearingsSoldByApplicaionAndCustomerMaxMin

, BearingsSoldByApplicaionAndCustomer as 
	(select  BearingsPerApplication.FERGENERALAPPLICATIONMASTERV4RECID
		,total_bearings
		,BearingsSoldByApplicaionAndCustomeraux.ORDERACCOUNT
		,BearingsSoldByApplicaionAndCustomeraux.SUBSIDIARYID
		,COUNT(*) sold_bearings
		,BearingsPerApplication.total_FBOX
		,SUM(BearingsSoldByApplicaionAndCustomeraux.IS_FBOX) sold_fbox
			from 
			BearingsPerApplication
			 ,BearingsSoldByApplicaionAndCustomeraux
		where 	BearingsPerApplication.FERGENERALAPPLICATIONMASTERV4RECID = BearingsSoldByApplicaionAndCustomeraux.FERGENERALAPPLICATIONMASTERV4RECID
		group by  BearingsPerApplication.FERGENERALAPPLICATIONMASTERV4RECID,total_bearings,total_FBOX, BearingsSoldByApplicaionAndCustomeraux.ORDERACCOUNT,BearingsSoldByApplicaionAndCustomeraux.SUBSIDIARYID)		
									
--select * from BearingsSoldByApplicaionAndCustomer

--Ordenamos las aplicaciones por ratio de venta

,ApplicationsSoldByCustomer	as
						(select BearingsSoldByApplicaionAndCustomer.*
									,(sold_bearings/total_bearings) as ratio  
								from BearingsSoldByApplicaionAndCustomer 
								where sold_bearings>0 and total_bearings>sold_bearings)


--select * from ApplicationsSoldByCustomer
-- Sacamos los productos por aplicación que no están vendidos para el cliente 

select   dercf.NAME APPLICATIONCATEGORY
		,dercf1.NAME  APPLICATIONBRAND
    	,dff.APPLICATIONMODEL
		,ItemsPerApllication.FERGENERALAPPLICATIONMASTERV4RECID
		,ApplicationsSoldByCustomer.SUBSIDIARYID
		,ApplicationsSoldByCustomer.ORDERACCOUNT
		,ca.NAME 
		,ca.SALESMANAGER 
		,ApplicationsSoldByCustomer.sold_bearings
		,ApplicationsSoldByCustomer.total_bearings
		,ApplicationsSoldByCustomer.ratio
		,ApplicationsSoldByCustomer.total_FBOX
		,ApplicationsSoldByCustomer.sold_FBOX
		,maxminperapp.max_sold
		,maxminperapp.min_sold
		,ItemsPerApllication.ITEMID  --applicationitem
		,ia."CATALOG" 
		,ItemsPerApllication.IS_FBOX
		,ISNULL((SELECT ItemAvg_EUR FROM ItemsPerApllicationAVGPriceAUX WHERE ItemsPerApllicationAVGPriceAUX.ITEMID=ItemsPerApllication.ITEMID --AND ItemsPerApllicationAVGPriceAUX.SUBSIDIARYID=ApplicationsSoldByCustomer.SUBSIDIARYID
										),0) ItemAvg_EUR
		,ISNULL((SELECT ItemAvgCost_EUR FROM ItemsPerApllicationAVGPriceAUX WHERE ItemsPerApllicationAVGPriceAUX.ITEMID=ItemsPerApllication.ITEMID --AND ItemsPerApllicationAVGPriceAUX.SUBSIDIARYID=ApplicationsSoldByCustomer.SUBSIDIARYID
										),0) ItemAvgCost_EUR
		--,CustomerSaleshist.ITEMID  customerhistitem
		from ApplicationsSoldByCustomer  --, 
		INNER JOIN ItemsPerApllication ON ApplicationsSoldByCustomer.FERGENERALAPPLICATIONMASTERV4RECID = ItemsPerApllication.FERGENERALAPPLICATIONMASTERV4RECID
		FULL OUTER JOIN CustomerSaleshist ON CustomerSaleshist.ORDERACCOUNT = ApplicationsSoldByCustomer.ORDERACCOUNT AND ApplicationsSoldByCustomer.SUBSIDIARYID= CustomerSaleshist.SUBSIDIARYID AND ItemsPerApllication.itemid = CustomerSaleshist.itemid 
			/*and ItemsPerApllication.itemid NOT EXISTS   
			(select distinct itemid from CustomerSaleshist where ORDERACCOUNT = ApplicationsSoldByCustomer.ORDERACCOUNT)
			order by ApplicationsSoldByCustomer.ratio  desc,ItemsPerApllication.FERGENERALAPPLICATIONMASTERV4RECID */
		INNER JOIN fersads.ds_FERGENERALAPPLICATIONMASTERV4_FER dff ON dff.RECID = ApplicationsSoldByCustomer.FERGENERALAPPLICATIONMASTERV4RECID
		INNER JOIN fersads.ds_EcoResCategory_FER dercf  on dercf.RECID = dff.APPLICATIONCATEGORYID 
		INNER JOIN fersads.ds_EcoResCategory_FER dercf1  on dercf1.RECID = dff.APPLICATIONBRANDCATEGORYID  
		INNER JOIN fersadv.Customer_ALL ca ON ca.CUSTOMERID = ApplicationsSoldByCustomer.ORDERACCOUNT  AND CA.SUBSIDIARYID = ApplicationsSoldByCustomer.SUBSIDIARYID
		INNER JOIN fersadv.Item_ALL ia  ON ia.ITEMID = ItemsPerApllication.ITEMID AND ia.SUBSIDIARYID = ApplicationsSoldByCustomer.SUBSIDIARYID
	    INNER JOIN BearingsSoldByApplicaionAndCustomerMaxMin maxminperapp ON maxminperapp.ORDERACCOUNT=ApplicationsSoldByCustomer.ORDERACCOUNT AND maxminperapp.SUBSIDIARYID=ApplicationsSoldByCustomer.SUBSIDIARYID AND maxminperapp.FERGENERALAPPLICATIONMASTERV4RECID=ApplicationsSoldByCustomer.FERGENERALAPPLICATIONMASTERV4RECID    
 		where ItemsPerApllication.ITEMID IS NOT NULL AND CustomerSaleshist.ITEMID IS NULL and ItemAvg_EUR>0
 		order by  ApplicationsSoldByCustomer.ratio  desc,ItemsPerApllication.FERGENERALAPPLICATIONMASTERV4RECID;