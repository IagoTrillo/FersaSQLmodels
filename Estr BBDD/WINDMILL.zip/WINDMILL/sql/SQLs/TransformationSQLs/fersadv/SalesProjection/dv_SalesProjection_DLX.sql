TRUNCATE TABLE fersadv.SalesProjection_DLX;

INSERT INTO fersadv.SalesProjection_DLX
(MATERIAL, CUSTOMER, QUANTITY, AMOUNT, "DATE")
SELECT MATERIAL, CUSTOMER, QUANTITY, AMOUNT, "DATE" 
FROM fersads.ds_SalesProjection_DLX dspd ;