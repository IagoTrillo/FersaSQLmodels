TRUNCATE TABLE fersadv.Supplier_FER_SP; 

INSERT INTO fersadv.Supplier_FER_SP
(BLOCKED, ACCOUNTNUM, FERLEADTIME, INVENTSITEID, DLVMODE, TRANSPORTDAYS
, BANKACCOUNT, INVOICEACCOUNT, DBA, INVENTLOCATION, DLVTERM
, PAYMMODE, FACTORINGACCOUNT, CURRENCY, DATAAREAID, COUNTRYREGIONID, CONTACTEMAIL, CONTACTPHONE, ITEMBUYERGROUPID
, PAYMSCHED, PRICEGROUP, VENDTABLERECID, NAME, VENDGROUP, PAYMTERMID, VENDMODIFIEDDATETIME,INTERCOMPANY)
WITH SUPPLIERFER AS (
SELECT VendTable.dataareaid DATAAREAID
     ,VendTable.AccountNum ACCOUNTNUM
    ,VendTable.BankAccount BANKACCOUNT
    ,VendTable.Blocked BLOCKED
    ,VendTable.DBA DBA
    ,VendTable.DlvMode DLVMODE
    ,VendTable.DlvTerm DLVTERM
    ,Deliverymode.TRANSPORTDAYS TRANSPORTDAYS
    ,VendTable.FERLeadTime FERLEADTIME
    ,VendTable.InventLocation INVENTLOCATION
    ,VendTable.InventSiteId INVENTSITEID
    ,VendTable.InvoiceAccount INVOICEACCOUNT
    ,VendTable.FactoringAccount FACTORINGACCOUNT
    ,VendTable.RecId VENDTABLERECID
    ,VendTable.PaymMode PAYMMODE
    ,VendTable.PaymSched PAYMSCHED
    ,VendTable.Currency CURRENCY
    ,dirpartytable.Name NAME
    ,LogisticsPostalAddress.CountryRegionId COUNTRYREGIONID
    ,LogisticsElectronicAddressMail.Locator CONTACTEMAIL
    ,LogisticsElectronicAddressPhone.Locator CONTACTPHONE
    ,VendTable.VendGroup VENDGROUP
    ,VendTable.ModifiedDateTime VENDMODIFIEDDATETIME
    ,VendTable.ItemBuyerGroupId ITEMBUYERGROUPID
    ,VendTable.PaymTermId PAYMTERMID
    ,VendTable.PRICEGROUP
	,APPLY_MAX(ARRAY[VendTable.MODIFIEDDATETIME, DirPartyTable.MODIFIEDDATETIME, LogisticsPostalAddress.MODIFIEDDATETIME]) as lastModified
	,ROW_NUMBER() OVER (PARTITION BY VendTable.DATAAREAID, VendTable.ACCOUNTNUM ORDER BY CONTACTEMAIL, ISNULL(LogisticsElectronicAddressMail.ISPRIMARY, -1) DESC, CONTACTPHONE, ISNULL(LogisticsElectronicAddressPhone.ISPRIMARY, -1) DESC) AS ROWID
    ,CASE WHEN EXISTS (
                SELECT 1 FROM fersads.ds_InterCompanyTradingPatner_FER ICTP INNER JOIN fersads.ds_InterCompanyTradingRelation_FER ICTR ON ICTR.INTERCOMPANYTRADINGVENDOR = ICTP.RECID
                WHERE ICTP.VENDORPARTY = VendTable.PARTY AND UPPER(ICTP.VENDORDATAAREAID) = UPPER(VendTable.DATAAREAID) AND ICTR.ACTIVE = 1) THEN 1 ELSE 0
    END AS INTERCOMPANY
FROM fersads.ds_SupplierTable_FER  VendTable
LEFT JOIN fersads.ds_DirPartyTable_FER  DirPartyTable on DirPartyTable.RecId=VendTable.Party
LEFT JOIN fersads.ds_LogisticsPostalAddress_FER  LogisticsPostalAddress on LogisticsPostalAddress.Location=DirPartyTable.PrimaryAddressLocation and year(validTO)= 2154
LEFT JOIN fersads.ds_DirPartyLocation_FER DirPartyLocation on DirPartyLocation.Party = DirPartyTable.RecId
LEFT JOIN (SELECT Location, Locator, ISPRIMARY FROM fersads.ds_LogisticsElectronicAddress_FER WHERE TYPE = 1) LogisticsElectronicAddressPhone on LogisticsElectronicAddressPhone.Location = DirPartyLocation.Location
LEFT JOIN (SELECT Location, Locator, ISPRIMARY FROM fersads.ds_LogisticsElectronicAddress_FER WHERE TYPE = 2) LogisticsElectronicAddressMail on LogisticsElectronicAddressMail.Location = DirPartyLocation.Location
LEFT JOIN fersads.ds_DlvMode_FER Deliverymode ON Deliverymode.CODE=VendTable.DlvMode AND UPPER(Deliverymode.DATAAREAID)=UPPER(VendTable.dataareaid)
)SELECT BLOCKED, ACCOUNTNUM, FERLEADTIME, INVENTSITEID, DLVMODE, TRANSPORTDAYS
, BANKACCOUNT, INVOICEACCOUNT, DBA, INVENTLOCATION, DLVTERM
, PAYMMODE, FACTORINGACCOUNT, CURRENCY, DATAAREAID, COUNTRYREGIONID, CONTACTEMAIL, CONTACTPHONE, ITEMBUYERGROUPID
, PAYMSCHED, PRICEGROUP, VENDTABLERECID, NAME, VENDGROUP, PAYMTERMID, VENDMODIFIEDDATETIME,INTERCOMPANY
FROM SUPPLIERFER
INNER JOIN fersaParams.CompanyLocation_standalone CL ON UPPER(CL.LOCATIONID) = UPPER(DATAAREAID)
WHERE CL.ORIGIN = 'FER' AND ROWID = 1;