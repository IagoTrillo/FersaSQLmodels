DELETE FROM fersadv.Customer_ALL WHERE HASH(ORIGIN) = HASH('NKE');

INSERT INTO fersadv.Customer_ALL(COMPANYID,SUBSIDIARYID,CUSTOMERID, MAINACCOUNTID, MAINACCOUNTNAME, NAME,CUSTOMERGROUPNAME,CATEGORY,SECTOR,ACTIVITY,CUSTOMERTYPE,COUNTRY,CONTINENT,CUSTOMERZONE,LINEOFBUSINESS,VATNUM,DIVISION,SALESMANAGER,
        SALESMANAGEREMAIL,ADMINMANAGER,ADMINMANAGEREMAIL,CURRENCYCODE,LANGUAGECODE,DELIVERYMODE,DELIVERYTERM,PRICEGROUP,DISCOUNTGROUP,CUSTGROUP,INVOICEACCOUNT,COMMISSIONGROUP,CORESSTYLENAME,ORIGIN, DATEMODIFIED
        ,WEBSHOPCUSTOMER,ISCOMPANY,EASYNUMBER)
WITH CUSTOMER AS (SELECT
                dcls.COMPANYID
                ,dcls.SUBSIDIARYID
                ,dcls.CUSTOMERID
                ,dcls.MAINACCOUNTID
                ,MainAccountData.Name AS MAINACCOUNTNAME
                ,dcls.NAME
                ,ISNULL(dcls.CUSTOMERGROUPNAME,dcls.NAME) AS CUSTOMERGROUPNAME
                ,dcls.CATEGORY
                ,ISNULL(dcls.SECTOR,'OTHR') AS SECTOR
                ,dcls.ACTIVITY
                ,UPPER(dcls.CUSTOMERTYPE)
                ,dcls.COUNTRY
                ,CONT.CONTINENT AS CONTINENT
                ,NULL AS CUSTOMERZONE
                ,ISNULL(dcls.LINEOFBUSINESS,'NB') AS LINEOFBUSINESS
                ,dcls.VATNUM
                ,ISNULL(dcls.DIVISION,'OTHR') AS SECTOR
                ,dcls.SALESMANAGER
                ,dcls.SALESMANAGEREMAIL
                ,dcls.ADMINMANAGER
                ,dcls.ADMINMANAGEREMAIL
                ,dcls.CURRENCYCODE
                ,dcls.LANGUAGECODE
                ,dcls.DELIVERYMODE
                ,dcls.DELIVERYTERM
                ,dcls.PRICEGROUP
                ,dcls.DISCOUNTGROUP
                ,dcls.CUSTOMERGROUPNAME
                ,dcls.INVOICEACCOUNT
                ,dcls.COMMISSIONGROUP
                ,'GEN' AS CORESSTYLENAME
                ,COMP.origin
                ,dcls.DATEMODIFIED
                ,dcls.WEBSHOPCUSTOMER
                ,dcls.ISCOMPANY
                ,dcls.EASYNUMBER 
            FROM fersads.ds_Customer_SP_NKE dcls
            INNER JOIN fersaParams.CompanyLocation_standalone COMP on COMP.LOCATIONID = dcls.SUBSIDIARYID
            LEFT JOIN(
                select distinct cs.ISO2, cs.ISO3, cs2.Name AS CONTINENT
                from fersaParams.Country_standalone cs
                left join fersaParams.Continent_standalone cs2 on cs2.ContinentId = cs.ContinentId
            )CONT on CONT.ISO3=dcls.COUNTRY
            LEFT JOIN fersads.ds_Customer_SP_NKE AS MainAccountData ON MainAccountData.CustomerId = dcls.MainAccount
            )SELECT * FROM CUSTOMER;