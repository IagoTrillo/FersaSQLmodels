DELETE FROM fersadv.Customer_ALL WHERE HASH(ORIGIN) = HASH('DLX');

INSERT INTO fersadv.Customer_ALL(
    COMPANYID,SUBSIDIARYID,CUSTOMERID,NAME,CUSTOMERGROUPNAME,CATEGORY,SECTOR,ACTIVITY,CUSTOMERTYPE,COUNTRY,CONTINENT,CUSTOMERZONE,LINEOFBUSINESS,VATNUM,DIVISION,SALESMANAGER,
    SALESMANAGEREMAIL,ADMINMANAGER,ADMINMANAGEREMAIL,CURRENCYCODE,LANGUAGECODE,DELIVERYMODE,DELIVERYTERM,PRICEGROUP,DISCOUNTGROUP,CUSTGROUP,INVOICEACCOUNT,COMMISSIONGROUP,
    CORESSTYLENAME, SALESDISTRICTID, ORIGIN
    )
    WITH CUSTOMER AS (
        WITH DISTINCT_CUSTOMERS_DLX AS (
            SELECT dcd.COMPANYID
            ,dcd.SUBSIDIARYID
            ,dcd.CUSTOMERID
            ,dcd.NAME
            ,ISNULL(dcd.CUSTOMERGROUP, dcd.NAME) as CUSTOMERGROUPNAME
            ,dcd.CATEGORY
            ,ISNULL(SECTOR,'OTHR') AS SECTOR
            ,dcd.ACTIVITY
            ,dcd.ZONE AS CUSTOMERZONE
            ,dcd.LINEOFBUSINESS
            ,dcd.VATNUM
            ,dcd.COUNTRY
            ,ISNULL(DIVISION,'OTHR') AS DIVISION
            ,dcd.SALESMANAGER
            ,dcd.ADMINMANAGER
            ,dcd.CURRENCYCODE
            -- SALESDISTRICTID required by Markus Schneider
            -- For DLX use field zone to define as no additional field has been created
            ,CASE
            	WHEN UPPER(dcd.ZONE) IN ('SOUTH', 'WEST', 'EAST', 'NORTH', 'OTHER', 'INSTITUTIONAL', 'TVS') THEN 'IND'
            	WHEN UPPER(dcd.ZONE) IN ('EXPORT', 'NORTHERN REGION', 'SOUTH ISLAND') THEN 'NA'
            	ELSE UPPER(dcd.ZONE)
            END AS SALESDISTRICTID
            FROM fersads.ds_Customer_DLX dcd
            LIMIT 1 OVER (PARTITION BY SUBSIDIARYID, CUSTOMERID ORDER BY DCD.NAME, DCD.SALESMANAGER DESC)
            )
        SELECT DISTINCT dcd.COMPANYID
        ,dcd.SUBSIDIARYID
        ,dcd.CUSTOMERID
        ,dcd.NAME
        ,dcd.CUSTOMERGROUPNAME
        ,dcd.CATEGORY
        ,dcd.SECTOR
        ,dcd.ACTIVITY
        ,(CASE  WHEN LENGTH(CUSTVENDACCOUNT) > 1 THEN 'INTERNAL' ELSE 'EXTERNAL' END) AS CUSTOMERTYPE
        ,CONT.ISO3 AS COUNTRY
        ,CONT.CONTINENT AS CONTINENT
        ,dcd.CUSTOMERZONE
        ,dcd.LINEOFBUSINESS
        ,dcd.VATNUM
        ,DIVISION
        ,dcd.SALESMANAGER
        ,NULL as SALESMANAGEREMAIL
        ,dcd.ADMINMANAGER
        ,NULL as ADMINMANAGEREMAIL
        ,dcd.CURRENCYCODE
        ,NULL as LANGUAGECODE
        ,NULL as DELIVERYMODE
        ,NULL as DELIVERYTERM
        ,NULL as PRICEGROUP
        ,NULL as DISCOUNTGROUP
        ,NULL as CUSTOMERGROUP
        ,NULL as INVOICEACCOUNT
        ,NULL as COMMISSIONGROUP
        ,'GEN' as CORESSTYLENAME
        ,dcls.origin
        ,dcd.SALESDISTRICTID
        FROM DISTINCT_CUSTOMERS_DLX dcd
        INNER JOIN fersaParams.CompanyLocation_standalone dcls on dcls.LOCATIONID = dcd.SUBSIDIARYID
        LEFT JOIN fersaParamsPublic.CustomerVendorInterCo_standalone CVI ON CVI.TYPE = 2 AND CVI.CUSTVENDACCOUNT = DCD.CUSTOMERID and CVI.FROMDATAAREAID = DCD.SUBSIDIARYID
        LEFT JOIN(
            SELECT DISTINCT cs.ISO2, cs.ISO3, cs2.Name AS CONTINENT
            FROM fersaParams.Country_standalone cs
            LEFT JOIN fersaParams.Continent_standalone cs2 on cs2.ContinentId = cs.ContinentId
        ) CONT on CONT.ISO2=dcd.COUNTRY
) SELECT COMPANYID, SUBSIDIARYID, CUSTOMERID, NAME, CUSTOMERGROUPNAME, CATEGORY, SECTOR, ACTIVITY, CUSTOMERTYPE, COUNTRY, CONTINENT, CUSTOMERZONE, LINEOFBUSINESS, VATNUM, DIVISION,
    SALESMANAGER, SALESMANAGEREMAIL, ADMINMANAGER, ADMINMANAGEREMAIL, CURRENCYCODE, LANGUAGECODE, DELIVERYMODE, DELIVERYTERM, PRICEGROUP, DISCOUNTGROUP, CUSTOMERGROUP, INVOICEACCOUNT,
    COMMISSIONGROUP, CORESSTYLENAME, SALESDISTRICTID, ORIGIN
FROM CUSTOMER;


TRUNCATE TABLE fersadv.Customer_DLX;

INSERT INTO fersadv.Customer_DLX(
    CUSTOMERGROUPNAME, CATEGORY, SECTOR, ACTIVITY, YEAR1, YEAR2, YEAR3, YEAR4, CUSTOMERTYPE, COUNTRY, CONTINENT, LINEOFBUSINESS, CPSTATUS, FIELD1, FIELD2, FIELD3, VATNUM,
    DIVISION, SALESMANAGER, ADMINMANAGER, FIELD4, CURRENCYCODE, "ZONE", CITY, STATE, COMPANYID, SUBSIDIARYID, CUSTOMERID, NAME, ASM, SE
    )
    WITH CUSTOMER AS (
        WITH DISTINCT_CUSTOMERS_DLX AS (
            SELECT dcd.COMPANYID
            ,dcd.subsidiaryid
            ,dcd.CUSTOMERID
            ,dcd.NAME
            ,ISNULL(dcd.CUSTOMERGROUP,dcd.NAME) as CUSTOMERGROUPNAME
            ,dcd.CATEGORY
            ,ISNULL(SECTOR,'OTHR') AS SECTOR
            ,dcd.ACTIVITY
            ,dcd.LINEOFBUSINESS
            ,dcd.VATNUM
            ,ISNULL(DIVISION,'OTHR') AS DIVISION
            ,dcd.SALESMANAGER
            ,dcd.ADMINMANAGER
            ,dcd.CURRENCYCODE
            ,dcd.COUNTRY
            ,dcd."ZONE" 
            ,dcd.CITY 
            ,dcd.STATE 
            ,dcd.YEAR1 
            ,dcd.YEAR2 
            ,dcd.YEAR3 
            ,dcd.YEAR4 
            ,dcd.CPSTATUS
            ,dcd.FIELD1
            ,dcd.FIELD2 
            ,dcd.FIELD3 
            ,dcd.FIELD4 
            ,dcd.ASM
            ,SUBSTRING(dcd.SE, 4) AS SE 
            FROM fersads.ds_Customer_DLX dcd
            LIMIT 1 OVER (PARTITION BY SUBSIDIARYID, CUSTOMERID ORDER BY DCD.NAME, DCD.SALESMANAGER DESC)
        )
        SELECT DISTINCT dcd.COMPANYID
        ,dcd.subsidiaryid
        ,dcd.CUSTOMERID
        ,dcd.NAME
        ,dcd.CUSTOMERGROUPNAME
        ,dcd.CATEGORY
        ,dcd.SECTOR
        ,dcd.ACTIVITY
        ,(CASE  WHEN LENGTH(CUSTVENDACCOUNT) > 1 THEN 'INTERNAL' ELSE 'EXTERNAL' END) AS CUSTOMERTYPE
        ,CONT.ISO3 AS COUNTRY
        ,CONT.CONTINENT AS CONTINENT
        ,dcd.LINEOFBUSINESS
        ,dcd.VATNUM
        ,ISNULL(DIVISION,'OTHR') AS DIVISION
        ,dcd.SALESMANAGER
        ,dcd.ADMINMANAGER
        ,dcd.CURRENCYCODE
        ,dcd."ZONE" 
        ,dcd.CITY 
        ,dcd.STATE 
        ,dcd.YEAR1 
        ,dcd.YEAR2 
        ,dcd.YEAR3 
        ,dcd.YEAR4 
        ,dcd.CPSTATUS
        ,dcd.FIELD1
        ,dcd.FIELD2 
        ,dcd.FIELD3 
        ,dcd.FIELD4
        ,dcd.ASM
        ,dcd.SE
        FROM DISTINCT_CUSTOMERS_DLX dcd
        LEFT JOIN fersaParamsPublic.CustomerVendorInterCo_standalone on type = 2 and custvendaccount = CUSTOMERID and FROMDATAAREAID = dcd.SUBSIDIARYID
        LEFT JOIN(
        SELECT DISTINCT cs.ISO2, cs.ISO3, cs2.Name AS CONTINENT
        FROM fersaParams.Country_standalone cs
            LEFT JOIN fersaParams.Continent_standalone cs2 on cs2.ContinentId = cs.ContinentId
        ) CONT on CONT.ISO2=dcd.COUNTRY
) SELECT CUSTOMERGROUPNAME, CATEGORY, SECTOR, ACTIVITY, YEAR1, YEAR2, YEAR3, YEAR4, CUSTOMERTYPE, COUNTRY, CONTINENT,LINEOFBUSINESS, CPSTATUS, FIELD1, FIELD2, FIELD3, VATNUM,
	DIVISION, SALESMANAGER, ADMINMANAGER, FIELD4, CURRENCYCODE, "ZONE", CITY, STATE, COMPANYID, SUBSIDIARYID, CUSTOMERID, NAME, ASM, SE
 FROM CUSTOMER;
