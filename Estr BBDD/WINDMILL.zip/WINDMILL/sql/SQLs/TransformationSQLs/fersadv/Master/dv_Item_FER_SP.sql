TRUNCATE TABLE fersadv.Item_FER_SP;

INSERT INTO fersadv.Item_FER_SP
(ITEMID, OUTERDIAMETER, INNERDIAMETER, ANGLE, BEARINGTYPE
, ABCPRIORITY, RADIUS, ITEMCATEGORYCODE,  BEARINGSUBTYPE
, BICONICAPPLICATIONS, RPATYPE, FERNKEITEM, SBU, COSTMODEL, WEBVISIBLE, ITEMPLANNERGROUPID
, ITEMTYPEEXTENDED, STOCKROTATION, WIDTH, HEIGHT, NAMEALIAS, FERCATALOGNUMBER, ITEMTYPE, COSTGROUPID
, DEFAULTORDERTYPE, NETWEIGHT, MODELGROUPID, STORAGEDIMENSIONNAME, STORAGEDIMENSIONGROUP, NAME, INVENTTABLERECID
, ITEMGROUPID, INTRASTATCOMMODITYCODE, DESCRIPTION, TRACKINGDIMENSIONGROUP, UNITID, ITEMCREATEDDATETIME
, TRACKINGDIMENSIONNAME, PRODUCTTYPE_OLD, FAMILYNAMECODE, SALESSTOPPED, SALESSTOPPEDREASON, PUBLISHWEBDATE, LINEDISC
, FERGLOBALPRODUCTTYPE, PURCHSTOPPED, PURCHSTOPPEDREASON, FERFINISHPRODUCTCLASSIFICATION, TARAWEIGHT, INVENTSTOPPED, INVENTSTOPPEDREASON, ITEMMODIFIEDDATETIME
, FINDIMENSIONS, FERPRODUCTTYPE, PRIMARYVENDORID, LASTMODIFIED, INTERNALDESCR, OUTERDIAMETER2, GREENREVENUE, REQGROUPID
, PURCHASECATEGORY, MOQ, ECOMMERCEVISIBLE, PURCHASESUBCATEGORY, PIMVISIBLE, CSR, SALESRPATYPE, INTRASTATCOMMODITYCODEV2
, DATAAREAID, FERITEMCATEGORIZATION,SUPPITEMGROUPID,SALESMULTIPLE,ITEMBUYERGROUPID ,PURCHASELEADTIME, FERAPSFAMILY, FERAPSLEVEL, FERAPSPRODUCTTYPE
, ALTITEMID, USEALTITEMID, BARCCODE,TECHDOCVISIBLE )
WITH DimensionSetEntity AS (SELECT 
    IT.ITEMID AS ProductNumber,
    BusinessUnitValue AS DefaultLedgerDimensionDisplayValue,
    IT.DATAAREAID,
    IT.RECID RECID, 
    MAX(GREATEST(IT.MODIFIEDDATETIME, DIMC.MODIFIEDDATETIME)) AS MODIFIEDDATETIME
FROM 
    fersads.ds_InventTable_FER IT
JOIN 
    fersads.ds_DimensionAttributeValueSet_FER DIMC ON IT.DEFAULTDIMENSION = DIMC.RECID
GROUP BY 
    IT.ITEMID, IT.RECID, BusinessUnitValue, DATAAREAID)
, ITEMTABLE AS (
select InventTable.dataareaid DATAAREAID
      , InventTable.itemid ITEMID
	  , InventTableExtended.ABCPriority ABCPRIORITY
	  , ISNULL(InventTableExtended.Angle, 0) AS ANGLE
	  , InventTableExtended.BearingSubtype BEARINGSUBTYPE
	  , InventTableExtended.BearingType BEARINGTYPE
	  , InventTableExtended.BiconicApplications BICONICAPPLICATIONS
	  , ISNULL(InventTableExtended.InnerDiameter, 0) AS INNERDIAMETER
	  , InventTableExtended.ItemCategoryCode ITEMCATEGORYCODE
	  , ISNULL(InventTableExtended.OuterDiameter, 0) AS OUTERDIAMETER
	  , ISNULL(InventTableExtended.ProductType_old, 0) AS PRODUCTTYPE_OLD
	  , ISNULL(InventTableExtended.Radius, 0) AS RADIUS
	  , ISNULL(InventTableExtended.RPAType, 0) AS RPATYPE
	  , ISNULL(InventTableExtended.StockRotation, 0) AS STOCKROTATION
	  , ISNULL(InventTableExtended.WebVisible, 0) AS WEBVISIBLE
	  , REPLACE(InventTable.FERCatalogNumber, '"', '') AS FERCATALOGNUMBER
	  , InventTable.FERNKEItem FERNKEITEM
	  , ISNULL(InventTableExtended.Height, 0) AS HEIGHT
	  , InventTable.ItemPlannerGroupId ITEMPLANNERGROUPID
	  -- , InventTable.ItemType ITEMTYPE
	-- New definition of item type. When a product can't appear in inventories, it is a service
	  , CASE WHEN InventModelGroup.STOCKEDPRODUCT = 0 THEN 1 ELSE 0 END AS ITEMTYPE
	  , InventTable.ItemTypeExtended ITEMTYPEEXTENDED
	  , InventTable.CostGroupId COSTGROUPID
	  , InventTable.CostModel COSTMODEL
	  , InventTable.Width WIDTH
	  , InventTable.SBU SBU
	  , InventTable.NameAlias NAMEALIAS
	  , ISNULL(InventItemSetupSupplyType.DefaultOrderType, 0) AS DEFAULTORDERTYPE
	  , InventItemGroupItem.ItemGroupId ITEMGROUPID
	  , ISNULL(EcoResStorageDimensionGroupItem.StorageDimensionGroup, 0) AS STORAGEDIMENSIONGROUP
	  , ISNULL(EcoResTrackingDimensionGroupItem.TrackingDimensionGroup, 0) AS TRACKINGDIMENSIONGROUP
	  , ISNULL(InventModelGroup.ModelGroupId, 'FIFO') AS MODELGROUPID
	  , EcoResProductTranslation.Description DESCRIPTION
	  , EcoResProductTranslation.Name NAME
	  , InventTableModuleInvent.UnitId UNITID
	  , InventTable.Recid INVENTTABLERECID
	  , InventTable.CreatedDateTime ITEMCREATEDDATETIME
	  , InventTable.NetWeight NETWEIGHT
	  , InventTableExtended.ChinaIntrastatCommodityCode  as INTRASTATCOMMODITYCODE
	  , EcoResStorageDimensionGroup.Name as STORAGEDIMENSIONNAME
	  , EcoResTrackingDimensionGroup.Name as TRACKINGDIMENSIONNAME
	  , ISNULL(InventItemPurchSetup.Stopped::INT, '0') AS PURCHSTOPPED
	  , InventItemPurchSetup.FERBLOCKINGTYPE::VARCHAR AS PURCHSTOPPEDREASON
	  , ISNULL(InventItemSalesSetup.Stopped::INT, '0') as SALESSTOPPED
	  , InventItemSalesSetup.FERBLOCKINGTYPE::VARCHAR AS SALESSTOPPEDREASON
	  , ISNULL(InventItemInventSetup.Stopped::INT, '0') as INVENTSTOPPED
	  , InventItemInventSetup.FERBLOCKINGTYPE::VARCHAR AS INVENTSTOPPEDREASON
	  , InventTableExtended.FamilyNameCode FAMILYNAMECODE
	  , InventTable.TaraWeight TARAWEIGHT
	  , ISNULL(InventTableExtended.PublishWebDate, '1900-01-01') AS PUBLISHWEBDATE
	  , InventTable.ModifiedDateTime ITEMMODIFIEDDATETIME
	  , InventTableModuleSales.LineDisc LINEDISC
	  , DimensionSetEntity.DefaultLedgerDimensionDisplayValue::VARCHAR FINDIMENSIONS
	  , InventTableExtended.FERFinishProductClassification FERFINISHPRODUCTCLASSIFICATION
	  , InventTableExtended.FERGlobalProductType FERGLOBALPRODUCTTYPE
	  , InventTableExtended.FERProductType FERPRODUCTTYPE
	  , InventTable.PrimaryVendorId PRIMARYVENDORID
	  , ISNULL(InventTableExtended.ECommerceVisible, 0) AS ECOMMERCEVISIBLE
	  , ISNULL(InventTableExtended.OuterDiameter2, 0) AS OUTERDIAMETER2
	  , ISNULL(InventItemPurchSetup.LOWESTQTY::NUMERIC(32,6), '0') AS MOQ
	  , InventTableExtended.InternalDescr INTERNALDESCR
	  , ISNULL(InventTableExtended.PIMVisible, 0) AS PIMVISIBLE
	  , ISNULL(InventTableExtended.GreenRevenue, 0) AS GREENREVENUE
	  , ISNULL(InventTableExtended.SalesRPAType, '0') AS SALESRPATYPE
	  , InventTable.ReqGroupId REQGROUPID
	  , ecorescategory.code as INTRASTATCOMMODITYCODEV2
	  , InventTableExtended.Csr CSR
	  , InventTableExtended.PURCHASECATEGORY
          , InventTableExtended.PURCHASESUBCATEGORY
	  ,InventTableExtended.FERITEMCATEGORIZATION FERITEMCATEGORIZATION
	  ,APPLY_MAX(ARRAY[INVENTTABLE.MODIFIEDDATETIME, INVENTTABLEEXTENDED.MODIFIEDDATETIME, INVENTITEMINVENTSETUP.MODIFIEDDATETIME,INVENTITEMPURCHSETUP.MODIFIEDDATETIME,INVENTITEMSALESSETUP.MODIFIEDDATETIME, InventItemSetupSupplyType.MODIFIEDDATETIME, InventTableModuleInvent.MODIFIEDDATETIME, InventTableModuleSales.MODIFIEDDATETIME, DimensionSetEntity.MODIFIEDDATETIME, PackingInstructionLine.MODIFIEDDATETIME, labelInstructionLine.MODIFIEDDATETIME, ecorescategory.MODIFIEDDATETIME]) as LASTMODIFIED
	  ,InventTableModuleSales.SUPPITEMGROUPID
	  ,ISNULL(InventItemSalesSetup.MULTIPLEQTY, '0') AS SALESMULTIPLE
	  ,InventTable.ITEMBUYERGROUPID
	  ,InventItemPurchSetup.LEADTIME AS PURCHASELEADTIME
	  ,InventTable.FERAPSFAMILY
	  ,InventTable.FERAPSLEVEL
	  ,InventTable.FERAPSPRODUCTTYPE
	  ,InventTable.ALTITEMID
	  ,InventTable.USEALTITEMID
	  ,ISNULL( labelInstructionLine.BARCCODE , PACKINGINSTRUCTIONLINE.BARCCODE ) AS BARCCODE
	  ,InventTableExtended.TECHDOCVISIBLE
FROM fersads.ds_InventTable_FER  InventTable
LEFT JOIN fersads.ds_INVENTTABLEEXTENDED_FER InventTableExtended on inventtable.itemid= InventTableExtended.itemid and UPPER(inventtable.dataareaid) = UPPER(InventTableExtended.dataareaid)
LEFT JOIN fersads.ds_InventItemSetupSupplyType_FER InventItemSetupSupplyType on inventtable.itemid= InventItemSetupSupplyType.itemid and UPPER(inventtable.dataareaid) = UPPER(InventItemSetupSupplyType.itemdataareaid)
LEFT JOIN fersads.ds_InventModelGroupItem_FER InventModelGroupItem on inventtable.itemid= InventModelGroupItem.itemid and UPPER(inventtable.dataareaid) = UPPER(InventModelGroupItem.itemdataareaid)
LEFT JOIN fersads.ds_InventModelGroup_FER InventModelGroup on UPPER(InventModelGroup.DataAreaId) = UPPER(InventModelGroupItem.ModelGroupDataAreaId) and InventModelGroup.ModelGroupId = InventModelGroupItem.ModelGroupId
LEFT JOIN fersads.ds_InventItemGroupItem_FER InventItemGroupItem on inventtable.itemid= InventItemGroupItem.itemid and UPPER(inventtable.dataareaid) = UPPER(InventItemGroupItem.itemdataareaid)
LEFT JOIN fersads.ds_EcoResStorageDimensionGroupItem_FER  EcoResStorageDimensionGroupItem on inventtable.itemid= EcoResStorageDimensionGroupItem.itemid and UPPER(inventtable.dataareaid) = UPPER(EcoResStorageDimensionGroupItem.itemdataareaid)
LEFT JOIN fersads.ds_EcoResStorageDimensionGroup_FER  EcoResStorageDimensionGroup on EcoResStorageDimensionGroupItem.StorageDimensionGroup=EcoResStorageDimensionGroup.recid 
LEFT JOIN fersads.ds_EcoResTrackingDimensionGroupItem_FER  EcoResTrackingDimensionGroupItem on inventtable.itemid= EcoResTrackingDimensionGroupItem.itemid and UPPER(inventtable.dataareaid) = UPPER(EcoResTrackingDimensionGroupItem.itemdataareaid)
LEFT JOIN fersads.ds_EcoResTrackingDimensionGroup_FER  EcoResTrackingDimensionGroup on EcoResTrackingDimensionGroupItem.TrackingDimensionGroup = EcoResTrackingDimensionGroup.Recid
LEFT JOIN fersads.ds_EcoResProductTranslation_FER EcoResProductTranslation on inventtable.Product= EcoResProductTranslation.Product and EcoResProductTranslation.languageid='es'
LEFT JOIN fersads.ds_InventTableModule_FER InventTableModuleInvent on  inventtable.itemid= InventTableModuleInvent.itemid and UPPER(inventtable.dataareaid) = UPPER(InventTableModuleInvent.dataareaid) and InventTableModuleInvent.moduletype=0
LEFT JOIN fersads.ds_InventTableModule_FER InventTableModuleSales on  inventtable.itemid= InventTableModuleSales.itemid and UPPER(inventtable.dataareaid) = UPPER(InventTableModuleSales.dataareaid) and InventTableModuleSales.moduletype=2
LEFT JOIN DimensionSetEntity on inventtable.ITEMID = DimensionSetEntity.ProductNumber and UPPER(inventtable.DATAAREAID) = UPPER(DimensionSetEntity.DATAAREAID)
LEFT JOIN (SELECT * FROM fersads.ds_FERPACKINGINSTRUCTIONLINE_FER
LIMIT 1 OVER(PARTITION BY ITEMNO ORDER BY RECID ASC)) PackingInstructionLine ON InventTable.ITEMID= PackingInstructionLine.ITEMNO
LEFT JOIN  (SELECT * FROM  fersads.ds_FERLABELINGINSTRUCTIONLINE_FER  
LIMIT 1 OVER(PARTITION BY ITEMNO, DATAAREAID ORDER BY  MODIFIEDDATETIME ASC, VERSION ASC)) labelInstructionLine ON InventTable.ITEMID = labelInstructionLine.ITEMNO AND  UPPER(inventtable.DATAAREAID) = UPPER(DimensionSetEntity.DATAAREAID)
LEFT JOIN (SELECT * FROM fersads.ds_InventItemPurchSetup_FER  
LIMIT 1 OVER(PARTITION BY ITEMID, DATAAREAID ORDER BY  MODIFIEDDATETIME ASC )) InventItemPurchSetup on inventtable.itemid=InventItemPurchSetup.itemid and UPPER(inventtable.dataareaid) = UPPER(InventItemPurchSetup.dataareaid)
LEFT JOIN (SELECT * FROM Fersads.ds_InventItemSalesSetup_FER  
LIMIT 1 OVER(PARTITION BY ITEMID, DATAAREAID ORDER BY MULTIPLEQTY DESC)) InventItemSalesSetup on inventtable.itemid=InventItemSalesSetup.itemid and UPPER(inventtable.dataareaid) = UPPER(InventItemSalesSetup.dataareaid)
LEFT JOIN  (SELECT * FROM fersads.ds_InventItemInventSetup_FER 
LIMIT 1 OVER(PARTITION BY ITEMID, DATAAREAID ORDER BY  MODIFIEDDATETIME ASC)) InventItemInventSetup on inventtable.itemid=InventItemInventSetup.itemid and UPPER(inventtable.dataareaid) = UPPER(InventItemInventSetup.dataareaid)
LEFT JOIN fersads.ds_EcoResCategory_FER  ecorescategory on ecorescategory.recid=inventtable.IntrastatCommodity
)
SELECT 
ITEMID, OUTERDIAMETER, INNERDIAMETER, 
 ANGLE, BEARINGTYPE
, ABCPRIORITY, RADIUS, ITEMCATEGORYCODE, 
 BEARINGSUBTYPE, BICONICAPPLICATIONS, RPATYPE, FERNKEITEM, SBU, COSTMODEL, WEBVISIBLE, ITEMPLANNERGROUPID
, ITEMTYPEEXTENDED, STOCKROTATION, WIDTH, HEIGHT, NAMEALIAS, FERCATALOGNUMBER, ITEMTYPE, COSTGROUPID
, DEFAULTORDERTYPE, NETWEIGHT, MODELGROUPID, STORAGEDIMENSIONNAME, STORAGEDIMENSIONGROUP, NAME, INVENTTABLERECID
, ITEMGROUPID, INTRASTATCOMMODITYCODE, DESCRIPTION, TRACKINGDIMENSIONGROUP, UNITID, ITEMCREATEDDATETIME
, TRACKINGDIMENSIONNAME,PRODUCTTYPE_OLD, FAMILYNAMECODE, SALESSTOPPED, SALESSTOPPEDREASON, PUBLISHWEBDATE, LINEDISC
, FERGLOBALPRODUCTTYPE, PURCHSTOPPED, PURCHSTOPPEDREASON, FERFINISHPRODUCTCLASSIFICATION, TARAWEIGHT, INVENTSTOPPED, INVENTSTOPPEDREASON, ITEMMODIFIEDDATETIME
, FINDIMENSIONS, FERPRODUCTTYPE, PRIMARYVENDORID, LASTMODIFIED, INTERNALDESCR, OUTERDIAMETER2, GREENREVENUE, REQGROUPID
, PURCHASECATEGORY, MOQ, ECOMMERCEVISIBLE, PURCHASESUBCATEGORY, PIMVISIBLE, CSR, SALESRPATYPE, INTRASTATCOMMODITYCODEV2
, DATAAREAID , FERITEMCATEGORIZATION,SUPPITEMGROUPID,SALESMULTIPLE, ITEMBUYERGROUPID, PURCHASELEADTIME, FERAPSFAMILY, FERAPSLEVEL, FERAPSPRODUCTTYPE
, ALTITEMID, USEALTITEMID, BARCCODE, TECHDOCVISIBLE
FROM ITEMTABLE
INNER JOIN fersaParams.CompanyLocation_standalone CL ON UPPER(CL.LOCATIONID) = UPPER(DATAAREAID)
WHERE CL.ORIGIN = 'FER';