
TRUNCATE TABLE fersadv.ExchangeRateYearly_ALL;

INSERT INTO fersadv.ExchangeRateYearly_ALL(EXCHANGERATE,VALIDFROM,VALIDTO,FROMCURRENCYCODE,TOCURRENCYCODE,ERPSOURCE)
WITH EX AS(
            select DISTINCT BUDGETYEAR
                    , CurrencyFrom
                    , CurrencyTo
                    ,CurrencyFactor
            from fersads.ds_BudgetCurrencyFactorYearly_EDC
        ),INVERSES_NOTDEFINED AS(
            select ex.BUDGETYEAR, ex.CURRENCYTO AS CURRENCYFROM, ex.CURRENCYFROM AS CURRENCYTO, 1/ex.CURRENCYFACTOR AS CURRENCYFACTOR
            from (
                SELECT BUDGETYEAR, CURRENCYTO AS CURRENCYFROM, CURRENCYFROM AS CURRENCYTO
                FROM EX
                EXCEPT
                select BUDGETYEAR, CURRENCYFROM, CURRENCYTO
                from EX
            )T left join EX ex ON(T.BUDGETYEAR=ex.BUDGETYEAR and T.CURRENCYFROM=ex.CURRENCYTO and T.CURRENCYTO=ex.CURRENCYFROM)
        ), UNITARIES AS(
            select DISTINCT inv.*
            from(
                SELECT BUDGETYEAR, CURRENCYFROM, CURRENCYFROM AS CURRENCYTO, 1 AS CURRENCYFACTOR
                FROM EX
                EXCEPT
                select BUDGETYEAR,CURRENCYFROM,CURRENCYTO,CURRENCYFACTOR
                FROM EX
                UNION ALL
                SELECT BUDGETYEAR, CURRENCYTO AS CURRENCYFROM,  CURRENCYTO, 1 AS CURRENCYFACTOR
                FROM EX
                EXCEPT
                select BUDGETYEAR,CURRENCYFROM,CURRENCYTO,CURRENCYFACTOR
                FROM EX
            )inv inner join(
                select *
                from fersaParamsPublic.StandardExchangeRateCombinations_standalone
                where ENABLED
                ) sercs ON (sercs.FROMCURRENCYCODE=inv.CURRENCYFROM AND sercs.TOCURRENCYCODE=inv.CURRENCYTO)
        ),TRIANGULATED_ALL AS(
            select DISTINCT cf1.*
            from (
                select BUDGETYEAR,CURRENCYFROM,CURRENCYTO,MAX(CURRENCYFACTOR) AS CURRENCYFACTOR
                from(
                    SELECT cf1.BUDGETYEAR, cf1.CURRENCYFROM, cf2.CURRENCYTO, cf1.CURRENCYFACTOR*cf2.CURRENCYFACTOR AS CURRENCYFACTOR
                    from (
                        select * from ex
                        UNION ALL
                        select * from INVERSES_NOTDEFINED
                    )cf1
                    join (
                        select *
                        from fersads.ds_BudgetCurrencyFactorYearly_EDC
                        ) cf2  ON (cf2.BUDGETYEAR=cf1.BUDGETYEAR and cf1.CURRENCYTO=cf2.CURRENCYFROM)
                )dropDuplicated
                group by BUDGETYEAR,CURRENCYFROM,CURRENCYTO
            )cf1 inner join(
                    select *
                    from fersaParamsPublic.StandardExchangeRateCombinations_standalone
                    where ENABLED
                    ) sercs ON (sercs.FROMCURRENCYCODE=cf1.CURRENCYFROM AND sercs.TOCURRENCYCODE=cf1.CURRENCYTO)
            WHERE cf1.CURRENCYFROM<>cf1.CURRENCYTO
        ),TRIANGULED_NOTDEFINED AS(
            select TR.BUDGETYEAR, TR.CURRENCYFROM, TR.CURRENCYTO, TR.CURRENCYFACTOR
            from(
                select BUDGETYEAR, CURRENCYFROM, CURRENCYTO
                from TRIANGULATED_ALL
                EXCEPT
                select BUDGETYEAR, CURRENCYFROM, CURRENCYTO
                from (
                    select * from ex
                    UNION ALL
                    select * from INVERSES_NOTDEFINED
                )tmp
            )TR_NOTIN left join TRIANGULATED_ALL TR ON(TR_NOTIN.BUDGETYEAR=TR.BUDGETYEAR and TR_NOTIN.CURRENCYFROM=TR.CURRENCYFROM and TR_NOTIN.CURRENCYTO=TR.CURRENCYTO)
        )
        select ROUND(CURRENCYFACTOR,6) AS CURRENCYFACTOR, BUDGETYEAR ,BUDGETYEAR, CURRENCYFROM, CURRENCYTO, 'DEFAULT' AS ERPSOURCE
        from(
            select *
            from EX
            UNION ALL
            select *
            from UNITARIES
            UNION ALL
            select *
            from INVERSES_NOTDEFINED
            UNION ALL
            select *
            from TRIANGULED_NOTDEFINED
        )T;