TRUNCATE TABLE fersadv.PurchaseBudgetDaily_SP_ALL;

INSERT INTO fersadv.PurchaseBudgetDaily_SP_ALL(DAILYQTY,DAILYOTHERCOST,DATE,SUBSIDIARYID,UNITPRICE,ITEMID
                    ,QTY,YEAR,CURRENCYCODE,SUPPLIERID,CUSTOMCOST,OTHERCOST,TRANSPORTCOST,CORRECTIONFACTOR
                    ,COMPANYID,CURRENCYCODE_LOCAL,EXCHANGERATE_EUR,EXCHANGERATE_USD,EXCHANGERATE_LOCAL)
SELECT QTY/YEARDAYS.COUNTDAYS AS DAILYQTY
        , OTHERCOST/YEARDAYS.COUNTDAYS AS DAILYOTHERCOST
        , YEARDAYS.date_time AS DATE
        , pbyp.*
FROM fersadv.PurchaseBudgetYearly_ALL pbyp
LEFT JOIN (
    SELECT DAYS.date_time, DAYS.weekyearnumber, YEARDAYS.COUNTDAYS FROM
        (SELECT date_time, weekyearnumber
        FROM fersaParams.dimdate as DATES
        GROUP BY date_time, weekyearnumber) AS DAYS
    LEFT JOIN
        (SELECT DAYS.weekyearnumber, COUNT(*) AS COUNTDAYS
        FROM (SELECT date_time, weekyearnumber
                FROM fersaParams.dimdate
                GROUP BY date_time, weekyearnumber) AS DAYS
        GROUP BY DAYS.weekyearnumber) YEARDAYS
    ON YEARDAYS.weekyearnumber = DAYS.weekyearnumber
) AS YEARDAYS
ON pbyp.YEAR = YEARDAYS.weekyearnumber
;