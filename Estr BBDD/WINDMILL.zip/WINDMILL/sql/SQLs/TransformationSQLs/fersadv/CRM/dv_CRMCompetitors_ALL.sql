/* Objectives--> to concat the diferent competitors and referencies in the same format as in the appplication:  
COMPETITOR1 | REF1, REF2,... ~ COMPETITOR2 | REF1,....*/

/* In oder to add more than 5 competitors with the resursivity you need this command*/
ALTER SESSION SET PARAMETER WithClauseRecursionLimit=100; 
 

/* Auxiliar table that for each competitor groups all his associated referrences separated by ,  in a column call acc */
CREATE LOCAL TEMP TABLE GROUP_REF_BY_COMPETITOR
ON COMMIT PRESERVE ROWS
AS
WITH RECURSIVE
/* ItemName based on competitor list (comma separated) */
competitor_pairs AS (
SELECT
	cat_norm,
	ext_id,
	competitor,
	ROW_NUMBER() OVER (PARTITION BY cat_norm, competitor
ORDER BY
	ext_id, competitor) AS rn, 
		d."CATALOG",
		d.MODEL,
		d.NAME,
		d.ORIGINALBRAND,
		d.ITEMID,
		CONCAT(d.MODEL, CONCAT('-', d.PRODUCTBRAND)) AS KEY, 
		d.MODIFIEDDATETIME
FROM
	(
	SELECT
		DISTINCT
      REGEXP_REPLACE(UPPER(IFC.NAME), '[^A-Z0-9]+', '') AS cat_norm,
		--deletes verything that isn't a letter o number from the ITEMNAME
		DFF.EXTERNALITEMID AS ext_id, 
		DFF.COMPETITOROEMID AS competitor,
		IFC."CATALOG",
        CASE
			WHEN IFC.NAME LIKE '%NKE_%' THEN REPLACE(IFC.NAME, 'NKE_', '')
			ELSE IFC.NAME
		END AS MODEL,
		IFC.NAME,
        IFC.ITEMID,
        CASE
			WHEN IFC.BRAND = 'FER' THEN 'FERSA'
			ELSE IFC.BRAND
		END AS PRODUCTBRAND, 
		BRAND AS ORIGINALBRAND, 
		APPLY_MAX(ARRAY[DFF.MODIFIEDDATETIME, IFC.MODIFIEDDATETIME]) AS MODIFIEDDATETIME
    FROM
		fersads.ds_FERCOMPETITOROEMV2_FER DFF
	JOIN fersadv.Item_ALL IFC
      ON
		IFC.ITEMID = DFF.ITEMID
		--AND IF2.SUBSIDIARYID = 'FBEA'	
  ) d
),
/* fiRst recursive to concat COMPETITOR1 | REF1, REF2, REF3, ...*/
competitor_concat_pairs (cat_norm,
rn,
competitor,
acc, 
maxmod) AS (
  /* seed */
SELECT
	cat_norm,
	rn,
	competitor,
	ext_id::VARCHAR(65000), 
	MODIFIEDDATETIME AS MAXMOD
FROM
	competitor_pairs
WHERE
	rn = 1 
UNION ALL
  /* step */
SELECT
	p.cat_norm,
	p.rn,
	p.competitor,
	(c.acc || ';'::VARCHAR || p.ext_id)::VARCHAR(65000), 
	APPLY_MAX(ARRAY[c.maxmod, p.MODIFIEDDATETIME])
FROM
	competitor_pairs p
JOIN competitor_concat_pairs c
    ON
	p.cat_norm = c.cat_norm
	AND 
	p.competitor=c.competitor
	AND 
	p.rn = c.rn + 1
)
SELECT 
		ccp.cat_norm,
        cp."CATALOG",
        cp.MODEL, 
        cp.NAME,
        cp.ORIGINALBRAND,
        cp.KEY,
        cp.ITEMID,
		(ccp.COMPETITOR || '|' || ccp.ACC) AS COMP_REF, 
		ccp.maxmod as MODIFIEDDATETIME
FROM competitor_concat_pairs ccp JOIN competitor_pairs cp ON ccp.cat_norm=cp.cat_norm
LIMIT 1 OVER (PARTITION BY ccp.cat_norm,ccp.competitor order by ccp.rn desc);/* seleccion of the line with all the references for each competitor  */


DELETE FROM  fersadv.CRMCompetitors_ALL ; 


/* Second recursivity to concat all the competitors of the same item in the same row separated by ~*/
INSERT
	INTO
	fersadv.CRMCompetitors_ALL 
(
    ITEMNAME_NORM,
	CATALOG,
	MODEL ,
	KEY,
	ITEMID,
	COMP_REF, 
	NAME, 
	ORIGINALBRAND, 
	MODIFIEDDATETIME
)
WITH RECURSIVE auxiliary_competitors AS (
	SELECT
		cat_norm,
		COMP_REF::VARCHAR(65000) ,
		"CATALOG",
		MODEL,
		ITEMID,
		KEY,
		ROW_NUMBER() OVER (PARTITION BY CAT_NORM
	ORDER BY
		COMP_REF) AS rn2, 
		NAME, 
		ORIGINALBRAND, 
		MODIFIEDDATETIME
	FROM
		GROUP_REF_BY_COMPETITOR
),
	competitor_concat AS (
  /* seed */
	SELECT
		cat_norm,
		rn2,
		COMP_REF::VARCHAR(65000), 
		MODIFIEDDATETIME AS maxmod
	FROM
		auxiliary_competitors
	WHERE
		rn2 = 1
UNION ALL
  /* step */
	SELECT
		p.cat_norm,
		p.rn2,
		(c.COMP_REF || '~'::VARCHAR || p.COMP_REF)::VARCHAR(65000), 
		APPLY_MAX(ARRAY[c.maxmod, p.MODIFIEDDATETIME])
	FROM
		auxiliary_competitors p
	JOIN competitor_concat c ON
		p.cat_norm = c.cat_norm
		AND 
	p.rn2 = c.rn2 + 1
)
SELECT
	CC.cat_norm,
	AUX."CATALOG",
	AUX.MODEL,
	AUX.KEY,
	AUX.ITEMID,
	CC.COMP_REF::VARCHAR(65000) AS CROSS_REFERENCES, 
	NAME, 
	ORIGINALBRAND, 
	CC.maxmod AS MODIFIEDDATETIME 
FROM
	competitor_concat cc
JOIN auxiliary_competitors AUX ON
	cc.cat_norm = aux.cat_norm
LIMIT 1 OVER ( PARTITION BY cc.CAT_NORM
ORDER BY
cc.RN2 DESC);

DROP TABLE IF EXISTS GROUP_REF_BY_COMPETITOR;