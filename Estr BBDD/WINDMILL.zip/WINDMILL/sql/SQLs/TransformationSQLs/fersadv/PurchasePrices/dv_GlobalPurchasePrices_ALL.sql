TRUNCATE TABLE fersadv.GlobalPurchasePrices_ALL;

INSERT INTO fersadv.GlobalPurchasePrices_ALL(ITEMID,COMPANYID ,SUBSIDIARYID ,SUPPLIERID,UNITPRICE,
    CURRENCYCODE,FROMDATE,UNITID,FROMQUANTITY,TOQUANTITY,PURCHASETYPE,CURRENCYCODE_LOCAL,EXCHANGERATE_EUR,EXCHANGERATE_USD,EXCHANGERATE_LOCAL,SCALEDROW, MODIFIEDDATETIME)

--WITH GLOBALPURCHASEPRICES AS (		--POR PRIMARY
						WITH
						PurchasePriceDLXHC AS 
						(SELECT DS.ITEMID,C.COMPANYID,C.LOCATIONID AS SUBSIDIARYID,DS.SUPPLIERID,DS.UNITPRICE,'INR' AS CURRENCYCODE, 'UD' AS UNITID, NULL::numeric AS FROMQUANTITY
							   , NULL::numeric AS TOQUANTITY,'DLXHC' AS PURCHASETYPE , NULL::timestamp AS MODIFIEDDATETIME
						FROM thirdParty.DeluxSupplier DS
						CROSS JOIN fersaParams.CompanyLocation_standalone C
						WHERE C.COMPANYID='DLX'
						) 
						,PurchasePriceByPrimaryVendor  AS
						(SELECT ITEMID,COMPANYID,SUBSIDIARYID,SUPPLIERID,UNITPRICE,CURRENCYCODE,UNITID,FROMQUANTITY
							   ,TOQUANTITY,PURCHASETYPE, MODIFIEDDATETIME FROM
						(SELECT ilsa.ITEMID
						        ,ilsa.COMPANYID
							   ,ilsa.SUBSIDIARYID
							   ,ilsa.PRIMARYVENDORID  SUPPLIERID
							   ,PPPrimary.UNITPRICE
							   ,PPPrimary.CURRENCYCODE
							   ,PPPrimary.UNITID
							   ,PPPrimary.FROMQUANTITY
							   ,PPPrimary.TOQUANTITY
							   ,'PRIMARY-PRICE' AS PURCHASETYPE
							   ,ilsa.MODIFIEDDATETIME
							   ,ROW_NUMBER() OVER (PARTITION BY ilsa.ITEMID, ilsa.SUBSIDIARYID,FROMQUANTITY,TOQUANTITY ORDER BY FROMDATE DESC) AS ROWNUM
							FROM
								fersadv.Item_ALL ilsa
								LEFT JOIN fersadv.PurchasePrices_ALL PPPrimary
								ON ((PPPrimary.ITEMID IS NOT NULL) AND (PPPrimary.ITEMID <> ''::varchar)
												AND ((PPPrimary.TODATE IS NULL) OR (PPPrimary.TODATE > (now())::date))
												AND (PPPrimary.SUPPLIERID IS NOT NULL) AND (PPPrimary.SUPPLIERID <> ''::varchar)
												AND (PPPrimary.ITEMID= ilsa.ITEMID)
												AND (PPPrimary.SUPPLIERID = ilsa.PRIMARYVENDORID)
												AND (PPPrimary.SUBSIDIARYID = ilsa.SUBSIDIARYID))
								WHERE  LENGTH (ilsa.PRIMARYVENDORID)>0  AND PPPrimary.UNITPRICE>0) A
						WHERE ROWNUM=1
						AND CONCAT(ITEMID,SUBSIDIARYID)
								NOT IN (SELECT CONCAT(ITEMID ,SUBSIDIARYID)
												FROM PurchasePriceDLXHC ))
						,PurchaseLineByPrimaryVendor  AS
						(SELECT ilsa.ITEMID
						        ,ilsa.COMPANYID
							   ,ilsa.SUBSIDIARYID
							   ,ilsa.PRIMARYVENDORID  SUPPLIERID
							   ,VV.UNITPRICE
							   ,vv.CURRENCYCODE
							   ,vv.PURCHUNIT AS UNITID
							   ,NULL::numeric AS FROMQUANTITY
							   ,NULL::numeric AS TOQUANTITY
							   ,'PRIMARY-PLINE' AS PURCHASETYPE
							   ,APPLY_MAX(ARRAY[ilsa.MODIFIEDDATETIME, VV.MODIFIEDDATETIME]) AS MODIFIEDDATETIME
							FROM
								fersadv.Item_ALL ilsa
								LEFT JOIN (SELECT plpas.SUBSIDIARYID, plpas.ITEMID, plpas.CURRENCYCODE, plpas.UNITPRICE, plpas.SUPPLIERID,plpas.PURCHUNIT, plpas.MODIFIEDDATETIME,
                                            ROW_NUMBER() OVER (PARTITION BY plpas.SUBSIDIARYID,plpas.ITEMID,plpas.SUPPLIERID ORDER BY plpas.PURCHASEDATE DESC)
                                            FROM fersadv.PurchaseLines_ALL plpas
                                            where plpas.UNITPRICE>0
                                        ) VV ON VV.ROW_NUMBER = 1 AND VV.SUBSIDIARYID = ilsa.SUBSIDIARYID AND VV.ITEMID= ilsa.ITEMID AND VV.SUPPLIERID= ilsa.PRIMARYVENDORID
								WHERE  LENGTH (ilsa.PRIMARYVENDORID)>0  AND VV.UNITPRICE>0
								AND CONCAT(ilsa.ITEMID,ilsa.SUBSIDIARYID)
								NOT IN (SELECT CONCAT(ITEMID ,SUBSIDIARYID)
												FROM PurchasePriceDLXHC 
										UNION ALL 
									    SELECT CONCAT(ITEMID ,SUBSIDIARYID)
												FROM PurchasePriceByPrimaryVendor ))

						--POR TARIFA DE VENTA INTERCOMPANY
						,PurchasePriceByPrimaryIntercompanyVendor  AS
						(SELECT ilsa.ITEMID
							    ,ilsa.COMPANYID
							   ,ilsa.SUBSIDIARYID
							   ,ilsa.PRIMARYVENDORID SUPPLIERID
							   --,VV.UNITPRICE
							   --,VV3.fromSale
							   --,VV3.customer
							   ,SPPrimary.UNITPRICE
							   ,SPPrimary.CURRENCYCODE
							   ,SPPrimary.UNITID
							   ,SPPrimary.FROMQUANTITY
							   ,SPPrimary.TOQUANTITY
							   ,'SALESPRICEINTERCO' AS PURCHASETYPE
							   , APPLY_MAX(ARRAY[ilsa.MODIFIEDDATETIME, SPPrimary.MODIFIEDDATETIME]) AS MODIFIEDDATETIME
						FROM
						    fersadv.Item_ALL ilsa
							INNER  JOIN (SELECT clsa1.CUSTVENDACCOUNT vendor, clsa1.FROMDATAAREAID fromPurchase, clsa2.FROMDATAAREAID fromSale,clsa2.CUSTVENDACCOUNT customer  FROM
												fersaParamsPublic.CustomerVendorInterCo_standalone clsa1, fersaParamsPublic.CustomerVendorInterCo_standalone clsa2
												WHERE   clsa1.TYPE=1
														AND clsa2.FROMDATAAREAID  = clsa1.TODATAAREAID
														AND	clsa2.TODATAAREAID  = clsa1.FROMDATAAREAID
														AND clsa2.TYPE=2
														AND clsa1.DEFAULT
														AND clsa2.DEFAULT
								)vv3 ON
									vv3.fromPurchase = ilsa.SUBSIDIARYID
									AND vv3.vendor		 = 	ilsa.PRIMARYVENDORID
							LEFT JOIN fersadv.SalesPricesActive_ALL SPPrimary
								ON ((SPPrimary.ITEMID IS NOT NULL) AND (SPPrimary.ITEMID <> ''::varchar)
												AND ((SPPrimary.TODATE IS NULL) OR (SPPrimary.TODATE > (now())::date))
												AND (SPPrimary.CUSTOMERID IS NOT NULL) AND (SPPrimary.CUSTOMERID <> ''::varchar)
												AND (SPPrimary.ITEMID= ilsa.ITEMID)
												AND (SPPrimary.CUSTOMERID  = VV3.customer)
												AND (SPPrimary.SUBSIDIARYID = VV3.fromSale))
								WHERE  LENGTH (ilsa.PRIMARYVENDORID)>0  AND SPPrimary.UNITPRICE>0
								AND CONCAT(ilsa.ITEMID,ilsa.SUBSIDIARYID)
								NOT IN (	SELECT CONCAT(ITEMID ,SUBSIDIARYID)
												FROM PurchasePriceDLXHC 
											UNION ALL
											SELECT CONCAT(ppprice.ITEMID ,ppprice.SUBSIDIARYID)
												FROM PurchasePriceByPrimaryVendor ppprice
											UNION ALL 
									    		SELECT CONCAT(ITEMID ,SUBSIDIARYID)
												FROM PurchaseLineByPrimaryVendor))

						--POR PEDIDO DE COMPRA SI NO ESTÁ EN LAS DOS ANTERIORES
						,PurchasePriceByLastPurchase  AS
						(SELECT ilsa.ITEMID
                           ,ilsa.COMPANYID
                           ,ilsa.SUBSIDIARYID
                           ,CASE WHEN ilsa.PRIMARYVENDORID IS NULL THEN VV.SUPPLIERID ELSE ilsa.PRIMARYVENDORID END AS SUPPLIERID
                           ,VV.UNITPRICE
                           ,VV.CURRENCYCODE
                           ,VV.PURCHUNIT AS UNITID
                           , NULL::numeric AS FROMQUANTITY
                           , NULL::numeric AS TOQUANTITY
                           ,'PURCHLINE' AS PURCHASETYPE
						   , APPLY_MAX(ARRAY[ilsa.MODIFIEDDATETIME, VV.MODIFIEDDATETIME]) AS MODIFIEDDATETIME
                        FROM
                            fersadv.Item_ALL ilsa
                            INNER JOIN (SELECT plpas.SUBSIDIARYID, plpas.ITEMID, plpas.CURRENCYCODE, plpas.UNITPRICE, plpas.SUPPLIERID,plpas.PURCHUNIT, plpas.MODIFIEDDATETIME,
                                            ROW_NUMBER() OVER (PARTITION BY plpas.SUBSIDIARYID,plpas.ITEMID ORDER BY plpas.PURCHASEDATE DESC)
                                            FROM fersadv.PurchaseLines_ALL plpas
                                            where plpas.UNITPRICE>0
                                        ) VV ON VV.ROW_NUMBER = 1 AND VV.SUBSIDIARYID = ilsa.SUBSIDIARYID AND VV.ITEMID= ilsa.ITEMID
								WHERE
								CONCAT(ilsa.ITEMID,ilsa.SUBSIDIARYID)
									NOT IN (SELECT CONCAT(ITEMID ,SUBSIDIARYID)
												FROM PurchasePriceDLXHC 
											UNION ALL
											SELECT CONCAT(ppprice.ITEMID ,ppprice.SUBSIDIARYID)
												FROM PurchasePriceByPrimaryVendor ppprice
											UNION ALL 
									    		SELECT CONCAT(ITEMID ,SUBSIDIARYID)
												FROM PurchaseLineByPrimaryVendor
											 UNION ALL
											SELECT CONCAT(ppprice2.ITEMID ,ppprice2.SUBSIDIARYID)
												FROM PurchasePriceByPrimaryIntercompanyVendor ppprice2))
						--POR STANDARD 
						,PurchasePriceStandard  AS
						(SELECT ilsa.ITEMID
                           ,ilsa.COMPANYID
                           ,ilsa.SUBSIDIARYID
                           ,ilsa.PRIMARYVENDORID as SUPPLIERID
                           ,VV.UNITPRICE
                           ,VV.CURRENCYCODE
                           ,VV.UNITID
                           , NULL::numeric AS FROMQUANTITY
                           , NULL::numeric AS TOQUANTITY
                           ,'STANDARD' AS PURCHASETYPE
						   , ilsa.MODIFIEDDATETIME
                        FROM
                            fersadv.Item_ALL ilsa
                            LEFT JOIN (SELECT SUBSIDIARYID, ITEMID, CURRENCYCODE, UNITPRICE,UNITID
                                            FROM fersadv.StandardCosts_ALL
                                            INNER JOIN fersaParams.CompanyLocation_standalone cls ON HASH(cls.LOCATIONID)=HASH(StandardCosts_ALL.SUBSIDIARYID)
                                        ) VV ON VV.SUBSIDIARYID = ilsa.SUBSIDIARYID AND VV.ITEMID= ilsa.ITEMID
								WHERE
								CONCAT(ilsa.ITEMID,ilsa.SUBSIDIARYID)
									NOT IN (SELECT CONCAT(ITEMID ,SUBSIDIARYID)
												FROM PurchasePriceDLXHC 
											UNION ALL
											SELECT CONCAT(ppprice.ITEMID ,ppprice.SUBSIDIARYID)
												FROM PurchasePriceByPrimaryVendor ppprice
											UNION ALL 
									    		SELECT CONCAT(ITEMID ,SUBSIDIARYID)
												FROM PurchaseLineByPrimaryVendor
											 UNION ALL
											SELECT CONCAT(ppprice2.ITEMID ,ppprice2.SUBSIDIARYID)
												FROM PurchasePriceByPrimaryIntercompanyVendor ppprice2
											 UNION ALL
											SELECT CONCAT(ppprice3.ITEMID ,ppprice3.SUBSIDIARYID)
												FROM PurchasePriceByLastPurchase ppprice3))
						--PFI
						,PurchasePricePFI AS (
						SELECT ilsa.ITEMID
						,cls.COMPANYID
						,cvics.TODATAAREAID AS SUBSIDIARYID
						,cvics2.CUSTVENDACCOUNT SUPPLIERID
						,sia.AMOUNT/sia.INVOICEQTY UNITPRICE
						,sia.CURRENCYCODE
						,'UD' AS UNITID
						,NULL::numeric AS FROMQUANTITY
						,NULL::numeric AS TOQUANTITY
						,'SALESPRICEINTERCO' AS PURCHASETYPE
						, ilsa.MODIFIEDDATETIME
							FROM fersadv.Item_ALL ilsa
							INNER JOIN (SELECT SUBSIDIARYID, ITEMID,AMOUNT,INVOICEQTY, CURRENCYCODE, CUSTOMERID,
																	ROW_NUMBER() OVER (PARTITION BY SUBSIDIARYID, ITEMID ORDER BY INVOICEDATE DESC)
																	FROM fersadv.SalesInvoices_ALL 
																	WHERE INVOICEQTY>0 AND AMOUNT>0
																)   
							sia ON sia.ROW_NUMBER = 1 AND HASH(ilsa.SUBSIDIARYID,ilsa.ITEMID)=HASH(sia.SUBSIDIARYID,sia.ITEMID) 
							INNER JOIN fersaParamsPublic.CustomerVendorInterCo_standalone cvics ON HASH(cvics.FROMDATAAREAID,cvics.CUSTVENDACCOUNT)=HASH(sia.SUBSIDIARYID,sia.CUSTOMERID) AND cvics.TYPE = 2
							INNER JOIN fersaParamsPublic.CustomerVendorInterCo_standalone cvics2 ON HASH(cvics2.FROMDATAAREAID,cvics2.TODATAAREAID)=HASH(cvics.TODATAAREAID,ilsa.SUBSIDIARYID ) AND cvics2.TYPE = 1 AND cvics2.DEFAULT
							INNER JOIN fersaParams.CompanyLocation_standalone cls ON cls.LOCATIONID = cvics.TODATAAREAID 
							WHERE cls.COMPANYID ='PFI'
							AND 
							CONCAT(ilsa.ITEMID,cvics.TODATAAREAID)
															NOT IN (SELECT CONCAT(ITEMID ,SUBSIDIARYID)
																		FROM PurchasePriceDLXHC 
																	UNION ALL
																	SELECT CONCAT(ppprice.ITEMID ,ppprice.SUBSIDIARYID)
																		FROM PurchasePriceByPrimaryVendor ppprice
																	UNION ALL 
																		SELECT CONCAT(ITEMID ,SUBSIDIARYID)
																		FROM PurchaseLineByPrimaryVendor
																	UNION ALL
																	SELECT CONCAT(ppprice2.ITEMID ,ppprice2.SUBSIDIARYID)
																		FROM PurchasePriceByPrimaryIntercompanyVendor ppprice2
																	UNION ALL
																	SELECT CONCAT(ppprice3.ITEMID ,ppprice3.SUBSIDIARYID)
																		FROM PurchasePriceByLastPurchase ppprice3
																	UNION ALL
																	SELECT CONCAT(ppprice4.ITEMID ,ppprice4.SUBSIDIARYID)
																		FROM PurchasePriceStandard ppprice4))

						,PurchasePricebyCurrencyAll  AS
						(SELECT PurchasePriceDLXHC.*
								, (now()-1)::date FROMDATE
							FROM PurchasePriceDLXHC
						    UNION ALL
						SELECT PurchasePriceByPrimaryVendor.*
								, (now()-1)::date FROMDATE
							FROM PurchasePriceByPrimaryVendor
						    UNION ALL
						SELECT PurchaseLineByPrimaryVendor.*
								, (now()-1)::date FROMDATE
							FROM PurchaseLineByPrimaryVendor
						    UNION ALL
						SELECT
								PurchasePriceByPrimaryIntercompanyVendor.*
								, (now()-1)::date FROMDATE
								FROM PurchasePriceByPrimaryIntercompanyVendor
							UNION ALL
						SELECT PurchasePriceByLastPurchase.*
							 , (now()-1)::date FROMDATE
							FROM  PurchasePriceByLastPurchase
							UNION ALL
						SELECT PurchasePriceStandard.*
							 , (now()-1)::date FROMDATE
							FROM  PurchasePriceStandard
							UNION ALL
						SELECT PurchasePricePFI.*
							 , (now()-1)::date FROMDATE
							FROM  PurchasePricePFI
						)

						,PurchasePricebyCurrencyAllREPLACE  AS
						(SELECT ITEMID,
								COMPANYID,
								SUBSIDIARYID,
								SUPPLIERID,
								UNITPRICE,
								REPLACE(CURRENCYCODE,'RMB','CNY') CURRENCYCODE,
								UNITID,
								FROMDATE,
								FROMQUANTITY,
								TOQUANTITY,
								PURCHASETYPE, 
								MODIFIEDDATETIME
							FROM PurchasePricebyCurrencyAll)

						--SELECT * FROM PurchasePricebyCurrencyAllREPLACE

						SELECT SP.ITEMID,SP.COMPANYID ,SP.SUBSIDIARYID ,SP.SUPPLIERID,SP.UNITPRICE,
    					SP.CURRENCYCODE,SP.FROMDATE,SP.UNITID,SP.FROMQUANTITY,SP.TOQUANTITY,PURCHASETYPE
						,COMP.CURRENCYCODELOCAL  CURRENCYCODE_LOCAL
						,(SELECT MAX(EX.EXCHANGERATE) FROM fersadv.ExchangeRateDaily_ALL EX WHERE EX.FROMCURRENCYCODE = SP.CURRENCYCODE AND EX.TOCURRENCYCODE = 'EUR' AND EX.EXCHANGERATE >0 AND DATE(SP.FROMDATE) = DATE(EX.VALIDFROM) AND EX.ERPSOURCE='DEFAULT') EXCHANGERATE_EUR
						,(SELECT MAX(EX.EXCHANGERATE) FROM fersadv.ExchangeRateDaily_ALL EX WHERE EX.FROMCURRENCYCODE = SP.CURRENCYCODE AND EX.TOCURRENCYCODE = 'USD' AND EX.EXCHANGERATE >0 AND DATE(SP.FROMDATE) = DATE(EX.VALIDFROM) AND EX.ERPSOURCE='DEFAULT') EXCHANGERATE_USD
						,(SELECT MAX(EX.EXCHANGERATE) FROM fersadv.ExchangeRateDaily_ALL EX WHERE EX.FROMCURRENCYCODE = SP.CURRENCYCODE  AND EX.TOCURRENCYCODE = COMP.CURRENCYCODELOCAL AND EX.EXCHANGERATE >0 AND DATE(SP.FROMDATE) = DATE(EX.VALIDFROM) AND EX.ERPSOURCE='DEFAULT') EXCHANGERATE_LOCAL
						,ROW_NUMBER() OVER (PARTITION BY SP.ITEMID, SP.SUBSIDIARYID,SP.SUPPLIERID ORDER BY SP.FROMQUANTITY ASC) AS SCALEDROW
						, SP.MODIFIEDDATETIME
						FROM PurchasePricebyCurrencyAllREPLACE SP
						INNER JOIN fersaParams.CompanyLocation_standalone COMP ON COMP.LOCATIONID  = SP.SUBSIDIARYID
						WHERE SP.CURRENCYCODE<> 'CNY'
						
						UNION ALL

						SELECT SP.ITEMID,SP.COMPANYID ,SP.SUBSIDIARYID ,SP.SUPPLIERID,SP.UNITPRICE,
    					SP.CURRENCYCODE,SP.FROMDATE,SP.UNITID,SP.FROMQUANTITY,SP.TOQUANTITY,PURCHASETYPE
						,COMP.CURRENCYCODELOCAL CURRENCYCODE_LOCAL
						,ISNULL(EXCHANGERATE_EUR_ORG,0)EXCHANGERATE_EUR
						,ISNULL(EXCHANGERATE_USD_ORG,0) EXCHANGERATE_USD
						,1 EXCHANGERATE_LOCAL
						,ROW_NUMBER() OVER (PARTITION BY SP.ITEMID, SP.SUBSIDIARYID,SP.SUPPLIERID ORDER BY SP.FROMQUANTITY ASC) AS SCALEDROW
						, SP.MODIFIEDDATETIME
						FROM PurchasePricebyCurrencyAllREPLACE SP
						INNER JOIN
							(SELECT VV.EXCHANGERATE EXCHANGERATE_EUR_ORG,VALIDFROM,FROMCURRENCYCODE FROM
								(
									SELECT EX.ERPSOURCE,EX.EXCHANGERATE,EX.VALIDFROM,EX.FROMCURRENCYCODE, ROW_NUMBER() OVER (PARTITION BY EX.ERPSOURCE ,EX.FROMCURRENCYCODE, EX.TOCURRENCYCODE, MONTH(EX.VALIDFROM), YEAR(EX.VALIDFROM) ORDER BY EX.VALIDFROM ASC)
									FROM fersadv.ExchangeRateDaily_ALL EX
									WHERE EX.TOCURRENCYCODE ='EUR'
								)VV WHERE VV.ROW_NUMBER = 1 AND VV.FROMCURRENCYCODE = 'CNY'  AND VV.ERPSOURCE = 'AXCN'
							) EXCHANGERATE_EUR_ORG ON YEAR(EXCHANGERATE_EUR_ORG.VALIDFROM)=YEAR(SP.FROMDATE) AND MONTH(EXCHANGERATE_EUR_ORG.VALIDFROM)=MONTH(SP.FROMDATE) 
						INNER JOIN
						   (SELECT VV.EXCHANGERATE EXCHANGERATE_USD_ORG,VALIDFROM,FROMCURRENCYCODE FROM
								(
									SELECT EX.ERPSOURCE,EX.EXCHANGERATE,EX.VALIDFROM,EX.FROMCURRENCYCODE, ROW_NUMBER() OVER (PARTITION BY EX.ERPSOURCE ,EX.FROMCURRENCYCODE, EX.TOCURRENCYCODE, MONTH(EX.VALIDFROM), YEAR(EX.VALIDFROM) ORDER BY EX.VALIDFROM ASC)
									FROM fersadv.ExchangeRateDaily_ALL EX
									WHERE EX.TOCURRENCYCODE ='USD'
								)VV WHERE VV.ROW_NUMBER = 1 AND VV.FROMCURRENCYCODE = 'CNY' AND VV.ERPSOURCE = 'AXCN'
							) EXCHANGERATE_USD_ORG ON YEAR(EXCHANGERATE_USD_ORG.VALIDFROM)=YEAR(SP.FROMDATE) AND MONTH(EXCHANGERATE_USD_ORG.VALIDFROM)=MONTH(SP.FROMDATE) 
							INNER JOIN fersaParams.CompanyLocation_standalone COMP ON COMP.LOCATIONID  = SP.SUBSIDIARYID
							WHERE SP.CURRENCYCODE = 'CNY'
														     
						UNION ALL
						
						SELECT SP.ITEMID,SP.COMPANYID ,SP.SUBSIDIARYID ,SP.SUPPLIERID,SP.UNITPRICE,
    					SP.CURRENCYCODE,SP.FROMDATE,SP.UNITID,SP.FROMQUANTITY,SP.TOQUANTITY,PURCHASETYPE
						,null as CURRENCYCODE_LOCAL
						,NULL AS EXCHANGERATE_EUR
						,NULL AS EXCHANGERATE_USD
						,1 EXCHANGERATE_LOCAL
						,1 AS SCALEDROW
						, SP.MODIFIEDDATETIME
						FROM PurchasePricebyCurrencyAllREPLACE SP
						WHERE SP.CURRENCYCODE IS NULL
						/*SELECT * -- MAX(EX.EXCHANGERATE)
								FROM fersadv.ExchangeRateDaily_ALL EX
									WHERE
									EX.FROMCURRENCYCODE = 'CNY'
									AND
									EX.TOCURRENCYCODE = 'USD'
									AND
									EX.EXCHANGERATE >0
									ORDER BY VALIDFROM DESC
									--AND DATE((now()-1)::date) = DATE(EX.VALIDFROM) */
									--AND EX.ERPSOURCE='DEFAULT')

