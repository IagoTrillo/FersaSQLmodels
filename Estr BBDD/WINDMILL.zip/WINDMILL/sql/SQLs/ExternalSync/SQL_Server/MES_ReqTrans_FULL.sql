SELECT
    rta.SUBSIDIARYID, 
    rta.INVENTLOCATIONID,
    rta.ITEMID as ITEM_MOM,
    COALESCE(rta.INVENTSTYLEID, 'GEN') AS INVENTSTYLEID, 
    COALESCE(rta.INVENTSTATUSID, 'Available') AS INVENTSTATUSID,
    rta.ITEMID || '_' || COALESCE(rta.INVENTSTYLEID, 'GEN') || '_' || COALESCE(rta.INVENTSTATUSID, 'Available') AS ITEM_APS,
    rta.RECID, 
    rta.REFTYPENAME, 
    rta.REFID,
    CASE WHEN rta.QTY<0 THEN (
        CASE 
            WHEN rta.REFTYPE IN (8,10,16) THEN 'Firm Sales'
            WHEN rta.REFTYPE IN (14,21,35,43) THEN 'Sales Forecast'
            WHEN rta.REFTYPE = 1 THEN 'On Hand'
            ELSE NULL 
        END )
    ELSE (
        CASE 
            WHEN rta.REFTYPE IN (8,10,17) THEN 'Firm Purchase'
            WHEN rta.REFTYPE IN (33,41) THEN 'Purchase Forecast'
            WHEN rta.REFTYPE = 1 THEN 'On Hand'
            ELSE NULL 
        END )
    END as REQGROUP,
    rta.QTY, 
    rta.REQDATE, 
    rta.FUTURESDAYS, 
    rta.FUTURESDATE, 
    pia.DESCRIPTIONENGLISH AS CUSTOMER
FROM fersadv.ReqTrans_ALL rta
    LEFT JOIN fersadv.PackingInstruction_ALL pia ON rta.ITEMID = pia.ITEMID 
WHERE
    rta.SUBSIDIARYID='FBEA'
    AND rta.INVENTLOCATIONID='ZGZ'
    AND rta.REFTYPE NOT IN (9,13,46);