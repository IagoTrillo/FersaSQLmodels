--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_GoodsIssueLine_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_GoodsIssueLine_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_GoodsIssueLine_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_GoodsIssueLine_NKE (OrderBomId, RecId, ConsumptionUoMId, GoodsIssueId, SalesOrderLineId, Id, Name, SalesUoMId, Weight, LineId, ItemId, "Timestamp", Quantity
, DrawingNumber, BatchId, "Language", WarehouseId, Status, OrderBomLineId, SalesOrderId, NoStockFlag, DeliveryQuantity, NoDispoFlag, ConsumptionDimensions
, WarehouseBinId, UnitsRecorded, SalesDimensions, ActiveVariants, CustomerItemNumber, CostUnitId, NameInternal, SalesAgreementDetailId, BomFlag, LinePrintFlag
, ItemCustomerRelationId, ProjectId, DataSource, SalesAgreementDetailLineId, LineDispoFlag, Insdate, VSSerialNumber, Upduser, Packaging, Insuser, WorkOrderId
, ItemGroupId, TextLineFlag, BonusFlag, SubTotalFlag, WorkOrderLineId, OriginType, Upddate, AccountingAccountId, ClearingAccountId, ParcelFlag, CostGroupId
, NoOrderBomFlag, PostingDate, ToCheckFlag, NoStatisticsFlag, UserLine, NoPosFlag, NoAccountingFlag, SectionSumFlag, SalesConsignmentWarehouseBinId
, InstallationId, CommissionFlag, ChangedFlag, LineOrderPath, DeliveryRunPlanId, IsChangeFlag, NoPaymentDepositFlag, InventoryPhysicalFlag
, PackagingMaterialFlag, PackagingRule, CustomsGoodsFlag, DontPrintFlag, "Usage", SupplierCompanyAccountId, ForwarderCompanyAccountId, RentalItemFlag
, PackagingInstructions, IsFirstDeliveryFlag, NotInvoiceable, NKE_TransportModeId, LabelGross, PackagingNumberEnd, GoodsReceiptId, DirectDeliveryFlag
, AutomotiveNaelAiBMW, LabelFillQuantity, LabelNet, PackagingNumberStart, AddonText, GoodsReceiptLineId, LabelSignature, Ai, NKE_Process, Direction
, StatisticalValue, MasterLine, MainPMFlag, LabelAmountPackage, IndexText, ClientId, NKE_QSCode, ContainerNumber, RevisionIndexId, SalesCalculatedFlag
, VItemLine, ReferenceCustomerNumbers, CallOffNumber, DeliveryCallOffQuantity, MaterialTagType, PackagingTypeStdTxt, RentalDuration, RentalFrom,
 PackagingLevel, CallOffType, DeliveryCallOffUoM, OptionFromLine, CallOffDate, SamplesWarehouseBinId, RentalTo, MixedPackagingFlag, NoPostingFlag, 
 PurchaseOrderLineId, PackagingMaterialCompanyAccountId, PackagingUserLine, ANP_PurchaseOrderLineId, PMNotFullFlag, ECOMPurchaseOrderLIneId,
  PackagingLineOrderPath, PlannedTransportId, ANP_PurchaseOrderId, FinalSalesInvoiceLineId, ECOMPurchaseOrderId, NoIntrastatFlag, PurchaseOrderId,
   ANP_Width, ANP_Weight, DeliveryScheduleDate, ANP_PackagingNetValue, NetProforma, GoodsIssueLineNoInvoicing, GrossProforma, GUID, OperationId,
    RevenueProforma, ANP_Height, ANP_Length, CustomsTariffId, CostsTransportProforma, RecDateModified, ProvisionOrderPostingFlag, MaintenanceGroup,
     RecDateSync, RecActive, AttributeClassId, RecDateStart, RecDateReport, PackFlag, ANP_CustomerPurchaseOrderLine, RecUserCreated, RecDateCreated,
      EDLIgnoreFlag, RecDateEnd, VERPACKSTUELI, SrcRecLocationId, SrcRecTimestamp, RecUserModified, LAGERATTRIB, SrcRecId, SrcRecVersion, SalesPriceListId
      , RecCountModified)
SELECT OrderBomId, RecId, ConsumptionUoMId, GoodsIssueId, SalesOrderLineId, Id, Name, SalesUoMId, Weight, LineId, ItemId, "Timestamp", Quantity
, DrawingNumber, BatchId, "Language", WarehouseId, Status, OrderBomLineId, SalesOrderId, NoStockFlag, DeliveryQuantity, NoDispoFlag, ConsumptionDimensions
, WarehouseBinId, UnitsRecorded, SalesDimensions, ActiveVariants, CustomerItemNumber, CostUnitId, NameInternal, SalesAgreementDetailId, BomFlag, LinePrintFlag
, ItemCustomerRelationId, ProjectId, DataSource, SalesAgreementDetailLineId, LineDispoFlag, Insdate, VSSerialNumber, Upduser, Packaging, Insuser, WorkOrderId
, ItemGroupId, TextLineFlag, BonusFlag, SubTotalFlag, WorkOrderLineId, OriginType, Upddate, AccountingAccountId, ClearingAccountId, ParcelFlag, CostGroupId
, NoOrderBomFlag, PostingDate, ToCheckFlag, NoStatisticsFlag, UserLine, NoPosFlag, NoAccountingFlag, SectionSumFlag, SalesConsignmentWarehouseBinId
, InstallationId, CommissionFlag, ChangedFlag, LineOrderPath, DeliveryRunPlanId, IsChangeFlag, NoPaymentDepositFlag, InventoryPhysicalFlag
, PackagingMaterialFlag, PackagingRule, CustomsGoodsFlag, DontPrintFlag, "Usage", SupplierCompanyAccountId, ForwarderCompanyAccountId, RentalItemFlag
, PackagingInstructions, IsFirstDeliveryFlag, NotInvoiceable, NKE_TransportModeId, LabelGross, PackagingNumberEnd, GoodsReceiptId, DirectDeliveryFlag
, AutomotiveNaelAiBMW, LabelFillQuantity, LabelNet, PackagingNumberStart, AddonText, GoodsReceiptLineId, LabelSignature, Ai, NKE_Process, Direction
, StatisticalValue, MasterLine, MainPMFlag, LabelAmountPackage, IndexText, ClientId, NKE_QSCode, ContainerNumber, RevisionIndexId, SalesCalculatedFlag
, VItemLine, ReferenceCustomerNumbers, CallOffNumber, DeliveryCallOffQuantity, MaterialTagType, PackagingTypeStdTxt, RentalDuration, RentalFrom,
 PackagingLevel, CallOffType, DeliveryCallOffUoM, OptionFromLine, CallOffDate, SamplesWarehouseBinId, RentalTo, MixedPackagingFlag, NoPostingFlag, 
 PurchaseOrderLineId, PackagingMaterialCompanyAccountId, PackagingUserLine, ANP_PurchaseOrderLineId, PMNotFullFlag, ECOMPurchaseOrderLIneId,
  PackagingLineOrderPath, PlannedTransportId, ANP_PurchaseOrderId, FinalSalesInvoiceLineId::int, ECOMPurchaseOrderId, NoIntrastatFlag, PurchaseOrderId,
   ANP_Width, ANP_Weight, DeliveryScheduleDate, ANP_PackagingNetValue, NetProforma, GoodsIssueLineNoInvoicing, GrossProforma, GUID, OperationId,
    RevenueProforma, ANP_Height, ANP_Length, CustomsTariffId, CostsTransportProforma, RecDateModified, ProvisionOrderPostingFlag, MaintenanceGroup,
     RecDateSync, RecActive, AttributeClassId, RecDateStart, RecDateReport, PackFlag, ANP_CustomerPurchaseOrderLine, RecUserCreated, RecDateCreated,
      EDLIgnoreFlag, RecDateEnd, VERPACKSTUELI, SrcRecLocationId, SrcRecTimestamp, RecUserModified, LAGERATTRIB, SrcRecId, SrcRecVersion, SalesPriceListId
      , RecCountModified
FROM	nkeTempIncremental.ds_GoodsIssueLine_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_GoodsIssueLine_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_GoodsIssueLine_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_GoodsIssueLine_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_GoodsIssueLine_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_GoodsIssueLine_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_GoodsIssueLine_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_GoodsIssueLine_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_GoodsIssueLine_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_GoodsIssueLine_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_GoodsIssueLine_NKE(OrderBomId, RecId, ConsumptionUoMId, GoodsIssueId, SalesOrderLineId, Id, Name, SalesUoMId, Weight, LineId, ItemId, "Timestamp", Quantity
, DrawingNumber, BatchId, "Language", WarehouseId, Status, OrderBomLineId, SalesOrderId, NoStockFlag, DeliveryQuantity, NoDispoFlag, ConsumptionDimensions
, WarehouseBinId, UnitsRecorded, SalesDimensions, ActiveVariants, CustomerItemNumber, CostUnitId, NameInternal, SalesAgreementDetailId, BomFlag, LinePrintFlag
, ItemCustomerRelationId, ProjectId, DataSource, SalesAgreementDetailLineId, LineDispoFlag, Insdate, VSSerialNumber, Upduser, Packaging, Insuser, WorkOrderId
, ItemGroupId, TextLineFlag, BonusFlag, SubTotalFlag, WorkOrderLineId, OriginType, Upddate, AccountingAccountId, ClearingAccountId, ParcelFlag, CostGroupId
, NoOrderBomFlag, PostingDate, ToCheckFlag, NoStatisticsFlag, UserLine, NoPosFlag, NoAccountingFlag, SectionSumFlag, SalesConsignmentWarehouseBinId
, InstallationId, CommissionFlag, ChangedFlag, LineOrderPath, DeliveryRunPlanId, IsChangeFlag, NoPaymentDepositFlag, InventoryPhysicalFlag
, PackagingMaterialFlag, PackagingRule, CustomsGoodsFlag, DontPrintFlag, "Usage", SupplierCompanyAccountId, ForwarderCompanyAccountId, RentalItemFlag
, PackagingInstructions, IsFirstDeliveryFlag, NotInvoiceable, NKE_TransportModeId, LabelGross, PackagingNumberEnd, GoodsReceiptId, DirectDeliveryFlag
, AutomotiveNaelAiBMW, LabelFillQuantity, LabelNet, PackagingNumberStart, AddonText, GoodsReceiptLineId, LabelSignature, Ai, NKE_Process, Direction
, StatisticalValue, MasterLine, MainPMFlag, LabelAmountPackage, IndexText, ClientId, NKE_QSCode, ContainerNumber, RevisionIndexId, SalesCalculatedFlag
, VItemLine, ReferenceCustomerNumbers, CallOffNumber, DeliveryCallOffQuantity, MaterialTagType, PackagingTypeStdTxt, RentalDuration, RentalFrom,
 PackagingLevel, CallOffType, DeliveryCallOffUoM, OptionFromLine, CallOffDate, SamplesWarehouseBinId, RentalTo, MixedPackagingFlag, NoPostingFlag, 
 PurchaseOrderLineId, PackagingMaterialCompanyAccountId, PackagingUserLine, ANP_PurchaseOrderLineId, PMNotFullFlag, ECOMPurchaseOrderLIneId,
  PackagingLineOrderPath, PlannedTransportId, ANP_PurchaseOrderId, FinalSalesInvoiceLineId, ECOMPurchaseOrderId, NoIntrastatFlag, PurchaseOrderId,
   ANP_Width, ANP_Weight, DeliveryScheduleDate, ANP_PackagingNetValue, NetProforma, GoodsIssueLineNoInvoicing, GrossProforma, GUID, OperationId,
    RevenueProforma, ANP_Height, ANP_Length, CustomsTariffId, CostsTransportProforma, RecDateModified, ProvisionOrderPostingFlag, MaintenanceGroup,
     RecDateSync, RecActive, AttributeClassId, RecDateStart, RecDateReport, PackFlag, ANP_CustomerPurchaseOrderLine, RecUserCreated, RecDateCreated,
      EDLIgnoreFlag, RecDateEnd, VERPACKSTUELI, SrcRecLocationId, SrcRecTimestamp, RecUserModified, LAGERATTRIB, SrcRecId, SrcRecVersion, SalesPriceListId
      , RecCountModified)
SELECT OrderBomId, RecId, ConsumptionUoMId, GoodsIssueId, SalesOrderLineId, Id, Name, SalesUoMId, Weight, LineId, ItemId, "Timestamp", Quantity
, DrawingNumber, BatchId, "Language", WarehouseId, Status, OrderBomLineId, SalesOrderId, NoStockFlag, DeliveryQuantity, NoDispoFlag, ConsumptionDimensions
, WarehouseBinId, UnitsRecorded, SalesDimensions, ActiveVariants, CustomerItemNumber, CostUnitId, NameInternal, SalesAgreementDetailId, BomFlag, LinePrintFlag
, ItemCustomerRelationId, ProjectId, DataSource, SalesAgreementDetailLineId, LineDispoFlag, Insdate, VSSerialNumber, Upduser, Packaging, Insuser, WorkOrderId
, ItemGroupId, TextLineFlag, BonusFlag, SubTotalFlag, WorkOrderLineId, OriginType, Upddate, AccountingAccountId, ClearingAccountId, ParcelFlag, CostGroupId
, NoOrderBomFlag, PostingDate, ToCheckFlag, NoStatisticsFlag, UserLine, NoPosFlag, NoAccountingFlag, SectionSumFlag, SalesConsignmentWarehouseBinId
, InstallationId, CommissionFlag, ChangedFlag, LineOrderPath, DeliveryRunPlanId, IsChangeFlag, NoPaymentDepositFlag, InventoryPhysicalFlag
, PackagingMaterialFlag, PackagingRule, CustomsGoodsFlag, DontPrintFlag, "Usage", SupplierCompanyAccountId, ForwarderCompanyAccountId, RentalItemFlag
, PackagingInstructions, IsFirstDeliveryFlag, NotInvoiceable, NKE_TransportModeId, LabelGross, PackagingNumberEnd, GoodsReceiptId, DirectDeliveryFlag
, AutomotiveNaelAiBMW, LabelFillQuantity, LabelNet, PackagingNumberStart, AddonText, GoodsReceiptLineId, LabelSignature, Ai, NKE_Process, Direction
, StatisticalValue, MasterLine, MainPMFlag, LabelAmountPackage, IndexText, ClientId, NKE_QSCode, ContainerNumber, RevisionIndexId, SalesCalculatedFlag
, VItemLine, ReferenceCustomerNumbers, CallOffNumber, DeliveryCallOffQuantity, MaterialTagType, PackagingTypeStdTxt, RentalDuration, RentalFrom,
 PackagingLevel, CallOffType, DeliveryCallOffUoM, OptionFromLine, CallOffDate, SamplesWarehouseBinId, RentalTo, MixedPackagingFlag, NoPostingFlag, 
 PurchaseOrderLineId, PackagingMaterialCompanyAccountId, PackagingUserLine, ANP_PurchaseOrderLineId, PMNotFullFlag, ECOMPurchaseOrderLIneId,
  PackagingLineOrderPath, PlannedTransportId, ANP_PurchaseOrderId, FinalSalesInvoiceLineId::int, ECOMPurchaseOrderId, NoIntrastatFlag, PurchaseOrderId,
   ANP_Width, ANP_Weight, DeliveryScheduleDate, ANP_PackagingNetValue, NetProforma, GoodsIssueLineNoInvoicing, GrossProforma, GUID, OperationId,
    RevenueProforma, ANP_Height, ANP_Length, CustomsTariffId, CostsTransportProforma, RecDateModified, ProvisionOrderPostingFlag, MaintenanceGroup,
     RecDateSync, RecActive, AttributeClassId, RecDateStart, RecDateReport, PackFlag, ANP_CustomerPurchaseOrderLine, RecUserCreated, RecDateCreated,
      EDLIgnoreFlag, RecDateEnd, VERPACKSTUELI, SrcRecLocationId, SrcRecTimestamp, RecUserModified, LAGERATTRIB, SrcRecId, SrcRecVersion, SalesPriceListId
      , RecCountModified
FROM nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_GoodsIssueLine_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);


--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_GoodsIssueLine_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_GoodsIssueLine_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_GoodsIssueLine_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_GoodsIssueLine_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_GoodsIssueLine_NKE');
*/