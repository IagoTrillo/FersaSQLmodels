--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_GoodsReceipt_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_GoodsReceipt_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_GoodsReceipt_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_GoodsReceipt_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_GoodsReceipt_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_GoodsReceipt_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_GoodsReceipt_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_GoodsReceipt_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_GoodsReceipt_NKE (RecId, Status, Id, GoodsReceiptId, DeliveryNote, CompanyAccountId, OrderType, CostUnitId, "Date", StaffId, "Timestamp", DeliveryNoteDate
, Notes, DirectDeliveryFlag, Insuser, ProjectId, SeaPort, PostingDate, Upduser, IntrastatStatisticalMode, DeliveryCompanyAccountId, Upddate
, CompanyId, IntrastatTransportMode, Insdate, IntrastatBusinessMode, TaxText, VDAShippingMode, NKE_ReservedFlag, NKE_PurchaseSupplierInvoiceId
, FactoryDirectCustomer, EDIDDId, TransportIn, CustomerWarehouse, ReferenceCustomerLAB, IsGAProcedureFlag, NKE_Upddate, ClientId
, NKE_InTransactionFlag, DeliveryUnloadingPoint, MaterialConsumptionLocation, DocDeliveryCompanyAccountName1, GoodsIssueId, NoIntrastatFlag
, NKE_GoodsReceivingScheduleFixedFlag, IntrastatCustomsCountry, WorkflowId, OriginLocationId, DocDeliveryCompanyAccountName2
, FulfillerLocationId, IntrastatCustomsGoodsClearanceFlag, ANP_ECOMUseIn, ECOMUseIn, WFProcName, BPIgnoreFlag, GUID, DocDeliveryFax
, DocDeliveryCompanyAccountName3, DocDeliveryName, DocDeliveryPostCode, DocDeliveryCity, DocDeliveryCompanyAccountManuallyFlag, AttributeClassId
, DocDeliveryCountryCode, DocDeliveryDepartment, DocDeliveryStreet, DocDeliveryPostCode2, DocDeliveryPhone, DocDeliveryVATNumber, RecDateStart, ANP_Weight
, GoodsIssueDirectDelivery, ANP_CarrierCompanyAccountId, TermsPurchaseDeliveryStdTxt, ANP_ReceivedBy, "Language", EDLReportIn, ANP_Volume,
 ANP_TransportModeId, ANP_ReceivingDate, ANP_CollosCount, ANP_ShippingNumber, RecActive, SrcRecLocationId, RecDateSync, RecDateModified, RecUserModified,
  RecDateEnd, RecCountModified, RecDateReport, SrcRecTimestamp, SrcRecId, RecDateCreated, RecUserCreated, SrcRecVersion)
SELECT RecId, Status, Id, GoodsReceiptId, DeliveryNote, CompanyAccountId, OrderType, CostUnitId, "Date", StaffId, "Timestamp", DeliveryNoteDate
, Notes, DirectDeliveryFlag, Insuser, ProjectId, SeaPort, PostingDate, Upduser, IntrastatStatisticalMode, DeliveryCompanyAccountId, Upddate
, CompanyId, IntrastatTransportMode, Insdate, IntrastatBusinessMode, TaxText, VDAShippingMode, NKE_ReservedFlag, NKE_PurchaseSupplierInvoiceId
, FactoryDirectCustomer, EDIDDId, TransportIn, CustomerWarehouse, ReferenceCustomerLAB, IsGAProcedureFlag, NKE_Upddate, ClientId
, NKE_InTransactionFlag, DeliveryUnloadingPoint, MaterialConsumptionLocation, DocDeliveryCompanyAccountName1, GoodsIssueId, NoIntrastatFlag
, NKE_GoodsReceivingScheduleFixedFlag, IntrastatCustomsCountry, WorkflowId, OriginLocationId, DocDeliveryCompanyAccountName2
, FulfillerLocationId, IntrastatCustomsGoodsClearanceFlag, ANP_ECOMUseIn, ECOMUseIn, WFProcName, BPIgnoreFlag, GUID, DocDeliveryFax
, DocDeliveryCompanyAccountName3, DocDeliveryName, DocDeliveryPostCode, DocDeliveryCity, DocDeliveryCompanyAccountManuallyFlag, AttributeClassId
, DocDeliveryCountryCode, DocDeliveryDepartment, DocDeliveryStreet, DocDeliveryPostCode2, DocDeliveryPhone, DocDeliveryVATNumber, RecDateStart, ANP_Weight
, GoodsIssueDirectDelivery, ANP_CarrierCompanyAccountId, TermsPurchaseDeliveryStdTxt, ANP_ReceivedBy, "Language", EDLReportIn, ANP_Volume,
 ANP_TransportModeId, ANP_ReceivingDate, ANP_CollosCount, ANP_ShippingNumber, RecActive, SrcRecLocationId, RecDateSync, RecDateModified, RecUserModified,
  RecDateEnd, RecCountModified, RecDateReport, SrcRecTimestamp, SrcRecId, RecDateCreated, RecUserCreated, SrcRecVersion
FROM	nkeTempIncremental.ds_GoodsReceipt_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_GoodsReceipt_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_GoodsReceipt_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_GoodsReceipt_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_GoodsReceipt_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_GoodsReceipt_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_GoodsReceipt_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_GoodsReceipt_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_GoodsReceipt_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_GoodsReceipt_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_GoodsReceipt_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_GoodsReceipt_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_GoodsReceipt_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_GoodsReceipt_NKE(RecId, Status, Id, GoodsReceiptId, DeliveryNote, CompanyAccountId, OrderType, CostUnitId, "Date", StaffId, "Timestamp", DeliveryNoteDate
, Notes, DirectDeliveryFlag, Insuser, ProjectId, SeaPort, PostingDate, Upduser, IntrastatStatisticalMode, DeliveryCompanyAccountId, Upddate
, CompanyId, IntrastatTransportMode, Insdate, IntrastatBusinessMode, TaxText, VDAShippingMode, NKE_ReservedFlag, NKE_PurchaseSupplierInvoiceId
, FactoryDirectCustomer, EDIDDId, TransportIn, CustomerWarehouse, ReferenceCustomerLAB, IsGAProcedureFlag, NKE_Upddate, ClientId
, NKE_InTransactionFlag, DeliveryUnloadingPoint, MaterialConsumptionLocation, DocDeliveryCompanyAccountName1, GoodsIssueId, NoIntrastatFlag
, NKE_GoodsReceivingScheduleFixedFlag, IntrastatCustomsCountry, WorkflowId, OriginLocationId, DocDeliveryCompanyAccountName2
, FulfillerLocationId, IntrastatCustomsGoodsClearanceFlag, ANP_ECOMUseIn, ECOMUseIn, WFProcName, BPIgnoreFlag, GUID, DocDeliveryFax
, DocDeliveryCompanyAccountName3, DocDeliveryName, DocDeliveryPostCode, DocDeliveryCity, DocDeliveryCompanyAccountManuallyFlag, AttributeClassId
, DocDeliveryCountryCode, DocDeliveryDepartment, DocDeliveryStreet, DocDeliveryPostCode2, DocDeliveryPhone, DocDeliveryVATNumber, RecDateStart, ANP_Weight
, GoodsIssueDirectDelivery, ANP_CarrierCompanyAccountId, TermsPurchaseDeliveryStdTxt, ANP_ReceivedBy, "Language", EDLReportIn, ANP_Volume,
 ANP_TransportModeId, ANP_ReceivingDate, ANP_CollosCount, ANP_ShippingNumber, RecActive, SrcRecLocationId, RecDateSync, RecDateModified, RecUserModified,
  RecDateEnd, RecCountModified, RecDateReport, SrcRecTimestamp, SrcRecId, RecDateCreated, RecUserCreated, SrcRecVersion)
SELECT RecId, Status, Id, GoodsReceiptId, DeliveryNote, CompanyAccountId, OrderType, CostUnitId, "Date", StaffId, "Timestamp", DeliveryNoteDate
, Notes, DirectDeliveryFlag, Insuser, ProjectId, SeaPort, PostingDate, Upduser, IntrastatStatisticalMode, DeliveryCompanyAccountId, Upddate
, CompanyId, IntrastatTransportMode, Insdate, IntrastatBusinessMode, TaxText, VDAShippingMode, NKE_ReservedFlag, NKE_PurchaseSupplierInvoiceId
, FactoryDirectCustomer, EDIDDId, TransportIn, CustomerWarehouse, ReferenceCustomerLAB, IsGAProcedureFlag, NKE_Upddate, ClientId
, NKE_InTransactionFlag, DeliveryUnloadingPoint, MaterialConsumptionLocation, DocDeliveryCompanyAccountName1, GoodsIssueId, NoIntrastatFlag
, NKE_GoodsReceivingScheduleFixedFlag, IntrastatCustomsCountry, WorkflowId, OriginLocationId, DocDeliveryCompanyAccountName2
, FulfillerLocationId, IntrastatCustomsGoodsClearanceFlag, ANP_ECOMUseIn, ECOMUseIn, WFProcName, BPIgnoreFlag, GUID, DocDeliveryFax
, DocDeliveryCompanyAccountName3, DocDeliveryName, DocDeliveryPostCode, DocDeliveryCity, DocDeliveryCompanyAccountManuallyFlag, AttributeClassId
, DocDeliveryCountryCode, DocDeliveryDepartment, DocDeliveryStreet, DocDeliveryPostCode2, DocDeliveryPhone, DocDeliveryVATNumber, RecDateStart, ANP_Weight
, GoodsIssueDirectDelivery, ANP_CarrierCompanyAccountId, TermsPurchaseDeliveryStdTxt, ANP_ReceivedBy, "Language", EDLReportIn, ANP_Volume,
 ANP_TransportModeId, ANP_ReceivingDate, ANP_CollosCount, ANP_ShippingNumber, RecActive, SrcRecLocationId, RecDateSync, RecDateModified, RecUserModified,
  RecDateEnd, RecCountModified, RecDateReport, SrcRecTimestamp, SrcRecId, RecDateCreated, RecUserCreated, SrcRecVersion
FROM nkeTempIncremental.ds_GoodsReceipt_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_GoodsReceipt_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);


--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_GoodsReceipt_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_GoodsReceipt_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_GoodsReceipt_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_GoodsReceipt_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_GoodsReceipt_NKE');
*/