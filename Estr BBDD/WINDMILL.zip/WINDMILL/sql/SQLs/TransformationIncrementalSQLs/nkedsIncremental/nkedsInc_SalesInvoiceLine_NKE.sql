--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_SalesInvoiceLine_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_SalesInvoiceLine_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_SalesInvoiceLine_NKE (Quantity, RecId, Id, SalesInvoiceId, ItemId, RebateGroupId, RebatePrice, LineId, Net, "Timestamp", Name, Rebate, Price
, RevenueAccount, RebatePrice2, RevenuePerUnit, Tax, AccountingAccountId, ItemGroupId, "Language", SalesUoMId, Revenue, SalesOrderLineId
, OriginTaxPrice, Rebate2, SalesOrderId, WTaxCode, CostCenterId, DeliveryNote, ItemCustomerRelationId, QuantityRebate, NameInternal
, "Date", SalesAgreementDetailLineId, NoRebateFlag, DeliveryDate, CustomerItemNumber, QuantityRebatePrice, DataSource, CommissionFlag
, ContributionMargin, SalesAgreementDetailId, BomFlag, ActiveVariants, Percent, LineDispoFlag, BasePrice, PackagingQuantity, RepresentativeId
, NewAstlFlag, PriceUoMId, Commission, LinePrintFlag, CostUnitId, WithdrawedFlag, ProjectId, SalesDimensions, TargetAccountId, Commission2
, GrossPriceList, MaterialSurchargeSum, MaterialSurchargeMode, PriceGroupId, BatchId, Percent2, RepresentativeI2Id, BonusFlag, PDate
, ItemCustomerBOMFlag, MarginPercent, ToCheckFlag, ParcelFlag, Margin, TextLineFlag, GoodsIssueLineId, "Type", InventoryPrice, Status
, MarginPerUnit, ChangedFlag, RevenueManuallyFlag, SubTotalFlag, ProductionNumber, DepositPercent, InvoiceDate, GSStartFlag, SalesPriceListId
, EndDate, GoodsIssueId, DisplayNULLFlag, ProductionCosts, NetExternal, LastInvoiceDate, GSEndFlag, Insuser, CreditNoteStart, DisplayFlag
, LinesEnd, Insdate, Upddate, UserLine, DontPrintPriceFlag, NoStatisticsFlag, NoPosFlag, LinesStart, NoStatusCheckFlag, Upduser, LineOrderPath
, SetNumber, NoAccountingFlag, DontPrintFlag, MaintenanceTo, RevenueOrign, SectionSumFlag, OriginInvoiceId, RentalItemFlag, WarrantyFlag
, EffectiveServiceDate, OriginQuantity, NetOrigin, MaintenanceFrom, OriginInvoiceLineId, FinalSalesInvoiceId, InstallationId, CostGroupId
, DeliveryUnloadingPoint, EDIPartner, FinalSalesInvoiceLineId, VDAPriceUnit, SalesReturnLineId, ReferenceCustomer, ShippingLineFlag
, FactoryDirectCustomer, VDAShippingMode, DeliveryRunPlanId, PackagingLineFlag, HasModifiedOrder, Finalized, SalesReturnId, CauserId
, CauserSubLine, CreditNoteValueRefundFlag, NoPaymentDepositFlag, CostsFreight, PaymentFlag, DirectDeliveryFlag, InventoryPhysicalFlag
, CauserLineId, AccountingId, SupplierCompanyAccountId, CreditNoteAdvice, PaymentDate, DeliveryCostsFlag, GALine, ClientId, RentalTo
, SalesConsignmentWarehouseBinId, GaebLineType2, OptionFromLine, ProvisionMode, GASubLine, RentalFrom, RentalDuration, SamplesWarehouseBinId
, CostsContributionMargin, EDLWithdrawalMessageIn, GaebLineType, BonusAgreementId, BonusSalesInvoiceLineId, BasisValue, ConditionRanking2
, DepositAccountingInvoice, CommissionManuallyFlag, CreditNoteAdviceNumber, BonusSalesInvoiceId, BonusAccrual, BasisValue2, CreditedFlag
, DepositAccountingInvoiceDeadline, ConditionRanking, Commission2ManuallyFlag, FinalCalculated, ANP_PurchaseOrderLineId, PurchaseOrderLineId
, DisplayText, VOBTaxPrice, LocationId, GUID, ANP_PurchaseOrderId, PurchaseOrderId, EDIPartnerNumber, VOBPrice, CustomsOrFeesFlag, VOBRevenue
, CustomerReferenceNumber, MarginVOB, VOBQuantity, VOBPreInvoice, DiscountTax, CustomsTariffId, NetDiscount, NKE_CostsK01, VOBInvoicedQuantity
, VOBLine, VOBPreLine, PriceCode, OriginBasePrice, GrossDiscount, Commission3, Representative3Id, Percent3, RecActive, PriceCompanyId, RecDateStart
, PriceExternal, MaintenanceGroup, Commission3ManuallyFlag, ConditionRanking3, BasisValue3, RecDateReport, AttributeClassId, RecDateEnd
, ANP_CustomerPurchaseOrderLine, RecUserModified, RecDateSync, RecDateModified, ApprovedType, SrcRecLocationId, ANP_ADLCode, SrcRecTimestamp
, RecUserCreated, SrcRecId, NetRequest, RecDateCreated, RecCountModified, ErrorClass, SettlementCode, SrcRecVersion, VERPACKSTUELI, CotsType
, RecSyncId, LAGERATTRIB)
SELECT Quantity, RecId, Id, SalesInvoiceId, ItemId, RebateGroupId, RebatePrice, LineId, Net, "Timestamp", Name, Rebate, Price
, RevenueAccount, RebatePrice2, RevenuePerUnit, Tax, AccountingAccountId, ItemGroupId, "Language", SalesUoMId, Revenue, SalesOrderLineId
, OriginTaxPrice, Rebate2, SalesOrderId, WTaxCode, CostCenterId, DeliveryNote, ItemCustomerRelationId, QuantityRebate, NameInternal
, "Date", SalesAgreementDetailLineId, NoRebateFlag, DeliveryDate, CustomerItemNumber, QuantityRebatePrice, DataSource, CommissionFlag
, ContributionMargin, SalesAgreementDetailId, BomFlag, ActiveVariants, Percent, LineDispoFlag, BasePrice, PackagingQuantity, RepresentativeId
, NewAstlFlag, PriceUoMId, Commission, LinePrintFlag, CostUnitId, WithdrawedFlag, ProjectId, SalesDimensions, TargetAccountId, Commission2
, GrossPriceList, MaterialSurchargeSum, MaterialSurchargeMode, PriceGroupId, BatchId, Percent2, RepresentativeI2Id, BonusFlag, PDate
, ItemCustomerBOMFlag, MarginPercent, ToCheckFlag, ParcelFlag, Margin, TextLineFlag, GoodsIssueLineId, "Type", InventoryPrice, Status
, MarginPerUnit, ChangedFlag, RevenueManuallyFlag, SubTotalFlag, ProductionNumber, DepositPercent, InvoiceDate, GSStartFlag, SalesPriceListId
, EndDate, GoodsIssueId, DisplayNULLFlag, ProductionCosts, NetExternal, LastInvoiceDate, GSEndFlag, Insuser, CreditNoteStart, DisplayFlag
, LinesEnd, Insdate, Upddate, UserLine, DontPrintPriceFlag, NoStatisticsFlag, NoPosFlag, LinesStart, NoStatusCheckFlag, Upduser, LineOrderPath
, SetNumber, NoAccountingFlag, DontPrintFlag, MaintenanceTo, RevenueOrign, SectionSumFlag, OriginInvoiceId, RentalItemFlag, WarrantyFlag
, EffectiveServiceDate, OriginQuantity, NetOrigin, MaintenanceFrom, OriginInvoiceLineId, FinalSalesInvoiceId, InstallationId, CostGroupId
, DeliveryUnloadingPoint, EDIPartner, FinalSalesInvoiceLineId, VDAPriceUnit, SalesReturnLineId, ReferenceCustomer, ShippingLineFlag
, FactoryDirectCustomer, VDAShippingMode, DeliveryRunPlanId, PackagingLineFlag, HasModifiedOrder, Finalized, SalesReturnId, CauserId
, CauserSubLine, CreditNoteValueRefundFlag, NoPaymentDepositFlag, CostsFreight, PaymentFlag, DirectDeliveryFlag, InventoryPhysicalFlag
, CauserLineId, AccountingId, SupplierCompanyAccountId, CreditNoteAdvice, PaymentDate, DeliveryCostsFlag, GALine, ClientId, RentalTo
, SalesConsignmentWarehouseBinId, GaebLineType2, OptionFromLine, ProvisionMode, GASubLine, RentalFrom, RentalDuration, SamplesWarehouseBinId
, CostsContributionMargin, EDLWithdrawalMessageIn, GaebLineType, BonusAgreementId, BonusSalesInvoiceLineId, BasisValue, ConditionRanking2
, DepositAccountingInvoice, CommissionManuallyFlag, CreditNoteAdviceNumber, BonusSalesInvoiceId, BonusAccrual, BasisValue2, CreditedFlag
, DepositAccountingInvoiceDeadline, ConditionRanking, Commission2ManuallyFlag, FinalCalculated, ANP_PurchaseOrderLineId, PurchaseOrderLineId
, DisplayText, VOBTaxPrice, LocationId, GUID, ANP_PurchaseOrderId, PurchaseOrderId, EDIPartnerNumber, VOBPrice, CustomsOrFeesFlag, VOBRevenue
, CustomerReferenceNumber, MarginVOB, VOBQuantity, VOBPreInvoice, DiscountTax, CustomsTariffId, NetDiscount, NKE_CostsK01, VOBInvoicedQuantity
, VOBLine, VOBPreLine, PriceCode, OriginBasePrice, GrossDiscount, Commission3, Representative3Id, Percent3, RecActive, PriceCompanyId, RecDateStart
, PriceExternal, MaintenanceGroup, Commission3ManuallyFlag, ConditionRanking3, BasisValue3, RecDateReport, AttributeClassId, RecDateEnd
, ANP_CustomerPurchaseOrderLine, RecUserModified, RecDateSync, RecDateModified, ApprovedType, SrcRecLocationId, ANP_ADLCode, SrcRecTimestamp
, RecUserCreated, SrcRecId, NetRequest, RecDateCreated, RecCountModified, ErrorClass, SettlementCode, SrcRecVersion, VERPACKSTUELI, CotsType
, RecSyncId, LAGERATTRIB
FROM	nkeTempIncremental.ds_SalesInvoiceLine_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_SalesInvoiceLine_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_SalesInvoiceLine_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_SalesInvoiceLine_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_SalesInvoiceLine_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesInvoiceLine_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_SalesInvoiceLine_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_SalesInvoiceLine_NKE(Quantity, RecId, Id, SalesInvoiceId, ItemId, RebateGroupId, RebatePrice, LineId, Net, "Timestamp", Name, Rebate, Price
, RevenueAccount, RebatePrice2, RevenuePerUnit, Tax, AccountingAccountId, ItemGroupId, "Language", SalesUoMId, Revenue, SalesOrderLineId
, OriginTaxPrice, Rebate2, SalesOrderId, WTaxCode, CostCenterId, DeliveryNote, ItemCustomerRelationId, QuantityRebate, NameInternal
, "Date", SalesAgreementDetailLineId, NoRebateFlag, DeliveryDate, CustomerItemNumber, QuantityRebatePrice, DataSource, CommissionFlag
, ContributionMargin, SalesAgreementDetailId, BomFlag, ActiveVariants, Percent, LineDispoFlag, BasePrice, PackagingQuantity, RepresentativeId
, NewAstlFlag, PriceUoMId, Commission, LinePrintFlag, CostUnitId, WithdrawedFlag, ProjectId, SalesDimensions, TargetAccountId, Commission2
, GrossPriceList, MaterialSurchargeSum, MaterialSurchargeMode, PriceGroupId, BatchId, Percent2, RepresentativeI2Id, BonusFlag, PDate
, ItemCustomerBOMFlag, MarginPercent, ToCheckFlag, ParcelFlag, Margin, TextLineFlag, GoodsIssueLineId, "Type", InventoryPrice, Status
, MarginPerUnit, ChangedFlag, RevenueManuallyFlag, SubTotalFlag, ProductionNumber, DepositPercent, InvoiceDate, GSStartFlag, SalesPriceListId
, EndDate, GoodsIssueId, DisplayNULLFlag, ProductionCosts, NetExternal, LastInvoiceDate, GSEndFlag, Insuser, CreditNoteStart, DisplayFlag
, LinesEnd, Insdate, Upddate, UserLine, DontPrintPriceFlag, NoStatisticsFlag, NoPosFlag, LinesStart, NoStatusCheckFlag, Upduser, LineOrderPath
, SetNumber, NoAccountingFlag, DontPrintFlag, MaintenanceTo, RevenueOrign, SectionSumFlag, OriginInvoiceId, RentalItemFlag, WarrantyFlag
, EffectiveServiceDate, OriginQuantity, NetOrigin, MaintenanceFrom, OriginInvoiceLineId, FinalSalesInvoiceId, InstallationId, CostGroupId
, DeliveryUnloadingPoint, EDIPartner, FinalSalesInvoiceLineId, VDAPriceUnit, SalesReturnLineId, ReferenceCustomer, ShippingLineFlag
, FactoryDirectCustomer, VDAShippingMode, DeliveryRunPlanId, PackagingLineFlag, HasModifiedOrder, Finalized, SalesReturnId, CauserId
, CauserSubLine, CreditNoteValueRefundFlag, NoPaymentDepositFlag, CostsFreight, PaymentFlag, DirectDeliveryFlag, InventoryPhysicalFlag
, CauserLineId, AccountingId, SupplierCompanyAccountId, CreditNoteAdvice, PaymentDate, DeliveryCostsFlag, GALine, ClientId, RentalTo
, SalesConsignmentWarehouseBinId, GaebLineType2, OptionFromLine, ProvisionMode, GASubLine, RentalFrom, RentalDuration, SamplesWarehouseBinId
, CostsContributionMargin, EDLWithdrawalMessageIn, GaebLineType, BonusAgreementId, BonusSalesInvoiceLineId, BasisValue, ConditionRanking2
, DepositAccountingInvoice, CommissionManuallyFlag, CreditNoteAdviceNumber, BonusSalesInvoiceId, BonusAccrual, BasisValue2, CreditedFlag
, DepositAccountingInvoiceDeadline, ConditionRanking, Commission2ManuallyFlag, FinalCalculated, ANP_PurchaseOrderLineId, PurchaseOrderLineId
, DisplayText, VOBTaxPrice, LocationId, GUID, ANP_PurchaseOrderId, PurchaseOrderId, EDIPartnerNumber, VOBPrice, CustomsOrFeesFlag, VOBRevenue
, CustomerReferenceNumber, MarginVOB, VOBQuantity, VOBPreInvoice, DiscountTax, CustomsTariffId, NetDiscount, NKE_CostsK01, VOBInvoicedQuantity
, VOBLine, VOBPreLine, PriceCode, OriginBasePrice, GrossDiscount, Commission3, Representative3Id, Percent3, RecActive, PriceCompanyId, RecDateStart
, PriceExternal, MaintenanceGroup, Commission3ManuallyFlag, ConditionRanking3, BasisValue3, RecDateReport, AttributeClassId, RecDateEnd
, ANP_CustomerPurchaseOrderLine, RecUserModified, RecDateSync, RecDateModified, ApprovedType, SrcRecLocationId, ANP_ADLCode, SrcRecTimestamp
, RecUserCreated, SrcRecId, NetRequest, RecDateCreated, RecCountModified, ErrorClass, SettlementCode, SrcRecVersion, VERPACKSTUELI, CotsType
, RecSyncId, LAGERATTRIB)
SELECT Quantity, RecId, Id, SalesInvoiceId, ItemId, RebateGroupId, RebatePrice, LineId, Net, "Timestamp", Name, Rebate, Price
, RevenueAccount, RebatePrice2, RevenuePerUnit, Tax, AccountingAccountId, ItemGroupId, "Language", SalesUoMId, Revenue, SalesOrderLineId
, OriginTaxPrice, Rebate2, SalesOrderId, WTaxCode, CostCenterId, DeliveryNote, ItemCustomerRelationId, QuantityRebate, NameInternal
, "Date", SalesAgreementDetailLineId, NoRebateFlag, DeliveryDate, CustomerItemNumber, QuantityRebatePrice, DataSource, CommissionFlag
, ContributionMargin, SalesAgreementDetailId, BomFlag, ActiveVariants, Percent, LineDispoFlag, BasePrice, PackagingQuantity, RepresentativeId
, NewAstlFlag, PriceUoMId, Commission, LinePrintFlag, CostUnitId, WithdrawedFlag, ProjectId, SalesDimensions, TargetAccountId, Commission2
, GrossPriceList, MaterialSurchargeSum, MaterialSurchargeMode, PriceGroupId, BatchId, Percent2, RepresentativeI2Id, BonusFlag, PDate
, ItemCustomerBOMFlag, MarginPercent, ToCheckFlag, ParcelFlag, Margin, TextLineFlag, GoodsIssueLineId, "Type", InventoryPrice, Status
, MarginPerUnit, ChangedFlag, RevenueManuallyFlag, SubTotalFlag, ProductionNumber, DepositPercent, InvoiceDate, GSStartFlag, SalesPriceListId
, EndDate, GoodsIssueId, DisplayNULLFlag, ProductionCosts, NetExternal, LastInvoiceDate, GSEndFlag, Insuser, CreditNoteStart, DisplayFlag
, LinesEnd, Insdate, Upddate, UserLine, DontPrintPriceFlag, NoStatisticsFlag, NoPosFlag, LinesStart, NoStatusCheckFlag, Upduser, LineOrderPath
, SetNumber, NoAccountingFlag, DontPrintFlag, MaintenanceTo, RevenueOrign, SectionSumFlag, OriginInvoiceId, RentalItemFlag, WarrantyFlag
, EffectiveServiceDate, OriginQuantity, NetOrigin, MaintenanceFrom, OriginInvoiceLineId, FinalSalesInvoiceId, InstallationId, CostGroupId
, DeliveryUnloadingPoint, EDIPartner, FinalSalesInvoiceLineId, VDAPriceUnit, SalesReturnLineId, ReferenceCustomer, ShippingLineFlag
, FactoryDirectCustomer, VDAShippingMode, DeliveryRunPlanId, PackagingLineFlag, HasModifiedOrder, Finalized, SalesReturnId, CauserId
, CauserSubLine, CreditNoteValueRefundFlag, NoPaymentDepositFlag, CostsFreight, PaymentFlag, DirectDeliveryFlag, InventoryPhysicalFlag
, CauserLineId, AccountingId, SupplierCompanyAccountId, CreditNoteAdvice, PaymentDate, DeliveryCostsFlag, GALine, ClientId, RentalTo
, SalesConsignmentWarehouseBinId, GaebLineType2, OptionFromLine, ProvisionMode, GASubLine, RentalFrom, RentalDuration, SamplesWarehouseBinId
, CostsContributionMargin, EDLWithdrawalMessageIn, GaebLineType, BonusAgreementId, BonusSalesInvoiceLineId, BasisValue, ConditionRanking2
, DepositAccountingInvoice, CommissionManuallyFlag, CreditNoteAdviceNumber, BonusSalesInvoiceId, BonusAccrual, BasisValue2, CreditedFlag
, DepositAccountingInvoiceDeadline, ConditionRanking, Commission2ManuallyFlag, FinalCalculated, ANP_PurchaseOrderLineId, PurchaseOrderLineId
, DisplayText, VOBTaxPrice, LocationId, GUID, ANP_PurchaseOrderId, PurchaseOrderId, EDIPartnerNumber, VOBPrice, CustomsOrFeesFlag, VOBRevenue
, CustomerReferenceNumber, MarginVOB, VOBQuantity, VOBPreInvoice, DiscountTax, CustomsTariffId, NetDiscount, NKE_CostsK01, VOBInvoicedQuantity
, VOBLine, VOBPreLine, PriceCode, OriginBasePrice, GrossDiscount, Commission3, Representative3Id, Percent3, RecActive, PriceCompanyId, RecDateStart
, PriceExternal, MaintenanceGroup, Commission3ManuallyFlag, ConditionRanking3, BasisValue3, RecDateReport, AttributeClassId, RecDateEnd
, ANP_CustomerPurchaseOrderLine, RecUserModified, RecDateSync, RecDateModified, ApprovedType, SrcRecLocationId, ANP_ADLCode, SrcRecTimestamp
, RecUserCreated, SrcRecId, NetRequest, RecDateCreated, RecCountModified, ErrorClass, SettlementCode, SrcRecVersion, VERPACKSTUELI, CotsType
, RecSyncId, LAGERATTRIB
FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesInvoiceLine_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesInvoiceLine_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_SalesInvoiceLine_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_SalesInvoiceLine_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_SalesInvoiceLine_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesInvoiceLine_NKE');
*/