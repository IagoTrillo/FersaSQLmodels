-- Done by Miguel Plasencia. 

--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_TEMPLATE_NKE WHERE RECID IS NULL 
OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_TEMPLATE_NKE WHERE ID IS NULL) -- For those records that has been deleted in AP+ 
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_TEMPLATE_NKE WHERE ID IS NOT NULL); -- For those records that has been updated or created in AP+ 

/*Why don´t we use either only the ID or the RECID for deleting? Because when a record is deleted in AP+ its ID turns into NULL*/

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_TEMPLATE_NKE(A,B,C,D)
SELECT A,B,C,D
FROM nkeTempIncremental.ds_TEMPLATE_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL --Only insert live records
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_TEMPLATE_NKE') -- only for those whose MODIFIEDDATE is greater than the last update
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC); -- and grouping by (AP+'s) ID, becasue it may happen that for 
                                    -- the same window of time we have more than one update/creation record in temp table for the same ID so we take the newest one

--3. Save last modified date, no matter we insert into the nkeds table or only delete from it
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_TEMPLATE_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_TEMPLATE_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_TEMPLATE_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_TEMPLATE_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_TEMPLATE_NKE');




