--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_Staff_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_Staff_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_Staff_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_Staff_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_Staff_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_Staff_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_Staff_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_Staff_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_Staff_NKE (Id, EntryDate, DepartmentId, RecId, StaffId, Environment, TimeScheduleRosterId, LeavingDate, "Timestamp", CapacityCenterId, Name, Card
, SettlementGroupId, OverheadCostFlag, TripApprovedFlag, WorkingGroupFlag, ShiftSwitchFlag, Access, MachineGroupId, FlexitimeForward
, GroupWorkFlag, HourlyRate, FlexitimeBacklog, CapacityCenterSwitchFlag, QueryFlag, OrdersFlag, ReportUnitsFlag, ProfileName, PIN, ReportRejectFlag
, Extension, Identifier, ReportMissingReasonFlag, OvertimeAuthorization2Flag, WageGroupId, StaffTimeActiveFlag, Picture, Phone, OvertimeAuthorizationFlag
, OvertimeAuthorizationDaysFlag, GroupId, Initials, Description, SeveralWorkOrderOperationMode, Insuser, Upduser, CompanyAccountId, ObjectClass
, ObjectGUID, "Function", AutoTerminateFlag, Insdate, Upddate, WageNumber, DispoStaffFlag, CompanyEntryDate, OvertimeAuthorizationSunFlag, ActiveFrom
, AccountingInitials, BirthDate, OvertimeAuthorizationFriFlag, RoundingModelId, WageClientId, OvertimeAuthorizationVacationFlag, ActiveTo, ActiveFlag
, OvertimeAuthorizationMonFlag, OvertimeAuthorizationSatFlag, CorrDate, NKE_LastName, NKE_Salutation, CORRUSER, NKE_ApprenticeshipStart, NKE_CountryCode
, NKE_City, NKE_SafetyOfficerFlag, NKE_FirstAidOfficerFlag, NKE_Title, NKE_Profession, NKE_ApprenticeshipYearNumber, NKE_PostCode, NKE_FunctionalLevel
, NKE_FireProtectionOfficer, Password, RestrictedFlag, NKE_WasteOfficerFlag, NKE_ExternalFlag, NKE_Street, GUIDP, TimeScheduleWeekPersonalizableFlag
, CostUnitId, VacationSupoerOfficerFlag, NKE_LeasingFlag, NKE_FirstName, ProfitCenterId, VacationOfficerStaffId, LocationId, AttributeClassId, ClientId
, CheckGroup, MachineFlag, NameLast, StaffEnvironment, VacationCoOfficerStaffId, TimeScheduleStartOfDay, GUID, ReadOnlyFlag, NameFirst, StaffTimeOnlyFlag
, Login, SettlementClass, RecDateSync, RecActive, BiometryStatus, SetupWageGroupId, MailServer, RecDateStart, RecDateModified, RecDateCreated, RecDateReport
, SalesBeatToken, MailNickname, ANP_EmailStaffTime, RecDateEnd, RecUserCreated, ISTPZEBERECHTIGT, EXPORTIERT, RecUserModified, SrcRecLocationId
, SrcRecTimestamp, AZEAKTIV, StaffPlanningFlag, BankAccountNumber, IBAN, RecCountModified, SrcRecId, SrcRecVersion, BankId, PZEBEARBEITER
, STELLVPZEBEARBEITER, RecSyncId, USTIDFREIGABE)
SELECT Id, EntryDate, DepartmentId, RecId, StaffId, Environment, TimeScheduleRosterId, LeavingDate, "Timestamp", CapacityCenterId, Name, Card
, SettlementGroupId, OverheadCostFlag, TripApprovedFlag, WorkingGroupFlag, ShiftSwitchFlag, Access, MachineGroupId, FlexitimeForward
, GroupWorkFlag, HourlyRate, FlexitimeBacklog, CapacityCenterSwitchFlag, QueryFlag, OrdersFlag, ReportUnitsFlag, ProfileName, PIN, ReportRejectFlag
, Extension, Identifier, ReportMissingReasonFlag, OvertimeAuthorization2Flag, WageGroupId, StaffTimeActiveFlag, Picture, Phone, OvertimeAuthorizationFlag
, OvertimeAuthorizationDaysFlag, GroupId, Initials, Description, SeveralWorkOrderOperationMode, Insuser, Upduser, CompanyAccountId, ObjectClass
, ObjectGUID, "Function", AutoTerminateFlag, Insdate, Upddate, WageNumber, DispoStaffFlag, CompanyEntryDate, OvertimeAuthorizationSunFlag, ActiveFrom
, AccountingInitials, BirthDate, OvertimeAuthorizationFriFlag, RoundingModelId, WageClientId, OvertimeAuthorizationVacationFlag, ActiveTo, ActiveFlag
, OvertimeAuthorizationMonFlag, OvertimeAuthorizationSatFlag, CorrDate, NKE_LastName, NKE_Salutation, CORRUSER, NKE_ApprenticeshipStart, NKE_CountryCode
, NKE_City, NKE_SafetyOfficerFlag, NKE_FirstAidOfficerFlag, NKE_Title, NKE_Profession, NKE_ApprenticeshipYearNumber, NKE_PostCode, NKE_FunctionalLevel
, NKE_FireProtectionOfficer, Password, RestrictedFlag, NKE_WasteOfficerFlag, NKE_ExternalFlag, NKE_Street, GUIDP, TimeScheduleWeekPersonalizableFlag
, CostUnitId, VacationSupoerOfficerFlag, NKE_LeasingFlag, NKE_FirstName, ProfitCenterId, VacationOfficerStaffId, LocationId, AttributeClassId, ClientId
, CheckGroup, MachineFlag, NameLast, StaffEnvironment, VacationCoOfficerStaffId, TimeScheduleStartOfDay, GUID, ReadOnlyFlag, NameFirst, StaffTimeOnlyFlag
, Login, SettlementClass, RecDateSync, RecActive, BiometryStatus, SetupWageGroupId, MailServer, RecDateStart, RecDateModified, RecDateCreated, RecDateReport
, SalesBeatToken, MailNickname, ANP_EmailStaffTime, RecDateEnd, RecUserCreated, ISTPZEBERECHTIGT, EXPORTIERT, RecUserModified, SrcRecLocationId
, SrcRecTimestamp, AZEAKTIV, StaffPlanningFlag, BankAccountNumber, IBAN, RecCountModified, SrcRecId, SrcRecVersion, BankId, PZEBEARBEITER
, STELLVPZEBEARBEITER, RecSyncId, USTIDFREIGABE
FROM	nkeTempIncremental.ds_Staff_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_Staff_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_Staff_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_Staff_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_Staff_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_Staff_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_Staff_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_Staff_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_Staff_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Staff_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_Staff_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_Staff_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_Staff_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_Staff_NKE(Id, EntryDate, DepartmentId, RecId, StaffId, Environment, TimeScheduleRosterId, LeavingDate, "Timestamp", CapacityCenterId, Name, Card
, SettlementGroupId, OverheadCostFlag, TripApprovedFlag, WorkingGroupFlag, ShiftSwitchFlag, Access, MachineGroupId, FlexitimeForward
, GroupWorkFlag, HourlyRate, FlexitimeBacklog, CapacityCenterSwitchFlag, QueryFlag, OrdersFlag, ReportUnitsFlag, ProfileName, PIN, ReportRejectFlag
, Extension, Identifier, ReportMissingReasonFlag, OvertimeAuthorization2Flag, WageGroupId, StaffTimeActiveFlag, Picture, Phone, OvertimeAuthorizationFlag
, OvertimeAuthorizationDaysFlag, GroupId, Initials, Description, SeveralWorkOrderOperationMode, Insuser, Upduser, CompanyAccountId, ObjectClass
, ObjectGUID, "Function", AutoTerminateFlag, Insdate, Upddate, WageNumber, DispoStaffFlag, CompanyEntryDate, OvertimeAuthorizationSunFlag, ActiveFrom
, AccountingInitials, BirthDate, OvertimeAuthorizationFriFlag, RoundingModelId, WageClientId, OvertimeAuthorizationVacationFlag, ActiveTo, ActiveFlag
, OvertimeAuthorizationMonFlag, OvertimeAuthorizationSatFlag, CorrDate, NKE_LastName, NKE_Salutation, CORRUSER, NKE_ApprenticeshipStart, NKE_CountryCode
, NKE_City, NKE_SafetyOfficerFlag, NKE_FirstAidOfficerFlag, NKE_Title, NKE_Profession, NKE_ApprenticeshipYearNumber, NKE_PostCode, NKE_FunctionalLevel
, NKE_FireProtectionOfficer, Password, RestrictedFlag, NKE_WasteOfficerFlag, NKE_ExternalFlag, NKE_Street, GUIDP, TimeScheduleWeekPersonalizableFlag
, CostUnitId, VacationSupoerOfficerFlag, NKE_LeasingFlag, NKE_FirstName, ProfitCenterId, VacationOfficerStaffId, LocationId, AttributeClassId, ClientId
, CheckGroup, MachineFlag, NameLast, StaffEnvironment, VacationCoOfficerStaffId, TimeScheduleStartOfDay, GUID, ReadOnlyFlag, NameFirst, StaffTimeOnlyFlag
, Login, SettlementClass, RecDateSync, RecActive, BiometryStatus, SetupWageGroupId, MailServer, RecDateStart, RecDateModified, RecDateCreated, RecDateReport
, SalesBeatToken, MailNickname, ANP_EmailStaffTime, RecDateEnd, RecUserCreated, ISTPZEBERECHTIGT, EXPORTIERT, RecUserModified, SrcRecLocationId
, SrcRecTimestamp, AZEAKTIV, StaffPlanningFlag, BankAccountNumber, IBAN, RecCountModified, SrcRecId, SrcRecVersion, BankId, PZEBEARBEITER
, STELLVPZEBEARBEITER, RecSyncId, USTIDFREIGABE)
SELECT Id, EntryDate, DepartmentId, RecId, StaffId, Environment, TimeScheduleRosterId, LeavingDate, "Timestamp", CapacityCenterId, Name, Card
, SettlementGroupId, OverheadCostFlag, TripApprovedFlag, WorkingGroupFlag, ShiftSwitchFlag, Access, MachineGroupId, FlexitimeForward
, GroupWorkFlag, HourlyRate, FlexitimeBacklog, CapacityCenterSwitchFlag, QueryFlag, OrdersFlag, ReportUnitsFlag, ProfileName, PIN, ReportRejectFlag
, Extension, Identifier, ReportMissingReasonFlag, OvertimeAuthorization2Flag, WageGroupId, StaffTimeActiveFlag, Picture, Phone, OvertimeAuthorizationFlag
, OvertimeAuthorizationDaysFlag, GroupId, Initials, Description, SeveralWorkOrderOperationMode, Insuser, Upduser, CompanyAccountId, ObjectClass
, ObjectGUID, "Function", AutoTerminateFlag, Insdate, Upddate, WageNumber, DispoStaffFlag, CompanyEntryDate, OvertimeAuthorizationSunFlag, ActiveFrom
, AccountingInitials, BirthDate, OvertimeAuthorizationFriFlag, RoundingModelId, WageClientId, OvertimeAuthorizationVacationFlag, ActiveTo, ActiveFlag
, OvertimeAuthorizationMonFlag, OvertimeAuthorizationSatFlag, CorrDate, NKE_LastName, NKE_Salutation, CORRUSER, NKE_ApprenticeshipStart, NKE_CountryCode
, NKE_City, NKE_SafetyOfficerFlag, NKE_FirstAidOfficerFlag, NKE_Title, NKE_Profession, NKE_ApprenticeshipYearNumber, NKE_PostCode, NKE_FunctionalLevel
, NKE_FireProtectionOfficer, Password, RestrictedFlag, NKE_WasteOfficerFlag, NKE_ExternalFlag, NKE_Street, GUIDP, TimeScheduleWeekPersonalizableFlag
, CostUnitId, VacationSupoerOfficerFlag, NKE_LeasingFlag, NKE_FirstName, ProfitCenterId, VacationOfficerStaffId, LocationId, AttributeClassId, ClientId
, CheckGroup, MachineFlag, NameLast, StaffEnvironment, VacationCoOfficerStaffId, TimeScheduleStartOfDay, GUID, ReadOnlyFlag, NameFirst, StaffTimeOnlyFlag
, Login, SettlementClass, RecDateSync, RecActive, BiometryStatus, SetupWageGroupId, MailServer, RecDateStart, RecDateModified, RecDateCreated, RecDateReport
, SalesBeatToken, MailNickname, ANP_EmailStaffTime, RecDateEnd, RecUserCreated, ISTPZEBERECHTIGT, EXPORTIERT, RecUserModified, SrcRecLocationId
, SrcRecTimestamp, AZEAKTIV, StaffPlanningFlag, BankAccountNumber, IBAN, RecCountModified, SrcRecId, SrcRecVersion, BankId, PZEBEARBEITER
, STELLVPZEBEARBEITER, RecSyncId, USTIDFREIGABE
FROM nkeTempIncremental.ds_Staff_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Staff_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Staff_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_Staff_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_Staff_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_Staff_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Staff_NKE');
*/