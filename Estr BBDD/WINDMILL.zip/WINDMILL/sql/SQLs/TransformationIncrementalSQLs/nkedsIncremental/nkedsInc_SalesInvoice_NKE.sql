--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_SalesInvoice_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_SalesInvoice_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_SalesInvoice_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesInvoice_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesInvoice_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_SalesInvoice_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_SalesInvoice_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesInvoice_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_SalesInvoice_NKE (InvoiceCompanyAccountId, RecId, "Type", Id, SalesInvoiceId, SalesOrderId, "Date", StaffId, YourText, Status, CompanyAccountId
, DueDate, "Timestamp", DMGross, StdTxt, NetRevenue, OriginTaxPrice, CurrencyCode, RebatePrice, WithdrawedFlag, PriceListFlag, DMNetRevenue, DMFactor
, Net, Gross, TaxCode, "Language", DocDeliveryFax, DocDeliveryCity, DocDeliveryDepartment, DeliveryCompanyAccountId, DocDeliveryPostCode
, DocDeliveryCompanyAccountName1, DocDeliveryCompanyAccountManuallyFlag, OrderType, RepresentativeId, DocDeliveryName, DocDeliveryPhone,
 DocDeliveryStreet, DocDeliveryCountryCode, EVAFlag, PriceCode, CostUnitId, CompanyId, ValutaDate, Insuser, Upduser, DocDeliveryCompanyAccountName2
 , ProjectId, PostingPeriod, DMDivisor, RepresentativeI2Id, Insdate, Upddate, DocDeliveryCompanyAccountName3, ExchangeRateOrigin1, InProcessFlag
 , MarginPercent, OrderDate, ThirdPartyPostingDate, SuppllierCompanyId, JobId, YourOrder, ExchangeRateOrigin2, DecisionHorizont, Margin, PDate
 , RunningNumber, InvoiceMode, TaxText, OriginInvoiceId, ServiceFlag, DocDeliveryVATNumber, CreditNoteValueRefundFlag, EDIPartner, MatchCode
 , InvoiceOut, PrintedFlag, EffectiveServiceDate, DeliveryScheduleDate, InspectionNumber, MainenanceFlag, FactoryDirectCustomer, GoodsIssueWeight
 , ClientId, NKE_Percent, MyOpenFactory, SamplesWarehouseId, ExchangeRateFactor, EInvoiceTransferStatus, PriceCompanyId, Nke_Percent2, CostsFreight
 , SalesConsignmentWarehouseId, ExchangeRateType, InvoiceAutomatic, EInvoiceTransferError, EDIPartnerNumber, DocDeliveryPostCode2, PaymentPlanId
 , MarginVOB, VOBOp, VOBNetRevenue, WorkflowId, FinalCalculated, LocationId, ANP_AccountingTransfer, VOBMarginPercent, VOBPayment, VOBGross
 , WFProcName, VOBGrossRequest, PrintCustomsNumberFlag, VOBNetPayment, CustomsMRNNumber, ANP_ExportCertificationBy, NKE_PaidFlag, VOBNetRequest
 , VOBPreInvoice, NKE_FactoringFlag, NKE_ExportCertificateFlag, AccountingRunningDocumentNumber, InvoiceVATNumber, VOBNetOP, Representative3Id
 , TermsPaymentId, ANP_ExportCertificationDate, RecDateEnd, RecDateCreated, GUID, VOBDiscount, RecDateReport, VOBNumber, AttributeClassId
 , RecDateStart, RecActive, RecDateModified, CollectiveOrderId, RecDateSync, RecUserCreated, SrcRecId, SrcRecVersion, EINVOICE_DISPATCH
 , KONVERTEDINVOICE, RecCountModified, EINVOICEXML, SrcRecLocationId, RecUserModified, ANP_FERITEMCATEGORIZATION, LEITWEGID, LASTTRANSFERID
 , SrcRecTimestamp, CONVERTEDINVOICEREQUESTED, EINVOICE_INTERFACE, ErrorClass, RecSyncId, USTIDNOPRUEF)
SELECT InvoiceCompanyAccountId, RecId, "Type", Id, SalesInvoiceId, SalesOrderId, "Date", StaffId, YourText, Status, CompanyAccountId
, DueDate, "Timestamp", DMGross, StdTxt, NetRevenue, OriginTaxPrice, CurrencyCode, RebatePrice, WithdrawedFlag, PriceListFlag, DMNetRevenue, DMFactor
, Net, Gross, TaxCode, "Language", DocDeliveryFax, DocDeliveryCity, DocDeliveryDepartment, DeliveryCompanyAccountId, DocDeliveryPostCode
, DocDeliveryCompanyAccountName1, DocDeliveryCompanyAccountManuallyFlag, OrderType, RepresentativeId, DocDeliveryName, DocDeliveryPhone,
 DocDeliveryStreet, DocDeliveryCountryCode, EVAFlag, PriceCode, CostUnitId, CompanyId, ValutaDate, Insuser, Upduser, DocDeliveryCompanyAccountName2
 , ProjectId, PostingPeriod, DMDivisor, RepresentativeI2Id, Insdate, Upddate, DocDeliveryCompanyAccountName3, ExchangeRateOrigin1, InProcessFlag
 , MarginPercent, OrderDate, ThirdPartyPostingDate, SuppllierCompanyId, JobId, YourOrder, ExchangeRateOrigin2, DecisionHorizont, Margin, PDate
 , RunningNumber, InvoiceMode, TaxText, OriginInvoiceId, ServiceFlag, DocDeliveryVATNumber, CreditNoteValueRefundFlag, EDIPartner, MatchCode
 , InvoiceOut, PrintedFlag, EffectiveServiceDate, DeliveryScheduleDate, InspectionNumber, MainenanceFlag, FactoryDirectCustomer, GoodsIssueWeight
 , ClientId, NKE_Percent, MyOpenFactory, SamplesWarehouseId, ExchangeRateFactor, EInvoiceTransferStatus, PriceCompanyId, Nke_Percent2, CostsFreight
 , SalesConsignmentWarehouseId, ExchangeRateType, InvoiceAutomatic, EInvoiceTransferError, EDIPartnerNumber, DocDeliveryPostCode2, PaymentPlanId
 , MarginVOB, VOBOp, VOBNetRevenue, WorkflowId, FinalCalculated, LocationId, ANP_AccountingTransfer, VOBMarginPercent, VOBPayment, VOBGross
 , WFProcName, VOBGrossRequest, PrintCustomsNumberFlag, VOBNetPayment, CustomsMRNNumber, ANP_ExportCertificationBy, NKE_PaidFlag, VOBNetRequest
 , VOBPreInvoice, NKE_FactoringFlag, NKE_ExportCertificateFlag, AccountingRunningDocumentNumber, InvoiceVATNumber, VOBNetOP, Representative3Id
 , TermsPaymentId, ANP_ExportCertificationDate, RecDateEnd, RecDateCreated, GUID, VOBDiscount, RecDateReport, VOBNumber, AttributeClassId
 , RecDateStart, RecActive, RecDateModified, CollectiveOrderId, RecDateSync, RecUserCreated, SrcRecId, SrcRecVersion, EINVOICE_DISPATCH
 , KONVERTEDINVOICE, RecCountModified, EINVOICEXML, SrcRecLocationId, RecUserModified, ANP_FERITEMCATEGORIZATION, LEITWEGID, LASTTRANSFERID
 , SrcRecTimestamp, CONVERTEDINVOICEREQUESTED, EINVOICE_INTERFACE, ErrorClass, RecSyncId, USTIDNOPRUEF
FROM	nkeTempIncremental.ds_SalesInvoice_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesInvoice_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_SalesInvoice_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_SalesInvoice_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesInvoice_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_SalesInvoice_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_SalesInvoice_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesInvoice_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_SalesInvoice_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesInvoice_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_SalesInvoice_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_SalesInvoice_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_SalesInvoice_NKE WHERE ID IS NOT NULL);
--2. Insert only modified rows.              
INSERT INTO nkeds.ds_SalesInvoice_NKE(InvoiceCompanyAccountId, RecId, "Type", Id, SalesInvoiceId, SalesOrderId, "Date", StaffId, YourText, Status, CompanyAccountId
, DueDate, "Timestamp", DMGross, StdTxt, NetRevenue, OriginTaxPrice, CurrencyCode, RebatePrice, WithdrawedFlag, PriceListFlag, DMNetRevenue, DMFactor
, Net, Gross, TaxCode, "Language", DocDeliveryFax, DocDeliveryCity, DocDeliveryDepartment, DeliveryCompanyAccountId, DocDeliveryPostCode
, DocDeliveryCompanyAccountName1, DocDeliveryCompanyAccountManuallyFlag, OrderType, RepresentativeId, DocDeliveryName, DocDeliveryPhone,
 DocDeliveryStreet, DocDeliveryCountryCode, EVAFlag, PriceCode, CostUnitId, CompanyId, ValutaDate, Insuser, Upduser, DocDeliveryCompanyAccountName2
 , ProjectId, PostingPeriod, DMDivisor, RepresentativeI2Id, Insdate, Upddate, DocDeliveryCompanyAccountName3, ExchangeRateOrigin1, InProcessFlag
 , MarginPercent, OrderDate, ThirdPartyPostingDate, SuppllierCompanyId, JobId, YourOrder, ExchangeRateOrigin2, DecisionHorizont, Margin, PDate
 , RunningNumber, InvoiceMode, TaxText, OriginInvoiceId, ServiceFlag, DocDeliveryVATNumber, CreditNoteValueRefundFlag, EDIPartner, MatchCode
 , InvoiceOut, PrintedFlag, EffectiveServiceDate, DeliveryScheduleDate, InspectionNumber, MainenanceFlag, FactoryDirectCustomer, GoodsIssueWeight
 , ClientId, NKE_Percent, MyOpenFactory, SamplesWarehouseId, ExchangeRateFactor, EInvoiceTransferStatus, PriceCompanyId, Nke_Percent2, CostsFreight
 , SalesConsignmentWarehouseId, ExchangeRateType, InvoiceAutomatic, EInvoiceTransferError, EDIPartnerNumber, DocDeliveryPostCode2, PaymentPlanId
 , MarginVOB, VOBOp, VOBNetRevenue, WorkflowId, FinalCalculated, LocationId, ANP_AccountingTransfer, VOBMarginPercent, VOBPayment, VOBGross
 , WFProcName, VOBGrossRequest, PrintCustomsNumberFlag, VOBNetPayment, CustomsMRNNumber, ANP_ExportCertificationBy, NKE_PaidFlag, VOBNetRequest
 , VOBPreInvoice, NKE_FactoringFlag, NKE_ExportCertificateFlag, AccountingRunningDocumentNumber, InvoiceVATNumber, VOBNetOP, Representative3Id
 , TermsPaymentId, ANP_ExportCertificationDate, RecDateEnd, RecDateCreated, GUID, VOBDiscount, RecDateReport, VOBNumber, AttributeClassId
 , RecDateStart, RecActive, RecDateModified, CollectiveOrderId, RecDateSync, RecUserCreated, SrcRecId, SrcRecVersion, EINVOICE_DISPATCH
 , KONVERTEDINVOICE, RecCountModified, EINVOICEXML, SrcRecLocationId, RecUserModified, ANP_FERITEMCATEGORIZATION, LEITWEGID, LASTTRANSFERID
 , SrcRecTimestamp, CONVERTEDINVOICEREQUESTED, EINVOICE_INTERFACE, ErrorClass, RecSyncId, USTIDNOPRUEF)
SELECT InvoiceCompanyAccountId, RecId, "Type", Id, SalesInvoiceId, SalesOrderId, "Date", StaffId, YourText, Status, CompanyAccountId
, DueDate, "Timestamp", DMGross, StdTxt, NetRevenue, OriginTaxPrice, CurrencyCode, RebatePrice, WithdrawedFlag, PriceListFlag, DMNetRevenue, DMFactor
, Net, Gross, TaxCode, "Language", DocDeliveryFax, DocDeliveryCity, DocDeliveryDepartment, DeliveryCompanyAccountId, DocDeliveryPostCode
, DocDeliveryCompanyAccountName1, DocDeliveryCompanyAccountManuallyFlag, OrderType, RepresentativeId, DocDeliveryName, DocDeliveryPhone,
 DocDeliveryStreet, DocDeliveryCountryCode, EVAFlag, PriceCode, CostUnitId, CompanyId, ValutaDate, Insuser, Upduser, DocDeliveryCompanyAccountName2
 , ProjectId, PostingPeriod, DMDivisor, RepresentativeI2Id, Insdate, Upddate, DocDeliveryCompanyAccountName3, ExchangeRateOrigin1, InProcessFlag
 , MarginPercent, OrderDate, ThirdPartyPostingDate, SuppllierCompanyId, JobId, YourOrder, ExchangeRateOrigin2, DecisionHorizont, Margin, PDate
 , RunningNumber, InvoiceMode, TaxText, OriginInvoiceId, ServiceFlag, DocDeliveryVATNumber, CreditNoteValueRefundFlag, EDIPartner, MatchCode
 , InvoiceOut, PrintedFlag, EffectiveServiceDate, DeliveryScheduleDate, InspectionNumber, MainenanceFlag, FactoryDirectCustomer, GoodsIssueWeight
 , ClientId, NKE_Percent, MyOpenFactory, SamplesWarehouseId, ExchangeRateFactor, EInvoiceTransferStatus, PriceCompanyId, Nke_Percent2, CostsFreight
 , SalesConsignmentWarehouseId, ExchangeRateType, InvoiceAutomatic, EInvoiceTransferError, EDIPartnerNumber, DocDeliveryPostCode2, PaymentPlanId
 , MarginVOB, VOBOp, VOBNetRevenue, WorkflowId, FinalCalculated, LocationId, ANP_AccountingTransfer, VOBMarginPercent, VOBPayment, VOBGross
 , WFProcName, VOBGrossRequest, PrintCustomsNumberFlag, VOBNetPayment, CustomsMRNNumber, ANP_ExportCertificationBy, NKE_PaidFlag, VOBNetRequest
 , VOBPreInvoice, NKE_FactoringFlag, NKE_ExportCertificateFlag, AccountingRunningDocumentNumber, InvoiceVATNumber, VOBNetOP, Representative3Id
 , TermsPaymentId, ANP_ExportCertificationDate, RecDateEnd, RecDateCreated, GUID, VOBDiscount, RecDateReport, VOBNumber, AttributeClassId
 , RecDateStart, RecActive, RecDateModified, CollectiveOrderId, RecDateSync, RecUserCreated, SrcRecId, SrcRecVersion, EINVOICE_DISPATCH
 , KONVERTEDINVOICE, RecCountModified, EINVOICEXML, SrcRecLocationId, RecUserModified, ANP_FERITEMCATEGORIZATION, LEITWEGID, LASTTRANSFERID
 , SrcRecTimestamp, CONVERTEDINVOICEREQUESTED, EINVOICE_INTERFACE, ErrorClass, RecSyncId, USTIDNOPRUEF
FROM nkeTempIncremental.ds_SalesInvoice_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesInvoice_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesInvoice_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_SalesInvoice_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_SalesInvoice_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_SalesInvoice_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesInvoice_NKE');
*/