--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_Company_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_Company_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_Company_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_Company_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_Company_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_Company_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_Company_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_Company_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_Company_NKE (RecId, Id, CompanyId, CompanyAccountId, PriceListFlag, TermsQuotationStdTxt, TermsWebshopStdTxt, Name
, "Timestamp", TermsPaymentId, TermsDeliveryNoteStdTxt, CustomerGroup, RebateDate, TermsOrderStdTxt, TermsDeliveryStdTxt
, TermsCreditNoteStdTxt, CountryId, SalesTurnover, RejectionFlag, PaymentDepositFlag, TermsInvoice, PurchasePaymentDepositFlag
, TermsPurchaseOrderStdTxt, LastOrderDate, PaymentDepositOverdueFlag, VATNumber, PurchaseTurnover, MinimumOrderValue, PurchaseVATCode
, CreditLimitAlert, AccountingMatchCode, CreditorCompanyAccountId, VATPersonsGroup, CreditorAccountNumber, CreditLimit, SalesVATCode
, AccountingExportFlag, PaymentMode, DebitCompanyAccountId, TaxCountryCode, DebitAccountNumber, SupplierFlag, AccountPayable, PreviousYear
, CreditorAccountingExportStatus, PurchaseCurrencyCode, PriceCode, GlobalRebate, DebitAccountingExportStatus, RevenueGroup, AccountReceivable
, CustomerFlag, Tolerance, CurrencyCode, EuroPrintFlag, BankAccountNumber, MaterialSurcharge, AllAccountsFlag, DunningGroup, ThirdPartyPostingDate
, Upduser, Insuser, BankAccounting, MaterialSurchargeDeductionFlag, BonusCollectionFlag, BankId, DebitAccountingExportStatus2, Upddate, Insdate, URL
, AbcAnalysisId, CustomerClassListId, CreditorAccountingExportStatus2, PurchasePaymentMode, CompetitorFlag, PotentialPercent, TaxNumber, Potential
, CompanyNumberOfEmployees, BankAccounting2, SuperordinateCompanyId, AbcClassification, CompanyTurnover, TipSalesAgreementFlag, IBAN, RevenueAccount
, PriceCompanyId, TipSalesOrderFlag, CreditorTemplate, CustomerReferenceNumber, TipSalesQuotationFlag, PartialDeliveryFlag, AccountPreInput
, PurchasePriceCompanyId, TipGoodsIssueFlag, TermsAccountingInvoice, DebitTemplate, NKE_VATNumberCheckUserId, TipGoodsReceiptFlag, TipPurchaseInquiryFlag
, TipSalesInvoiceFlag, NKE_IISContactId, TipServiceFlag, TipSales, NKE_VATNumberCheckDate, TipPurchaseSupplierInvoiceFlag, TipPurchaseOrderFlag
, TipPurchaseAgreementFlag, ClientId, NKE_CessionIndicator, TipPurchase, PurchaseCreditLimit, NaceCode, GUIDF, ANP_CreditorAlwaysExport, NKE_LbtContactEmail
, AccountingReportInformation, DunsNumber, NaceExtended, PackagingMaterialTakeOverFlag, SYNCMSCRM, NKE_AccountingContactPerson, ANP_DebtosAlwaysExport
, CommercialRegisterNumber, CustomerSince, NKE_QSDocument, NKE_PlaceOfJurisdiction, NKE_AccountingContactEmail, NKE_FactoringFlag, PurchaseGlobalRebate
, NKE_SCR_ServiceFee, SupplierRatingScore, NKE_ApplicableLaw, NKE_GuaranteePeriod, NKE_ProspectFlag, NKE_TanListFlag, TipPurchaseReturnFlag, SupplierRatingLastDate,
SupplierRatingClass, DeliveryWeekMode, CorrespondingAccountNumbersFlag, NKE_WebshopRebate, AttributeClassId, DeliveryThursdayFlag, DeliverySautrdayFlag
, DeliveryTuesdayFlag, DeliverySundayFlag, DeliveryMondayFlag, DebitBusinessPartnerFlag, GUID, SupplierReferenceNumber, DeliveryFridayFlag, DeliveryWednesdayFlag
, RecDateEnd, LinkSalesBeat, LegalSuccessor, CountryISONumeric, RecDateReport, NKE_NoQSInspectionFlag, NKE_VATNumberNonEU, NKE_EoriNumber, GaebFormatMode
, GaebFormatExportMode, RecActive, TipSalesMaintenanceFlag, RecDateSync, RecDateStart, SrcRecId, RecCountModified, RecUserCreated, ANP_AttachDrawingsToMail
, RecDateCreated, BELEGHEADERIMG, SrcRecVersion, SrcRecLocationId, RecUserModified, RecDateModified, BlockedFlag, SPERRUSER, SrcRecTimestamp
, BELEGFOOTERIMG, ANP_CompanyQualityCategoryId, SPERRDATE, GF1, ANP_FACTORINGREF, SPERRGRUND, GF2, ANP_PFICompanyId, ANP_PFICustomerFlag)
SELECT RecId, Id, CompanyId, CompanyAccountId, PriceListFlag, TermsQuotationStdTxt, TermsWebshopStdTxt, Name
, "Timestamp", TermsPaymentId, TermsDeliveryNoteStdTxt, CustomerGroup, RebateDate, TermsOrderStdTxt, TermsDeliveryStdTxt
, TermsCreditNoteStdTxt, CountryId, SalesTurnover, RejectionFlag, PaymentDepositFlag, TermsInvoice, PurchasePaymentDepositFlag
, TermsPurchaseOrderStdTxt, LastOrderDate, PaymentDepositOverdueFlag, VATNumber, PurchaseTurnover, MinimumOrderValue, PurchaseVATCode
, CreditLimitAlert, AccountingMatchCode, CreditorCompanyAccountId, VATPersonsGroup, CreditorAccountNumber, CreditLimit, SalesVATCode
, AccountingExportFlag, PaymentMode, DebitCompanyAccountId, TaxCountryCode, DebitAccountNumber, SupplierFlag, AccountPayable, PreviousYear
, CreditorAccountingExportStatus, PurchaseCurrencyCode, PriceCode, GlobalRebate, DebitAccountingExportStatus, RevenueGroup, AccountReceivable
, CustomerFlag, Tolerance, CurrencyCode, EuroPrintFlag, BankAccountNumber, MaterialSurcharge, AllAccountsFlag, DunningGroup, ThirdPartyPostingDate
, Upduser, Insuser, BankAccounting, MaterialSurchargeDeductionFlag, BonusCollectionFlag, BankId, DebitAccountingExportStatus2, Upddate, Insdate, URL
, AbcAnalysisId, CustomerClassListId, CreditorAccountingExportStatus2, PurchasePaymentMode, CompetitorFlag, PotentialPercent, TaxNumber, Potential
, CompanyNumberOfEmployees, BankAccounting2, SuperordinateCompanyId, AbcClassification, CompanyTurnover, TipSalesAgreementFlag, IBAN, RevenueAccount
, PriceCompanyId, TipSalesOrderFlag, CreditorTemplate, CustomerReferenceNumber, TipSalesQuotationFlag, PartialDeliveryFlag, AccountPreInput
, PurchasePriceCompanyId, TipGoodsIssueFlag, TermsAccountingInvoice, DebitTemplate, NKE_VATNumberCheckUserId, TipGoodsReceiptFlag, TipPurchaseInquiryFlag
, TipSalesInvoiceFlag, NKE_IISContactId, TipServiceFlag, TipSales, NKE_VATNumberCheckDate, TipPurchaseSupplierInvoiceFlag, TipPurchaseOrderFlag
, TipPurchaseAgreementFlag, ClientId, NKE_CessionIndicator, TipPurchase, PurchaseCreditLimit, NaceCode, GUIDF, ANP_CreditorAlwaysExport, NKE_LbtContactEmail
, AccountingReportInformation, DunsNumber, NaceExtended, PackagingMaterialTakeOverFlag, SYNCMSCRM, NKE_AccountingContactPerson, ANP_DebtosAlwaysExport
, CommercialRegisterNumber, CustomerSince, NKE_QSDocument, NKE_PlaceOfJurisdiction, NKE_AccountingContactEmail, NKE_FactoringFlag, PurchaseGlobalRebate
, NKE_SCR_ServiceFee, SupplierRatingScore, NKE_ApplicableLaw, NKE_GuaranteePeriod, NKE_ProspectFlag, NKE_TanListFlag, TipPurchaseReturnFlag, SupplierRatingLastDate,
SupplierRatingClass, DeliveryWeekMode, CorrespondingAccountNumbersFlag, NKE_WebshopRebate, AttributeClassId, DeliveryThursdayFlag, DeliverySautrdayFlag
, DeliveryTuesdayFlag, DeliverySundayFlag, DeliveryMondayFlag, DebitBusinessPartnerFlag, GUID, SupplierReferenceNumber, DeliveryFridayFlag, DeliveryWednesdayFlag
, RecDateEnd, LinkSalesBeat, LegalSuccessor, CountryISONumeric, RecDateReport, NKE_NoQSInspectionFlag, NKE_VATNumberNonEU, NKE_EoriNumber, GaebFormatMode
, GaebFormatExportMode, RecActive, TipSalesMaintenanceFlag, RecDateSync, RecDateStart, SrcRecId, RecCountModified, RecUserCreated, ANP_AttachDrawingsToMail
, RecDateCreated, BELEGHEADERIMG, SrcRecVersion, SrcRecLocationId, RecUserModified, RecDateModified, BlockedFlag, SPERRUSER, SrcRecTimestamp
, BELEGFOOTERIMG, ANP_CompanyQualityCategoryId, SPERRDATE, GF1, ANP_FACTORINGREF, SPERRGRUND, GF2, ANP_PFICompanyId, ANP_PFICustomerFlag
FROM	nkeTempIncremental.ds_Company_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_Company_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_Company_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_Company_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_Company_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_Company_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_Company_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_Company_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_Company_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Company_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_Company_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_Company_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_Company_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_Company_NKE(RecId, Id, CompanyId, CompanyAccountId, PriceListFlag, TermsQuotationStdTxt, TermsWebshopStdTxt, Name
, "Timestamp", TermsPaymentId, TermsDeliveryNoteStdTxt, CustomerGroup, RebateDate, TermsOrderStdTxt, TermsDeliveryStdTxt
, TermsCreditNoteStdTxt, CountryId, SalesTurnover, RejectionFlag, PaymentDepositFlag, TermsInvoice, PurchasePaymentDepositFlag
, TermsPurchaseOrderStdTxt, LastOrderDate, PaymentDepositOverdueFlag, VATNumber, PurchaseTurnover, MinimumOrderValue, PurchaseVATCode
, CreditLimitAlert, AccountingMatchCode, CreditorCompanyAccountId, VATPersonsGroup, CreditorAccountNumber, CreditLimit, SalesVATCode
, AccountingExportFlag, PaymentMode, DebitCompanyAccountId, TaxCountryCode, DebitAccountNumber, SupplierFlag, AccountPayable, PreviousYear
, CreditorAccountingExportStatus, PurchaseCurrencyCode, PriceCode, GlobalRebate, DebitAccountingExportStatus, RevenueGroup, AccountReceivable
, CustomerFlag, Tolerance, CurrencyCode, EuroPrintFlag, BankAccountNumber, MaterialSurcharge, AllAccountsFlag, DunningGroup, ThirdPartyPostingDate
, Upduser, Insuser, BankAccounting, MaterialSurchargeDeductionFlag, BonusCollectionFlag, BankId, DebitAccountingExportStatus2, Upddate, Insdate, URL
, AbcAnalysisId, CustomerClassListId, CreditorAccountingExportStatus2, PurchasePaymentMode, CompetitorFlag, PotentialPercent, TaxNumber, Potential
, CompanyNumberOfEmployees, BankAccounting2, SuperordinateCompanyId, AbcClassification, CompanyTurnover, TipSalesAgreementFlag, IBAN, RevenueAccount
, PriceCompanyId, TipSalesOrderFlag, CreditorTemplate, CustomerReferenceNumber, TipSalesQuotationFlag, PartialDeliveryFlag, AccountPreInput
, PurchasePriceCompanyId, TipGoodsIssueFlag, TermsAccountingInvoice, DebitTemplate, NKE_VATNumberCheckUserId, TipGoodsReceiptFlag, TipPurchaseInquiryFlag
, TipSalesInvoiceFlag, NKE_IISContactId, TipServiceFlag, TipSales, NKE_VATNumberCheckDate, TipPurchaseSupplierInvoiceFlag, TipPurchaseOrderFlag
, TipPurchaseAgreementFlag, ClientId, NKE_CessionIndicator, TipPurchase, PurchaseCreditLimit, NaceCode, GUIDF, ANP_CreditorAlwaysExport, NKE_LbtContactEmail
, AccountingReportInformation, DunsNumber, NaceExtended, PackagingMaterialTakeOverFlag, SYNCMSCRM, NKE_AccountingContactPerson, ANP_DebtosAlwaysExport
, CommercialRegisterNumber, CustomerSince, NKE_QSDocument, NKE_PlaceOfJurisdiction, NKE_AccountingContactEmail, NKE_FactoringFlag, PurchaseGlobalRebate
, NKE_SCR_ServiceFee, SupplierRatingScore, NKE_ApplicableLaw, NKE_GuaranteePeriod, NKE_ProspectFlag, NKE_TanListFlag, TipPurchaseReturnFlag, SupplierRatingLastDate,
SupplierRatingClass, DeliveryWeekMode, CorrespondingAccountNumbersFlag, NKE_WebshopRebate, AttributeClassId, DeliveryThursdayFlag, DeliverySautrdayFlag
, DeliveryTuesdayFlag, DeliverySundayFlag, DeliveryMondayFlag, DebitBusinessPartnerFlag, GUID, SupplierReferenceNumber, DeliveryFridayFlag, DeliveryWednesdayFlag
, RecDateEnd, LinkSalesBeat, LegalSuccessor, CountryISONumeric, RecDateReport, NKE_NoQSInspectionFlag, NKE_VATNumberNonEU, NKE_EoriNumber, GaebFormatMode
, GaebFormatExportMode, RecActive, TipSalesMaintenanceFlag, RecDateSync, RecDateStart, SrcRecId, RecCountModified, RecUserCreated, ANP_AttachDrawingsToMail
, RecDateCreated, BELEGHEADERIMG, SrcRecVersion, SrcRecLocationId, RecUserModified, RecDateModified, BlockedFlag, SPERRUSER, SrcRecTimestamp
, BELEGFOOTERIMG, ANP_CompanyQualityCategoryId, SPERRDATE, GF1, ANP_FACTORINGREF, SPERRGRUND, GF2)
SELECT RecId, Id, CompanyId, CompanyAccountId, PriceListFlag, TermsQuotationStdTxt, TermsWebshopStdTxt, Name
, "Timestamp", TermsPaymentId, TermsDeliveryNoteStdTxt, CustomerGroup, RebateDate, TermsOrderStdTxt, TermsDeliveryStdTxt
, TermsCreditNoteStdTxt, CountryId, SalesTurnover, RejectionFlag, PaymentDepositFlag, TermsInvoice, PurchasePaymentDepositFlag
, TermsPurchaseOrderStdTxt, LastOrderDate, PaymentDepositOverdueFlag, VATNumber, PurchaseTurnover, MinimumOrderValue, PurchaseVATCode
, CreditLimitAlert, AccountingMatchCode, CreditorCompanyAccountId, VATPersonsGroup, CreditorAccountNumber, CreditLimit, SalesVATCode
, AccountingExportFlag, PaymentMode, DebitCompanyAccountId, TaxCountryCode, DebitAccountNumber, SupplierFlag, AccountPayable, PreviousYear
, CreditorAccountingExportStatus, PurchaseCurrencyCode, PriceCode, GlobalRebate, DebitAccountingExportStatus, RevenueGroup, AccountReceivable
, CustomerFlag, Tolerance, CurrencyCode, EuroPrintFlag, BankAccountNumber, MaterialSurcharge, AllAccountsFlag, DunningGroup, ThirdPartyPostingDate
, Upduser, Insuser, BankAccounting, MaterialSurchargeDeductionFlag, BonusCollectionFlag, BankId, DebitAccountingExportStatus2, Upddate, Insdate, URL
, AbcAnalysisId, CustomerClassListId, CreditorAccountingExportStatus2, PurchasePaymentMode, CompetitorFlag, PotentialPercent, TaxNumber, Potential
, CompanyNumberOfEmployees, BankAccounting2, SuperordinateCompanyId, AbcClassification, CompanyTurnover, TipSalesAgreementFlag, IBAN, RevenueAccount
, PriceCompanyId, TipSalesOrderFlag, CreditorTemplate, CustomerReferenceNumber, TipSalesQuotationFlag, PartialDeliveryFlag, AccountPreInput
, PurchasePriceCompanyId, TipGoodsIssueFlag, TermsAccountingInvoice, DebitTemplate, NKE_VATNumberCheckUserId, TipGoodsReceiptFlag, TipPurchaseInquiryFlag
, TipSalesInvoiceFlag, NKE_IISContactId, TipServiceFlag, TipSales, NKE_VATNumberCheckDate, TipPurchaseSupplierInvoiceFlag, TipPurchaseOrderFlag
, TipPurchaseAgreementFlag, ClientId, NKE_CessionIndicator, TipPurchase, PurchaseCreditLimit, NaceCode, GUIDF, ANP_CreditorAlwaysExport, NKE_LbtContactEmail
, AccountingReportInformation, DunsNumber, NaceExtended, PackagingMaterialTakeOverFlag, SYNCMSCRM, NKE_AccountingContactPerson, ANP_DebtosAlwaysExport
, CommercialRegisterNumber, CustomerSince, NKE_QSDocument, NKE_PlaceOfJurisdiction, NKE_AccountingContactEmail, NKE_FactoringFlag, PurchaseGlobalRebate
, NKE_SCR_ServiceFee, SupplierRatingScore, NKE_ApplicableLaw, NKE_GuaranteePeriod, NKE_ProspectFlag, NKE_TanListFlag, TipPurchaseReturnFlag, SupplierRatingLastDate,
SupplierRatingClass, DeliveryWeekMode, CorrespondingAccountNumbersFlag, NKE_WebshopRebate, AttributeClassId, DeliveryThursdayFlag, DeliverySautrdayFlag
, DeliveryTuesdayFlag, DeliverySundayFlag, DeliveryMondayFlag, DebitBusinessPartnerFlag, GUID, SupplierReferenceNumber, DeliveryFridayFlag, DeliveryWednesdayFlag
, RecDateEnd, LinkSalesBeat, LegalSuccessor, CountryISONumeric, RecDateReport, NKE_NoQSInspectionFlag, NKE_VATNumberNonEU, NKE_EoriNumber, GaebFormatMode
, GaebFormatExportMode, RecActive, TipSalesMaintenanceFlag, RecDateSync, RecDateStart, SrcRecId, RecCountModified, RecUserCreated, ANP_AttachDrawingsToMail
, RecDateCreated, BELEGHEADERIMG, SrcRecVersion, SrcRecLocationId, RecUserModified, RecDateModified, BlockedFlag, SPERRUSER, SrcRecTimestamp
, BELEGFOOTERIMG, ANP_CompanyQualityCategoryId, SPERRDATE, GF1, ANP_FACTORINGREF, SPERRGRUND, GF2
FROM nkeTempIncremental.ds_Company_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Company_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Company_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_Company_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_Company_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_Company_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Company_NKE');
*/