--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_CompanyAccount_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_CompanyAccount_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_CompanyAccount_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_CompanyAccount_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_CompanyAccount_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_CompanyAccount_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_CompanyAccount_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_CompanyAccount_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_CompanyAccount_NKE (CompanyAccountId, Id, CompanyAccountName1, CompanyAccountName3, RecId, Industry, NameShort, CompanyAccountName2
, "Timestamp", CompanyId, DepartmentId, Name, Street, PhoneCell, City, Phone, Region, Street2, CountryText
, CustomerFlag, PostCode2, Email, Fax, CountryCode, PostCode, BlockedFlag, SupplierFlag, RepresentativeChecked
, RepresentativeId, "Language", DeliveryCompanyAccountId, InfoFlag, CustomerReferenceNumber, "Function", CollectiveInvoiceFlag
, InvoiceCompanyAccountId, StaffId, FollowUp, Notes, CountryId, AccountingExportFlag, ProspectFlag, Insdate, InvoiceFlag,
 PostBox, Upddate, Layout, RepresentativeI2Id, Upduser, PaymentCycleMode, DeliveryFlag, Insuser, Accounting2CompanyAccountId, Password,
  AccountingCompanyAccountId, SalesConsignmentWarehouseId, ObjectGUID, Homepage, NameFirst, ForwarderFlag, TransportPartner, ShippingMode
  , TransportMeans, SalesConsignmentWarehouseBinId, ObjectClass, StaffFlag, NameLast, ForwarderCompanyAccountId, TargetGroup, VATNumber
  , Salutation, ShippingFactoryPostCode, VDAShippingMode, GeoCode, NameContact, TransportMeansNumber, NKE_Percent, Title, BirthDate, TruckType
  , TransportTime, ServiceBlockedFlag, TransportVehicleRegistration, NKE_ShippingFlag, NKE_PrivateFlag, NKE_AdministrativeDistrict, NKE_FactoryCode
  , NKE_PriceLIst, NKE_VATNumberCreatedDate, Nke_Percent2, NKE_PostBox, NKE_NativeLanguage, NKE_StockList, NKE_BlockedMode, NKE_InfoMaterial
  , NKE_VATNumberCreatedUserId, NKE_FactoryFlag, DominoVersionId, DominoBlockedFlag, NKE_VATNumberCheckUserId, NKE_IISEmployeeId, NKE_PriceInfoFlag
  , DominoLastCheckDate, NKE_CustomsTariffNumberFlag, ElectronicInvoiceFlag, DominoServiceBlockedFlag, NKE_VATNumberCheckDate, NKE_CustomsTariffNumber1Flag
  , NoEmbargoCheckFlag, DominoMatchcode, NKE_IISStaffId, Carrier, ClientId, NKE_AreaRepresentativelId, NKE_BudgetCompanyAccountId, NKE_PrintCountryOfOriginFlag
  , SamplesWarehouseId, BEXEmbargoVer, NoCompanyGoupSelectionFlag, GUIDA, NKE_Segment, NKE_BudgetName, NKE_PrintPreferentialCountryOfOriginFlag
  , SamplesWarehouseBinId, NKE_BudgetFlag, PackagingMaterialCompanyAccountId, TipSalesOrderFlag, ILN, SYNCMSCRM, NoIntrastatFlag, TipPurchase, GUIDK
  , TipSales, TipGoodsIssueFlag, SendShippingFlag, MOFID, NKE_PrintProductNameFlag, TipSalesQuotationFlag, NoContactFlag, NKE_TransportTime
  , NKE_MarketingNotes, TipPurchaseOrderFlag, TipServiceFlag, TipGoodsReceiptFlag, NKE_DistributorLogin, TipSalesReturnFlag, NKE_VATTextMode
  , TipPurchaseOrderProposalFlag, TipPurchaseInquiryFlag, TipPurchaseSupplierInvoiceFlag, NKE_ProspectMode, NKE_AccountCountryEqualsCountryOfOriginFlag
  , TipSalesInvoiceFlag, PrintCustomsNumberFlag, SupplierRatingScore, GUID, OrdersId, Master, ForwarderAgentCodeUpdate, NKE_DeliveryUnloadingLocation
  , SupplierRatingLastDate, AgencyCode, SupplierRatingClass, PostBoxPostCode, TipPurchaseReturnFlag, ForwarderAgentName, NKE_DeliveryUnloadingPoint
  , NKE_PostalInvoiceFlag, CustomerClassId, ANP_UrgentFlag, NewsletterConfirmedFlag, ProspectClassId, DeliveryDateCalculationMode, NKE_TanListFlag
  , NewsletterFlag, DeliveryWeekMode, DataSource, Representative3Id, NewsletterDoubleOptInFlag, InitialContact, NKE_WebshopCustomerFlag, DeliverySundayFlag
  , Floor, DeliveryWednesdayFlag, DeliveryFridayFlag, SkypeName, CentralRegulatorCompanyAccountId, DeliveryMondayFlag, DeliveryThursdayFlag, AttributeClassId
  , Apartment, DeliverySautrdayFlag, SupplierReferenceNumber, Building, DeliveryTuesdayFlag, District, FederalCountry, RecDateStart, TipSalesMaintenanceFlag
  , ANP_DeliveryNoteBarcodeFlag, ANP_ShippingNotificationFlag, "Zone", Province, ANP_InvoiceEmailFlag, RecDateEnd, DunsNumber, ANP_InvoiceEmailAddress
  , ANP_PackingListMode, Direction, RecDateSync, RecUserModified, EINVOICE_DISPATCH, RecDateModified, SrcRecLocationId, SrcRecTimestamp, RecActive,
   RecDateReport, RecDateCreated, RecUserCreated, RecCountModified, EINVOICE_INTERFACE, SrcRecId, SrcRecVersion, FGESPERRT, GEOX, LEITWEGID, USTIDERGEBNIS,
    ANP_EMAILADRLIEFERAVIS, USTIDLOG, USTIDLOGTEXT, GEOY, FSERVICEGESPERRT, TEAMSNAME, USTIDGUELTIG, ANP_EMAILSQD, USTIDLOGDATUM, USTIDNOPRUEF, ANP_PFICustomerFlag)
SELECT CompanyAccountId, Id, CompanyAccountName1, CompanyAccountName3, RecId, Industry, NameShort, CompanyAccountName2
, "Timestamp", CompanyId, DepartmentId, Name, Street, PhoneCell, City, Phone, Region, Street2, CountryText
, CustomerFlag, PostCode2, Email, Fax, CountryCode, PostCode, BlockedFlag, SupplierFlag, RepresentativeChecked
, RepresentativeId, "Language", DeliveryCompanyAccountId, InfoFlag, CustomerReferenceNumber, "Function", CollectiveInvoiceFlag
, InvoiceCompanyAccountId, StaffId, FollowUp, Notes, CountryId, AccountingExportFlag, ProspectFlag, Insdate, InvoiceFlag,
 PostBox, Upddate, Layout, RepresentativeI2Id, Upduser, PaymentCycleMode, DeliveryFlag, Insuser, Accounting2CompanyAccountId, Password,
  AccountingCompanyAccountId, SalesConsignmentWarehouseId, ObjectGUID, Homepage, NameFirst, ForwarderFlag, TransportPartner, ShippingMode
  , TransportMeans, SalesConsignmentWarehouseBinId, ObjectClass, StaffFlag, NameLast, ForwarderCompanyAccountId, TargetGroup, VATNumber
  , Salutation, ShippingFactoryPostCode, VDAShippingMode, GeoCode, NameContact, TransportMeansNumber, NKE_Percent, Title, BirthDate, TruckType
  , TransportTime, ServiceBlockedFlag, TransportVehicleRegistration, NKE_ShippingFlag, NKE_PrivateFlag, NKE_AdministrativeDistrict, NKE_FactoryCode
  , NKE_PriceLIst, NKE_VATNumberCreatedDate, Nke_Percent2, NKE_PostBox, NKE_NativeLanguage, NKE_StockList, NKE_BlockedMode, NKE_InfoMaterial
  , NKE_VATNumberCreatedUserId, NKE_FactoryFlag, DominoVersionId, DominoBlockedFlag, NKE_VATNumberCheckUserId, NKE_IISEmployeeId, NKE_PriceInfoFlag
  , DominoLastCheckDate, NKE_CustomsTariffNumberFlag, ElectronicInvoiceFlag, DominoServiceBlockedFlag, NKE_VATNumberCheckDate, NKE_CustomsTariffNumber1Flag
  , NoEmbargoCheckFlag, DominoMatchcode, NKE_IISStaffId, Carrier, ClientId, NKE_AreaRepresentativelId, NKE_BudgetCompanyAccountId, NKE_PrintCountryOfOriginFlag
  , SamplesWarehouseId, BEXEmbargoVer, NoCompanyGoupSelectionFlag, GUIDA, NKE_Segment, NKE_BudgetName, NKE_PrintPreferentialCountryOfOriginFlag
  , SamplesWarehouseBinId, NKE_BudgetFlag, PackagingMaterialCompanyAccountId, TipSalesOrderFlag, ILN, SYNCMSCRM, NoIntrastatFlag, TipPurchase, GUIDK
  , TipSales, TipGoodsIssueFlag, SendShippingFlag, MOFID, NKE_PrintProductNameFlag, TipSalesQuotationFlag, NoContactFlag, NKE_TransportTime
  , NKE_MarketingNotes, TipPurchaseOrderFlag, TipServiceFlag, TipGoodsReceiptFlag, NKE_DistributorLogin, TipSalesReturnFlag, NKE_VATTextMode
  , TipPurchaseOrderProposalFlag, TipPurchaseInquiryFlag, TipPurchaseSupplierInvoiceFlag, NKE_ProspectMode, NKE_AccountCountryEqualsCountryOfOriginFlag
  , TipSalesInvoiceFlag, PrintCustomsNumberFlag, SupplierRatingScore, GUID, OrdersId, Master, ForwarderAgentCodeUpdate, NKE_DeliveryUnloadingLocation
  , SupplierRatingLastDate, AgencyCode, SupplierRatingClass, PostBoxPostCode, TipPurchaseReturnFlag, ForwarderAgentName, NKE_DeliveryUnloadingPoint
  , NKE_PostalInvoiceFlag, CustomerClassId, ANP_UrgentFlag, NewsletterConfirmedFlag, ProspectClassId, DeliveryDateCalculationMode, NKE_TanListFlag
  , NewsletterFlag, DeliveryWeekMode, DataSource, Representative3Id, NewsletterDoubleOptInFlag, InitialContact, NKE_WebshopCustomerFlag, DeliverySundayFlag
  , Floor, DeliveryWednesdayFlag, DeliveryFridayFlag, SkypeName, CentralRegulatorCompanyAccountId, DeliveryMondayFlag, DeliveryThursdayFlag, AttributeClassId
  , Apartment, DeliverySautrdayFlag, SupplierReferenceNumber, Building, DeliveryTuesdayFlag, District, FederalCountry, RecDateStart, TipSalesMaintenanceFlag
  , ANP_DeliveryNoteBarcodeFlag, ANP_ShippingNotificationFlag, "Zone", Province, ANP_InvoiceEmailFlag, RecDateEnd, DunsNumber, ANP_InvoiceEmailAddress
  , ANP_PackingListMode, Direction::int, RecDateSync, RecUserModified, EINVOICE_DISPATCH, RecDateModified, SrcRecLocationId, SrcRecTimestamp, RecActive,
   RecDateReport, RecDateCreated, RecUserCreated, RecCountModified, EINVOICE_INTERFACE, SrcRecId, SrcRecVersion, FGESPERRT, GEOX, LEITWEGID, USTIDERGEBNIS,
    ANP_EMAILADRLIEFERAVIS, USTIDLOG, USTIDLOGTEXT, GEOY, FSERVICEGESPERRT, TEAMSNAME, USTIDGUELTIG, ANP_EMAILSQD, USTIDLOGDATUM, USTIDNOPRUEF, ANP_PFICustomerFlag
FROM	nkeTempIncremental.ds_CompanyAccount_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_CompanyAccount_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_CompanyAccount_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_CompanyAccount_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_CompanyAccount_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_CompanyAccount_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_CompanyAccount_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_CompanyAccount_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_CompanyAccount_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_CompanyAccount_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_CompanyAccount_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_CompanyAccount_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_CompanyAccount_NKE WHERE ID IS NOT NULL);


--2. Insert only modified rows.              
INSERT INTO nkeds.ds_CompanyAccount_NKE(CompanyAccountId, Id, CompanyAccountName1, CompanyAccountName3, RecId, Industry, NameShort, CompanyAccountName2
, "Timestamp", CompanyId, DepartmentId, Name, Street, PhoneCell, City, Phone, Region, Street2, CountryText
, CustomerFlag, PostCode2, Email, Fax, CountryCode, PostCode, BlockedFlag, SupplierFlag, RepresentativeChecked
, RepresentativeId, "Language", DeliveryCompanyAccountId, InfoFlag, CustomerReferenceNumber, "Function", CollectiveInvoiceFlag
, InvoiceCompanyAccountId, StaffId, FollowUp, Notes, CountryId, AccountingExportFlag, ProspectFlag, Insdate, InvoiceFlag,
 PostBox, Upddate, Layout, RepresentativeI2Id, Upduser, PaymentCycleMode, DeliveryFlag, Insuser, Accounting2CompanyAccountId, Password,
  AccountingCompanyAccountId, SalesConsignmentWarehouseId, ObjectGUID, Homepage, NameFirst, ForwarderFlag, TransportPartner, ShippingMode
  , TransportMeans, SalesConsignmentWarehouseBinId, ObjectClass, StaffFlag, NameLast, ForwarderCompanyAccountId, TargetGroup, VATNumber
  , Salutation, ShippingFactoryPostCode, VDAShippingMode, GeoCode, NameContact, TransportMeansNumber, NKE_Percent, Title, BirthDate, TruckType
  , TransportTime, ServiceBlockedFlag, TransportVehicleRegistration, NKE_ShippingFlag, NKE_PrivateFlag, NKE_AdministrativeDistrict, NKE_FactoryCode
  , NKE_PriceLIst, NKE_VATNumberCreatedDate, Nke_Percent2, NKE_PostBox, NKE_NativeLanguage, NKE_StockList, NKE_BlockedMode, NKE_InfoMaterial
  , NKE_VATNumberCreatedUserId, NKE_FactoryFlag, DominoVersionId, DominoBlockedFlag, NKE_VATNumberCheckUserId, NKE_IISEmployeeId, NKE_PriceInfoFlag
  , DominoLastCheckDate, NKE_CustomsTariffNumberFlag, ElectronicInvoiceFlag, DominoServiceBlockedFlag, NKE_VATNumberCheckDate, NKE_CustomsTariffNumber1Flag
  , NoEmbargoCheckFlag, DominoMatchcode, NKE_IISStaffId, Carrier, ClientId, NKE_AreaRepresentativelId, NKE_BudgetCompanyAccountId, NKE_PrintCountryOfOriginFlag
  , SamplesWarehouseId, BEXEmbargoVer, NoCompanyGoupSelectionFlag, GUIDA, NKE_Segment, NKE_BudgetName, NKE_PrintPreferentialCountryOfOriginFlag
  , SamplesWarehouseBinId, NKE_BudgetFlag, PackagingMaterialCompanyAccountId, TipSalesOrderFlag, ILN, SYNCMSCRM, NoIntrastatFlag, TipPurchase, GUIDK
  , TipSales, TipGoodsIssueFlag, SendShippingFlag, MOFID, NKE_PrintProductNameFlag, TipSalesQuotationFlag, NoContactFlag, NKE_TransportTime
  , NKE_MarketingNotes, TipPurchaseOrderFlag, TipServiceFlag, TipGoodsReceiptFlag, NKE_DistributorLogin, TipSalesReturnFlag, NKE_VATTextMode
  , TipPurchaseOrderProposalFlag, TipPurchaseInquiryFlag, TipPurchaseSupplierInvoiceFlag, NKE_ProspectMode, NKE_AccountCountryEqualsCountryOfOriginFlag
  , TipSalesInvoiceFlag, PrintCustomsNumberFlag, SupplierRatingScore, GUID, OrdersId, Master, ForwarderAgentCodeUpdate, NKE_DeliveryUnloadingLocation
  , SupplierRatingLastDate, AgencyCode, SupplierRatingClass, PostBoxPostCode, TipPurchaseReturnFlag, ForwarderAgentName, NKE_DeliveryUnloadingPoint
  , NKE_PostalInvoiceFlag, CustomerClassId, ANP_UrgentFlag, NewsletterConfirmedFlag, ProspectClassId, DeliveryDateCalculationMode, NKE_TanListFlag
  , NewsletterFlag, DeliveryWeekMode, DataSource, Representative3Id, NewsletterDoubleOptInFlag, InitialContact, NKE_WebshopCustomerFlag, DeliverySundayFlag
  , Floor, DeliveryWednesdayFlag, DeliveryFridayFlag, SkypeName, CentralRegulatorCompanyAccountId, DeliveryMondayFlag, DeliveryThursdayFlag, AttributeClassId
  , Apartment, DeliverySautrdayFlag, SupplierReferenceNumber, Building, DeliveryTuesdayFlag, District, FederalCountry, RecDateStart, TipSalesMaintenanceFlag
  , ANP_DeliveryNoteBarcodeFlag, ANP_ShippingNotificationFlag, "Zone", Province, ANP_InvoiceEmailFlag, RecDateEnd, DunsNumber, ANP_InvoiceEmailAddress
  , ANP_PackingListMode, Direction, RecDateSync, RecUserModified, EINVOICE_DISPATCH, RecDateModified, SrcRecLocationId, SrcRecTimestamp, RecActive,
   RecDateReport, RecDateCreated, RecUserCreated, RecCountModified, EINVOICE_INTERFACE, SrcRecId, SrcRecVersion, FGESPERRT, GEOX, LEITWEGID, USTIDERGEBNIS,
    ANP_EMAILADRLIEFERAVIS, USTIDLOG, USTIDLOGTEXT, GEOY, FSERVICEGESPERRT, TEAMSNAME, USTIDGUELTIG, ANP_EMAILSQD, USTIDLOGDATUM, USTIDNOPRUEF)
SELECT CompanyAccountId, Id, CompanyAccountName1, CompanyAccountName3, RecId, Industry, NameShort, CompanyAccountName2
, "Timestamp", CompanyId, DepartmentId, Name, Street, PhoneCell, City, Phone, Region, Street2, CountryText
, CustomerFlag, PostCode2, Email, Fax, CountryCode, PostCode, BlockedFlag, SupplierFlag, RepresentativeChecked
, RepresentativeId, "Language", DeliveryCompanyAccountId, InfoFlag, CustomerReferenceNumber, "Function", CollectiveInvoiceFlag
, InvoiceCompanyAccountId, StaffId, FollowUp, Notes, CountryId, AccountingExportFlag, ProspectFlag, Insdate, InvoiceFlag,
 PostBox, Upddate, Layout, RepresentativeI2Id, Upduser, PaymentCycleMode, DeliveryFlag, Insuser, Accounting2CompanyAccountId, Password,
  AccountingCompanyAccountId, SalesConsignmentWarehouseId, ObjectGUID, Homepage, NameFirst, ForwarderFlag, TransportPartner, ShippingMode
  , TransportMeans, SalesConsignmentWarehouseBinId, ObjectClass, StaffFlag, NameLast, ForwarderCompanyAccountId, TargetGroup, VATNumber
  , Salutation, ShippingFactoryPostCode, VDAShippingMode, GeoCode, NameContact, TransportMeansNumber, NKE_Percent, Title, BirthDate, TruckType
  , TransportTime, ServiceBlockedFlag, TransportVehicleRegistration, NKE_ShippingFlag, NKE_PrivateFlag, NKE_AdministrativeDistrict, NKE_FactoryCode
  , NKE_PriceLIst, NKE_VATNumberCreatedDate, Nke_Percent2, NKE_PostBox, NKE_NativeLanguage, NKE_StockList, NKE_BlockedMode, NKE_InfoMaterial
  , NKE_VATNumberCreatedUserId, NKE_FactoryFlag, DominoVersionId, DominoBlockedFlag, NKE_VATNumberCheckUserId, NKE_IISEmployeeId, NKE_PriceInfoFlag
  , DominoLastCheckDate, NKE_CustomsTariffNumberFlag, ElectronicInvoiceFlag, DominoServiceBlockedFlag, NKE_VATNumberCheckDate, NKE_CustomsTariffNumber1Flag
  , NoEmbargoCheckFlag, DominoMatchcode, NKE_IISStaffId, Carrier, ClientId, NKE_AreaRepresentativelId, NKE_BudgetCompanyAccountId, NKE_PrintCountryOfOriginFlag
  , SamplesWarehouseId, BEXEmbargoVer, NoCompanyGoupSelectionFlag, GUIDA, NKE_Segment, NKE_BudgetName, NKE_PrintPreferentialCountryOfOriginFlag
  , SamplesWarehouseBinId, NKE_BudgetFlag, PackagingMaterialCompanyAccountId, TipSalesOrderFlag, ILN, SYNCMSCRM, NoIntrastatFlag, TipPurchase, GUIDK
  , TipSales, TipGoodsIssueFlag, SendShippingFlag, MOFID, NKE_PrintProductNameFlag, TipSalesQuotationFlag, NoContactFlag, NKE_TransportTime
  , NKE_MarketingNotes, TipPurchaseOrderFlag, TipServiceFlag, TipGoodsReceiptFlag, NKE_DistributorLogin, TipSalesReturnFlag, NKE_VATTextMode
  , TipPurchaseOrderProposalFlag, TipPurchaseInquiryFlag, TipPurchaseSupplierInvoiceFlag, NKE_ProspectMode, NKE_AccountCountryEqualsCountryOfOriginFlag
  , TipSalesInvoiceFlag, PrintCustomsNumberFlag, SupplierRatingScore, GUID, OrdersId, Master, ForwarderAgentCodeUpdate, NKE_DeliveryUnloadingLocation
  , SupplierRatingLastDate, AgencyCode, SupplierRatingClass, PostBoxPostCode, TipPurchaseReturnFlag, ForwarderAgentName, NKE_DeliveryUnloadingPoint
  , NKE_PostalInvoiceFlag, CustomerClassId, ANP_UrgentFlag, NewsletterConfirmedFlag, ProspectClassId, DeliveryDateCalculationMode, NKE_TanListFlag
  , NewsletterFlag, DeliveryWeekMode, DataSource, Representative3Id, NewsletterDoubleOptInFlag, InitialContact, NKE_WebshopCustomerFlag, DeliverySundayFlag
  , Floor, DeliveryWednesdayFlag, DeliveryFridayFlag, SkypeName, CentralRegulatorCompanyAccountId, DeliveryMondayFlag, DeliveryThursdayFlag, AttributeClassId
  , Apartment, DeliverySautrdayFlag, SupplierReferenceNumber, Building, DeliveryTuesdayFlag, District, FederalCountry, RecDateStart, TipSalesMaintenanceFlag
  , ANP_DeliveryNoteBarcodeFlag, ANP_ShippingNotificationFlag, "Zone", Province, ANP_InvoiceEmailFlag, RecDateEnd, DunsNumber, ANP_InvoiceEmailAddress
  , ANP_PackingListMode, Direction::int, RecDateSync, RecUserModified, EINVOICE_DISPATCH, RecDateModified, SrcRecLocationId, SrcRecTimestamp, RecActive,
   RecDateReport, RecDateCreated, RecUserCreated, RecCountModified, EINVOICE_INTERFACE, SrcRecId, SrcRecVersion, FGESPERRT, GEOX, LEITWEGID, USTIDERGEBNIS,
    ANP_EMAILADRLIEFERAVIS, USTIDLOG, USTIDLOGTEXT, GEOY, FSERVICEGESPERRT, TEAMSNAME, USTIDGUELTIG, ANP_EMAILSQD, USTIDLOGDATUM, USTIDNOPRUEF
FROM nkeTempIncremental.ds_CompanyAccount_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_CompanyAccount_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_CompanyAccount_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_CompanyAccount_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_CompanyAccount_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_CompanyAccount_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_CompanyAccount_NKE');
*/