--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_Item_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_Item_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_Item_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_Item_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_Item_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_Item_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_Item_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_Item_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_Item_NKE (RecId, ItemId, DIN, Id, DrawingNumber, PurchaseFlag, ProductionRoutingFlag, Name, SalesFlag
, "Timestamp", Tool, ProductionFlag, ProductionBomFlag, NoDeliveryNoteFlag, DispoWarehouseFlag, ReplacementFlag
, NoDispoFlag, GoodsReceiptInspectionFlag, PostingMandadortyFlag, ItemGroupId, BatchFlag, DispoOrderFlag
, SerialNumberFlag, NoStockFlag, RawMaterialFlag, IventoryPhysicalId, RebateGroupId, CostCenterId, PriceGroupId
, SalesDimensions, ExpenseAccount, Dimensions, PackagingQuantity, TaxCode, ConsumptionUoMId, RevenueAccount
, PriceUoMId, FreightCostsAccountId, SalesUoMId, Net, NoRebateFlag, DispoStaffId, CommissionFlag, CountryOfOrigin
, AssemblyTime, MinOrderQuantity, PreferenceFlag, WarehouseId, CompanyAccountId, PurchaseStaffId, FederalCountryOfOrigin
, StaffId, CustomsTariffId, WarehouseBinId, Weight, MaxOrderQuantity, StockReportingQuantity, MaterialConsumptionABC
, MinStockQuantity, StockABC, WarehouseCostRate, OrderRhythm, Material, WasteFactor, MaterialRequirementsABC, OrderQuantity
, MaxStockQuantity, MaterialRequirementsQuantity, ReplenishmentTime, AlternativeRoutingFlag, Upduser, OrderPostingFlag
, Insuser, Config, ProvisionMode, Variants, AlternativeBomFlag, Upddate, PreCutFlag, Insdate, PreviewFlag, ProvisionTime
, AttributeClassId, PlanningItemFlag, CostingGroupId, SupplierRatingLastDate, DeliveryCostsFlag, SupplierRatingClass
, RevisionIndexId, NoContributionMarginFlag, ProductionLevel, SupplierRatingScore, NoSupplierRatingFlag, BonusFlag
, RatingFlag, RoundingMode, SupplierRatingId, OldPrice, NoOrderBomFlag, ReplacementKit, CostElementId, CADDate
, NoStatisticsFlag, Documents, StockConstantQuantity, Difference, SuccessorItem, CatalogGroupId, CADUser, EANCode
, DispoRunPlanMode, StackingFactor, NoProtocollFlag, PricePQuantity, RentalItemFlag, MaterialTagType, ItemMaintenanceRate
, Width, RecyclingMode, TariffRate, "Length", ConfigMode, ItemMaintenanceGroupId, ItemMaintenanceGuaranteeRate, Height
, MaxWeight, ItemExtraRate, VSFlag, PlanningDecimalPlace, AutoWithdrawalFlag, PackagingMaterialFlag, CADItemFlag
, PseudoBomFlag, PlanningEstimateMode, P2PlusSystemFlag, CostGroupId, AutoReceiptFlag, OperatingResource, PackFlag
, SuccessorItemId, OperationResourceUniqueKeyFlag, DevaluationDefinitionId, HazardousMaterialCode, WearPartFlag
, ProvisionLineFlag, IncompleteFlag, AlternativeItemId, MinBatchSize, CompleteDispoFlag, PreferenceStatusMode
, NoWarehousePlanRunFlag, NoIntrastatFlag, PredecessorItemId, NKE_Width, ServiceFlag, SurchargeSet, OverheadCostGroupId
, NKE_PriceBase, NKE_MadeInAustriaFlag, NKE_BoreDiameter, DirectDeliveryFlag, NKE_ItemRangeId, ItemType, NoPaymentDepositFlag
, NKE_ComponentFlag, NKE_InternalSalesPriceListFlag, NKE_OuterDiameter, NKE_NameBMD, NKE_LabelCode, NKE_ItemTypeId
, NKE_AssemblyFlag, NKE_WidthInside, NKE_UnitsInBox, NKE_HouseSalesPriceListFlag, NKE_Duration, NKE_DiscontinuedFlag
, NKE_LengthInside, NKE_PackagingFlag, NKE_HeightInside, NKE_LargesizeBearingFlag, NKE_BookSalesPriceListFlag
, NKE_ColloFlag, NKE_MINAKLStock, NKE_TGWGEWKLFlag, PackagingTypeStdTxt, NKE_TGWWarehouseId, NKE_TGWPackagingItemFlag
, NKE_TGWLoadingAidDefinition, NKE_TGWSalesItemId, NKE_MaxAKLStock, NKE_MaxAKLContainer, NKE_TGWItemFlag
, NKE_TGWPackagingClass, NKE_TGWLoadingAidName, NKE_HighBayWarehouseFullOutFlag, NKE_MaxHeightInside
, NKE_PackagingTypeId, NKE_DismountableFlag, NKE_TGWSector, ClientId, NKE_NoStocklistFlag, NKE_InspectionPlanFlag
, NKE_NoQSInspectionFlag, NKE_PackagingItemId, NKE_ISO14001Flag, NKE_SerialNumberFlag, RentalFlag, NKE_Status
, NKE_ApprovedPackagingTypeId, SalesPlanFlag, BatchCardFlag, ThirdPartyCostElementId, DontDisposeFlag
, TipSalesAgreementFlag, TipSales, MaterialGroupId, SYNCMSCRM, InventoryPriceGroupingId, WarehouseCostRateUoMId
, TipPurchase, NoStatistics, WorkstationAutoPostingFlag, TipSalesQuotationFlag, TipServiceFlag
, TipPurchaseOrderProposalFlag, TipSalesReturnFlag, TipPurchaseSupplierInvoiceFlag, TipPurchaseInquiryFlag
, TipSalesOrderFlag, NKE_WeightCheckedFlag, TipPurchaseAgreementFlag, TipGoodsReceiptFlag, TipSalesInvoiceFlag
, PDMIdentNumber, TipPurchaseOrderFlag, TipGoodsIssueFlag, NKE_ClearanceLowerLimit, NKE_WebshopFlag, NKE_ItemTypeOld
, NKE_EnvelopingCircleTolerance, PlanningColour, NKE_StockColloFlag, NKE_ClearanceUpperLimit, ProductionValidTo
, NKE_WebshopActiveFlag, NKE_EnvelopingCircleType, ProductionStandardPriceUpdateFlag, NKE_ProductionDrawing
, NKE_WebshopRequest, NKE_EnvelopingCircle, ProductionValidFrom, NKE_ERPNew_Info, FollowUpBatchSize
, ANP_DeliveryCostElementId, NKE_Name_Fersa, NKE_DrawingConfirmedFlag, ItemStatus, NKE_WebshopNewItemFlag
, ANP_SalesTargetMarket, NKE_ItemNumber_Fersa, NKE_ItemId_Old, NKE_WeightClass, TipPurchaseReturnFlag
, InventoryPriceQuantity, NKE_WebshopOpportunityFlag, LLEFlag, LicensorId, LicenseMandatoryFlag, MaterialMESWithdrawalFlag
, GUID, BufferTime, AccountingGroupManuallyFlag, ProductionContainerUniqueFlag, QSMandatoryFlag, MaterialMESWithdrawalMode
, LicenseRate, AccountingGroupId, CostingQuantity, WeightManuallyFlag, ServiceApplicationFlag, OverheadCostGroupManuallyFlag
, NKE_ItemNamePurchase_Fersa, BatchSizeTimeHorizon, NKE_GreenRevenueFlag, BaseItemId, RecDateStart, ANP_CustomerProtectionFlag, MaxBatchSize
, RecDateEnd, RessanzFlag, StandardGEWLSTFlag, NKE_ABCSalesItem, NKE_ItemNumberPurchase_Fersa, SrcRecLocationId, RecActive, ANP_ItemQualityCategoryId
, RecDateModified, RecDateSync, SrcRecTimestamp, RecUserModified, RecUserCreated, SrcRecId, RecDateReport, ANP_ADLCode, RecDateCreated, SrcRecVersion
, RecCountModified, LABELN, PRAEFERENZKALKNR, ANP_ConstructionItemId
, ANP_IGNORESENDCILOG, NKE_FLAECHENLAST, PRAEFERENZAKTIV, NOPRAEFKALK, NKE_RANDLAST, ANP_DMC, DUALIS_OPTMERKMAL, PRAEFERENZKALK
, ANP_PFIFlag, ANP_PlannerGroup_FERSA, ANP_SBU_FERSA, ANP_SingleCartonType_FERSA, ANP_EANCodeMastercarton_FERSA, ANP_MastercartonType_FERSA
, NKE_MinimumSalesPrice, ANP_MinSalesOrderQuantity)
SELECT RecId, ItemId, DIN, Id, DrawingNumber, PurchaseFlag, ProductionRoutingFlag, Name, SalesFlag
, "Timestamp", Tool, ProductionFlag, ProductionBomFlag, NoDeliveryNoteFlag, DispoWarehouseFlag, ReplacementFlag
, NoDispoFlag, GoodsReceiptInspectionFlag, PostingMandadortyFlag, ItemGroupId, BatchFlag, DispoOrderFlag
, SerialNumberFlag, NoStockFlag, RawMaterialFlag, IventoryPhysicalId, RebateGroupId, CostCenterId, PriceGroupId
, SalesDimensions, ExpenseAccount, Dimensions, PackagingQuantity, TaxCode, ConsumptionUoMId, RevenueAccount
, PriceUoMId, FreightCostsAccountId, SalesUoMId, Net, NoRebateFlag, DispoStaffId, CommissionFlag, CountryOfOrigin
, AssemblyTime, MinOrderQuantity, PreferenceFlag, WarehouseId, CompanyAccountId, PurchaseStaffId, FederalCountryOfOrigin
, StaffId, CustomsTariffId, WarehouseBinId, Weight, MaxOrderQuantity, StockReportingQuantity, MaterialConsumptionABC
, MinStockQuantity, StockABC, WarehouseCostRate, OrderRhythm, Material, WasteFactor, MaterialRequirementsABC, OrderQuantity
, MaxStockQuantity, MaterialRequirementsQuantity, ReplenishmentTime, AlternativeRoutingFlag, Upduser, OrderPostingFlag
, Insuser, Config, ProvisionMode, Variants, AlternativeBomFlag, Upddate, PreCutFlag, Insdate, PreviewFlag, ProvisionTime
, AttributeClassId, PlanningItemFlag, CostingGroupId, SupplierRatingLastDate, DeliveryCostsFlag, SupplierRatingClass
, RevisionIndexId, NoContributionMarginFlag, ProductionLevel, SupplierRatingScore, NoSupplierRatingFlag, BonusFlag
, RatingFlag, RoundingMode, SupplierRatingId, OldPrice, NoOrderBomFlag, ReplacementKit, CostElementId, CADDate
, NoStatisticsFlag, Documents, StockConstantQuantity, Difference, SuccessorItem, CatalogGroupId, CADUser, EANCode
, DispoRunPlanMode, StackingFactor, NoProtocollFlag, PricePQuantity, RentalItemFlag, MaterialTagType, ItemMaintenanceRate
, Width, RecyclingMode, TariffRate, "Length", ConfigMode, ItemMaintenanceGroupId, ItemMaintenanceGuaranteeRate, Height
, MaxWeight, ItemExtraRate, VSFlag, PlanningDecimalPlace, AutoWithdrawalFlag, PackagingMaterialFlag, CADItemFlag
, PseudoBomFlag, PlanningEstimateMode, P2PlusSystemFlag, CostGroupId, AutoReceiptFlag, OperatingResource, PackFlag
, SuccessorItemId, OperationResourceUniqueKeyFlag, DevaluationDefinitionId, HazardousMaterialCode, WearPartFlag
, ProvisionLineFlag, IncompleteFlag, AlternativeItemId, MinBatchSize, CompleteDispoFlag, PreferenceStatusMode
, NoWarehousePlanRunFlag, NoIntrastatFlag, PredecessorItemId, NKE_Width, ServiceFlag, SurchargeSet, OverheadCostGroupId
, NKE_PriceBase, NKE_MadeInAustriaFlag, NKE_BoreDiameter, DirectDeliveryFlag, NKE_ItemRangeId, ItemType, NoPaymentDepositFlag
, NKE_ComponentFlag, NKE_InternalSalesPriceListFlag, NKE_OuterDiameter, NKE_NameBMD, NKE_LabelCode, NKE_ItemTypeId
, NKE_AssemblyFlag, NKE_WidthInside, NKE_UnitsInBox, NKE_HouseSalesPriceListFlag, NKE_Duration, NKE_DiscontinuedFlag
, NKE_LengthInside, NKE_PackagingFlag, NKE_HeightInside, NKE_LargesizeBearingFlag, NKE_BookSalesPriceListFlag
, NKE_ColloFlag, NKE_MINAKLStock, NKE_TGWGEWKLFlag, PackagingTypeStdTxt, NKE_TGWWarehouseId, NKE_TGWPackagingItemFlag
, NKE_TGWLoadingAidDefinition, NKE_TGWSalesItemId, NKE_MaxAKLStock, NKE_MaxAKLContainer, NKE_TGWItemFlag
, NKE_TGWPackagingClass, NKE_TGWLoadingAidName, NKE_HighBayWarehouseFullOutFlag, NKE_MaxHeightInside
, NKE_PackagingTypeId, NKE_DismountableFlag, NKE_TGWSector, ClientId, NKE_NoStocklistFlag, NKE_InspectionPlanFlag
, NKE_NoQSInspectionFlag, NKE_PackagingItemId, NKE_ISO14001Flag, NKE_SerialNumberFlag, RentalFlag, NKE_Status
, NKE_ApprovedPackagingTypeId, SalesPlanFlag, BatchCardFlag, ThirdPartyCostElementId, DontDisposeFlag
, TipSalesAgreementFlag, TipSales, MaterialGroupId, SYNCMSCRM, InventoryPriceGroupingId, WarehouseCostRateUoMId
, TipPurchase, NoStatistics, WorkstationAutoPostingFlag, TipSalesQuotationFlag, TipServiceFlag
, TipPurchaseOrderProposalFlag, TipSalesReturnFlag, TipPurchaseSupplierInvoiceFlag, TipPurchaseInquiryFlag
, TipSalesOrderFlag, NKE_WeightCheckedFlag, TipPurchaseAgreementFlag, TipGoodsReceiptFlag, TipSalesInvoiceFlag
, PDMIdentNumber, TipPurchaseOrderFlag, TipGoodsIssueFlag, NKE_ClearanceLowerLimit, NKE_WebshopFlag, NKE_ItemTypeOld
, NKE_EnvelopingCircleTolerance, PlanningColour, NKE_StockColloFlag, NKE_ClearanceUpperLimit, ProductionValidTo
, NKE_WebshopActiveFlag, NKE_EnvelopingCircleType, ProductionStandardPriceUpdateFlag, NKE_ProductionDrawing
, NKE_WebshopRequest, NKE_EnvelopingCircle, ProductionValidFrom, NKE_ERPNew_Info, FollowUpBatchSize
, ANP_DeliveryCostElementId, NKE_Name_Fersa, NKE_DrawingConfirmedFlag, ItemStatus, NKE_WebshopNewItemFlag
, ANP_SalesTargetMarket, NKE_ItemNumber_Fersa, NKE_ItemId_Old, NKE_WeightClass, TipPurchaseReturnFlag
, InventoryPriceQuantity, NKE_WebshopOpportunityFlag, LLEFlag, LicensorId, LicenseMandatoryFlag, MaterialMESWithdrawalFlag
, GUID, BufferTime, AccountingGroupManuallyFlag, ProductionContainerUniqueFlag, QSMandatoryFlag, MaterialMESWithdrawalMode
, LicenseRate, AccountingGroupId, CostingQuantity, WeightManuallyFlag, ServiceApplicationFlag, OverheadCostGroupManuallyFlag
, NKE_ItemNamePurchase_Fersa, BatchSizeTimeHorizon, NKE_GreenRevenueFlag, BaseItemId, RecDateStart, ANP_CustomerProtectionFlag, MaxBatchSize
, RecDateEnd, RessanzFlag, StandardGEWLSTFlag, NKE_ABCSalesItem, NKE_ItemNumberPurchase_Fersa, SrcRecLocationId, RecActive, ANP_ItemQualityCategoryId
, RecDateModified, RecDateSync, SrcRecTimestamp, RecUserModified, RecUserCreated, SrcRecId, RecDateReport, ANP_ADLCode, RecDateCreated, SrcRecVersion
, RecCountModified, LABELN, PRAEFERENZKALKNR, ANP_ConstructionItemId
, ANP_IGNORESENDCILOG, NKE_FLAECHENLAST, PRAEFERENZAKTIV, NOPRAEFKALK, NKE_RANDLAST, ANP_DMC, DUALIS_OPTMERKMAL, PRAEFERENZKALK
, ANP_PFIFlag, ANP_PlannerGroup_FERSA, ANP_SBU_FERSA, ANP_SingleCartonType_FERSA, ANP_EANCodeMastercarton_FERSA, ANP_MastercartonType_FERSA
, NKE_MinimumSalesPrice, ANP_MinSalesOrderQuantity
FROM	nkeTempIncremental.ds_Item_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_Item_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_Item_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_Item_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_Item_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_Item_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_Item_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_Item_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_Item_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Item_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_Item_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_Item_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_Item_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_Item_NKE(RecId, ItemId, DIN, Id, DrawingNumber, PurchaseFlag, ProductionRoutingFlag, Name, SalesFlag
, "Timestamp", Tool, ProductionFlag, ProductionBomFlag, NoDeliveryNoteFlag, DispoWarehouseFlag, ReplacementFlag
, NoDispoFlag, GoodsReceiptInspectionFlag, PostingMandadortyFlag, ItemGroupId, BatchFlag, DispoOrderFlag
, SerialNumberFlag, NoStockFlag, RawMaterialFlag, IventoryPhysicalId, RebateGroupId, CostCenterId, PriceGroupId
, SalesDimensions, ExpenseAccount, Dimensions, PackagingQuantity, TaxCode, ConsumptionUoMId, RevenueAccount
, PriceUoMId, FreightCostsAccountId, SalesUoMId, Net, NoRebateFlag, DispoStaffId, CommissionFlag, CountryOfOrigin
, AssemblyTime, MinOrderQuantity, PreferenceFlag, WarehouseId, CompanyAccountId, PurchaseStaffId, FederalCountryOfOrigin
, StaffId, CustomsTariffId, WarehouseBinId, Weight, MaxOrderQuantity, StockReportingQuantity, MaterialConsumptionABC
, MinStockQuantity, StockABC, WarehouseCostRate, OrderRhythm, Material, WasteFactor, MaterialRequirementsABC, OrderQuantity
, MaxStockQuantity, MaterialRequirementsQuantity, ReplenishmentTime, AlternativeRoutingFlag, Upduser, OrderPostingFlag
, Insuser, Config, ProvisionMode, Variants, AlternativeBomFlag, Upddate, PreCutFlag, Insdate, PreviewFlag, ProvisionTime
, AttributeClassId, PlanningItemFlag, CostingGroupId, SupplierRatingLastDate, DeliveryCostsFlag, SupplierRatingClass
, RevisionIndexId, NoContributionMarginFlag, ProductionLevel, SupplierRatingScore, NoSupplierRatingFlag, BonusFlag
, RatingFlag, RoundingMode, SupplierRatingId, OldPrice, NoOrderBomFlag, ReplacementKit, CostElementId, CADDate
, NoStatisticsFlag, Documents, StockConstantQuantity, Difference, SuccessorItem, CatalogGroupId, CADUser, EANCode
, DispoRunPlanMode, StackingFactor, NoProtocollFlag, PricePQuantity, RentalItemFlag, MaterialTagType, ItemMaintenanceRate
, Width, RecyclingMode, TariffRate, "Length", ConfigMode, ItemMaintenanceGroupId, ItemMaintenanceGuaranteeRate, Height
, MaxWeight, ItemExtraRate, VSFlag, PlanningDecimalPlace, AutoWithdrawalFlag, PackagingMaterialFlag, CADItemFlag
, PseudoBomFlag, PlanningEstimateMode, P2PlusSystemFlag, CostGroupId, AutoReceiptFlag, OperatingResource, PackFlag
, SuccessorItemId, OperationResourceUniqueKeyFlag, DevaluationDefinitionId, HazardousMaterialCode, WearPartFlag
, ProvisionLineFlag, IncompleteFlag, AlternativeItemId, MinBatchSize, CompleteDispoFlag, PreferenceStatusMode
, NoWarehousePlanRunFlag, NoIntrastatFlag, PredecessorItemId, NKE_Width, ServiceFlag, SurchargeSet, OverheadCostGroupId
, NKE_PriceBase, NKE_MadeInAustriaFlag, NKE_BoreDiameter, DirectDeliveryFlag, NKE_ItemRangeId, ItemType, NoPaymentDepositFlag
, NKE_ComponentFlag, NKE_InternalSalesPriceListFlag, NKE_OuterDiameter, NKE_NameBMD, NKE_LabelCode, NKE_ItemTypeId
, NKE_AssemblyFlag, NKE_WidthInside, NKE_UnitsInBox, NKE_HouseSalesPriceListFlag, NKE_Duration, NKE_DiscontinuedFlag
, NKE_LengthInside, NKE_PackagingFlag, NKE_HeightInside, NKE_LargesizeBearingFlag, NKE_BookSalesPriceListFlag
, NKE_ColloFlag, NKE_MINAKLStock, NKE_TGWGEWKLFlag, PackagingTypeStdTxt, NKE_TGWWarehouseId, NKE_TGWPackagingItemFlag
, NKE_TGWLoadingAidDefinition, NKE_TGWSalesItemId, NKE_MaxAKLStock, NKE_MaxAKLContainer, NKE_TGWItemFlag
, NKE_TGWPackagingClass, NKE_TGWLoadingAidName, NKE_HighBayWarehouseFullOutFlag, NKE_MaxHeightInside
, NKE_PackagingTypeId, NKE_DismountableFlag, NKE_TGWSector, ClientId, NKE_NoStocklistFlag, NKE_InspectionPlanFlag
, NKE_NoQSInspectionFlag, NKE_PackagingItemId, NKE_ISO14001Flag, NKE_SerialNumberFlag, RentalFlag, NKE_Status
, NKE_ApprovedPackagingTypeId, SalesPlanFlag, BatchCardFlag, ThirdPartyCostElementId, DontDisposeFlag
, TipSalesAgreementFlag, TipSales, MaterialGroupId, SYNCMSCRM, InventoryPriceGroupingId, WarehouseCostRateUoMId
, TipPurchase, NoStatistics, WorkstationAutoPostingFlag, TipSalesQuotationFlag, TipServiceFlag
, TipPurchaseOrderProposalFlag, TipSalesReturnFlag, TipPurchaseSupplierInvoiceFlag, TipPurchaseInquiryFlag
, TipSalesOrderFlag, NKE_WeightCheckedFlag, TipPurchaseAgreementFlag, TipGoodsReceiptFlag, TipSalesInvoiceFlag
, PDMIdentNumber, TipPurchaseOrderFlag, TipGoodsIssueFlag, NKE_ClearanceLowerLimit, NKE_WebshopFlag, NKE_ItemTypeOld
, NKE_EnvelopingCircleTolerance, PlanningColour, NKE_StockColloFlag, NKE_ClearanceUpperLimit, ProductionValidTo
, NKE_WebshopActiveFlag, NKE_EnvelopingCircleType, ProductionStandardPriceUpdateFlag, NKE_ProductionDrawing
, NKE_WebshopRequest, NKE_EnvelopingCircle, ProductionValidFrom, NKE_ERPNew_Info, FollowUpBatchSize
, ANP_DeliveryCostElementId, NKE_Name_Fersa, NKE_DrawingConfirmedFlag, ItemStatus, NKE_WebshopNewItemFlag
, ANP_SalesTargetMarket, NKE_ItemNumber_Fersa, NKE_ItemId_Old, NKE_WeightClass, TipPurchaseReturnFlag
, InventoryPriceQuantity, NKE_WebshopOpportunityFlag, LLEFlag, LicensorId, LicenseMandatoryFlag, MaterialMESWithdrawalFlag
, GUID, BufferTime, AccountingGroupManuallyFlag, ProductionContainerUniqueFlag, QSMandatoryFlag, MaterialMESWithdrawalMode
, LicenseRate, AccountingGroupId, CostingQuantity, WeightManuallyFlag, ServiceApplicationFlag, OverheadCostGroupManuallyFlag
, NKE_ItemNamePurchase_Fersa, BatchSizeTimeHorizon, NKE_GreenRevenueFlag, BaseItemId, RecDateStart, ANP_CustomerProtectionFlag, MaxBatchSize
, RecDateEnd, RessanzFlag, StandardGEWLSTFlag, NKE_ABCSalesItem, NKE_ItemNumberPurchase_Fersa, SrcRecLocationId, RecActive, ANP_ItemQualityCategoryId
, RecDateModified, RecDateSync, SrcRecTimestamp, RecUserModified, RecUserCreated, SrcRecId, RecDateReport, ANP_ADLCode, RecDateCreated, SrcRecVersion
, RecCountModified, LABELN, PRAEFERENZKALKNR, ANP_ConstructionItemId
, ANP_IGNORESENDCILOG, NKE_FLAECHENLAST, PRAEFERENZAKTIV, NOPRAEFKALK, NKE_RANDLAST, ANP_DMC, DUALIS_OPTMERKMAL, PRAEFERENZKALK)
SELECT RecId, ItemId, DIN, Id, DrawingNumber, PurchaseFlag, ProductionRoutingFlag, Name, SalesFlag
, "Timestamp", Tool, ProductionFlag, ProductionBomFlag, NoDeliveryNoteFlag, DispoWarehouseFlag, ReplacementFlag
, NoDispoFlag, GoodsReceiptInspectionFlag, PostingMandadortyFlag, ItemGroupId, BatchFlag, DispoOrderFlag
, SerialNumberFlag, NoStockFlag, RawMaterialFlag, IventoryPhysicalId, RebateGroupId, CostCenterId, PriceGroupId
, SalesDimensions, ExpenseAccount, Dimensions, PackagingQuantity, TaxCode, ConsumptionUoMId, RevenueAccount
, PriceUoMId, FreightCostsAccountId, SalesUoMId, Net, NoRebateFlag, DispoStaffId, CommissionFlag, CountryOfOrigin
, AssemblyTime, MinOrderQuantity, PreferenceFlag, WarehouseId, CompanyAccountId, PurchaseStaffId, FederalCountryOfOrigin
, StaffId, CustomsTariffId, WarehouseBinId, Weight, MaxOrderQuantity, StockReportingQuantity, MaterialConsumptionABC
, MinStockQuantity, StockABC, WarehouseCostRate, OrderRhythm, Material, WasteFactor, MaterialRequirementsABC, OrderQuantity
, MaxStockQuantity, MaterialRequirementsQuantity, ReplenishmentTime, AlternativeRoutingFlag, Upduser, OrderPostingFlag
, Insuser, Config, ProvisionMode, Variants, AlternativeBomFlag, Upddate, PreCutFlag, Insdate, PreviewFlag, ProvisionTime
, AttributeClassId, PlanningItemFlag, CostingGroupId, SupplierRatingLastDate, DeliveryCostsFlag, SupplierRatingClass
, RevisionIndexId, NoContributionMarginFlag, ProductionLevel, SupplierRatingScore, NoSupplierRatingFlag, BonusFlag
, RatingFlag, RoundingMode, SupplierRatingId, OldPrice, NoOrderBomFlag, ReplacementKit, CostElementId, CADDate
, NoStatisticsFlag, Documents, StockConstantQuantity, Difference, SuccessorItem, CatalogGroupId, CADUser, EANCode
, DispoRunPlanMode, StackingFactor, NoProtocollFlag, PricePQuantity, RentalItemFlag, MaterialTagType, ItemMaintenanceRate
, Width, RecyclingMode, TariffRate, "Length", ConfigMode, ItemMaintenanceGroupId, ItemMaintenanceGuaranteeRate, Height
, MaxWeight, ItemExtraRate, VSFlag, PlanningDecimalPlace, AutoWithdrawalFlag, PackagingMaterialFlag, CADItemFlag
, PseudoBomFlag, PlanningEstimateMode, P2PlusSystemFlag, CostGroupId, AutoReceiptFlag, OperatingResource, PackFlag
, SuccessorItemId, OperationResourceUniqueKeyFlag, DevaluationDefinitionId, HazardousMaterialCode, WearPartFlag
, ProvisionLineFlag, IncompleteFlag, AlternativeItemId, MinBatchSize, CompleteDispoFlag, PreferenceStatusMode
, NoWarehousePlanRunFlag, NoIntrastatFlag, PredecessorItemId, NKE_Width, ServiceFlag, SurchargeSet, OverheadCostGroupId
, NKE_PriceBase, NKE_MadeInAustriaFlag, NKE_BoreDiameter, DirectDeliveryFlag, NKE_ItemRangeId, ItemType, NoPaymentDepositFlag
, NKE_ComponentFlag, NKE_InternalSalesPriceListFlag, NKE_OuterDiameter, NKE_NameBMD, NKE_LabelCode, NKE_ItemTypeId
, NKE_AssemblyFlag, NKE_WidthInside, NKE_UnitsInBox, NKE_HouseSalesPriceListFlag, NKE_Duration, NKE_DiscontinuedFlag
, NKE_LengthInside, NKE_PackagingFlag, NKE_HeightInside, NKE_LargesizeBearingFlag, NKE_BookSalesPriceListFlag
, NKE_ColloFlag, NKE_MINAKLStock, NKE_TGWGEWKLFlag, PackagingTypeStdTxt, NKE_TGWWarehouseId, NKE_TGWPackagingItemFlag
, NKE_TGWLoadingAidDefinition, NKE_TGWSalesItemId, NKE_MaxAKLStock, NKE_MaxAKLContainer, NKE_TGWItemFlag
, NKE_TGWPackagingClass, NKE_TGWLoadingAidName, NKE_HighBayWarehouseFullOutFlag, NKE_MaxHeightInside
, NKE_PackagingTypeId, NKE_DismountableFlag, NKE_TGWSector, ClientId, NKE_NoStocklistFlag, NKE_InspectionPlanFlag
, NKE_NoQSInspectionFlag, NKE_PackagingItemId, NKE_ISO14001Flag, NKE_SerialNumberFlag, RentalFlag, NKE_Status
, NKE_ApprovedPackagingTypeId, SalesPlanFlag, BatchCardFlag, ThirdPartyCostElementId, DontDisposeFlag
, TipSalesAgreementFlag, TipSales, MaterialGroupId, SYNCMSCRM, InventoryPriceGroupingId, WarehouseCostRateUoMId
, TipPurchase, NoStatistics, WorkstationAutoPostingFlag, TipSalesQuotationFlag, TipServiceFlag
, TipPurchaseOrderProposalFlag, TipSalesReturnFlag, TipPurchaseSupplierInvoiceFlag, TipPurchaseInquiryFlag
, TipSalesOrderFlag, NKE_WeightCheckedFlag, TipPurchaseAgreementFlag, TipGoodsReceiptFlag, TipSalesInvoiceFlag
, PDMIdentNumber, TipPurchaseOrderFlag, TipGoodsIssueFlag, NKE_ClearanceLowerLimit, NKE_WebshopFlag, NKE_ItemTypeOld
, NKE_EnvelopingCircleTolerance, PlanningColour, NKE_StockColloFlag, NKE_ClearanceUpperLimit, ProductionValidTo
, NKE_WebshopActiveFlag, NKE_EnvelopingCircleType, ProductionStandardPriceUpdateFlag, NKE_ProductionDrawing
, NKE_WebshopRequest, NKE_EnvelopingCircle, ProductionValidFrom, NKE_ERPNew_Info, FollowUpBatchSize
, ANP_DeliveryCostElementId, NKE_Name_Fersa, NKE_DrawingConfirmedFlag, ItemStatus, NKE_WebshopNewItemFlag
, ANP_SalesTargetMarket, NKE_ItemNumber_Fersa, NKE_ItemId_Old, NKE_WeightClass, TipPurchaseReturnFlag
, InventoryPriceQuantity, NKE_WebshopOpportunityFlag, LLEFlag, LicensorId, LicenseMandatoryFlag, MaterialMESWithdrawalFlag
, GUID, BufferTime, AccountingGroupManuallyFlag, ProductionContainerUniqueFlag, QSMandatoryFlag, MaterialMESWithdrawalMode
, LicenseRate, AccountingGroupId, CostingQuantity, WeightManuallyFlag, ServiceApplicationFlag, OverheadCostGroupManuallyFlag
, NKE_ItemNamePurchase_Fersa, BatchSizeTimeHorizon, NKE_GreenRevenueFlag, BaseItemId, RecDateStart, ANP_CustomerProtectionFlag, MaxBatchSize
, RecDateEnd, RessanzFlag, StandardGEWLSTFlag, NKE_ABCSalesItem, NKE_ItemNumberPurchase_Fersa, SrcRecLocationId, RecActive, ANP_ItemQualityCategoryId
, RecDateModified, RecDateSync, SrcRecTimestamp, RecUserModified, RecUserCreated, SrcRecId, RecDateReport, ANP_ADLCode, RecDateCreated, SrcRecVersion
, RecCountModified, LABELN, PRAEFERENZKALKNR, ANP_ConstructionItemId
, ANP_IGNORESENDCILOG, NKE_FLAECHENLAST, PRAEFERENZAKTIV, NOPRAEFKALK, NKE_RANDLAST, ANP_DMC, DUALIS_OPTMERKMAL, PRAEFERENZKALK
FROM nkeTempIncremental.ds_Item_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Item_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Item_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_Item_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_Item_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;


--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_Item_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_Item_NKE');
*/