--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_NKE_SalesOrder_QuotationAnalysis_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_NKE_SalesOrder_QuotationAnalysis_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_NKE_SalesOrder_QuotationAnalysis_NKE (RecId, Id, "Timestamp", SalesOrderId, LineId, ItemId, QuotationDate, QuotationShippingDueDate, QuotationQuantity, QuotationCurrencyCode, QuotationDMFactor
, QuotationRevenuePerUnit, QuotationRevenue, OrderDateCreated, OrderDate, OrderShippingDueDate, OrderQuantityInitial, OrderQuantity, OrderCurrencyCode, OrderDMFactor
, OrderRevenuePerUnit, OrderRevenue, ClientId, RecDateStart, RecDateEnd, RecActive, RecDateReport, RecDateSync, RecDateCreated, RecDateModified, RecUserCreated
, RecUserModified, RecCountModified, SrcRecLocationId, SrcRecId, SrcRecTimestamp, SrcRecVersion)
SELECT RecId, Id, "Timestamp", SalesOrderId, LineId, ItemId, QuotationDate, QuotationShippingDueDate, QuotationQuantity, QuotationCurrencyCode, QuotationDMFactor
, QuotationRevenuePerUnit, QuotationRevenue, OrderDateCreated, OrderDate, OrderShippingDueDate, OrderQuantityInitial, OrderQuantity, OrderCurrencyCode, OrderDMFactor
, OrderRevenuePerUnit, OrderRevenue, ClientId, RecDateStart, RecDateEnd, RecActive, RecDateReport, RecDateSync, RecDateCreated, RecDateModified, RecUserCreated
, RecUserModified, RecCountModified, SrcRecLocationId, SrcRecId, SrcRecTimestamp, SrcRecVersion
FROM	nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_NKE_SalesOrder_QuotationAnalysis_NKE);

--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_NKE_SalesOrder_QuotationAnalysis_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_NKE_SalesOrder_QuotationAnalysis_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_NKE_SalesOrder_QuotationAnalysis_NKE)
DELETE FROM nkeTempIncremental.ds_NKE_SalesOrder_QuotationAnalysis_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_NKE_SalesOrder_QuotationAnalysis_NKE');