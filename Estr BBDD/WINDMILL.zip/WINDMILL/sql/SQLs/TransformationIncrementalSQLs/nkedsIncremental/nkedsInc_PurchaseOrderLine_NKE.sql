--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_PurchaseOrderLine_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_PurchaseOrderLine_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_PurchaseOrderLine_NKE (RecId, Id, PurchaseOrderId, Agreement, ItemId, InvoicedQuantity, DeliveredQuantity, LineId, "Timestamp", Quantity, 
PurchaseUoMId, FaultyQuantity, AgreementLineId, Net, Name, RebatePrice, DocDeliveryItemId, OriginTaxPrice, DeliveryScheduleDate, PurchaseQuantity,
Rebate, RequiredDate, Price, DocDeliveryName, DataSource, Tax, ConsumptionUoMId, CostsPerUnit, OriginType, DataNumber, DocDeliveryScale,
ExpenseAccount, AccountingAccountId, Dimensions, PurchasePriceUoMId, Costs, CostCenterId, WTaxCode, Rebate2, PreCutFlag, DunningNextDate,
PurchasePriceUnit, CostUnitId, DunningCount, Status, CorrectionFlag, ClearingAccountId, SupplierRatingScheduleDate, ProjectId,
OrderPostingFlag, DunningLastDate, SupplierRatingClass, SupplierRatingManual2, RequiredDateOld, SupplierRatingQuantity, 
SupplierRatingPriceLevel, QuantityOld, ProvisionFlag, SupplierRatingScore, Insdate, SupplierRatingQuality, SupplierRatingManual1,
DueDateOld, SubTotalFlag, PurchaseInquiryLineId, ActiveVariants, Insuser, Upduser, RevenueManuallyFlag, TextLineFlag,
NoStatisticsFlag, Upddate, PurchaseInquiryId, CauserId, ServiceFlag, ToCheckFlag, NKE_ProductionQuantity, XLine, LastStatus, 
PurchaseDimensions, HasSurchargeFlag, CauserLineId, CauserType, NKE_ProudctionDueDate, CostGroupId, NetOld, NKE_PreBatchId,
NKE_Status, NKE_ShippingDueDate, NKE_FactoryCompanyAccountId, NKE_QualityQuantity, NKE_SupplierPackaging, NKE_EOrder,
NKE_DispatchQuantityOld, NKE_Priority, NKE_CorrectedDeliveryDueDate, NKE_PurchaseSupplierInvoiceId, NKE_DispatchScheduledDate, 
NKE_QualityDueDate, NKE_EOrderLine, NKE_EDueDate, NKE_Factory, NKE_DevalutationSchedule, NKE_DispatchScheduleDateOld, 
NKE_DispatchScheduleDate_Old, MaterialSurchargeMode, NKE_EQuantity, NKE_InfoOrderLine, NKE_Counter, NKE_FaultyQuantity,
RebatePrice2, NKE_FactoryCode, NoAccountingFlag, ClientId, NKE_QualityPlanDueDate, NKE_NotConfirmedFlag, FreeOfChargeFlag, 
PurchaseOrderProposalId, LineOrderPath, DeliveryCostsFlag, TargetAccountId, ItemGroupId, DrawingNumber, OperationId, SectionSumFlag,
LineType, NKE_DispatchPlanScheduleDate, NKE_PortalUpduser, BatchId, GaebLineType, ChangedFlag, PMNotFullFlag, PackagingLevel, 
NKE_SplitPosFlag, NKE_TotalCostsAdditional, NKE_LbtReWorkFlag, LabelFillQuantity, CostsPerUnitOld, SurchargeSet, NKE_TransportModeId,
NKE_DispatchQuantity, NKE_QualityNumber, NKE_TransportPayer, NoDispoFlag, NKE_CostsAdditional, NKE_PurchaseOrderProposalDate, 
SalesCalculatedFlag, PackagingMaterialFlag, GUID, MixedPackagingFlag, UserLine, LabelGross, LabelAmountPackage, NKE_InterfaceAXId,
PackagingNumberStart, LabelSignature, PackagingRule, NKE_InterfaceCreate, VItemLine, MasterLine, LabelNet, PackagingNumberEnd,
ANP_RequiredDateExternal, PackagingInstructions, MainPMFlag, NKE_InterfaceUpdateFlag, MaterialTagType, NKE_TanListFlag, 
AttributeClassId, NKE_QSCertificateText, NKE_NoQSInspectionFlag, NKE_InspectorStaffId, NKE_QSInspectionCompleteFlag, NKE_QSDecision,
NKE_QSNotesInternal, NKE_SupplierInvoiceDate, ProjectDifferenceFlag, NKE_QSOnSiteInspectionResult, NKE_InspectionEndDate, 
NKE_QSCertificateFLag, NKE_QSQuantity, ANP_JLCQuantity, NKE_QSMaterialInspectionResult, NKE_QSOnSiteMarkingAndPackaging, 
RecActive, ANP_JLCSplitLine, ANP_PPAP, RecDateStart, AnP_JLC_LastUpdate, NKE_QSMaterialInspector, NKE_QSJLCPacked, RecDateReport,
ANP_JLCRemainingQuantity, NKE_Process, RecDateEnd, SrcRecLocationId, RecDateSync, RecDateModified, InstallationNumber, 
RecUserModified, SrcRecTimestamp, ANP_CompanyQualityCategoryId, SrcRecId, RecDateCreated, RecUserCreated, BRUTTOKORREKTUR,
RecCountModified, SrcRecVersion, ANP_ItemQualityCategoryId, MaintenanceGroup, MANKSTR, MANKOSTENSTELLE, ANP_ZOLLVERFAHREN)
SELECT RecId, Id, PurchaseOrderId, Agreement, ItemId, InvoicedQuantity, DeliveredQuantity, LineId, "Timestamp", Quantity, 
PurchaseUoMId, FaultyQuantity, AgreementLineId, Net, Name, RebatePrice, DocDeliveryItemId, OriginTaxPrice, DeliveryScheduleDate, PurchaseQuantity,
Rebate, RequiredDate, Price, DocDeliveryName, DataSource, Tax, ConsumptionUoMId, CostsPerUnit, OriginType, DataNumber, DocDeliveryScale,
ExpenseAccount, AccountingAccountId, Dimensions, PurchasePriceUoMId, Costs, CostCenterId, WTaxCode, Rebate2, PreCutFlag, DunningNextDate,
PurchasePriceUnit, CostUnitId, DunningCount, Status, CorrectionFlag, ClearingAccountId, SupplierRatingScheduleDate, ProjectId,
OrderPostingFlag, DunningLastDate, SupplierRatingClass, SupplierRatingManual2, RequiredDateOld, SupplierRatingQuantity, 
SupplierRatingPriceLevel, QuantityOld, ProvisionFlag, SupplierRatingScore, Insdate, SupplierRatingQuality, SupplierRatingManual1,
DueDateOld, SubTotalFlag, PurchaseInquiryLineId, ActiveVariants, Insuser, Upduser, RevenueManuallyFlag, TextLineFlag,
NoStatisticsFlag, Upddate, PurchaseInquiryId, CauserId, ServiceFlag, ToCheckFlag, NKE_ProductionQuantity, XLine, LastStatus, 
PurchaseDimensions, HasSurchargeFlag, CauserLineId, CauserType, NKE_ProudctionDueDate, CostGroupId, NetOld, NKE_PreBatchId,
NKE_Status, NKE_ShippingDueDate, NKE_FactoryCompanyAccountId, NKE_QualityQuantity, NKE_SupplierPackaging, NKE_EOrder,
NKE_DispatchQuantityOld, NKE_Priority, NKE_CorrectedDeliveryDueDate, NKE_PurchaseSupplierInvoiceId, NKE_DispatchScheduledDate, 
NKE_QualityDueDate, NKE_EOrderLine, NKE_EDueDate, NKE_Factory, NKE_DevalutationSchedule, NKE_DispatchScheduleDateOld, 
NKE_DispatchScheduleDate_Old, MaterialSurchargeMode, NKE_EQuantity, NKE_InfoOrderLine, NKE_Counter, NKE_FaultyQuantity,
RebatePrice2, NKE_FactoryCode, NoAccountingFlag, ClientId, NKE_QualityPlanDueDate, NKE_NotConfirmedFlag, FreeOfChargeFlag, 
PurchaseOrderProposalId, LineOrderPath, DeliveryCostsFlag, TargetAccountId, ItemGroupId, DrawingNumber, OperationId, SectionSumFlag,
LineType, NKE_DispatchPlanScheduleDate, NKE_PortalUpduser, BatchId, GaebLineType, ChangedFlag, PMNotFullFlag, PackagingLevel, 
NKE_SplitPosFlag, NKE_TotalCostsAdditional, NKE_LbtReWorkFlag, LabelFillQuantity, CostsPerUnitOld, SurchargeSet, NKE_TransportModeId,
NKE_DispatchQuantity, NKE_QualityNumber, NKE_TransportPayer, NoDispoFlag, NKE_CostsAdditional, NKE_PurchaseOrderProposalDate, 
SalesCalculatedFlag, PackagingMaterialFlag, GUID, MixedPackagingFlag, UserLine, LabelGross, LabelAmountPackage, NKE_InterfaceAXId,
PackagingNumberStart, LabelSignature, PackagingRule, NKE_InterfaceCreate, VItemLine, MasterLine, LabelNet, PackagingNumberEnd,
ANP_RequiredDateExternal, PackagingInstructions, MainPMFlag, NKE_InterfaceUpdateFlag, MaterialTagType, NKE_TanListFlag, 
AttributeClassId, NKE_QSCertificateText, NKE_NoQSInspectionFlag, NKE_InspectorStaffId, NKE_QSInspectionCompleteFlag, NKE_QSDecision,
NKE_QSNotesInternal, NKE_SupplierInvoiceDate, ProjectDifferenceFlag, NKE_QSOnSiteInspectionResult, NKE_InspectionEndDate, 
NKE_QSCertificateFLag, NKE_QSQuantity, ANP_JLCQuantity, NKE_QSMaterialInspectionResult, NKE_QSOnSiteMarkingAndPackaging, 
RecActive, ANP_JLCSplitLine, ANP_PPAP, RecDateStart, AnP_JLC_LastUpdate, NKE_QSMaterialInspector, NKE_QSJLCPacked, RecDateReport,
ANP_JLCRemainingQuantity, NKE_Process, RecDateEnd, SrcRecLocationId, RecDateSync, RecDateModified, InstallationNumber, 
RecUserModified, SrcRecTimestamp, ANP_CompanyQualityCategoryId, SrcRecId, RecDateCreated, RecUserCreated, BRUTTOKORREKTUR,
RecCountModified, SrcRecVersion, ANP_ItemQualityCategoryId, MaintenanceGroup, MANKSTR, MANKOSTENSTELLE, ANP_ZOLLVERFAHREN
FROM	nkeTempIncremental.ds_PurchaseOrderLine_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_PurchaseOrderLine_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_PurchaseOrderLine_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_PurchaseOrderLine_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_PurchaseOrderLine_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_PurchaseOrderLine_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_PurchaseOrderLine_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_PurchaseOrderLine_NKE(RecId, Id, PurchaseOrderId, Agreement, ItemId, InvoicedQuantity, DeliveredQuantity, LineId, "Timestamp", Quantity, 
PurchaseUoMId, FaultyQuantity, AgreementLineId, Net, Name, RebatePrice, DocDeliveryItemId, OriginTaxPrice, DeliveryScheduleDate, PurchaseQuantity,
Rebate, RequiredDate, Price, DocDeliveryName, DataSource, Tax, ConsumptionUoMId, CostsPerUnit, OriginType, DataNumber, DocDeliveryScale,
ExpenseAccount, AccountingAccountId, Dimensions, PurchasePriceUoMId, Costs, CostCenterId, WTaxCode, Rebate2, PreCutFlag, DunningNextDate,
PurchasePriceUnit, CostUnitId, DunningCount, Status, CorrectionFlag, ClearingAccountId, SupplierRatingScheduleDate, ProjectId,
OrderPostingFlag, DunningLastDate, SupplierRatingClass, SupplierRatingManual2, RequiredDateOld, SupplierRatingQuantity, 
SupplierRatingPriceLevel, QuantityOld, ProvisionFlag, SupplierRatingScore, Insdate, SupplierRatingQuality, SupplierRatingManual1,
DueDateOld, SubTotalFlag, PurchaseInquiryLineId, ActiveVariants, Insuser, Upduser, RevenueManuallyFlag, TextLineFlag,
NoStatisticsFlag, Upddate, PurchaseInquiryId, CauserId, ServiceFlag, ToCheckFlag, NKE_ProductionQuantity, XLine, LastStatus, 
PurchaseDimensions, HasSurchargeFlag, CauserLineId, CauserType, NKE_ProudctionDueDate, CostGroupId, NetOld, NKE_PreBatchId,
NKE_Status, NKE_ShippingDueDate, NKE_FactoryCompanyAccountId, NKE_QualityQuantity, NKE_SupplierPackaging, NKE_EOrder,
NKE_DispatchQuantityOld, NKE_Priority, NKE_CorrectedDeliveryDueDate, NKE_PurchaseSupplierInvoiceId, NKE_DispatchScheduledDate, 
NKE_QualityDueDate, NKE_EOrderLine, NKE_EDueDate, NKE_Factory, NKE_DevalutationSchedule, NKE_DispatchScheduleDateOld, 
NKE_DispatchScheduleDate_Old, MaterialSurchargeMode, NKE_EQuantity, NKE_InfoOrderLine, NKE_Counter, NKE_FaultyQuantity,
RebatePrice2, NKE_FactoryCode, NoAccountingFlag, ClientId, NKE_QualityPlanDueDate, NKE_NotConfirmedFlag, FreeOfChargeFlag, 
PurchaseOrderProposalId, LineOrderPath, DeliveryCostsFlag, TargetAccountId, ItemGroupId, DrawingNumber, OperationId, SectionSumFlag,
LineType, NKE_DispatchPlanScheduleDate, NKE_PortalUpduser, BatchId, GaebLineType, ChangedFlag, PMNotFullFlag, PackagingLevel, 
NKE_SplitPosFlag, NKE_TotalCostsAdditional, NKE_LbtReWorkFlag, LabelFillQuantity, CostsPerUnitOld, SurchargeSet, NKE_TransportModeId,
NKE_DispatchQuantity, NKE_QualityNumber, NKE_TransportPayer, NoDispoFlag, NKE_CostsAdditional, NKE_PurchaseOrderProposalDate, 
SalesCalculatedFlag, PackagingMaterialFlag, GUID, MixedPackagingFlag, UserLine, LabelGross, LabelAmountPackage, NKE_InterfaceAXId,
PackagingNumberStart, LabelSignature, PackagingRule, NKE_InterfaceCreate, VItemLine, MasterLine, LabelNet, PackagingNumberEnd,
ANP_RequiredDateExternal, PackagingInstructions, MainPMFlag, NKE_InterfaceUpdateFlag, MaterialTagType, NKE_TanListFlag, 
AttributeClassId, NKE_QSCertificateText, NKE_NoQSInspectionFlag, NKE_InspectorStaffId, NKE_QSInspectionCompleteFlag, NKE_QSDecision,
NKE_QSNotesInternal, NKE_SupplierInvoiceDate, ProjectDifferenceFlag, NKE_QSOnSiteInspectionResult, NKE_InspectionEndDate, 
NKE_QSCertificateFLag, NKE_QSQuantity, ANP_JLCQuantity, NKE_QSMaterialInspectionResult, NKE_QSOnSiteMarkingAndPackaging, 
RecActive, ANP_JLCSplitLine, ANP_PPAP, RecDateStart, AnP_JLC_LastUpdate, NKE_QSMaterialInspector, NKE_QSJLCPacked, RecDateReport,
ANP_JLCRemainingQuantity, NKE_Process, RecDateEnd, SrcRecLocationId, RecDateSync, RecDateModified, InstallationNumber, 
RecUserModified, SrcRecTimestamp, ANP_CompanyQualityCategoryId, SrcRecId, RecDateCreated, RecUserCreated, BRUTTOKORREKTUR,
RecCountModified, SrcRecVersion, ANP_ItemQualityCategoryId, MaintenanceGroup, MANKSTR, MANKOSTENSTELLE, ANP_ZOLLVERFAHREN)
SELECT RecId, Id, PurchaseOrderId, Agreement, ItemId, InvoicedQuantity, DeliveredQuantity, LineId, "Timestamp", Quantity, 
PurchaseUoMId, FaultyQuantity, AgreementLineId, Net, Name, RebatePrice, DocDeliveryItemId, OriginTaxPrice, DeliveryScheduleDate, PurchaseQuantity,
Rebate, RequiredDate, Price, DocDeliveryName, DataSource, Tax, ConsumptionUoMId, CostsPerUnit, OriginType, DataNumber, DocDeliveryScale,
ExpenseAccount, AccountingAccountId, Dimensions, PurchasePriceUoMId, Costs, CostCenterId, WTaxCode, Rebate2, PreCutFlag, DunningNextDate,
PurchasePriceUnit, CostUnitId, DunningCount, Status, CorrectionFlag, ClearingAccountId, SupplierRatingScheduleDate, ProjectId,
OrderPostingFlag, DunningLastDate, SupplierRatingClass, SupplierRatingManual2, RequiredDateOld, SupplierRatingQuantity, 
SupplierRatingPriceLevel, QuantityOld, ProvisionFlag, SupplierRatingScore, Insdate, SupplierRatingQuality, SupplierRatingManual1,
DueDateOld, SubTotalFlag, PurchaseInquiryLineId, ActiveVariants, Insuser, Upduser, RevenueManuallyFlag, TextLineFlag,
NoStatisticsFlag, Upddate, PurchaseInquiryId, CauserId, ServiceFlag, ToCheckFlag, NKE_ProductionQuantity, XLine, LastStatus, 
PurchaseDimensions, HasSurchargeFlag, CauserLineId, CauserType, NKE_ProudctionDueDate, CostGroupId, NetOld, NKE_PreBatchId,
NKE_Status, NKE_ShippingDueDate, NKE_FactoryCompanyAccountId, NKE_QualityQuantity, NKE_SupplierPackaging, NKE_EOrder,
NKE_DispatchQuantityOld, NKE_Priority, NKE_CorrectedDeliveryDueDate, NKE_PurchaseSupplierInvoiceId, NKE_DispatchScheduledDate, 
NKE_QualityDueDate, NKE_EOrderLine, NKE_EDueDate, NKE_Factory, NKE_DevalutationSchedule, NKE_DispatchScheduleDateOld, 
NKE_DispatchScheduleDate_Old, MaterialSurchargeMode, NKE_EQuantity, NKE_InfoOrderLine, NKE_Counter, NKE_FaultyQuantity,
RebatePrice2, NKE_FactoryCode, NoAccountingFlag, ClientId, NKE_QualityPlanDueDate, NKE_NotConfirmedFlag, FreeOfChargeFlag, 
PurchaseOrderProposalId, LineOrderPath, DeliveryCostsFlag, TargetAccountId, ItemGroupId, DrawingNumber, OperationId, SectionSumFlag,
LineType, NKE_DispatchPlanScheduleDate, NKE_PortalUpduser, BatchId, GaebLineType, ChangedFlag, PMNotFullFlag, PackagingLevel, 
NKE_SplitPosFlag, NKE_TotalCostsAdditional, NKE_LbtReWorkFlag, LabelFillQuantity, CostsPerUnitOld, SurchargeSet, NKE_TransportModeId,
NKE_DispatchQuantity, NKE_QualityNumber, NKE_TransportPayer, NoDispoFlag, NKE_CostsAdditional, NKE_PurchaseOrderProposalDate, 
SalesCalculatedFlag, PackagingMaterialFlag, GUID, MixedPackagingFlag, UserLine, LabelGross, LabelAmountPackage, NKE_InterfaceAXId,
PackagingNumberStart, LabelSignature, PackagingRule, NKE_InterfaceCreate, VItemLine, MasterLine, LabelNet, PackagingNumberEnd,
ANP_RequiredDateExternal, PackagingInstructions, MainPMFlag, NKE_InterfaceUpdateFlag, MaterialTagType, NKE_TanListFlag, 
AttributeClassId, NKE_QSCertificateText, NKE_NoQSInspectionFlag, NKE_InspectorStaffId, NKE_QSInspectionCompleteFlag, NKE_QSDecision,
NKE_QSNotesInternal, NKE_SupplierInvoiceDate, ProjectDifferenceFlag, NKE_QSOnSiteInspectionResult, NKE_InspectionEndDate, 
NKE_QSCertificateFLag, NKE_QSQuantity, ANP_JLCQuantity, NKE_QSMaterialInspectionResult, NKE_QSOnSiteMarkingAndPackaging, 
RecActive, ANP_JLCSplitLine, ANP_PPAP, RecDateStart, AnP_JLC_LastUpdate, NKE_QSMaterialInspector, NKE_QSJLCPacked, RecDateReport,
ANP_JLCRemainingQuantity, NKE_Process, RecDateEnd, SrcRecLocationId, RecDateSync, RecDateModified, InstallationNumber, 
RecUserModified, SrcRecTimestamp, ANP_CompanyQualityCategoryId, SrcRecId, RecDateCreated, RecUserCreated, BRUTTOKORREKTUR,
RecCountModified, SrcRecVersion, ANP_ItemQualityCategoryId, MaintenanceGroup, MANKSTR, MANKOSTENSTELLE, ANP_ZOLLVERFAHREN
FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_PurchaseOrderLine_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_PurchaseOrderLine_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_PurchaseOrderLine_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_PurchaseOrderLine_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_PurchaseOrderLine_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_PurchaseOrderLine_NKE');
*/