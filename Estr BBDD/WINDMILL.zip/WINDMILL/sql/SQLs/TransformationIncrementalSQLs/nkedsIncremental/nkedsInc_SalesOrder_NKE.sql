--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_SalesOrder_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_SalesOrder_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_SalesOrder_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesOrder_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesOrder_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_SalesOrder_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_SalesOrder_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesOrder_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_SalesOrder_NKE (RecId, "Date", SalesOrderId, Id, CompanyAccountId, InvoiceCompanyAccountId, Net, Status
, "Timestamp", DeliveryCompanyAccountId, StaffId, DueDate, RebatePrice, TaxCode, SalesQuotationId, Gross, YourText, CurrencyCode, DMGross
, "Language", OriginTaxPrice, NetRevenue, StdTxt, DMNetRevenue, DMFactor, PriceListFlag, Upduser, RepresentativeId, ProjectId, Insuser
, DocDeliveryCountryCode, DocDeliveryStreet, DocDeliveryName, OrderType, DocDeliveryCity, DocDeliveryPostCode, Upddate, DocDeliveryCompanyAccountName1
, CostUnitId, DocDeliveryDepartment, DocDeliveryPhone, DocDeliveryCompanyAccountName2, DesiredScheduleDate, DocDeliveryFax, RepresentativeI2Id, Insdate
, PDate, SuppllierCompanyId, DMDivisor, DocDeliveryCompanyAccountName3, DocDeliveryCompanyAccountManuallyFlag, PriceCode, CompanyId, InProcessFlag
, GuaranteeId, DecisionHorizont, TaxText, BasketId, MarginPercent, OrderDate, ConfirmationFlag, DeliveryScheduleDate, PartialDeliveryFlag, PrintedFlag
, YourOrder, Weight, Margin, InspectionNumber, DocDeliveryVATNumber, NKE_Percent, NKE_SalesInvoiceExistsFlag, EDIPartner, OrderFlag, FactoryInvoice
, PriceCompanyId, ClientId, FactoryPurchaser, Nke_Percent2, NKE_OrderType, FactoryDirectCustomer, DeliveryUnloadingPoint, ProfitCenterId, SimulationFlag
, DocDeliveryPostCode2, NKE_ADBackorderFlag, NKE_WebshopResolvedFlag, ExchangeRateFactor, MyOpenFactoryOut, ShippingTypeStdTxt, WorkflowId, WFProcName
, ECOMUseIn, ANP_ECOMUseIn, NKE_WebshopFlag, ReferenceCustomer, MsgId, LocationId, ErrorClass, "Result", Reason, UseTo, EDIPartnerNumber, SettlementCode
, MatchCode, InitialCustomer, ServiceFlag, OperatorCompanyAccountId, UseFrom, MsgIdRsp, InstallationId, ReportingName, PrintCustomsNumberFlag
, ANP_WebshopimportCompleteFlag, VStaffId, ConditionFlag, ServiceProcedureId, Tstaff, NKE_WebExpressDeliveryFlag, ANP_ExternalID, NKE_ExpressDeliveryFlag
, Addon1, OriginSalesOrderId, ServiceRequestId, SubmissionDate, Representative3Id, RecDateEnd, RecDateReport, FEZDate, ServiceLevel, GUID, CollectiveOrderId
, RecDateCreated, RecDateStart, AttributeClassId, TermsPaymentId, RecActive, RecDateSync, SCSFlag, RecDateModified, SrcRecVersion, RecUserCreated, RecCountModified
, EINVOICE_DISPATCH, LEITWEGID, SrcRecId, SCSAUFTRAG, BEXTRANSFER, RecUserModified, SrcRecLocationId, EINVOICE_INTERFACE, MUSTERZAHLUNGSPLAN, SrcRecTimestamp
, USTIDNOPRUEF)
SELECT RecId, "Date", SalesOrderId, Id, CompanyAccountId, InvoiceCompanyAccountId, Net, Status
, "Timestamp", DeliveryCompanyAccountId, StaffId, DueDate, RebatePrice, TaxCode, SalesQuotationId, Gross, YourText, CurrencyCode, DMGross
, "Language", OriginTaxPrice, NetRevenue, StdTxt, DMNetRevenue, DMFactor, PriceListFlag, Upduser, RepresentativeId, ProjectId, Insuser
, DocDeliveryCountryCode, DocDeliveryStreet, DocDeliveryName, OrderType, DocDeliveryCity, DocDeliveryPostCode, Upddate, DocDeliveryCompanyAccountName1
, CostUnitId, DocDeliveryDepartment, DocDeliveryPhone, DocDeliveryCompanyAccountName2, DesiredScheduleDate, DocDeliveryFax, RepresentativeI2Id, Insdate
, PDate, SuppllierCompanyId, DMDivisor, DocDeliveryCompanyAccountName3, DocDeliveryCompanyAccountManuallyFlag, PriceCode, CompanyId, InProcessFlag
, GuaranteeId, DecisionHorizont, TaxText, BasketId, MarginPercent, OrderDate, ConfirmationFlag, DeliveryScheduleDate, PartialDeliveryFlag, PrintedFlag
, YourOrder, Weight, Margin, InspectionNumber, DocDeliveryVATNumber, NKE_Percent, NKE_SalesInvoiceExistsFlag, EDIPartner, OrderFlag, FactoryInvoice
, PriceCompanyId, ClientId, FactoryPurchaser, Nke_Percent2, NKE_OrderType, FactoryDirectCustomer, DeliveryUnloadingPoint, ProfitCenterId, SimulationFlag
, DocDeliveryPostCode2, NKE_ADBackorderFlag, NKE_WebshopResolvedFlag, ExchangeRateFactor, MyOpenFactoryOut, ShippingTypeStdTxt, WorkflowId, WFProcName
, ECOMUseIn, ANP_ECOMUseIn, NKE_WebshopFlag, ReferenceCustomer, MsgId, LocationId, ErrorClass, "Result", Reason, UseTo, EDIPartnerNumber, SettlementCode
, MatchCode, InitialCustomer, ServiceFlag, OperatorCompanyAccountId, UseFrom, MsgIdRsp, InstallationId, ReportingName, PrintCustomsNumberFlag
, ANP_WebshopimportCompleteFlag, VStaffId, ConditionFlag, ServiceProcedureId, Tstaff, NKE_WebExpressDeliveryFlag, ANP_ExternalID, NKE_ExpressDeliveryFlag
, Addon1, OriginSalesOrderId, ServiceRequestId, SubmissionDate, Representative3Id, RecDateEnd, RecDateReport, FEZDate, ServiceLevel, GUID, CollectiveOrderId
, RecDateCreated, RecDateStart, AttributeClassId, TermsPaymentId, RecActive, RecDateSync, SCSFlag, RecDateModified, SrcRecVersion, RecUserCreated, RecCountModified
, EINVOICE_DISPATCH, LEITWEGID, SrcRecId, SCSAUFTRAG, BEXTRANSFER, RecUserModified, SrcRecLocationId, EINVOICE_INTERFACE, MUSTERZAHLUNGSPLAN, SrcRecTimestamp
, USTIDNOPRUEF
FROM	nkeTempIncremental.ds_SalesOrder_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesOrder_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_SalesOrder_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_SalesOrder_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesOrder_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_SalesOrder_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_SalesOrder_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesOrder_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_SalesOrder_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesOrder_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_SalesOrder_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_SalesOrder_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_SalesOrder_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_SalesOrder_NKE(RecId, "Date", SalesOrderId, Id, CompanyAccountId, InvoiceCompanyAccountId, Net, Status
, "Timestamp", DeliveryCompanyAccountId, StaffId, DueDate, RebatePrice, TaxCode, SalesQuotationId, Gross, YourText, CurrencyCode, DMGross
, "Language", OriginTaxPrice, NetRevenue, StdTxt, DMNetRevenue, DMFactor, PriceListFlag, Upduser, RepresentativeId, ProjectId, Insuser
, DocDeliveryCountryCode, DocDeliveryStreet, DocDeliveryName, OrderType, DocDeliveryCity, DocDeliveryPostCode, Upddate, DocDeliveryCompanyAccountName1
, CostUnitId, DocDeliveryDepartment, DocDeliveryPhone, DocDeliveryCompanyAccountName2, DesiredScheduleDate, DocDeliveryFax, RepresentativeI2Id, Insdate
, PDate, SuppllierCompanyId, DMDivisor, DocDeliveryCompanyAccountName3, DocDeliveryCompanyAccountManuallyFlag, PriceCode, CompanyId, InProcessFlag
, GuaranteeId, DecisionHorizont, TaxText, BasketId, MarginPercent, OrderDate, ConfirmationFlag, DeliveryScheduleDate, PartialDeliveryFlag, PrintedFlag
, YourOrder, Weight, Margin, InspectionNumber, DocDeliveryVATNumber, NKE_Percent, NKE_SalesInvoiceExistsFlag, EDIPartner, OrderFlag, FactoryInvoice
, PriceCompanyId, ClientId, FactoryPurchaser, Nke_Percent2, NKE_OrderType, FactoryDirectCustomer, DeliveryUnloadingPoint, ProfitCenterId, SimulationFlag
, DocDeliveryPostCode2, NKE_ADBackorderFlag, NKE_WebshopResolvedFlag, ExchangeRateFactor, MyOpenFactoryOut, ShippingTypeStdTxt, WorkflowId, WFProcName
, ECOMUseIn, ANP_ECOMUseIn, NKE_WebshopFlag, ReferenceCustomer, MsgId, LocationId, ErrorClass, "Result", Reason, UseTo, EDIPartnerNumber, SettlementCode
, MatchCode, InitialCustomer, ServiceFlag, OperatorCompanyAccountId, UseFrom, MsgIdRsp, InstallationId, ReportingName, PrintCustomsNumberFlag
, ANP_WebshopimportCompleteFlag, VStaffId, ConditionFlag, ServiceProcedureId, Tstaff, NKE_WebExpressDeliveryFlag, ANP_ExternalID, NKE_ExpressDeliveryFlag
, Addon1, OriginSalesOrderId, ServiceRequestId, SubmissionDate, Representative3Id, RecDateEnd, RecDateReport, FEZDate, ServiceLevel, GUID, CollectiveOrderId
, RecDateCreated, RecDateStart, AttributeClassId, TermsPaymentId, RecActive, RecDateSync, SCSFlag, RecDateModified, SrcRecVersion, RecUserCreated, RecCountModified
, EINVOICE_DISPATCH, LEITWEGID, SrcRecId, SCSAUFTRAG, BEXTRANSFER, RecUserModified, SrcRecLocationId, EINVOICE_INTERFACE, MUSTERZAHLUNGSPLAN, SrcRecTimestamp
, USTIDNOPRUEF)
SELECT RecId, "Date", SalesOrderId, Id, CompanyAccountId, InvoiceCompanyAccountId, Net, Status
, "Timestamp", DeliveryCompanyAccountId, StaffId, DueDate, RebatePrice, TaxCode, SalesQuotationId, Gross, YourText, CurrencyCode, DMGross
, "Language", OriginTaxPrice, NetRevenue, StdTxt, DMNetRevenue, DMFactor, PriceListFlag, Upduser, RepresentativeId, ProjectId, Insuser
, DocDeliveryCountryCode, DocDeliveryStreet, DocDeliveryName, OrderType, DocDeliveryCity, DocDeliveryPostCode, Upddate, DocDeliveryCompanyAccountName1
, CostUnitId, DocDeliveryDepartment, DocDeliveryPhone, DocDeliveryCompanyAccountName2, DesiredScheduleDate, DocDeliveryFax, RepresentativeI2Id, Insdate
, PDate, SuppllierCompanyId, DMDivisor, DocDeliveryCompanyAccountName3, DocDeliveryCompanyAccountManuallyFlag, PriceCode, CompanyId, InProcessFlag
, GuaranteeId, DecisionHorizont, TaxText, BasketId, MarginPercent, OrderDate, ConfirmationFlag, DeliveryScheduleDate, PartialDeliveryFlag, PrintedFlag
, YourOrder, Weight, Margin, InspectionNumber, DocDeliveryVATNumber, NKE_Percent, NKE_SalesInvoiceExistsFlag, EDIPartner, OrderFlag, FactoryInvoice
, PriceCompanyId, ClientId, FactoryPurchaser, Nke_Percent2, NKE_OrderType, FactoryDirectCustomer, DeliveryUnloadingPoint, ProfitCenterId, SimulationFlag
, DocDeliveryPostCode2, NKE_ADBackorderFlag, NKE_WebshopResolvedFlag, ExchangeRateFactor, MyOpenFactoryOut, ShippingTypeStdTxt, WorkflowId, WFProcName
, ECOMUseIn, ANP_ECOMUseIn, NKE_WebshopFlag, ReferenceCustomer, MsgId, LocationId, ErrorClass, "Result", Reason, UseTo, EDIPartnerNumber, SettlementCode
, MatchCode, InitialCustomer, ServiceFlag, OperatorCompanyAccountId, UseFrom, MsgIdRsp, InstallationId, ReportingName, PrintCustomsNumberFlag
, ANP_WebshopimportCompleteFlag, VStaffId, ConditionFlag, ServiceProcedureId, Tstaff, NKE_WebExpressDeliveryFlag, ANP_ExternalID, NKE_ExpressDeliveryFlag
, Addon1, OriginSalesOrderId, ServiceRequestId, SubmissionDate, Representative3Id, RecDateEnd, RecDateReport, FEZDate, ServiceLevel, GUID, CollectiveOrderId
, RecDateCreated, RecDateStart, AttributeClassId, TermsPaymentId, RecActive, RecDateSync, SCSFlag, RecDateModified, SrcRecVersion, RecUserCreated, RecCountModified
, EINVOICE_DISPATCH, LEITWEGID, SrcRecId, SCSAUFTRAG, BEXTRANSFER, RecUserModified, SrcRecLocationId, EINVOICE_INTERFACE, MUSTERZAHLUNGSPLAN, SrcRecTimestamp
, USTIDNOPRUEF FROM nkeTempIncremental.ds_SalesOrder_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesOrder_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);


--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesOrder_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_SalesOrder_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_SalesOrder_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;


--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_SalesOrder_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesOrder_NKE');
*/