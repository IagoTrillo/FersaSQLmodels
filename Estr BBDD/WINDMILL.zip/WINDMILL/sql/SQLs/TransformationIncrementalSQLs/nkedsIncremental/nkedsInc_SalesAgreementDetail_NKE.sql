--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_SalesAgreementDetail_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_SalesAgreementDetail_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_SalesAgreementDetail_NKE (SalesAgreementDetailId, RecId, Id, CustomerItemNumber, Status, NameInternal, AgreementQuantity, CompanyId, ItemId
, "Date", "Timestamp", Quantity, Name, PriceListFlag, ValidTo, "Language", InvoicedQuantity, Net, CalledOffQuantity
, MaxCallOffQuantity, DeliveredQuantity, CurrencyCode, MinCallOffQuantity, SalesUoMId, ValidFrom, StdTxt, PriceUoMId, PackagingQuantity
, ValueDelivered, Insdate, TaxCode, DeliveryCompanyAccountId, CompanyAccountId, Upduser, StaffId, Insuser, InvoicedValue, Upddate, Reference
, ValueContractFlag, InvoiceCompanyAccountId, CustomsGoodsFlag, FactoryDirectCustomer, PackagingInstructions, LastCallOffDate, OrderQuantity
, DeliveryCallOffFlag, ActiveVariants, ProfitCenterId, DeliveryUnloadingPoint, EDIPartner, IsFirstDeliveryFlag, OrderValue, PackagingRule
, ItemCustomerRelationId, FzNullDateOld, ClientId, OrderStatisticsFlag, IsChangeFlag, VDAPriceUnit, AutomotiveNaelAiBMW, EDLFlag
, NKE_MarginPerUnit, RevisionIndexId, CumulativeQuantity, FzNullDateNew, Finalized, Ai, DrawingNumber, NKE_MarginPercent
, PrintedFlag, FzReceiptCorrection, SalesAgreementId, FinalSalesInvoiceLineId, EDIPartnerNumber, SalesQuotationId, NKE_Margin
, TimeLimitFlag, NKE_CostsContributionMargin, LineId, LocationId, SalesQuotationLineId, RecActive
, MaintenanceAgreementId, RecDateStart, RecDateSync, ProjectId, GUID, RecDateModified, ANP_ProjectId, RecDateEnd, RecDateCreated
, SrcRecTimestamp, SrcRecVersion, RecDateReport, TermsPaymentId, NKE_CostsK01, ANP_AgreementDetailType, RecUserCreated
, SrcRecLocationId, RecUserModified, VERPACKSTUELI, RecSyncId, RecCountModified, SrcRecId)
SELECT SalesAgreementDetailId, RecId, Id, CustomerItemNumber, Status, NameInternal, AgreementQuantity, CompanyId, ItemId
, "Date", "Timestamp", Quantity, Name, PriceListFlag, ValidTo, "Language", InvoicedQuantity, Net, CalledOffQuantity
, MaxCallOffQuantity, DeliveredQuantity, CurrencyCode, MinCallOffQuantity, SalesUoMId, ValidFrom, StdTxt, PriceUoMId, PackagingQuantity
, ValueDelivered, Insdate, TaxCode, DeliveryCompanyAccountId, CompanyAccountId, Upduser, StaffId, Insuser, InvoicedValue, Upddate, Reference
, ValueContractFlag, InvoiceCompanyAccountId, CustomsGoodsFlag, FactoryDirectCustomer, PackagingInstructions, LastCallOffDate, OrderQuantity
, DeliveryCallOffFlag, ActiveVariants, ProfitCenterId, DeliveryUnloadingPoint, EDIPartner, IsFirstDeliveryFlag, OrderValue, PackagingRule
, ItemCustomerRelationId, FzNullDateOld, ClientId, OrderStatisticsFlag, IsChangeFlag, VDAPriceUnit, AutomotiveNaelAiBMW, EDLFlag
, NKE_MarginPerUnit, RevisionIndexId, CumulativeQuantity, FzNullDateNew, Finalized, Ai, DrawingNumber, NKE_MarginPercent
, PrintedFlag, FzReceiptCorrection, SalesAgreementId, FinalSalesInvoiceLineId::int, EDIPartnerNumber, SalesQuotationId, NKE_Margin
, TimeLimitFlag, NKE_CostsContributionMargin, LineId, LocationId, SalesQuotationLineId, RecActive
, MaintenanceAgreementId, RecDateStart, RecDateSync, ProjectId, GUID, RecDateModified, ANP_ProjectId, RecDateEnd, RecDateCreated
, SrcRecTimestamp, SrcRecVersion, RecDateReport, TermsPaymentId, NKE_CostsK01, ANP_AgreementDetailType, RecUserCreated
, SrcRecLocationId, RecUserModified, VERPACKSTUELI, RecSyncId, RecCountModified, SrcRecId
FROM	nkeTempIncremental.ds_SalesAgreementDetail_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_SalesAgreementDetail_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_SalesAgreementDetail_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_SalesAgreementDetail_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_SalesAgreementDetail_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesAgreementDetail_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE  FROM nkeds.ds_SalesAgreementDetail_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_SalesAgreementDetail_NKE(SalesAgreementDetailId, RecId, Id, CustomerItemNumber, Status, NameInternal, AgreementQuantity, CompanyId, ItemId
, "Date", "Timestamp", Quantity, Name, PriceListFlag, ValidTo, "Language", InvoicedQuantity, Net, CalledOffQuantity
, MaxCallOffQuantity, DeliveredQuantity, CurrencyCode, MinCallOffQuantity, SalesUoMId, ValidFrom, StdTxt, PriceUoMId, PackagingQuantity
, ValueDelivered, Insdate, TaxCode, DeliveryCompanyAccountId, CompanyAccountId, Upduser, StaffId, Insuser, InvoicedValue, Upddate, Reference
, ValueContractFlag, InvoiceCompanyAccountId, CustomsGoodsFlag, FactoryDirectCustomer, PackagingInstructions, LastCallOffDate, OrderQuantity
, DeliveryCallOffFlag, ActiveVariants, ProfitCenterId, DeliveryUnloadingPoint, EDIPartner, IsFirstDeliveryFlag, OrderValue, PackagingRule
, ItemCustomerRelationId, FzNullDateOld, ClientId, OrderStatisticsFlag, IsChangeFlag, VDAPriceUnit, AutomotiveNaelAiBMW, EDLFlag
, NKE_MarginPerUnit, RevisionIndexId, CumulativeQuantity, FzNullDateNew, Finalized, Ai, DrawingNumber, NKE_MarginPercent
, PrintedFlag, FzReceiptCorrection, SalesAgreementId, FinalSalesInvoiceLineId, EDIPartnerNumber, SalesQuotationId, NKE_Margin
, TimeLimitFlag, NKE_CostsContributionMargin, LineId, LocationId, SalesQuotationLineId, RecActive
, MaintenanceAgreementId, RecDateStart, RecDateSync, ProjectId, GUID, RecDateModified, ANP_ProjectId, RecDateEnd, RecDateCreated
, SrcRecTimestamp, SrcRecVersion, RecDateReport, TermsPaymentId, NKE_CostsK01, ANP_AgreementDetailType, RecUserCreated
, SrcRecLocationId, RecUserModified, VERPACKSTUELI, RecSyncId, RecCountModified, SrcRecId)
SELECT SalesAgreementDetailId, RecId, Id, CustomerItemNumber, Status, NameInternal, AgreementQuantity, CompanyId, ItemId
, "Date", "Timestamp", Quantity, Name, PriceListFlag, ValidTo, "Language", InvoicedQuantity, Net, CalledOffQuantity
, MaxCallOffQuantity, DeliveredQuantity, CurrencyCode, MinCallOffQuantity, SalesUoMId, ValidFrom, StdTxt, PriceUoMId, PackagingQuantity
, ValueDelivered, Insdate, TaxCode, DeliveryCompanyAccountId, CompanyAccountId, Upduser, StaffId, Insuser, InvoicedValue, Upddate, Reference
, ValueContractFlag, InvoiceCompanyAccountId, CustomsGoodsFlag, FactoryDirectCustomer, PackagingInstructions, LastCallOffDate, OrderQuantity
, DeliveryCallOffFlag, ActiveVariants, ProfitCenterId, DeliveryUnloadingPoint, EDIPartner, IsFirstDeliveryFlag, OrderValue, PackagingRule
, ItemCustomerRelationId, FzNullDateOld, ClientId, OrderStatisticsFlag, IsChangeFlag, VDAPriceUnit, AutomotiveNaelAiBMW, EDLFlag
, NKE_MarginPerUnit, RevisionIndexId, CumulativeQuantity, FzNullDateNew, Finalized, Ai, DrawingNumber, NKE_MarginPercent
, PrintedFlag, FzReceiptCorrection, SalesAgreementId, FinalSalesInvoiceLineId::int, EDIPartnerNumber, SalesQuotationId, NKE_Margin
, TimeLimitFlag, NKE_CostsContributionMargin, LineId, LocationId, SalesQuotationLineId, RecActive
, MaintenanceAgreementId, RecDateStart, RecDateSync, ProjectId, GUID, RecDateModified, ANP_ProjectId, RecDateEnd, RecDateCreated
, SrcRecTimestamp, SrcRecVersion, RecDateReport, TermsPaymentId, NKE_CostsK01, ANP_AgreementDetailType, RecUserCreated
, SrcRecLocationId, RecUserModified, VERPACKSTUELI, RecSyncId, RecCountModified, SrcRecId
FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesAgreementDetail_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesAgreementDetail_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_SalesAgreementDetail_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_SalesAgreementDetail_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_SalesAgreementDetail_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesAgreementDetail_NKE');
*/