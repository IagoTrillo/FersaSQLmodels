--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_SalesOrderLine_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_SalesOrderLine_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_SalesOrderLine_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesOrderLine_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesOrderLine_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_SalesOrderLine_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_SalesOrderLine_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesOrderLine_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_SalesOrderLine_NKE (SalesOrderId, RecId, Id, DueDate, ItemId, Net, Rebate, LineId, "Timestamp", Name, Quantity, RebateGroupId, RebatePrice, Price
, SalesUoMId, RemainingQuantity, OriginTaxPrice, AccountingAccountId, RebatePrice2, RevenueAccount, SalesDimensions, SalesInvoiceId, Tax, RevenuePerUnit
, Revenue, Rebate2, ItemGroupId, WTaxCode, DisposedFlag, CostCenterId, "Language", ActiveVariants, FulfillerDocLineId, QuantityRebatePrice, InvoicedQuantity
, NoStockFlag, NoRebateFlag, NoDispoFlag, FulfillerDocId, QuantityRebate, BatchId, NameInternal, CostUnitId, SalesAgreementDetailLineId, ItemCustomerRelationId
, CommissionFlag, LinePrintFlag, PackagingQuantity, DataSource, ProjectId, CustomerItemNumber, SalesAgreementDetailId, BomFlag, PriceUoMId, BasePrice, Percent
, PurchaePrice, GrossPriceList, PriceGroupId, TargetAccountId, DispoWarehouseFlag, ProductionFlag, Percent2, Margin, BonusFlag, DesiredScheduleDate, DispoOrderFlag
, PurchaseFlag, PurchaseOrderProposalCreatedFlag, PSConfirmedFlag, ChangedFlag, SalesQuotationId, PDate, NoOrderBomFlag, MarginPercent, SubTotalFlag
, MaterialSurchargeMode, LastStatus, SalesQuotationLineId, Status, MarginPerUnit, TextLineFlag, ToCheckFlag, ProvisionFlag, NoStatisticsFlag, SalesPriceListId
, Weight, Insdate, Upddate, LinesEnd, Insuser, RemainingPercentage, NoAccountingFlag, RevenueManuallyFlag, Upduser, LinesStart, NoStatusCheckFlag, DontPrintPriceFlag
, UserLine, ResolveFlag, NoPosFlag, SectionSumFlag, WFNoPurchaseOrderProposalFlag, RevenueOrign, SetNumber, LineOrderPath, V_FulfillerType, DontPrintFlag
, PriceChangedFlag, NetOrigin, OriginQuantity, CanceledFlag, CostGroupId, ChangeReference, InventoryPrice, SalesBomId, NoPaymentDepositFlag, DirectDeliveryFlag
, InstallationId, ProposalQuantity, OriginRemainingQuantity, DeliveryScheduleDate, SalesLineId, SupplierCompanyAccountId, YourOrderLine, ChangeStatus, NKE_CheckedFlag
, Surcharge, NKE_CustomerTargetBasis, NKE_DontPrintDueDateFlag, NKE_AcDoneOffer, NKE_EOrder, OrderValue, NKE_CustomerItem_Res, NKE_TransportModeId
, NKE_CustomerTargetRebate, NKE_AcDoneFlag, NKE_InfoOrderLine, NKE_EOrderLine, NKE_CustomerItemName_Res, CostsContributionMargin, NKE_Process, OptionFromLine
, WithdrawalWarehouseBinId, OriginFulfillerDocLineId, GaebLineType, NKE_DueDate, Commission, ClientId, WithdrawalWarehouseId, OriginFulfillerDocId, ProvisionMode
, GaebLineType2, BasisValue, LocationId, BasisValue2, ConditionRanking, Commission2ManuallyFlag, ANP_PurchaseOrderLineId, PurchaseOrderLineId, Commission2
, NoPostingFlag, CommissionManuallyFlag, ConditionRanking2, ANP_PurchaseOrderId, PurchaseOrderId, GUID, SettlementCode, CauseCode, NetRequest, ConditionCode
, ErrorCode, InventoryPhysicalFlag, ServiceRequestId, ExternalConditionCode, ErrorClass, ApprovedType, ConditionFlag, ManuallySalesOrderLine, RepairCode
, SymptomCode, Cause, CustomsTariffId, ServiceFlag, RepresentativeId, OriginSalesOrderLineId, ANP_ExternalID, ISendItFixedFreightFlag, OriginBasePrice
, Elimination, OriginSalesOrderId, RepresentativeI2Id, Error, NKE_CostsK01, PriceCode, PriceCompanyId, Commission3ManuallyFlag, Representative3Id, "Date"
, BasisValue3, InstallationLineId, MaintenanceGroup, ConditionRanking3, AttributeClassId, Commission3, ANP_CustomerPurchaseOrderLine, Percent3, FEZDate
, BaseItemId, RecDateReport, RecDateCreated, ANP_PPAP, SrcRecId, RecDateEnd, RecUserCreated, RecCountModified, RecDateSync, RecDateModified, RecDateStart
, RecActive, RecUserModified, SrcRecLocationId, VERPACKSTUELI, SrcRecTimestamp, WARTUNGPOS, SrcRecVersion, LAGERATTRIB, MaintenanceAgreementId, BEXTRANSFER
, PROJEKT_NOCALC)
SELECT SalesOrderId, RecId, Id, DueDate, ItemId, Net, Rebate, LineId, "Timestamp", Name, Quantity, RebateGroupId, RebatePrice, Price
, SalesUoMId, RemainingQuantity, OriginTaxPrice, AccountingAccountId, RebatePrice2, RevenueAccount, SalesDimensions, SalesInvoiceId, Tax, RevenuePerUnit
, Revenue, Rebate2, ItemGroupId, WTaxCode, DisposedFlag, CostCenterId, "Language", ActiveVariants, FulfillerDocLineId, QuantityRebatePrice, InvoicedQuantity
, NoStockFlag, NoRebateFlag, NoDispoFlag, FulfillerDocId, QuantityRebate, BatchId, NameInternal, CostUnitId, SalesAgreementDetailLineId, ItemCustomerRelationId
, CommissionFlag, LinePrintFlag, PackagingQuantity, DataSource, ProjectId, CustomerItemNumber, SalesAgreementDetailId, BomFlag, PriceUoMId, BasePrice, Percent
, PurchaePrice, GrossPriceList, PriceGroupId, TargetAccountId, DispoWarehouseFlag, ProductionFlag, Percent2, Margin, BonusFlag, DesiredScheduleDate, DispoOrderFlag
, PurchaseFlag, PurchaseOrderProposalCreatedFlag, PSConfirmedFlag, ChangedFlag, SalesQuotationId, PDate, NoOrderBomFlag, MarginPercent, SubTotalFlag
, MaterialSurchargeMode, LastStatus, SalesQuotationLineId, Status, MarginPerUnit, TextLineFlag, ToCheckFlag, ProvisionFlag, NoStatisticsFlag, SalesPriceListId
, Weight, Insdate, Upddate, LinesEnd, Insuser, RemainingPercentage, NoAccountingFlag, RevenueManuallyFlag, Upduser, LinesStart, NoStatusCheckFlag, DontPrintPriceFlag
, UserLine, ResolveFlag, NoPosFlag, SectionSumFlag, WFNoPurchaseOrderProposalFlag, RevenueOrign, SetNumber, LineOrderPath, V_FulfillerType, DontPrintFlag
, PriceChangedFlag, NetOrigin, OriginQuantity, CanceledFlag, CostGroupId, ChangeReference, InventoryPrice, SalesBomId, NoPaymentDepositFlag, DirectDeliveryFlag
, InstallationId, ProposalQuantity, OriginRemainingQuantity, DeliveryScheduleDate, SalesLineId, SupplierCompanyAccountId, YourOrderLine, ChangeStatus, NKE_CheckedFlag
, Surcharge, NKE_CustomerTargetBasis, NKE_DontPrintDueDateFlag, NKE_AcDoneOffer, NKE_EOrder, OrderValue, NKE_CustomerItem_Res, NKE_TransportModeId
, NKE_CustomerTargetRebate, NKE_AcDoneFlag, NKE_InfoOrderLine, NKE_EOrderLine, NKE_CustomerItemName_Res, CostsContributionMargin, NKE_Process, OptionFromLine
, WithdrawalWarehouseBinId, OriginFulfillerDocLineId, GaebLineType, NKE_DueDate, Commission, ClientId, WithdrawalWarehouseId, OriginFulfillerDocId, ProvisionMode
, GaebLineType2, BasisValue, LocationId, BasisValue2, ConditionRanking, Commission2ManuallyFlag, ANP_PurchaseOrderLineId, PurchaseOrderLineId, Commission2
, NoPostingFlag, CommissionManuallyFlag, ConditionRanking2, ANP_PurchaseOrderId, PurchaseOrderId, GUID, SettlementCode, CauseCode, NetRequest, ConditionCode
, ErrorCode, InventoryPhysicalFlag, ServiceRequestId, ExternalConditionCode, ErrorClass, ApprovedType, ConditionFlag, ManuallySalesOrderLine, RepairCode
, SymptomCode, Cause, CustomsTariffId, ServiceFlag, RepresentativeId, OriginSalesOrderLineId, ANP_ExternalID, ISendItFixedFreightFlag, OriginBasePrice
, Elimination, OriginSalesOrderId, RepresentativeI2Id, Error, NKE_CostsK01, PriceCode, PriceCompanyId, Commission3ManuallyFlag, Representative3Id, "Date"
, BasisValue3, InstallationLineId, MaintenanceGroup, ConditionRanking3, AttributeClassId, Commission3, ANP_CustomerPurchaseOrderLine, Percent3, FEZDate
, BaseItemId, RecDateReport, RecDateCreated, ANP_PPAP, SrcRecId, RecDateEnd, RecUserCreated, RecCountModified, RecDateSync, RecDateModified, RecDateStart
, RecActive, RecUserModified, SrcRecLocationId, VERPACKSTUELI, SrcRecTimestamp, WARTUNGPOS, SrcRecVersion, LAGERATTRIB, MaintenanceAgreementId, BEXTRANSFER
, PROJEKT_NOCALC
FROM	nkeTempIncremental.ds_SalesOrderLine_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_SalesOrderLine_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_SalesOrderLine_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_SalesOrderLine_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesOrderLine_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_SalesOrderLine_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_SalesOrderLine_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_SalesOrderLine_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_SalesOrderLine_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesOrderLine_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_SalesOrderLine_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_SalesOrderLine_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_SalesOrderLine_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_SalesOrderLine_NKE(SalesOrderId, RecId, Id, DueDate, ItemId, Net, Rebate, LineId, "Timestamp", Name, Quantity, RebateGroupId, RebatePrice, Price
, SalesUoMId, RemainingQuantity, OriginTaxPrice, AccountingAccountId, RebatePrice2, RevenueAccount, SalesDimensions, SalesInvoiceId, Tax, RevenuePerUnit
, Revenue, Rebate2, ItemGroupId, WTaxCode, DisposedFlag, CostCenterId, "Language", ActiveVariants, FulfillerDocLineId, QuantityRebatePrice, InvoicedQuantity
, NoStockFlag, NoRebateFlag, NoDispoFlag, FulfillerDocId, QuantityRebate, BatchId, NameInternal, CostUnitId, SalesAgreementDetailLineId, ItemCustomerRelationId
, CommissionFlag, LinePrintFlag, PackagingQuantity, DataSource, ProjectId, CustomerItemNumber, SalesAgreementDetailId, BomFlag, PriceUoMId, BasePrice, Percent
, PurchaePrice, GrossPriceList, PriceGroupId, TargetAccountId, DispoWarehouseFlag, ProductionFlag, Percent2, Margin, BonusFlag, DesiredScheduleDate, DispoOrderFlag
, PurchaseFlag, PurchaseOrderProposalCreatedFlag, PSConfirmedFlag, ChangedFlag, SalesQuotationId, PDate, NoOrderBomFlag, MarginPercent, SubTotalFlag
, MaterialSurchargeMode, LastStatus, SalesQuotationLineId, Status, MarginPerUnit, TextLineFlag, ToCheckFlag, ProvisionFlag, NoStatisticsFlag, SalesPriceListId
, Weight, Insdate, Upddate, LinesEnd, Insuser, RemainingPercentage, NoAccountingFlag, RevenueManuallyFlag, Upduser, LinesStart, NoStatusCheckFlag, DontPrintPriceFlag
, UserLine, ResolveFlag, NoPosFlag, SectionSumFlag, WFNoPurchaseOrderProposalFlag, RevenueOrign, SetNumber, LineOrderPath, V_FulfillerType, DontPrintFlag
, PriceChangedFlag, NetOrigin, OriginQuantity, CanceledFlag, CostGroupId, ChangeReference, InventoryPrice, SalesBomId, NoPaymentDepositFlag, DirectDeliveryFlag
, InstallationId, ProposalQuantity, OriginRemainingQuantity, DeliveryScheduleDate, SalesLineId, SupplierCompanyAccountId, YourOrderLine, ChangeStatus, NKE_CheckedFlag
, Surcharge, NKE_CustomerTargetBasis, NKE_DontPrintDueDateFlag, NKE_AcDoneOffer, NKE_EOrder, OrderValue, NKE_CustomerItem_Res, NKE_TransportModeId
, NKE_CustomerTargetRebate, NKE_AcDoneFlag, NKE_InfoOrderLine, NKE_EOrderLine, NKE_CustomerItemName_Res, CostsContributionMargin, NKE_Process, OptionFromLine
, WithdrawalWarehouseBinId, OriginFulfillerDocLineId, GaebLineType, NKE_DueDate, Commission, ClientId, WithdrawalWarehouseId, OriginFulfillerDocId, ProvisionMode
, GaebLineType2, BasisValue, LocationId, BasisValue2, ConditionRanking, Commission2ManuallyFlag, ANP_PurchaseOrderLineId, PurchaseOrderLineId, Commission2
, NoPostingFlag, CommissionManuallyFlag, ConditionRanking2, ANP_PurchaseOrderId, PurchaseOrderId, GUID, SettlementCode, CauseCode, NetRequest, ConditionCode
, ErrorCode, InventoryPhysicalFlag, ServiceRequestId, ExternalConditionCode, ErrorClass, ApprovedType, ConditionFlag, ManuallySalesOrderLine, RepairCode
, SymptomCode, Cause, CustomsTariffId, ServiceFlag, RepresentativeId, OriginSalesOrderLineId, ANP_ExternalID, ISendItFixedFreightFlag, OriginBasePrice
, Elimination, OriginSalesOrderId, RepresentativeI2Id, Error, NKE_CostsK01, PriceCode, PriceCompanyId, Commission3ManuallyFlag, Representative3Id, "Date"
, BasisValue3, InstallationLineId, MaintenanceGroup, ConditionRanking3, AttributeClassId, Commission3, ANP_CustomerPurchaseOrderLine, Percent3, FEZDate
, BaseItemId, RecDateReport, RecDateCreated, ANP_PPAP, SrcRecId, RecDateEnd, RecUserCreated, RecCountModified, RecDateSync, RecDateModified, RecDateStart
, RecActive, RecUserModified, SrcRecLocationId, VERPACKSTUELI, SrcRecTimestamp, WARTUNGPOS, SrcRecVersion, LAGERATTRIB, MaintenanceAgreementId, BEXTRANSFER
, PROJEKT_NOCALC)
SELECT SalesOrderId, RecId, Id, DueDate, ItemId, Net, Rebate, LineId, "Timestamp", Name, Quantity, RebateGroupId, RebatePrice, Price
, SalesUoMId, RemainingQuantity, OriginTaxPrice, AccountingAccountId, RebatePrice2, RevenueAccount, SalesDimensions, SalesInvoiceId, Tax, RevenuePerUnit
, Revenue, Rebate2, ItemGroupId, WTaxCode, DisposedFlag, CostCenterId, "Language", ActiveVariants, FulfillerDocLineId, QuantityRebatePrice, InvoicedQuantity
, NoStockFlag, NoRebateFlag, NoDispoFlag, FulfillerDocId, QuantityRebate, BatchId, NameInternal, CostUnitId, SalesAgreementDetailLineId, ItemCustomerRelationId
, CommissionFlag, LinePrintFlag, PackagingQuantity, DataSource, ProjectId, CustomerItemNumber, SalesAgreementDetailId, BomFlag, PriceUoMId, BasePrice, Percent
, PurchaePrice, GrossPriceList, PriceGroupId, TargetAccountId, DispoWarehouseFlag, ProductionFlag, Percent2, Margin, BonusFlag, DesiredScheduleDate, DispoOrderFlag
, PurchaseFlag, PurchaseOrderProposalCreatedFlag, PSConfirmedFlag, ChangedFlag, SalesQuotationId, PDate, NoOrderBomFlag, MarginPercent, SubTotalFlag
, MaterialSurchargeMode, LastStatus, SalesQuotationLineId, Status, MarginPerUnit, TextLineFlag, ToCheckFlag, ProvisionFlag, NoStatisticsFlag, SalesPriceListId
, Weight, Insdate, Upddate, LinesEnd, Insuser, RemainingPercentage, NoAccountingFlag, RevenueManuallyFlag, Upduser, LinesStart, NoStatusCheckFlag, DontPrintPriceFlag
, UserLine, ResolveFlag, NoPosFlag, SectionSumFlag, WFNoPurchaseOrderProposalFlag, RevenueOrign, SetNumber, LineOrderPath, V_FulfillerType, DontPrintFlag
, PriceChangedFlag, NetOrigin, OriginQuantity, CanceledFlag, CostGroupId, ChangeReference, InventoryPrice, SalesBomId, NoPaymentDepositFlag, DirectDeliveryFlag
, InstallationId, ProposalQuantity, OriginRemainingQuantity, DeliveryScheduleDate, SalesLineId, SupplierCompanyAccountId, YourOrderLine, ChangeStatus, NKE_CheckedFlag
, Surcharge, NKE_CustomerTargetBasis, NKE_DontPrintDueDateFlag, NKE_AcDoneOffer, NKE_EOrder, OrderValue, NKE_CustomerItem_Res, NKE_TransportModeId
, NKE_CustomerTargetRebate, NKE_AcDoneFlag, NKE_InfoOrderLine, NKE_EOrderLine, NKE_CustomerItemName_Res, CostsContributionMargin, NKE_Process, OptionFromLine
, WithdrawalWarehouseBinId, OriginFulfillerDocLineId, GaebLineType, NKE_DueDate, Commission, ClientId, WithdrawalWarehouseId, OriginFulfillerDocId, ProvisionMode
, GaebLineType2, BasisValue, LocationId, BasisValue2, ConditionRanking, Commission2ManuallyFlag, ANP_PurchaseOrderLineId, PurchaseOrderLineId, Commission2
, NoPostingFlag, CommissionManuallyFlag, ConditionRanking2, ANP_PurchaseOrderId, PurchaseOrderId, GUID, SettlementCode, CauseCode, NetRequest, ConditionCode
, ErrorCode, InventoryPhysicalFlag, ServiceRequestId, ExternalConditionCode, ErrorClass, ApprovedType, ConditionFlag, ManuallySalesOrderLine, RepairCode
, SymptomCode, Cause, CustomsTariffId, ServiceFlag, RepresentativeId, OriginSalesOrderLineId, ANP_ExternalID, ISendItFixedFreightFlag, OriginBasePrice
, Elimination, OriginSalesOrderId, RepresentativeI2Id, Error, NKE_CostsK01, PriceCode, PriceCompanyId, Commission3ManuallyFlag, Representative3Id, "Date"
, BasisValue3, InstallationLineId, MaintenanceGroup, ConditionRanking3, AttributeClassId, Commission3, ANP_CustomerPurchaseOrderLine, Percent3, FEZDate
, BaseItemId, RecDateReport, RecDateCreated, ANP_PPAP, SrcRecId, RecDateEnd, RecUserCreated, RecCountModified, RecDateSync, RecDateModified, RecDateStart
, RecActive, RecUserModified, SrcRecLocationId, VERPACKSTUELI, SrcRecTimestamp, WARTUNGPOS, SrcRecVersion, LAGERATTRIB, MaintenanceAgreementId, BEXTRANSFER
, PROJEKT_NOCALC
FROM nkeTempIncremental.ds_SalesOrderLine_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesOrderLine_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);


--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesOrderLine_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_SalesOrderLine_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_SalesOrderLine_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_SalesOrderLine_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_SalesOrderLine_NKE');
*/