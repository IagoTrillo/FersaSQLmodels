--1. Full sync is available: Delete smaller RecSyncId lines from temp table, as not relevant anymore [C.Kraus]
DELETE FROM nkeTempIncremental.ds_PurchaseOrder_NKE
WHERE RecSyncId < (SELECT RecSyncId FROM nkeTempIncremental.ds_PurchaseOrder_NKE WHERE Is_Full IS TRUE ORDER BY RecSyncId DESC LIMIT 1);

--2.1 Remove lines not exist anymore in last full sync - if available - as no extra delete command exist [C.Kraus]
DELETE FROM nkeds.ds_PurchaseOrder_NKE
WHERE	RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_PurchaseOrder_NKE WHERE Is_Full IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_PurchaseOrder_NKE WHERE Is_Full IS TRUE) > 0;

--2.2. Remove deleted and modified lines [C.Kraus]
DELETE FROM nkeds.ds_PurchaseOrder_NKE
WHERE	RecId IN (SELECT RecId FROM nkeTempIncremental.ds_PurchaseOrder_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE)
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_PurchaseOrder_NKE WHERE Is_Full IS FALSE AND Is_Deleted IS TRUE) > 0;

		
--3. Insert lines having no deletion line with equal RecId [C.Kraus]
INSERT INTO nkeds.ds_PurchaseOrder_NKE (RecId, Id, CompanyAccountId, QuotationDate, PurchaseOrderId, InvoiceCompanyAccountId, OrderData, "Timestamp",
 DeliveryCompanyAccountId, StdTxt, Status, StaffId, SalesQuotationId, TaxCode, RebatePrice, CurrencyCode, DunningCount, TermsPurchaseDeliveryStdTxt, 
 Gross, DMGross, OriginTaxPrice, ToDeliverDueDate, DMFactor, DunningNextDate, DunningDate, "Date", TermsPaymentId, "Language", NetCosts, ProjectId,
  Upduser, Insuser, CorrectionFlag, ExchangeRateOrigin2, ExchangeRateOrigin1, CompanyId, DMNetCosts, TaxText, DMDivisor, Insdate, Upddate,
   ExchangeRateFactor, NKE_ShippingCompanyAccountId, PrintedFlag, OriginLocationId, SalesOrderId, MyOpenFactoryOut, WFProcName, MyOpenFactoryIn, 
   OrderDate, DirectDeliveryFlag, DocDeliveryCompanyAccountName1, ClientId, WorkflowId, FulfillerLocationId, DocDeliveryPostCode2, 
   DocDeliveryDepartment, DocDeliveryCompanyAccountName2, DocDeliveryVATNumber, DocDeliveryStreet, DocDeliveryPhone, DocDeliveryCountryCode,
    DocDeliveryCity, DocDeliveryName, DocDeliveryCompanyAccountName3, ANP_UrgentFlag, DocDeliveryPostCode, DocDeliveryFax, 
    DocDeliveryCompanyAccountManuallyFlag, RecActive, GUID, ANP_LastUrgeDate, RecUserModified, RecDateStart, RecDateSync, RecDateModified, 
    AttributeClassId, ShippingTypeStdTxt, RecCountModified, RecDateReport, RecDateEnd, RecDateCreated, RecUserCreated, SrcRecTimestamp,
     SrcRecLocationId, ANP_CompanyQualityCategoryId, SrcRecVersion, MUSTERZAHLUNGSPLAN, SrcRecId)
SELECT RecId, Id, CompanyAccountId, QuotationDate, PurchaseOrderId, InvoiceCompanyAccountId, OrderData, "Timestamp",
 DeliveryCompanyAccountId, StdTxt, Status, StaffId, SalesQuotationId, TaxCode, RebatePrice, CurrencyCode, DunningCount, TermsPurchaseDeliveryStdTxt, 
 Gross, DMGross, OriginTaxPrice, ToDeliverDueDate, DMFactor, DunningNextDate, DunningDate, "Date", TermsPaymentId, "Language", NetCosts, ProjectId,
  Upduser, Insuser, CorrectionFlag, ExchangeRateOrigin2, ExchangeRateOrigin1, CompanyId, DMNetCosts, TaxText, DMDivisor, Insdate, Upddate,
   ExchangeRateFactor, NKE_ShippingCompanyAccountId, PrintedFlag, OriginLocationId, SalesOrderId, MyOpenFactoryOut, WFProcName, MyOpenFactoryIn, 
   OrderDate, DirectDeliveryFlag, DocDeliveryCompanyAccountName1, ClientId, WorkflowId, FulfillerLocationId, DocDeliveryPostCode2, 
   DocDeliveryDepartment, DocDeliveryCompanyAccountName2, DocDeliveryVATNumber, DocDeliveryStreet, DocDeliveryPhone, DocDeliveryCountryCode,
    DocDeliveryCity, DocDeliveryName, DocDeliveryCompanyAccountName3, ANP_UrgentFlag, DocDeliveryPostCode, DocDeliveryFax, 
    DocDeliveryCompanyAccountManuallyFlag, RecActive, GUID, ANP_LastUrgeDate, RecUserModified, RecDateStart, RecDateSync, RecDateModified, 
    AttributeClassId, ShippingTypeStdTxt, RecCountModified, RecDateReport, RecDateEnd, RecDateCreated, RecUserCreated, SrcRecTimestamp,
     SrcRecLocationId, ANP_CompanyQualityCategoryId, SrcRecVersion, MUSTERZAHLUNGSPLAN, SrcRecId
FROM	nkeTempIncremental.ds_PurchaseOrder_NKE
WHERE	Is_Deleted IS FALSE
		AND RecId NOT IN (SELECT RecId FROM nkeTempIncremental.ds_PurchaseOrder_NKE WHERE Is_Deleted IS TRUE)
		AND RecId NOT IN (SELECT RecId FROM nkeds.ds_PurchaseOrder_NKE);

		
--4.1 Delete last stored modified date, but only if sync data was available [C.Kraus]
DELETE FROM fersaconfig.LastModifiedTable_NKE
WHERE	TABLENAME = 'ds_PurchaseOrder_NKE'
		AND (SELECT COUNT(*) FROM nkeTempIncremental.ds_PurchaseOrder_NKE) > 0;

--4.2 Save last modified date, but only if sync data was available [C.Kraus]
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT	'ds_PurchaseOrder_NKE' AS TABLENAME, RecSyncId AS LASTRECSYNCID
FROM	nkeTempIncremental.ds_PurchaseOrder_NKE
WHERE	(SELECT COUNT(*) FROM nkeTempIncremental.ds_PurchaseOrder_NKE) > 0
ORDER BY RecSyncId DESC
LIMIT 1;

--5. Clean temp table [M.Plasencia]
-- ATTENTION: RecSyncId < LASTRECSYNCID; You keep the last one (maybe unfinished) SyncId, but in step 3. we must ensure that same line is not inserted once again => AND RecId NOT IN (SELECT RecId FROM nkeds.ds_WarehouseOccupancy_NKE)
DELETE FROM nkeTempIncremental.ds_PurchaseOrder_NKE
WHERE RecSyncId < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_PurchaseOrder_NKE');


/* 2025-07-31: Old code from Miguel Plasencia*/
/*
--1. Remove deleted and modified rows.
DELETE FROM nkeds.ds_PurchaseOrder_NKE WHERE RECID IS NULL OR RECID in (SELECT ISNULL(RECID,'0') RECID FROM nkeTempIncremental.ds_PurchaseOrder_NKE WHERE ID IS NULL)
OR ID IN (SELECT ID FROM nkeTempIncremental.ds_PurchaseOrder_NKE WHERE ID IS NOT NULL);

--2. Insert only modified rows.              
INSERT INTO nkeds.ds_PurchaseOrder_NKE(RecId, Id, CompanyAccountId, QuotationDate, PurchaseOrderId, InvoiceCompanyAccountId, OrderData, "Timestamp",
 DeliveryCompanyAccountId, StdTxt, Status, StaffId, SalesQuotationId, TaxCode, RebatePrice, CurrencyCode, DunningCount, TermsPurchaseDeliveryStdTxt, 
 Gross, DMGross, OriginTaxPrice, ToDeliverDueDate, DMFactor, DunningNextDate, DunningDate, "Date", TermsPaymentId, "Language", NetCosts, ProjectId,
  Upduser, Insuser, CorrectionFlag, ExchangeRateOrigin2, ExchangeRateOrigin1, CompanyId, DMNetCosts, TaxText, DMDivisor, Insdate, Upddate,
   ExchangeRateFactor, NKE_ShippingCompanyAccountId, PrintedFlag, OriginLocationId, SalesOrderId, MyOpenFactoryOut, WFProcName, MyOpenFactoryIn, 
   OrderDate, DirectDeliveryFlag, DocDeliveryCompanyAccountName1, ClientId, WorkflowId, FulfillerLocationId, DocDeliveryPostCode2, 
   DocDeliveryDepartment, DocDeliveryCompanyAccountName2, DocDeliveryVATNumber, DocDeliveryStreet, DocDeliveryPhone, DocDeliveryCountryCode,
    DocDeliveryCity, DocDeliveryName, DocDeliveryCompanyAccountName3, ANP_UrgentFlag, DocDeliveryPostCode, DocDeliveryFax, 
    DocDeliveryCompanyAccountManuallyFlag, RecActive, GUID, ANP_LastUrgeDate, RecUserModified, RecDateStart, RecDateSync, RecDateModified, 
    AttributeClassId, ShippingTypeStdTxt, RecCountModified, RecDateReport, RecDateEnd, RecDateCreated, RecUserCreated, SrcRecTimestamp,
     SrcRecLocationId, ANP_CompanyQualityCategoryId, SrcRecVersion, MUSTERZAHLUNGSPLAN, SrcRecId)
SELECT RecId, Id, CompanyAccountId, QuotationDate, PurchaseOrderId, InvoiceCompanyAccountId, OrderData, "Timestamp",
 DeliveryCompanyAccountId, StdTxt, Status, StaffId, SalesQuotationId, TaxCode, RebatePrice, CurrencyCode, DunningCount, TermsPurchaseDeliveryStdTxt, 
 Gross, DMGross, OriginTaxPrice, ToDeliverDueDate, DMFactor, DunningNextDate, DunningDate, "Date", TermsPaymentId, "Language", NetCosts, ProjectId,
  Upduser, Insuser, CorrectionFlag, ExchangeRateOrigin2, ExchangeRateOrigin1, CompanyId, DMNetCosts, TaxText, DMDivisor, Insdate, Upddate,
   ExchangeRateFactor, NKE_ShippingCompanyAccountId, PrintedFlag, OriginLocationId, SalesOrderId, MyOpenFactoryOut, WFProcName, MyOpenFactoryIn, 
   OrderDate, DirectDeliveryFlag, DocDeliveryCompanyAccountName1, ClientId, WorkflowId, FulfillerLocationId, DocDeliveryPostCode2, 
   DocDeliveryDepartment, DocDeliveryCompanyAccountName2, DocDeliveryVATNumber, DocDeliveryStreet, DocDeliveryPhone, DocDeliveryCountryCode,
    DocDeliveryCity, DocDeliveryName, DocDeliveryCompanyAccountName3, ANP_UrgentFlag, DocDeliveryPostCode, DocDeliveryFax, 
    DocDeliveryCompanyAccountManuallyFlag, RecActive, GUID, ANP_LastUrgeDate, RecUserModified, RecDateStart, RecDateSync, RecDateModified, 
    AttributeClassId, ShippingTypeStdTxt, RecCountModified, RecDateReport, RecDateEnd, RecDateCreated, RecUserCreated, SrcRecTimestamp,
     SrcRecLocationId, ANP_CompanyQualityCategoryId, SrcRecVersion, MUSTERZAHLUNGSPLAN, SrcRecId
FROM nkeTempIncremental.ds_PurchaseOrder_NKE WHERE IS_DELETED IS FALSE AND RECID IS NOT NULL
AND recsyncid >= (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_PurchaseOrder_NKE')
LIMIT 1 OVER (PARTITION by ID ORDER BY recsyncid  DESC);


--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_PurchaseOrder_NKE';
INSERT INTO fersaconfig.LastModifiedTable_NKE (TABLENAME, LASTRECSYNCID)
SELECT 'ds_PurchaseOrder_NKE' AS TABLENAME ,recsyncid AS LASTRECSYNCID 
    FROM nkeTempIncremental.ds_PurchaseOrder_NKE 
    WHERE RECID IS NOT NULL and recsyncid is not null
	ORDER BY recsyncid  DESC LIMIT 1;

--4. Clean temp table.
DELETE FROM  nkeTempIncremental.ds_PurchaseOrder_NKE WHERE recsyncid < (SELECT LASTRECSYNCID FROM fersaconfig.LastModifiedTable_NKE WHERE TABLENAME = 'ds_PurchaseOrder_NKE');
*/
