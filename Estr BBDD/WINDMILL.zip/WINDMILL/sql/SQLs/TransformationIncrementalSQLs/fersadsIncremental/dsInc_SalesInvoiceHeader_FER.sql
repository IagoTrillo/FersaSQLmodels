--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_SalesInvoiceHeader_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_SalesInvoiceHeader_FER);
     
--2. Insert only modified rows.                    
INSERT INTO fersads.ds_SalesInvoiceHeader_FER(CURRENCYCODE, INVOICEACCOUNT,INVOICEID,ORDERACCOUNT,PAYMENT,LEDGERVOUCHER,DLVTERM,DLVMODE,DUEDATE,FERRECEPTIONDATE,RECID,DATAAREAID,SALESTYPE,ID,MODIFIEDDATETIME)
SELECT CURRENCYCODE,
    INVOICEACCOUNT,
    INVOICEID,
    ORDERACCOUNT,
    PAYMENT,
    LEDGERVOUCHER,
    DLVTERM,
    DLVMODE,
    DUEDATE,
    FERRECEPTIONDATE,
    RECID,
    DATAAREAID,
    SALESTYPE,
    ID,
    MODIFIEDDATETIME
FROM fersaTempIncremental.ds_SalesInvoiceHeader_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_SalesInvoiceHeader_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_SalesInvoiceHeader_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_SalesInvoiceHeader_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_SalesInvoiceHeader_FER;