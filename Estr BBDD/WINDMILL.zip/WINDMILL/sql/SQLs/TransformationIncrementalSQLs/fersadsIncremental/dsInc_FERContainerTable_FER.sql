--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_FERContainerTable_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_FERContainerTable_FER);

--2. Insert only modified rows.       
INSERT INTO fersads.ds_FERContainerTable_FER (ID,FIRSTETD,ETD ,FIRSTETA ,ETA,VESSEL,FERCONTAINER ,SCAC ,RECID ,MODIFIEDDATETIME ,DATAAREAID ,MODIFIEDTRANSACTIONID ,CREATEDTRANSACTIONID)             
 SELECT ID
    ,FIRSTETD
    ,ETD 
    ,FIRSTETA 
    ,ETA
    ,VESSEL
    ,FERCONTAINER 
    ,SCAC 
    ,RECID 
    ,MODIFIEDDATETIME 
    ,DATAAREAID 
    ,MODIFIEDTRANSACTIONID 
    ,CREATEDTRANSACTIONID
FROM  fersaTempIncremental.ds_FERContainerTable_FER
WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_FERContainerTable_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_FERContainerTable_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_FERContainerTable_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_FERContainerTable_FER;