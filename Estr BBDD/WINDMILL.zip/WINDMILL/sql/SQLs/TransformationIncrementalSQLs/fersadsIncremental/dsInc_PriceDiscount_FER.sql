
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_PriceDiscount_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_PriceDiscount_FER);
   
--2. Insert only modified rows.                        
INSERT INTO fersads.ds_PriceDiscount_FER(ACCOUNTCODE, ACCOUNTRELATION, AMOUNT, CURRENCY, DATAAREAID, FROMDATE, ID, ITEMCODE, ITEMRELATION, MODIFIEDDATETIME, PERCENT1, PERCENT2, PRICEUNIT, QUANTITYAMOUNTFROM, QUANTITYAMOUNTTO, RELATION, TODATE, UNITID)
SELECT ACCOUNTCODE,
    ACCOUNTRELATION,
    AMOUNT,
    CURRENCY,
   	DATAAREAID,
    FROMDATE,
    ID,
    ITEMCODE,
   	ITEMRELATION,
    MODIFIEDDATETIME,
    PERCENT1,
    PERCENT2,
    PRICEUNIT,
    QUANTITYAMOUNTFROM,
    QUANTITYAMOUNTTO,
    RELATION,
    TODATE,
    UNITID
FROM fersaTempIncremental.ds_PriceDiscount_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_PriceDiscount_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_PriceDiscount_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_PriceDiscount_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_PriceDiscount_FER;