
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_SalesLine_BR_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_SalesLine_BR_FER);

--2. Insert only modified rows.                      
INSERT INTO fersads.ds_SalesLine_BR_FER(ID,
    CFOPTABLE_BR,
    DELIVERYCFOPTABLE_BR,
    FISCALDOCUMENTTYPE_BR,
    SALESLINE,
    SUFRAMADISCOUNT_BR,
    TAXSERVICECODE_BR,
    MODIFIEDTRANSACTIONID,
    CREATEDTRANSACTIONID,
    DATAAREAID,
    RECVERSION,
    RECID)
SELECT  ID,
    CFOPTABLE_BR,
    DELIVERYCFOPTABLE_BR,
    FISCALDOCUMENTTYPE_BR,
    SALESLINE,
    SUFRAMADISCOUNT_BR,
    TAXSERVICECODE_BR,
    MODIFIEDTRANSACTIONID,
    CREATEDTRANSACTIONID,
    DATAAREAID,
    RECVERSION,
    RECID
FROM fersaTempIncremental.ds_SalesLine_BR_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_SalesLine_BR_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_SalesLine_BR_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_SalesLine_BR_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_SalesLine_BR_FER;