--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_SupplierTable_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_SupplierTable_FER);
       
--2. Insert only modified rows.                  
INSERT INTO fersads.ds_SupplierTable_FER(ACCOUNTNUM,BANKACCOUNT,BLOCKED,CURRENCY,DATAAREAID,DBA,DLVMODE,DLVTERM,FACTORINGACCOUNT,FERLEADTIME,ID,INVENTLOCATION,INVENTSITEID,INVOICEACCOUNT,ITEMBUYERGROUPID,MODIFIEDDATETIME,PARTY,PAYMMODE,PAYMSCHED,PAYMTERMID,PRICEGROUP,RECID,VENDGROUP)
SELECT      ACCOUNTNUM,
            BANKACCOUNT,
            BLOCKED,
            CURRENCY,
            DATAAREAID,
            DBA,
            DLVMODE,
            DLVTERM,
            FACTORINGACCOUNT,
            FERLEADTIME,
            ID,
            INVENTLOCATION,
            INVENTSITEID,
            INVOICEACCOUNT,
            ITEMBUYERGROUPID,
            MODIFIEDDATETIME,
            PARTY,
            PAYMMODE,
            PAYMSCHED,
            PAYMTERMID,
            PRICEGROUP,
            RECID,
            VENDGROUP
FROM fersaTempIncremental.ds_SupplierTable_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_SupplierTable_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_SupplierTable_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_SupplierTable_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_SupplierTable_FER;