--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_TaxTrans_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_TaxTrans_FER);
                    
--2. Insert only modified rows.    
INSERT INTO fersads.ds_TaxTrans_FER(ID, DATAAREAID,	VOUCHER, TRANSDATE,	INVENTTRANSID, TAXBASEAMOUNT, TAXAMOUNT, TAXCODE)
SELECT      ID,
		    DATAAREAID,	
		    VOUCHER,	
		    TRANSDATE,	
		    INVENTTRANSID,	
		    TAXBASEAMOUNT,
		    TAXAMOUNT,    
		    TAXCODE   
FROM fersaTempIncremental.ds_TaxTrans_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_TaxTrans_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_TaxTrans_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_TaxTrans_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_TaxTrans_FER;