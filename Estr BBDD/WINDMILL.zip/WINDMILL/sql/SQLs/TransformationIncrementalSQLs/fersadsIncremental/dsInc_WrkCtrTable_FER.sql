--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_WrkCtrTable_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_WrkCtrTable_FER);
                    
--2. Insert only modified rows.    
INSERT INTO fersads.ds_WrkCtrTable_FER(DATAAREAID, WRKCTRID, FERLINEID, WRKCTRTYPE, NAME, ID)
SELECT      DATAAREAID,
	        WRKCTRID,
	        FERLINEID,
	        WRKCTRTYPE,
			NAME,
            ID
FROM fersaTempIncremental.ds_WrkCtrTable_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_WrkCtrTable_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_WrkCtrTable_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_WrkCtrTable_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_WrkCtrTable_FER;