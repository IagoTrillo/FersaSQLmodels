
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_InventItemSalesSetup_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_InventItemSalesSetup_FER);
  
--2. Insert only modified rows.                          
INSERT INTO fersads.ds_InventItemSalesSetup_FER( DATAAREAID,
    ID,
    ITEMID,
    MODIFIEDDATETIME,
    STOPPED,
    MULTIPLEQTY,
    FERBLOCKINGTYPE)
SELECT DATAAREAID,
    ID,
    ITEMID,
    MODIFIEDDATETIME,
    STOPPED,
    MULTIPLEQTY,
    FERBLOCKINGTYPE
FROM fersaTempIncremental.ds_InventItemSalesSetup_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_InventItemSalesSetup_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_InventItemSalesSetup_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_InventItemSalesSetup_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_InventItemSalesSetup_FER;