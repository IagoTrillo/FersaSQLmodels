
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_CommissionSalesGroup_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_CommissionSalesGroup_FER);

--2. Insert only modified rows.              
INSERT INTO fersads.ds_CommissionSalesGroup_FER(DATAAREAID,GROUPID,ID,NAME,RECID)
SELECT  DATAAREAID,
        GROUPID,
        ID,
        NAME,
        RECID
FROM fersaTempIncremental.ds_CommissionSalesGroup_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_CommissionSalesGroup_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_CommissionSalesGroup_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_CommissionSalesGroup_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_CommissionSalesGroup_FER;