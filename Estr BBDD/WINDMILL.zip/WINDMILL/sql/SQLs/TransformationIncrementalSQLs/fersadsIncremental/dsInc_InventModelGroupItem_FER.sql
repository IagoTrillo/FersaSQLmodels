
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_InventModelGroupItem_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_InventModelGroupItem_FER);
  
--2. Insert only modified rows.                       
INSERT INTO fersads.ds_InventModelGroupItem_FER(ID,
    ITEMDATAAREAID,
    ITEMID,
    MODELGROUPDATAAREAID,
    MODELGROUPID)
SELECT ID,
    ITEMDATAAREAID,
    ITEMID,
    MODELGROUPDATAAREAID,
    MODELGROUPID
FROM fersaTempIncremental.ds_InventModelGroupItem_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL
AND ITEMID NOT IN (SELECT DISTINCT ITEMID FROM fersaconfig.ItemsToDelete); --- We have included this restriction because there are ghost items that appear in Synapse but do not appear in D365

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_InventModelGroupItem_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_InventModelGroupItem_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_InventModelGroupItem_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_InventModelGroupItem_FER;