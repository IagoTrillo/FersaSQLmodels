
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_EcoResProductTranslation_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_EcoResProductTranslation_FER);

--2. Insert only modified rows.                         
INSERT INTO fersads.ds_EcoResProductTranslation_FER(DESCRIPTION,
    ID,
    LANGUAGEID,
    NAME,
    PRODUCT)

SELECT DESCRIPTION,
    ID,
    LANGUAGEID,
    NAME,
    PRODUCT
FROM fersaTempIncremental.ds_EcoResProductTranslation_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_EcoResProductTranslation_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_EcoResProductTranslation_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_EcoResProductTranslation_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_EcoResProductTranslation_FER;