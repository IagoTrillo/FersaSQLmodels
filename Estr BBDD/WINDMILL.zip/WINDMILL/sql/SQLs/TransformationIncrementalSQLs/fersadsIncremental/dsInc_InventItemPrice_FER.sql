
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_InventItemPrice_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_InventItemPrice_FER);

--2. Insert only modified rows.                      
INSERT INTO fersads.ds_InventItemPrice_FER(INVENTDIMID, DATAAREAID, PRICE, PRICEUNIT, ID, MODIFIEDDATETIME, ITEMID, RECID, UNITID, ACTIVATIONDATE, CREATEDDATETIME)
SELECT INVENTDIMID,
    DATAAREAID,
    PRICE,
    PRICEUNIT,
    ID,
    MODIFIEDDATETIME,
    ITEMID,
    RECID,
    UNITID,
    ACTIVATIONDATE,
    CREATEDDATETIME
FROM fersaTempIncremental.ds_InventItemPrice_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_InventItemPrice_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_InventItemPrice_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_InventItemPrice_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_InventItemPrice_FER;