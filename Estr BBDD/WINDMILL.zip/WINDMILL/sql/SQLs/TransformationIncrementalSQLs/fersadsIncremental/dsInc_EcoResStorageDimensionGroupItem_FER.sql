
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_EcoResStorageDimensionGroupItem_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_EcoResStorageDimensionGroupItem_FER);

 --2. Insert only modified rows.                          
INSERT INTO fersads.ds_EcoResStorageDimensionGroupItem_FER(ID,
    ITEMDATAAREAID,
    ITEMID,
    STORAGEDIMENSIONGROUP)

SELECT ID,
    ITEMDATAAREAID,
    ITEMID,
    STORAGEDIMENSIONGROUP
FROM fersaTempIncremental.ds_EcoResStorageDimensionGroupItem_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;


--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_EcoResStorageDimensionGroupItem_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_EcoResStorageDimensionGroupItem_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_EcoResStorageDimensionGroupItem_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_EcoResStorageDimensionGroupItem_FER;