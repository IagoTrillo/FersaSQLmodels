
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_DimensionAttributeValueCombination_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_DimensionAttributeValueCombination_FER);

--2. Insert only modified rows.                      
INSERT INTO fersads.ds_DimensionAttributeValueCombination_FER(RECID,DISPLAYVALUE,ID,MAINACCOUNT, MODIFIEDDATETIME)
SELECT  RECID,
        DISPLAYVALUE,
        ID, 
        MAINACCOUNT, 
        MODIFIEDDATETIME
FROM fersaTempIncremental.ds_DimensionAttributeValueCombination_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_DimensionAttributeValueCombination_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_DimensionAttributeValueCombination_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_DimensionAttributeValueCombination_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_DimensionAttributeValueCombination_FER;