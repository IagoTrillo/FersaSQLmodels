
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_CustomerTransaction_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_CustomerTransaction_FER);

--2. Insert only modified rows.                        
INSERT INTO fersads.ds_CustomerTransaction_FER(DATAAREAID,CUSTEXCHADJUSTMENTREALIZED,EXCHADJUSTMENT,ACCOUNTNUM,AMOUNTCUR,AMOUNTMST,SETTLEAMOUNTCUR,SETTLEAMOUNTMST,TRANSDATE,TRANSTYPE,DUEDATE,ORDERACCOUNT,CURRENCYCODE,CLOSED,INVOICE,EXCHRATE,RECID,PAYMMODE,TXT,ID,MODIFIEDDATETIME,
            CREATEDDATETIME)
SELECT              DATAAREAID,
            CUSTEXCHADJUSTMENTREALIZED,
            EXCHADJUSTMENT,
            ACCOUNTNUM,
            AMOUNTCUR,
            AMOUNTMST,
            SETTLEAMOUNTCUR,
            SETTLEAMOUNTMST,
            TRANSDATE,
            TRANSTYPE,
            DUEDATE,
            ORDERACCOUNT,
            CURRENCYCODE,
            CLOSED,
            INVOICE,
            EXCHRATE,
            RECID,
            PAYMMODE,
            TXT,
            ID,
            MODIFIEDDATETIME,
            CREATEDDATETIME
FROM fersaTempIncremental.ds_CustomerTransaction_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_CustomerTransaction_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_CustomerTransaction_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_CustomerTransaction_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_CustomerTransaction_FER;