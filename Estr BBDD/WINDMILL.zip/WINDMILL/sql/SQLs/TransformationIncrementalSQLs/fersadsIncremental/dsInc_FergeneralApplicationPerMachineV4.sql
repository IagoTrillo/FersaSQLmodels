--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_FERGeneralApplicationPerMachinev4 WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_FERGeneralApplicationPerMachinev4);

--2. Insert only modified rows.              
INSERT INTO fersads.ds_FERGeneralApplicationPerMachinev4(ID,FERGENERALAPPLICATIONMASTER, FERMACHINEMODEL, DATAAREAID, RECID )
SELECT ID,FERGENERALAPPLICATIONMASTER, FERMACHINEMODEL, DATAAREAID, RECID 
FROM fersaTempIncremental.ds_FERGeneralApplicationPerMachinev4 WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_FERGeneralApplicationPerMachinev4';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_FERGeneralApplicationPerMachinev4',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_FERGeneralApplicationPerMachinev4 WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_FERGeneralApplicationPerMachinev4;
