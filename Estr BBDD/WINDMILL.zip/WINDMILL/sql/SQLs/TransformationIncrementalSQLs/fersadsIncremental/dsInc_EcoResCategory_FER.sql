--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_EcoResCategory_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_EcoResCategory_FER);
                      
--2. Insert only modified rows.     
INSERT INTO fersads.ds_EcoResCategory_FER(
    NAME,
    CODE,
    ID,
    PARENTCATEGORY,
    RECID, 
    MODIFIEDDATETIME)
SELECT 
    NAME,
    CODE,
    ID,
    PARENTCATEGORY,
    RECID, 
    MODIFIEDDATETIME
FROM fersaTempIncremental.ds_EcoResCategory_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_EcoResCategory_FER';

INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_EcoResCategory_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_EcoResCategory_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;