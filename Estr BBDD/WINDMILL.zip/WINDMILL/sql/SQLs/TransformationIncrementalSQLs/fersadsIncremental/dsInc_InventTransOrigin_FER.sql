--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_InventTransOrigin_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_InventTransOrigin_FER);

--2. Insert only modified rows.    
INSERT INTO fersads.ds_InventTransOrigin_FER(RECID, INVENTTRANSID, ITEMID, ITEMINVENTDIMID, REFERENCECATEGORY, REFERENCEID, DATAAREAID, ISEXCLUDEDFROMINVENTORYVALUE, ID)
SELECT RECID, INVENTTRANSID, ITEMID, ITEMINVENTDIMID, REFERENCECATEGORY, REFERENCEID, DATAAREAID, ISEXCLUDEDFROMINVENTORYVALUE, ID
FROM fersaTempIncremental.ds_InventTransOrigin_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_InventTransOrigin_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_InventTransOrigin_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_InventTransOrigin_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_InventTransOrigin_FER;