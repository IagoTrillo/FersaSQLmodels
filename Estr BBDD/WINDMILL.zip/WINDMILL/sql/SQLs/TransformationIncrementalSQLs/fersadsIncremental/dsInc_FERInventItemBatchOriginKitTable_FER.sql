--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_FERInventItemBatchOriginKitTable_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_FERInventItemBatchOriginKitTable_FER);

--2. Insert only modified rows.              
INSERT INTO fersads.ds_FERInventItemBatchOriginKitTable_FER (ID, ITEMID, INVENTBATCHID, ORIGIN, ITEMID_COMPONENT, INVENTBATCHID_COMPONENT, CREATEDTRANSACTIONID, DATAAREAID, RECID)
SELECT ID, ITEMID, INVENTBATCHID, ORIGIN, ITEMID_COMPONENT, INVENTBATCHID_COMPONENT, CREATEDTRANSACTIONID, DATAAREAID, RECID
FROM fersaTempIncremental.ds_FERInventItemBatchOriginKitTable_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_FERInventItemBatchOriginKitTable_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_FERInventItemBatchOriginKitTable_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_FERInventItemBatchOriginKitTable_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_FERInventItemBatchOriginKitTable_FER;
