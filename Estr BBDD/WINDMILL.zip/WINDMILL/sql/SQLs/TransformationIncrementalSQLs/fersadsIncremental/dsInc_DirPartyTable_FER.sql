
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_DirPartyTable_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_DirPartyTable_FER);

--2. Insert only modified rows.              
INSERT INTO fersads.ds_DirPartyTable_FER(ID,LANGUAGEID,MODIFIEDDATETIME,NAME,NAMEALIAS,PRIMARYADDRESSLOCATION,PRIMARYCONTACTEMAIL,RECID)
SELECT      ID,
            LANGUAGEID,
            MODIFIEDDATETIME,
            NAME,
            NAMEALIAS,
            PRIMARYADDRESSLOCATION,
            PRIMARYCONTACTEMAIL,
            RECID
FROM fersaTempIncremental.ds_DirPartyTable_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_DirPartyTable_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_DirPartyTable_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_DirPartyTable_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_DirPartyTable_FER;