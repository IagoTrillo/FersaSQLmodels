--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_WHSZone_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_WHSZone_FER);
                    
--2. Insert only modified rows.    
INSERT INTO fersads.ds_WHSZone_FER(ID, ZONEID, ZONENAME, DATAAREAID, ZONEGROUPID)
SELECT      ID,
		    ZONEID,
		    ZONENAME,
		    DATAAREAID,
		    ZONEGROUPID 
FROM fersaTempIncremental.ds_WHSZone_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_WHSZone_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_WHSZone_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_WHSZone_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_WHSZone_FER;