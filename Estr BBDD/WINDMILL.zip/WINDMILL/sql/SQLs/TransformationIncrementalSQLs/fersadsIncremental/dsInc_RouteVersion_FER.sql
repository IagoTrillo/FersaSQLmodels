
--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_RouteVersion_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_RouteVersion_FER);
       
--2. Insert only modified rows.                   
INSERT INTO fersads.ds_RouteVersion_FER( ID , ACTIVE , APPROVED , APPROVER , FROMDATE, FROMQTY, INVENTDIMID, ITEMID, NAME, ROUTEID, TODATE, MODIFIEDDATETIME,
    MODIFIEDBY, CREATEDDATETIME, CREATEDBY, DATAAREAID, RECID, VERSIONNUMBER)
SELECT ID ,
    ACTIVE ,
    APPROVED ,
    APPROVER ,
    FROMDATE,
    FROMQTY,
    INVENTDIMID,
    ITEMID,
    NAME,
    ROUTEID,
    TODATE,
    MODIFIEDDATETIME,
    MODIFIEDBY,
    CREATEDDATETIME,
    CREATEDBY,
    DATAAREAID,
    RECID,
    VERSIONNUMBER
FROM fersaTempIncremental.ds_RouteVersion_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_RouteVersion_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_RouteVersion_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_RouteVersion_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_RouteVersion_FER;