--1. Remove deleted and modified rows.
DELETE FROM fersads.ds_CustVendExternalItem_FER WHERE ID IS NULL OR ID in (SELECT ISNULL(ID,'0') ID FROM fersaTempIncremental.ds_CustVendExternalItem_FER);

--2. Insert only modified rows.              
INSERT INTO fersads.ds_CustVendExternalItem_FER ( ID,
    ABCCATEGORY ,
    MODULETYPE,
    CUSTVENDRELATION,
    DESCRIPTION ,
    EXTERNALITEMID ,
    EXTERNALITEMTXT ,
    ITEMID,
    FERCATALOGNUMBER ,
    DATAAREAID ,
    RECID)
SELECT ID,
    ABCCATEGORY ,
    MODULETYPE,
    CUSTVENDRELATION,
    DESCRIPTION ,
    EXTERNALITEMID ,
    EXTERNALITEMTXT ,
    ITEMID,
    FERCATALOGNUMBER ,
    DATAAREAID ,
    RECID
FROM  fersaTempIncremental.ds_CustVendExternalItem_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--3. Save last modified date.
DELETE FROM fersaconfig.LastModifiedTable WHERE TABLENAME = 'ds_CustVendExternalItem_FER';
INSERT INTO fersaconfig.LastModifiedTable (TABLENAME, LASTMODIFIEDDATE)
    SELECT 'ds_CustVendExternalItem_FER',MAX(MODIFIEDDATETIME) FROM fersaTempIncremental.ds_CustVendExternalItem_FER WHERE ISDELETE IS NULL AND ID IS NOT NULL;

--4. Clean temp table.
--TRUNCATE TABLE fersaTempIncremental.ds_CustVendExternalItem_FER;