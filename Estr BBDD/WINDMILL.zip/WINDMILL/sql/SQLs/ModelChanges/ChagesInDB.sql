/*PRO (20/08/2026)*/

INSERT INTO fersaconfig.TaskSchedulerbyEmail (sql_path,email_config,process,body_message,active,retries,LAST_EXECUTION,frequency_days,CCO,email_group_name,FROMDAY,TODAY)
	VALUES ('CRM/Tiers_prices.sql','nerea.alonso@fersa.com','New customers in prices tiers ','',true,3,'2026-07-21',1,'','',1,31);

INSERT INTO fersaconfig.TaskSchedulerbyEmail (sql_path,email_config,process,body_message,active,retries,LAST_EXECUTION,frequency_days,CCO,FROMDAY,TODAY)
	VALUES ('A&S_ProductInformation.sql','raul.fuentemilla@fersa.com, jorge.galvez@fersa.com, Hugo.Lopez@fersa.com, Antonio.Montanes@fersa.com, MariaPilar.Oliveros@fersa.com, cristina.pascual@fersa.com','A&S Product Information','Good Morning! PFA process result.',true,3,'2026-07-29',7,'',1,31);

/* PRE (18/08/2026)*/

/* DEV */

CREATE TABLE nkeds.ds_NKE_SalesOrder_QuotationAnalysis_NKE (
    RecId int,
    RecTimestamp varchar(2000),
    Id int,
    "Timestamp" varchar(2000),
    SalesOrderId varchar(2000),
    LineId int,
    ItemId varchar(2000),
    QuotationDate timestamp(6),
    QuotationShippingDueDate timestamp(6),
    QuotationQuantity numeric(32,6),
    QuotationCurrencyCode varchar(2000),
    QuotationDMFactor varchar(2000),
    QuotationRevenuePerUnit numeric(32,6),
    QuotationRevenue numeric(32,6),
    OrderDateCreated timestamp(6),
    OrderDate timestamp(6),
    OrderShippingDueDate timestamp(6),
    OrderQuantityInitial numeric(32,6),
    OrderQuantity numeric(32,6),
    OrderCurrencyCode varchar(2000),
    OrderDMFactor varchar(2000),
    OrderRevenuePerUnit numeric(32,6),
    OrderRevenue numeric(32,6),
    ClientId varchar(2000),
    RecDateStart timestamp(6),
    RecDateEnd timestamp(6),
    RecActive int,
    RecDateReport timestamp(6),
    RecDateSync timestamp(6),
    RecDateCreated timestamp(6),
    RecDateModified timestamp(6),
    RecUserCreated varchar(2000),
    RecUserModified varchar(2000),
    RecCountModified int,
    SrcRecLocationId varchar(2000),
    SrcRecId varchar(2000),
    SrcRecTimestamp varchar(2000),
    SrcRecVersion varchar(2000)
);

ALTER TABLE fersads.ds_SalesOrderLine_FER ADD COLUMN INTERCOMPANYINVENTTRANSID VARCHAR(400)
ALTER TABLE fersads.ds_PurchaseOrderHeader_FER ADD COLUMN REQATTENTION VARCHAR(400)
ALTER TABLE fersads.ds_PurchaseOrderLine_FER ADD COLUMN REQATTENTION VARCHAR(400)


/* DEV & PRE (20.08.2026)*/
ALTER TABLE nkeds.ds_Item_NKE ADD NKE_MinimumSalesPrice numeric(32,6) NULL;
ALTER TABLE nkeds.ds_Item_NKE ADD ANP_MinSalesOrderQuantity numeric(32,6) NULL;

CREATE TABLE fersads.ds_SalesOrderQuotationAnalysis_SP_NKE
(
    COMPANYID varchar(40),
    SUBSIDIARYID varchar(80),
    SALESID varchar(80),
    LINENUM numeric(32,6),
    ITEMID varchar(160),
    NAME varchar(160),
    MODELGROUPID varchar(40),
    SAFETYSTOCK numeric(32,6),
    QUOTATIONDATE timestamp(6),
    QUOTATIONSHIPPINGDUEDATE timestamp(6),
    QUOTATIONQUANTITY numeric(32,6),
    QUOTATIONCURRENCYCODE varchar(20),
    QUOTATIONCURRENCYEXCHANGERATE numeric(32,6),
    QUOTATIONUNITPRICE numeric(32,6),
    QUOTATIONAMOUNT numeric(32,6),
    QUOTATIONUNITPRICEEUR numeric(32,6),
    QUOTATIONAMOUNTEUR numeric(32,6),
    ORDERDATE timestamp(6),
    ORDERSHIPPINGDUEDATE timestamp(6),
    ORDERQUANTITYINITIAL numeric(32,6),
    ORDERQUANTITYFINAL numeric(32,6),
    ORDERCURRENCYCODE varchar(20),
    ORDERQUOTATIONCURRENCYEXCHANGERATE numeric(32,6),
    ORDERUNITPRICE numeric(32,6),
    ORDERAMOUNT numeric(32,6),
    ORDERUNITPRICEEUR numeric(32,6),
    ORDERAMOUNTEUR numeric(32,6)
);