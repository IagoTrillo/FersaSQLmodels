-- *** INVOICES ***
/* QUERIES TO UPDATE HISTORICAL DATA. STEP BY STEP:
First in Development Environment:
    1) Update SalesInvoice_ARCH_YEARLY and SalesInvoice_BI
    2) Update PurchaseInvoices_ARCH_YEARLY and PurchaseInvoices_BI

Then in Preproduction Environment:
    3) Update SalesInvoice_ARCH_YEARLY and SalesInvoice_BI
    4) Update PurchaseInvoices_ARCH_YEARLY and PurchaseInvoices_BI

Finally in Production Environment:
    3) Update SalesInvoice_ARCH_YEARLY and SalesInvoice_BI
    4) Update PurchaseInvoices_ARCH_YEARLY and PurchaseInvoices_BI

Important considarations:
    *) SalesInvoice_BI and PurchaseInvoices_BI: Composed by "FIXED" data for years < current_year + "LIVE" data for the current year
    *) SalesInvoice_ARCH_YEARLY: It has to be updated ONCE whenever Finance Team closes the year by inserting the data WHERE YEAR(INVOICEDATE)= YEAR(CURRENT_DATE())
    *) PurchaseInvoices_ARCH_YEARLY: It has to be updated ONCE whenever Finance Team closes the year by inserting the data WHERE YEAR(INVOICEDATE)= YEAR(CURRENT_DATE())
    *) SalesInvoice_FACT_LOG and PurchaseInvoices_FACT_LOG: These are the tables where the differences in Invoices are reported at line level.
*/
UPDATE fersadw.SalesInvoice_ARCH_YEARLY SET CUSTOMERTYPE = 'INTERNAL' WHERE CUSTOMERID IN ('');
UPDATE fersadw.SalesInvoice_BI SET CUSTOMERTYPE = 'INTERNAL' WHERE CUSTOMERID IN ('');

UPDATE fersadw.PurchaseInvoices_ARCH_YEARLY SET SUPPLIERTYPE = 'INTERNAL' WHERE SUPPLIERID IN ('');
UPDATE fersadw.PurchaseInvoices_BI SET SUPPLIERTYPE = 'INTERNAL' WHERE SUPPLIERID IN ('');



