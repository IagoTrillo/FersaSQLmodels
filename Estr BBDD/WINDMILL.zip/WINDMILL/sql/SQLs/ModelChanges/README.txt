In Bitbucket
------------
1- Pull request vertica_ingestion project.
2- Pull request SQL
3- Pull request windmill_code

In DataBase
---------------
1 - CleanTables.sql
    Situation after running
        fersads: Just show *_NKE and ds_Customer_HIST tables. Without data
        nkeds: Nothing (No data, No tables)
        fersadv: Only structure, without data. EXCEPT ExchangeRate_API
        fersadw: Only structure, without data.
2 - Apply changes
    FROM DEV -> PRE
        a)  Bitucket: Mege/Pull Request (Done in the fist step, Bibucket)
        b)  Vertica: Apply ChangesInDB.sql in the PRE environment
        c)  Git: In Development branch move the changes from ChangesInDB.sql -> HistoricalChangesInDB.sql. Commit & Push
    FROM PRE -> PRO
        a)  Bitucket: Mege/Pull Request (Done in the fist step, Bibucket)
        b)  Vertica: Apply ChangesInDB.sql in the PRO environment
        c)  Git: In Release branch move the changes from ChangesInDB.sql -> HistoricalChangesInDB.sql. Commit & Push
        d)  Git: In Master branch move the changes from ChangesInDB.sql -> HistoricalChangesInDB.sql. Commit & Push

3 - Execute Master Flow in windmill
4 - Scripts with userAccess (I think it's possible to automatize in the master flow process)


Master Flow
---------------
Prices_ALL depends NKE tables, first NKE